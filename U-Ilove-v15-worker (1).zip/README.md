# U&I — structure du code

Site de messagerie hébergé sur GitHub Pages. Tout est du JavaScript « classique » (sans compilation) : on envoie les fichiers tels quels dans le dépôt, en gardant les dossiers.

## Arborescence

```
index.html                    Le squelette : tout le HTML de l'appli (écrans, fenêtres), sans CSS ni JS en dur
firebase-messaging-sw.js      Service worker des notifications push (à la racine, obligatoire)
worker/                       Code du Worker Cloudflare « ui-recovery » (e-mails de récupération) — ne tourne pas sur le site, voir worker/LISEZ-MOI.md
push.js                       Ancien fichier push de ton dépôt (inchangé, non fourni ici)
manifest.webmanifest          Ton manifeste existant (inchangé)

css/                          Les styles, dans l'ordre de la cascade (le numéro = l'ordre, ne pas changer)
  01-base … 04-design-v6      Base puis les couches de design v3 à v6
  05 … 19                     Actualités, animations, jeux, Veilleuse, Étudier, assistant, réglages, Action ou vérité…

js/
  config.js                   Configuration : Firebase, push (VAPID + Worker), récupération par e-mail, numéro de version
  boot/                       Démarrage : thème, écran de chargement, chargeur, filet de sécurité
  app/                        L'appli elle-même, en 28 parties (voir ci-dessous)
  ui/                         Petits modules d'interface (onglets, animations, réglages, clavier…)
  games/                      Beat Rush, Cookie Match, sons des jeux
  modules/                    Gros modules : Étudier, assistant X.Uni
```

## Ordre de chargement

1. `index.html` charge dans l'ordre : `vibrate-guard`, `config`, `theme-init`, `splash`, `loader`, `blank-guard`, `push.js`, puis `etudier`, `assistant`, `clavier`, `reglages-sections`, `reglages-recherche`, `actualites-replie`.
2. `js/boot/loader.js` charge Firebase (4 miroirs), puis assemble et lance les 28 parties de `js/app/`, puis les modules `ui/` et `games/`.

## Pourquoi `js/app/` est en 28 parties

L'appli est une seule « fermeture » JavaScript : toutes ses variables (`state`, `fs`, `auth`, `PUSH`…) sont partagées. Les parties sont donc des morceaux de ce même bloc, lus dans l'ordre par `loader.js`. Ne les exécute pas seules.

| Partie | Contenu |
|---|---|
| 01-base | constantes, utilitaires, envoi de fichiers (Cloudinary) |
| 02-connexion-presence | connexion, inscription, présence |
| 03-liste-discussions | liste des discussions |
| 04-amis | amis, demandes, invitations |
| 05-outils-createur | statut masqué, annonce, suspension |
| 06-epingles-anniversaires-code | épingles, amis proches, anniversaires, code |
| 07-groupes | groupes et infos du groupe |
| 08-discussion | une discussion |
| 09-notifications | alertes, préférences, panneau des réglages |
| 10-actions-messages | supprimer, répondre |
| 11-apparence-profil | thèmes, photo de profil, surnom, nom |
| 12-reactions-photos | réactions, modifier un message, photos |
| 13-fichiers-vocaux | fichiers, musiques partagées, vocaux |
| 14-nettoyage | libérer de l'espace, supprimer une discussion |
| 15-jeu-mots | mots mélangés |
| 16-alerte-notes-badges | alerte dans le site, notes, badge |
| 17-comptes-createur | liste des comptes |
| 18-compte | likes de profil, mot de passe, suppression |
| 19-musique | musique et musiques partagées |
| 20-ecoute-ensemble | écoute en direct (WebRTC) |
| 21-appel-vocal | appel vocal 1-à-1 |
| 22-action-verite | Action ou vérité |
| 23-actualites-lettres | lettres anonymes |
| 24-actualites-commentaires | commentaires et commentaire vocal |
| 25-discussions-anonymes | discussions entre profils anonymes |
| 26-session-approbation | PWA, session, approbation des comptes |
| 27-push | notifications push (FCM) |
| 28-recuperation-email | e-mail de récupération, mot de passe oublié par code e-mail (Worker `ui-recovery`) |

## À chaque mise à jour

1. Modifie le fichier concerné.
2. Augmente le numéro `version` dans `js/config.js` **et** remplace `?v=15` par le nouveau numéro dans `index.html` (sinon le téléphone garde l'ancienne version en cache).
3. Envoie les fichiers modifiés dans GitHub, dans les mêmes dossiers.

## Ajouter un fichier

- Un style : crée `css/20-….css` et ajoute son `<link>` à la fin de la liste dans `index.html` (l'ordre = la cascade).
- Un module d'interface ou un jeu : crée le fichier dans `js/ui/` ou `js/games/` et ajoute son chemin à la liste `APP_MODULES` de `js/boot/loader.js`.
