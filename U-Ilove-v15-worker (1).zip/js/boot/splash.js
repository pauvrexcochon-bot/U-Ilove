/* U&I — js/boot/splash.js
   Écran de démarrage : le retire dès que l’appli est affichée */
(function () {
  var t0 = Date.now();
  function done() { var s = document.getElementById('splash'); if (!s) return; s.style.opacity = '0'; setTimeout(function () { if (s.parentNode) s.parentNode.removeChild(s); }, 300); }
  var iv = setInterval(function () {
    function vis(id) { var n = document.getElementById(id); return n && !n.hidden; }
    if (vis('login') || vis('app') || vis('apWait') || document.getElementById('blank-msg')) { clearInterval(iv); done(); return; }
    var m = document.getElementById('splashMsg');
    if (m && !document.getElementById('splashRetry') && Date.now() - t0 > 6000) m.textContent = 'Connexion lente… un instant';
  }, 150);
})();
