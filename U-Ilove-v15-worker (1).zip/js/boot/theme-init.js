/* U&I — js/boot/theme-init.js
   Applique tout de suite le thème sauvegardé (évite le flash blanc) */
(function(){try{var m=localStorage.getItem('uandi-mode')||'dark',k=localStorage.getItem('uandi-skin'),f={nuit:'dark',foret:'dark',clair:'light',rose:'light',neant:'dark'}[k];document.documentElement.dataset.eff=f||(m==='auto'?(matchMedia('(prefers-color-scheme: dark)').matches?'dark':'light'):m);if(f)document.documentElement.dataset.skin=k;}catch(e){}})();
