/* U&I — js/boot/blank-guard.js
   Filet de sécurité : message si le site n’a pas démarré après 60 s */
(function () {
  setTimeout(function () {
    function vis(id) { var n = document.getElementById(id); return n && !n.hidden; }
    if (vis('login') || vis('app') || vis('apWait') || document.getElementById('blank-msg')) return;
    var d = document.createElement('div'); d.id = 'blank-msg';
    d.style.cssText = 'position:fixed;inset:0;z-index:99;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:14px;padding:24px;text-align:center;font:500 16px system-ui,sans-serif;color:#5B1035;background:rgba(255,233,241,.92)';
    d.innerHTML = '<div style="font-size:2.4rem">U&amp;I</div><div>Le site n’a pas pu démarrer.<br>Vérifie ta connexion, puis réessaie.</div>';
    var b = document.createElement('button'); b.type = 'button'; b.textContent = 'Réessayer';
    b.style.cssText = 'padding:12px 26px;border:0;border-radius:999px;background:#E0457B;color:#fff;font:600 16px system-ui,sans-serif';
    b.onclick = function () { location.reload(); };
    d.appendChild(b); document.body.appendChild(d);
  }, 60000);
})();
