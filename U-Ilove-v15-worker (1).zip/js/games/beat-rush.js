/* U&I — js/games/beat-rush.js
   Jeu Beat Rush (rythme) */
(function () {
  /* ---------- Beat Rush : jeu de rythme avec musique générée (WebAudio) ---------- */
  var $ = function (i) { return document.getElementById(i); };
  var dlg = $('brDlg'), cv = $('brCv'), g = cv.getContext('2d');
  var COL = ['#ff5d8f', '#ffd166', '#06d6a0', '#4cc9f0'], FREQ = [440, 523.25, 587.33, 659.25];
  var KEYS = { d: 0, f: 1, j: 2, k: 3, arrowleft: 0, arrowdown: 1, arrowup: 2, arrowright: 3 };
  var LV = [{ n: 'Chill', bpm: 96, p: 0.36, bars: 18 }, { n: 'Pop', bpm: 118, p: 0.5, bars: 22 }, { n: 'Turbo', bpm: 138, p: 0.64, bars: 26 }];
  var CH = [
    { r: 110, t: [220, 261.63, 329.63] }, { r: 87.31, t: [174.61, 220, 261.63] },
    { r: 130.81, t: [261.63, 329.63, 392] }, { r: 98, t: [196, 246.94, 293.66] }
  ];
  var TRAVEL = 1.5, WIN = 0.14, PERF = 0.06;
  var ctx = null, master = null, bassBus = null, noise = null, dpr = 1;
  var fxIn, fxOut, fxLp, fxCl, fxDr, fxWs, fxLp2, fxDi, CU = null, CAP = 240;
  var R = { run: false, lv: 1, t0: 0, ed: 0, notes: [], next: 0, tot: 0, score: 0, combo: 0, max: 0, hp: 100, hit: 0, perf: 0,
            miss: 0, pr: [0, 0, 0, 0], tmr: 0, raf: 0, sched: false, shake: 0, txt: null, lastEnd: 0, cu: 0, src: null, spk: 0 };
  var best = (function () { try { return JSON.parse(localStorage.getItem('uandi-br-best')) || {}; } catch (e) { return {}; } })();

  function ensure() {
    if (!ctx) {
      var A = window.AudioContext || window.webkitAudioContext; if (!A) return false;
      ctx = new A();
      var comp = ctx.createDynamicsCompressor(); master = ctx.createGain(); master.gain.value = 0.9;
      /* chaîne « son détruit » : plus on rate, plus la musique se déforme (filtre + distorsion + coupures) */
      fxIn = ctx.createGain(); fxOut = ctx.createGain(); fxLp = ctx.createBiquadFilter(); fxLp.type = 'lowpass'; fxLp.frequency.value = 20000; fxLp.Q.value = 0.7;
      fxCl = ctx.createGain(); fxDr = ctx.createGain(); fxDr.gain.value = 4; fxWs = ctx.createWaveShaper();
      var cur = new Float32Array(1024), ci; for (ci = 0; ci < 1024; ci++) { var cx = ci / 511.5 - 1; cur[ci] = Math.max(-0.9, Math.min(0.9, Math.round(cx * 5) / 5 * 1.6)); }
      fxWs.curve = cur; fxLp2 = ctx.createBiquadFilter(); fxLp2.type = 'lowpass'; fxLp2.frequency.value = 6000; fxDi = ctx.createGain(); fxDi.gain.value = 0;
      master.connect(fxIn); fxIn.connect(fxLp); fxLp.connect(fxCl); fxCl.connect(fxOut);
      fxIn.connect(fxDr); fxDr.connect(fxWs); fxWs.connect(fxLp2); fxLp2.connect(fxDi); fxDi.connect(fxOut);
      fxOut.connect(comp); comp.connect(ctx.destination);
      bassBus = ctx.createBiquadFilter(); bassBus.type = 'lowpass'; bassBus.frequency.value = 520; bassBus.connect(master);
      noise = ctx.createBuffer(1, ctx.sampleRate, ctx.sampleRate);
      var d = noise.getChannelData(0); for (var i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
    }
    if (ctx.state === 'suspended') ctx.resume();
    return true;
  }
  function osc(t, f, d, type, v, dest, to) {
    var o = ctx.createOscillator(), a = ctx.createGain();
    o.type = type; o.frequency.setValueAtTime(f, t);
    if (to) o.frequency.exponentialRampToValueAtTime(to, t + d);
    a.gain.setValueAtTime(0.0001, t); a.gain.exponentialRampToValueAtTime(v, t + 0.012); a.gain.exponentialRampToValueAtTime(0.0001, t + d);
    o.connect(a); a.connect(dest || master); o.start(t); o.stop(t + d + 0.05);
  }
  function nz(t, d, v, type, f) {
    var s = ctx.createBufferSource(), fl = ctx.createBiquadFilter(), a = ctx.createGain();
    s.buffer = noise; fl.type = type; fl.frequency.value = f;
    a.gain.setValueAtTime(v, t); a.gain.exponentialRampToValueAtTime(0.0001, t + d);
    s.connect(fl); fl.connect(a); a.connect(master); s.start(t, Math.random() * 0.5); s.stop(t + d + 0.02);
  }
  function kick(t) { osc(t, 150, 0.22, 'sine', 0.9, master, 45); }
  function snare(t) { nz(t, 0.16, 0.35, 'bandpass', 1900); osc(t, 200, 0.1, 'triangle', 0.22, master, 120); }
  function hat(t, open) { nz(t, open ? 0.12 : 0.04, 0.1, 'highpass', 7500); }
  function pluck(f) {
    var t = ctx.currentTime;
    osc(t, f, 0.38, 'triangle', 0.24); osc(t, f * 2, 0.22, 'sine', 0.08); osc(t, f * 1.004, 0.28, 'square', 0.035);
  }
  function sparkle() { var t = ctx.currentTime; [659.25, 880, 1046.5, 1318.5].forEach(function (f, i) { osc(t + i * 0.06, f, 0.2, 'triangle', 0.1); }); }

  function eighth(i, t) {
    var bar = (i / 8) | 0, pos = i % 8, ch = CH[bar % 4], ed = R.ed, last = bar >= LV[R.lv].bars - 1;
    if (pos === 0 || pos === 4) kick(t);
    if (R.lv === 2 && pos === 6 && bar % 2) kick(t);
    if (bar >= 1 && (pos === 2 || pos === 6)) snare(t);
    hat(t, pos === 7);
    if (R.lv > 0 && pos % 2 === 1) hat(t + ed / 2, false);
    if (bar >= 1 && (pos === 0 || pos === 3 || pos === 4 || pos === 6)) osc(t, ch.r * (pos === 6 ? 2 : 1), ed * 1.6, 'sawtooth', 0.22, bassBus);
    if (pos === 0) ch.t.forEach(function (f) { osc(t, f, ed * 7.5, 'triangle', 0.035); });
    if (bar >= 2 && !last) osc(t, ch.t[pos % 3] * 2, ed * 0.9, 'triangle', 0.04);
    if (last && pos === 0) nz(t, 1.4, 0.3, 'highpass', 5000);
  }
  function scheduler() {
    if (!R.sched) return;
    while (R.next < R.tot && R.t0 + R.next * R.ed < ctx.currentTime + 0.25) { eighth(R.next, R.t0 + R.next * R.ed); R.next++; }
    if (R.next >= R.tot) { R.sched = false; clearInterval(R.tmr); }
  }
  function gen() {
    var L = LV[R.lv], notes = [], lane = 1, rep = 0;
    for (var i = 16; i < (L.bars - 2) * 8; i++) {
      var pos = i % 8;
      if (Math.random() >= L.p * (pos % 2 === 0 ? 1.25 : 0.8)) continue;
      var nl = Math.random() < 0.5 ? Math.max(0, Math.min(3, lane + (Math.random() < 0.5 ? -1 : 1))) : Math.floor(Math.random() * 4);
      if (nl === lane) { rep++; if (rep > 1) nl = (lane + 1 + Math.floor(Math.random() * 3)) % 4; } if (nl !== lane) rep = 0;
      lane = nl; notes.push({ t: R.t0 + i * R.ed, l: lane, done: 0 });
    }
    R.lastEnd = notes.length ? notes[notes.length - 1].t : R.t0;
    return notes;
  }

  function size() {
    var r = cv.getBoundingClientRect(); dpr = Math.min(2, window.devicePixelRatio || 1);
    cv.width = Math.max(200, Math.round(r.width * dpr)); cv.height = Math.max(220, Math.round(r.height * dpr));
  }
  function lanePos(l) { var r = cv.getBoundingClientRect(); return { x: r.left + (l + 0.5) * r.width / 4, y: r.top + r.height * 0.84 }; }
  function rr(x, y, w, h, r) { g.beginPath(); if (g.roundRect) g.roundRect(x, y, w, h, r); else g.rect(x, y, w, h); }
  function draw(now) {
    var W = cv.width, H = cv.height, lw = W / 4, hitY = H * 0.84, i, n;
    var ph = ((now - R.t0) / (2 * R.ed)) % 1; if (ph < 0 || now < R.t0) ph = 1;
    var pulse = Math.pow(1 - ph, 3);
    g.save();
    if (R.shake > now) g.translate((Math.random() - 0.5) * 8 * dpr, (Math.random() - 0.5) * 8 * dpr);
    g.fillStyle = '#0b0d1a'; g.fillRect(-20, -20, W + 40, H + 40);
    var gr = g.createRadialGradient(W / 2, H * 0.45, 10, W / 2, H * 0.45, W * (0.55 + pulse * 0.12));
    gr.addColorStop(0, 'rgba(130,90,255,' + (0.2 + pulse * 0.16) + ')'); gr.addColorStop(1, 'rgba(130,90,255,0)');
    g.fillStyle = gr; g.fillRect(0, 0, W, H);
    for (i = 0; i < 4; i++) {
      var on = now - R.pr[i] < 0.12;
      g.fillStyle = COL[i]; g.globalAlpha = on ? 0.3 : 0.07; g.fillRect(i * lw, 0, lw, H); g.globalAlpha = 1;
      if (i) { g.strokeStyle = 'rgba(255,255,255,.08)'; g.lineWidth = dpr; g.beginPath(); g.moveTo(i * lw, 0); g.lineTo(i * lw, H); g.stroke(); }
    }
    g.strokeStyle = 'rgba(255,255,255,' + (0.45 + pulse * 0.45) + ')'; g.lineWidth = 3 * dpr;
    g.beginPath(); g.moveTo(0, hitY); g.lineTo(W, hitY); g.stroke();
    for (i = 0; i < 4; i++) {
      var cx = (i + 0.5) * lw, hot = now - R.pr[i] < 0.12;
      g.beginPath(); g.arc(cx, hitY, lw * (0.3 + (hot ? 0.06 : pulse * 0.03)), 0, 7);
      g.lineWidth = 3 * dpr; g.strokeStyle = COL[i]; g.shadowColor = COL[i]; g.shadowBlur = (hot ? 22 : 8) * dpr; g.stroke();
      if (hot) { g.fillStyle = COL[i]; g.globalAlpha = 0.35; g.fill(); g.globalAlpha = 1; }
      g.shadowBlur = 0;
    }
    for (i = 0; i < R.notes.length; i++) {
      n = R.notes[i]; if (n.done) continue;
      var y = hitY - (n.t - now) / TRAVEL * hitY; if (y < -30 || y > H + 30) continue;
      g.fillStyle = COL[n.l]; g.shadowColor = COL[n.l]; g.shadowBlur = 14 * dpr;
      rr(n.l * lw + lw * 0.15, y - 13 * dpr, lw * 0.7, 26 * dpr, 12 * dpr); g.fill();
      g.shadowBlur = 0; g.fillStyle = 'rgba(255,255,255,.55)'; rr(n.l * lw + lw * 0.22, y - 8 * dpr, lw * 0.56, 7 * dpr, 4 * dpr); g.fill();
    }
    var start = R.t0 + 16 * R.ed;
    if (now < start) {
      var left = Math.ceil((start - now) / (2 * R.ed)); g.fillStyle = '#fff'; g.textAlign = 'center';
      g.font = '800 ' + 26 * dpr + 'px system-ui, sans-serif'; g.globalAlpha = 0.9;
      g.fillText(left > 3 ? 'Prépare-toi…' : String(left), W / 2, H * 0.4); g.globalAlpha = 1;
    }
    g.restore();
  }

  function fxAt(l, text, big) {
    if (!window.FX) return; var p = lanePos(l);
    FX.burst(p.x, p.y, big ? 14 : 8); FX.float(text, p.x, p.y - 34);
  }
  function stats() {
    $('brScore').textContent = R.score; $('brCombo').textContent = R.combo; $('brHp').style.width = Math.max(0, R.hp) + '%';
  }
  function press(l) {
    if (!R.run || !ctx) return;
    var now = ctx.currentTime, bn = null, bd = 1, i, n, d;
    R.pr[l] = now;
    for (i = 0; i < R.notes.length; i++) {
      n = R.notes[i]; if (n.done || n.l !== l) continue;
      d = Math.abs(n.t - now); if (d < bd) { bd = d; bn = n; }
    }
    if (!bn || bd > WIN) { osc(now, 220, 0.05, 'triangle', 0.04); return; }
    bn.done = 1; R.hit++; var perfect = bd <= PERF; if (perfect) R.perf++;
    R.combo++; if (R.combo > R.max) R.max = R.combo;
    R.score += Math.round((perfect ? 100 : 50) * (1 + Math.min(R.combo, 40) / 20));
    R.hp = Math.min(100, R.hp + 3);
    if (R.cu) osc(now, FREQ[l] * 2, 0.06, 'triangle', 0.05); else pluck(FREQ[l]);
    fxAt(l, perfect ? 'Parfait !' : 'Bien', false);
    if (R.combo === 10 || R.combo === 25 || R.combo === 50 || (R.combo > 50 && R.combo % 50 === 0)) {
      sparkle(); var p = lanePos(l);
      if (window.FX) { FX.confetti(p.x, p.y - 60); FX.float('Combo x' + R.combo + ' 🔥', p.x, p.y - 100); }
    }
    stats();
  }
  /* coupure/saccade + craquements quand on rate */
  function glitch(now) {
    var g0 = fxOut.gain, d = 0.04 + Math.random() * 0.05;
    g0.cancelScheduledValues(now); g0.setValueAtTime(g0.value, now);
    g0.setValueAtTime(0.04, now + 0.005); g0.setValueAtTime(1, now + d);
    g0.setValueAtTime(0.12, now + d + 0.04); g0.setValueAtTime(1, now + d + 0.09);
    nz(now, 0.2, 0.22, 'highpass', 2500);
  }
  function damage(now) {
    var D = Math.min(1, Math.max(0, (100 - R.hp) / 55) + R.spk);
    fxLp.frequency.setTargetAtTime(Math.max(380, 20000 * Math.pow(1 - D, 3)), now, 0.05);
    fxCl.gain.setTargetAtTime(1 - 0.75 * D, now, 0.05);
    fxDi.gain.setTargetAtTime(0.55 * D, now, 0.05);
    fxLp2.frequency.setTargetAtTime(6000 - 4200 * D, now, 0.05);
  }
  function damageReset() {
    var t = ctx.currentTime;
    fxLp.frequency.cancelScheduledValues(t); fxLp.frequency.setValueAtTime(20000, t);
    fxCl.gain.cancelScheduledValues(t); fxCl.gain.setValueAtTime(1, t);
    fxDi.gain.cancelScheduledValues(t); fxDi.gain.setValueAtTime(0, t);
    fxLp2.frequency.cancelScheduledValues(t); fxLp2.frequency.setValueAtTime(6000, t);
    fxOut.gain.cancelScheduledValues(t); fxOut.gain.setValueAtTime(1, t);
  }
  function miss(n, now) {
    n.done = 1; R.miss++; R.combo = 0; R.hp -= 12; R.shake = now + 0.18;
    osc(now, 130, 0.14, 'sawtooth', 0.06, master, 80);
    R.spk = 0.4; glitch(now);
    try { if (navigator.vibrate && window.SFX && SFX.isOn()) navigator.vibrate(30); } catch (e) {}
    stats();
  }
  function frame() {
    if (!R.run) return;
    var now = ctx.currentTime, i, n, left = 0;
    master.gain.setTargetAtTime((window.SFX && SFX.isOn()) ? 0.9 : 0, now, 0.03);
    for (i = 0; i < R.notes.length; i++) { n = R.notes[i]; if (n.done) continue; if (now - n.t > WIN) miss(n, now); else left++; }
    R.spk = Math.max(0, R.spk - 0.012); damage(now);
    draw(now);
    if (R.hp <= 0) { finish(false); return; }
    if (!left && now > R.lastEnd + 1.2) { finish(true); return; }
    R.raf = requestAnimationFrame(frame);
  }
  function hush() {
    R.sched = false; clearInterval(R.tmr);
    if (R.src) { try { R.src.stop(); } catch (e) {} try { R.src.disconnect(); } catch (e) {} R.src = null; }
    if (master && ctx) { master.gain.cancelScheduledValues(ctx.currentTime); master.gain.setTargetAtTime(0, ctx.currentTime, 0.06); }
  }
  /* la musique ralentit et s'éteint comme une cassette quand on perd */
  function tapeStop() {
    var s0 = R.src, t = ctx.currentTime; R.sched = false; clearInterval(R.tmr);
    if (!s0) return;
    try { s0.playbackRate.cancelScheduledValues(t); s0.playbackRate.setValueAtTime(1, t); s0.playbackRate.exponentialRampToValueAtTime(0.08, t + 0.9); } catch (e) {}
    fxOut.gain.cancelScheduledValues(t); fxOut.gain.setValueAtTime(fxOut.gain.value, t); fxOut.gain.linearRampToValueAtTime(0, t + 0.95);
    setTimeout(function () { try { s0.stop(); } catch (e) {} try { s0.disconnect(); } catch (e) {} if (R.src === s0) R.src = null; }, 1000);
  }
  function finish(win) {
    R.run = false; cancelAnimationFrame(R.raf);
    if (!win) { if (R.src) tapeStop(); else hush(); }
    else if (R.src) { var tf = ctx.currentTime; fxOut.gain.cancelScheduledValues(tf); fxOut.gain.setValueAtTime(fxOut.gain.value, tf); fxOut.gain.linearRampToValueAtTime(0, tf + 1.6); var sw = R.src; setTimeout(function () { try { sw.stop(); } catch (e) {} if (R.src === sw) R.src = null; }, 1800); }
    var tot = R.notes.length || 1, acc = Math.round(R.hit / tot * 100), stars = acc >= 90 ? 3 : acc >= 70 ? 2 : acc >= 40 ? 1 : 0;
    if (win) { stars = Math.max(stars, 1); if (window.SFX) SFX.win(); if (window.FX) { var r = cv.getBoundingClientRect(); FX.confetti(r.left + r.width / 2, r.top + r.height / 3); } }
    else if (window.SFX) SFX.lose();
    var bk = bkey(), isBest = R.score > (best[bk] || 0);
    if (isBest) { best[bk] = R.score; try { localStorage.setItem('uandi-br-best', JSON.stringify(best)); } catch (e) {} }
    $('brOvT').textContent = win ? 'Bravo ! 🎉' : 'Raté… réessaie !';
    $('brStars').textContent = win ? '★★★'.slice(0, stars) + '☆☆☆'.slice(0, 3 - stars) : '';
    $('brOvS').textContent = 'Score ' + R.score + (isBest && R.score ? ' · nouveau record !' : '') + ' · Combo max ' + R.max + ' · Précision ' + acc + '%';
    $('brGo').textContent = 'Rejouer'; $('brOv').hidden = false; paintSeg(); stats();
  }
  function bkey() { return CU ? 'c' + R.lv + ':' + CU.name : R.lv; }
  function paintSeg() {
    document.querySelectorAll('#brSeg button').forEach(function (b) { b.setAttribute('aria-pressed', +b.dataset.d === R.lv ? 'true' : 'false'); });
    var b = best[bkey()]; $('brBest').textContent = b ? 'Record ' + LV[R.lv].n + (CU ? ' · ' + CU.name : '') + ' : ' + b : '';
    $('brSong').textContent = CU ? '♪ ' + CU.name : ''; $('brNoSong').hidden = !CU;
  }
  function start() {
    if (!ensure()) { $('brOvS').textContent = 'Le son n’est pas disponible sur cet appareil.'; return; }
    hush(); cancelAnimationFrame(R.raf); size();
    var L = LV[R.lv], raw = null;
    if (CU) {
      raw = analyze(CU.buf, R.lv);
      if (raw.length < 15) { $('brOvS').textContent = 'Pas assez de rythme détecté dans ce morceau. Essaie-en un autre.'; return; }
    }
    R.cu = CU ? 1 : 0; R.spk = 0; damageReset();
    R.score = 0; R.combo = 0; R.max = 0; R.hp = 100; R.hit = 0; R.perf = 0; R.miss = 0; R.pr = [0, 0, 0, 0]; R.shake = 0;
    master.gain.cancelScheduledValues(ctx.currentTime); master.gain.setValueAtTime((window.SFX && SFX.isOn()) ? 0.9 : 0, ctx.currentTime);
    if (window.uandiMusic) uandiMusic.pause();
    if (CU) {
      R.ed = 0.25; R.t0 = ctx.currentTime + 0.35; R.tot = 0; R.next = 0; R.sched = false;
      var mt = R.t0 + 16 * R.ed, src = ctx.createBufferSource();
      src.buffer = CU.buf; src.connect(master); src.start(mt, 0, Math.min(CU.buf.duration, CAP)); R.src = src;
      R.notes = raw.map(function (o) { return { t: mt + o.t, l: o.l, done: 0 }; });
      R.lastEnd = R.notes[R.notes.length - 1].t; R.run = true;
      $('brOv').hidden = true; stats();
    } else {
      R.ed = 60 / L.bpm / 2; R.t0 = ctx.currentTime + 0.35; R.tot = L.bars * 8; R.next = 0; R.sched = true;
      R.notes = gen(); R.run = true;
      $('brOv').hidden = true; stats();
      scheduler(); R.tmr = setInterval(scheduler, 30);
    }
    R.raf = requestAnimationFrame(frame);
  }
  function stopAll() { R.run = false; cancelAnimationFrame(R.raf); hush(); }

  /* ---------- ta musique : détection des temps forts -> notes ---------- */
  function analyze(buf, lv) {
    var sr = buf.sampleRate, c0 = buf.getChannelData(0), c1 = buf.numberOfChannels > 1 ? buf.getChannelData(1) : null;
    var N = Math.min(buf.length, Math.floor(CAP * sr)), H = 1024, F = Math.floor(N / H), E = new Float32Array(F), Z = new Float32Array(F), S = new Float32Array(F), P = new Float64Array(F + 1);
    var i, j, o, x, sum, zc, prev;
    for (i = 0; i < F; i++) {
      sum = 0; zc = 0; prev = 0; o = i * H;
      for (j = 0; j < H; j++) { x = c1 ? (c0[o + j] + c1[o + j]) * 0.5 : c0[o + j]; sum += x * x; if ((x >= 0) !== (prev >= 0)) zc++; prev = x; }
      E[i] = Math.sqrt(sum / H); Z[i] = zc / H;
    }
    for (i = 1; i < F; i++) S[i] = Math.max(0, E[i] - E[i - 1]);
    for (i = 0; i < F; i++) P[i + 1] = P[i] + S[i];
    var W = Math.max(8, Math.round(sr / H * 0.6)), gap = [0.42, 0.3, 0.2][lv] * sr / H, k = [1.7, 1.45, 1.25][lv], picks = [], last = -1e9, lo, hi, mean;
    for (i = 2; i < F - 2; i++) {
      lo = Math.max(0, i - W); hi = Math.min(F - 1, i + W); mean = (P[hi + 1] - P[lo]) / (hi - lo + 1);
      if (S[i] > mean * k + 1e-4 && S[i] >= S[i - 1] && S[i] >= S[i + 1] && i - last >= gap) { picks.push(i); last = i; }
    }
    var zs = picks.map(function (p) { return (Z[p] + Z[p + 1] + Z[p + 2]) / 3; }), sorted = zs.slice().sort(function (a, b) { return a - b; });
    var q1 = sorted[Math.floor(sorted.length * 0.25)], q2 = sorted[Math.floor(sorted.length * 0.5)], q3 = sorted[Math.floor(sorted.length * 0.75)];
    var out = [], l1 = -1, l2 = -1, lane;
    picks.forEach(function (p, n) {
      var z = zs[n]; lane = z <= q1 ? 0 : z <= q2 ? 1 : z <= q3 ? 2 : 3;
      if (lane === l1 && l1 === l2) lane = (lane + 1 + (n % 2)) % 4;
      l2 = l1; l1 = lane; out.push({ t: p * H / sr + 0.01, l: lane });
    });
    return out;
  }
  function decodeBuf(ab) {
    return new Promise(function (ok, err) { var pr = ctx.decodeAudioData(ab, ok, err); if (pr && pr.then) pr.then(ok, err); });
  }
  function pickMsg(t) { $('brPickMsg').textContent = t || ''; }
  function setSong(name, ab) {
    if (!ensure()) { pickMsg('Le son n’est pas disponible sur cet appareil.'); return Promise.resolve(); }
    pickMsg('Chargement…');
    return decodeBuf(ab).then(function (buf) {
      CU = { name: String(name || 'Ma musique').replace(/\.[a-z0-9]{2,5}$/i, '').slice(0, 40), buf: buf };
      $('brPickOv').hidden = true; pickMsg(''); paintSeg();
      $('brOvT').textContent = 'Beat Rush 🎧'; $('brOvS').textContent = 'Les notes suivent ta musique. Chaque erreur la détruit un peu plus !'; $('brGo').textContent = 'Jouer';
    }).catch(function () { pickMsg('Impossible de lire ce fichier. Essaie un mp3, m4a ou wav.'); });
  }
  function pickList() {
    var box = $('brList'); box.replaceChildren();
    if (!window.uandiMusic) return;
    uandiMusic.load().then(function () {
      box.replaceChildren();
      var tr = uandiMusic.tracks();
      if (!tr.length) { var h = document.createElement('span'); h.className = 'hint'; h.textContent = 'Ta bibliothèque ♪ Musique est vide : importe un fichier.'; box.appendChild(h); return; }
      tr.forEach(function (t) {
        var b = document.createElement('button'); b.type = 'button'; b.className = 'ghost'; b.textContent = '♪ ' + (uandiMusic.label(t) || t.name);
        b.addEventListener('click', function () {
          pickMsg('Chargement…');
          fetch(t.url).then(function (r) { return r.arrayBuffer(); }).then(function (ab) { return setSong(uandiMusic.label(t) || t.name, ab); })
            .catch(function () { pickMsg('Impossible de lire ce morceau.'); });
        });
        box.appendChild(b);
      });
    }).catch(function () {});
  }
  $('brMy').addEventListener('click', function () { pickMsg(''); $('brPickOv').hidden = false; pickList(); });
  $('brPickBack').addEventListener('click', function () { $('brPickOv').hidden = true; });
  $('brNoSong').addEventListener('click', function () { CU = null; paintSeg(); $('brOvS').textContent = 'Touche les notes quand elles passent sur la ligne. Chaque note jouée fait la mélodie !'; });
  $('brImport').addEventListener('click', function () { $('brFile').click(); });
  $('brFile').addEventListener('change', function (e) {
    var f = e.target.files && e.target.files[0]; e.target.value = '';
    if (!f) return;
    if (!ensure()) { pickMsg('Le son n’est pas disponible sur cet appareil.'); return; }
    f.arrayBuffer().then(function (ab) {
      if (window.uandiMusic) { try { uandiMusic.add([f]); } catch (e2) {} }
      return setSong(f.name, ab);
    }).catch(function () { pickMsg('Impossible de lire ce fichier.'); });
  });

  $('brOpen').addEventListener('click', function () {
    dlg.showModal(); size(); R.run = false; R.notes = []; R.t0 = 0;
    $('brOvT').textContent = 'Beat Rush 🎧'; $('brStars').textContent = '';
    $('brOvS').textContent = 'Touche les notes quand elles passent sur la ligne. Chaque note jouée fait la mélodie !';
    $('brPickOv').hidden = true; $('brGo').textContent = 'Jouer'; $('brOv').hidden = false; paintSeg(); stats();
    g.clearRect(0, 0, cv.width, cv.height); draw(0);
  });
  $('brSeg').addEventListener('click', function (e) { var b = e.target.closest('button'); if (!b) return; R.lv = +b.dataset.d; paintSeg(); if (window.SFX) SFX.tap(); });
  $('brGo').addEventListener('click', start);
  $('brClose').addEventListener('click', function () { dlg.close(); });
  dlg.addEventListener('close', stopAll);
  document.addEventListener('visibilitychange', function () { if (document.hidden && R.run) { stopAll(); finish(false); } });
  $('brPads').addEventListener('pointerdown', function (e) {
    var b = e.target.closest('.brpad'); if (!b) return; e.preventDefault();
    b.classList.add('on'); setTimeout(function () { b.classList.remove('on'); }, 110); press(+b.dataset.l);
  });
  cv.addEventListener('pointerdown', function (e) {
    if (!R.run) return; e.preventDefault();
    var r = cv.getBoundingClientRect(); press(Math.max(0, Math.min(3, Math.floor((e.clientX - r.left) / r.width * 4))));
  });
  window.addEventListener('keydown', function (e) {
    if (!dlg.open) return;
    var l = KEYS[String(e.key).toLowerCase()];
    if (l === undefined) return;
    e.stopPropagation(); e.preventDefault();
    if (!e.repeat) { var b = document.querySelector('.brpad[data-l="' + l + '"]'); if (b) { b.classList.add('on'); setTimeout(function () { b.classList.remove('on'); }, 110); } press(l); }
  }, true);
})();
