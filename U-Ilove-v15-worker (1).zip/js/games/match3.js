/* U&I — js/games/match3.js
   Jeu Cookie Match (match-3) */
(function () {
  var $ = function (i) { return document.getElementById(i); };
  var N = 7, ICONS = ['🍪', '🍩', '🍓', '🍇', '🍋', '🍬'], KEY = 'ui_m3_v1', MAXLV = 50;
  var S = (function () { try { var v = JSON.parse(localStorage.getItem(KEY)); if (v && v.lv) return v; } catch (e) {} return { lv: 1, max: 1, g: null }; })();
  var busy = false, sel = -1, start = null, grid = $('m3Grid');
  function save() { try { localStorage.setItem(KEY, JSON.stringify(S)); } catch (e) {} }
  function cfg(l) { return { k: l < 4 ? 5 : 6, moves: Math.max(14, 25 - Math.floor(l / 2)), target: 400 + (l - 1) * 250 }; }
  function rnd(k) { return Math.floor(Math.random() * k); }
  function wait(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }
  function runs(b) {
    var m = {}, r, c, i;
    for (r = 0; r < N; r++) for (c = 0; c < N; c++) {
      i = r * N + c;
      if (c <= N - 3 && b[i] >= 0 && b[i] === b[i + 1] && b[i] === b[i + 2]) m[i] = m[i + 1] = m[i + 2] = 1;
      if (r <= N - 3 && b[i] >= 0 && b[i] === b[i + N] && b[i] === b[i + 2 * N]) m[i] = m[i + N] = m[i + 2 * N] = 1;
    }
    return Object.keys(m).map(Number);
  }
  function hasMove(b) {
    for (var i = 0; i < N * N; i++) {
      var c = i % N, t;
      if (c < N - 1) { t = b[i]; b[i] = b[i + 1]; b[i + 1] = t; var m = runs(b).length; t = b[i]; b[i] = b[i + 1]; b[i + 1] = t; if (m) return true; }
      if (i + N < N * N) { t = b[i]; b[i] = b[i + N]; b[i + N] = t; var m2 = runs(b).length; t = b[i]; b[i] = b[i + N]; b[i + N] = t; if (m2) return true; }
    }
    return false;
  }
  function newBoard(k) {
    var b;
    do {
      b = [];
      for (var i = 0; i < N * N; i++) {
        var v, c = i % N, tries = 0;
        do { v = rnd(k); tries++; } while (tries < 20 && ((c >= 2 && b[i - 1] === v && b[i - 2] === v) || (i >= 2 * N && b[i - N] === v && b[i - 2 * N] === v)));
        b.push(v);
      }
    } while (runs(b).length || !hasMove(b));
    return b;
  }
  function render(fresh) {
    var g = S.g, c = cfg(g.lv);
    grid.replaceChildren();
    g.b.forEach(function (t, i) {
      var e = document.createElement('button'); e.type = 'button';
      e.className = 'm3c' + (i === sel ? ' sel' : '') + (fresh && fresh[i] ? ' nw' : '');
      e.dataset.i = i; e.dataset.t = t; e.textContent = ICONS[t]; e.setAttribute('aria-label', 'Case ' + (i + 1));
      grid.appendChild(e);
    });
    $('m3Title').textContent = 'Niveau ' + g.lv;
    $('m3Moves').textContent = g.moves; $('m3Score').textContent = g.score;
    $('m3Tgt').textContent = 'Objectif ' + c.target;
    $('m3Bar').style.width = Math.min(100, g.score / c.target * 100) + '%';
  }
  function startLevel(l) {
    var c = cfg(l); S.lv = l; S.g = { lv: l, b: newBoard(c.k), moves: c.moves, score: 0 };
    sel = -1; save(); showPlay(); render();
  }
  function showPlay() { $('m3Levels').hidden = true; $('m3Play').hidden = false; $('m3Ov').hidden = true; }
  function levels() {
    var box = $('m3LvGrid'); box.replaceChildren(); $('m3Title').textContent = 'Niveaux';
    for (var n = 1; n <= MAXLV; n++) {
      var b = document.createElement('button'); b.type = 'button'; b.className = 'ghost' + (n === S.lv ? ' cur' : '');
      b.textContent = n; b.disabled = n > S.max; b.dataset.l = n; box.appendChild(b);
    }
    $('m3Play').hidden = true; $('m3Levels').hidden = false; $('m3Ov').hidden = true;
  }
  function adj(a, b) { var ar = Math.floor(a / N), br = Math.floor(b / N), ac = a % N, bc = b % N; return Math.abs(ar - br) + Math.abs(ac - bc) === 1; }
  function fx(m, combo) {
    if (!window.FX) return;
    var cells = grid.children, sx = 0, sy = 0, n = 0;
    m.forEach(function (i, k) {
      var c = cells[i]; if (!c) return;
      var r = c.getBoundingClientRect(), x = r.left + r.width / 2, y = r.top + r.height / 2;
      sx += x; sy += y; n++;
      if (k < 8) FX.burst(x, y, 6);
    });
    if (n) FX.float('+' + (m.length * 10 * combo) + (combo > 1 ? '  Combo x' + combo : ''), sx / n, sy / n);
  }
  async function resolve() {
    var g = S.g, k = cfg(g.lv).k, combo = 0;
    for (;;) {
      var m = runs(g.b); if (!m.length) break;
      combo++;
      var cells = grid.children; m.forEach(function (i) { if (cells[i]) cells[i].classList.add('pop'); });
      if (window.SFX) SFX.pop(combo);
      fx(m, combo);
      await wait(230);
      m.forEach(function (i) { g.b[i] = -1; });
      g.score += m.length * 10 * combo;
      var fresh = {};
      for (var c = 0; c < N; c++) {
        var col = [], r;
        for (r = N - 1; r >= 0; r--) if (g.b[r * N + c] >= 0) col.push(g.b[r * N + c]);
        for (r = N - 1; r >= 0; r--) { if (col.length) g.b[r * N + c] = col.shift(); else { g.b[r * N + c] = rnd(k); fresh[r * N + c] = 1; } }
      }
      render(fresh); await wait(260);
    }
    if (!hasMove(g.b)) { g.b = newBoard(k); render({}); }
  }
  async function swap(a, b) {
    if (busy || !S.g) return; busy = true; sel = -1;
    var g = S.g, t = g.b[a]; g.b[a] = g.b[b]; g.b[b] = t; render();
    if (!runs(g.b).length) { if (window.SFX) SFX.error(); if (window.FX) FX.shake(grid); await wait(200); t = g.b[a]; g.b[a] = g.b[b]; g.b[b] = t; render(); busy = false; return; }
    g.moves--; if (window.SFX) SFX.swap(); await resolve(); render(); save();
    var c = cfg(g.lv);
    if (g.score >= c.target) {
      if (window.SFX) SFX.win();
      if (window.FX) { var gr = grid.getBoundingClientRect(); FX.confetti(gr.left + gr.width / 2, gr.top + gr.height / 3); }
      S.max = Math.max(S.max, Math.min(MAXLV, g.lv + 1)); S.lv = Math.min(MAXLV, g.lv + 1); S.g = null; save();
      over('Niveau réussi ! 🎉', 'Score : ' + g.score, 'Niveau suivant', function () { startLevel(S.lv); });
    } else if (g.moves <= 0) {
      if (window.SFX) SFX.lose();
      S.g = null; save();
      over('Plus de coups', 'Score : ' + g.score + ' sur ' + c.target, 'Rejouer', function () { startLevel(g.lv); });
    }
    busy = false;
  }
  var ovFn = null;
  function over(t, sub, label, fn) { $('m3OvT').textContent = t; $('m3OvS').textContent = sub; $('m3OvGo').textContent = label; ovFn = fn; $('m3Ov').hidden = false; }
  $('m3OvGo').addEventListener('click', function () { if (ovFn) ovFn(); });
  grid.addEventListener('pointerdown', function (e) {
    var c = e.target.closest('.m3c'); if (!c || busy) return;
    start = { i: +c.dataset.i, x: e.clientX, y: e.clientY };
  });
  grid.addEventListener('pointerup', function (e) {
    if (!start || busy) { start = null; return; }
    var s0 = start, dx = e.clientX - s0.x, dy = e.clientY - s0.y; start = null;
    if (Math.max(Math.abs(dx), Math.abs(dy)) > 16) {
      var to = Math.abs(dx) > Math.abs(dy) ? s0.i + (dx > 0 ? 1 : -1) : s0.i + (dy > 0 ? N : -N);
      if (to >= 0 && to < N * N && adj(s0.i, to)) swap(s0.i, to);
      return;
    }
    if (window.SFX) SFX.tap();
    if (sel < 0) sel = s0.i; else if (sel === s0.i) sel = -1; else if (adj(sel, s0.i)) { swap(sel, s0.i); return; } else sel = s0.i;
    render();
  });
  $('m3Open').addEventListener('click', function () {
    $('m3Dlg').showModal();
    if (S.g && S.g.b) { showPlay(); sel = -1; render(); } else startLevel(S.lv);
  });
  $('m3LvBtn').addEventListener('click', function () { if (!busy) levels(); });
  $('m3LvGrid').addEventListener('click', function (e) { var b = e.target.closest('button'); if (b && !b.disabled) { if (window.SFX) SFX.tap(); startLevel(+b.dataset.l); } });
  $('m3Close').addEventListener('click', function () { $('m3Dlg').close(); });
})();
