/* U&I — js/games/sons.js
   Sons des jeux (WebAudio) */
(function () {
  /* ---------- sons des jeux (WebAudio, aucun fichier) ---------- */
  var KEY = 'uandi-sfx', ctx = null, on = true;
  try { on = localStorage.getItem(KEY) !== '0'; } catch (e) {}
  var reduce = !!(window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches);
  function ac() {
    try {
      if (!ctx) { var A = window.AudioContext || window.webkitAudioContext; if (!A) return null; ctx = new A(); }
      if (ctx.state === 'suspended') ctx.resume();
      return ctx;
    } catch (e) { return null; }
  }
  function tone(f, d, type, v, delay, to) {
    if (!on) return;
    var c = ac(); if (!c) return;
    try {
      var t = c.currentTime + (delay || 0), o = c.createOscillator(), g = c.createGain();
      o.type = type || 'sine'; o.frequency.setValueAtTime(f, t);
      if (to) o.frequency.exponentialRampToValueAtTime(to, t + d);
      g.gain.setValueAtTime(0.0001, t);
      g.gain.exponentialRampToValueAtTime(v || 0.1, t + 0.01);
      g.gain.exponentialRampToValueAtTime(0.0001, t + d);
      o.connect(g); g.connect(c.destination); o.start(t); o.stop(t + d + 0.03);
    } catch (e) {}
  }
  function vib(p) { if (!on) return; try { if (navigator.vibrate) navigator.vibrate(p); } catch (e) {} }
  var NT = { c: 523.25, e: 659.25, g: 783.99, a: 880, c2: 1046.5, e2: 1318.5 };
  var SFX = {
    tap: function () { tone(660, 0.07, 'triangle', 0.09, 0, 880); },
    back: function () { tone(440, 0.07, 'triangle', 0.08, 0, 330); },
    swap: function () { tone(300, 0.12, 'sine', 0.09, 0, 600); },
    error: function () { tone(190, 0.2, 'sawtooth', 0.06, 0, 110); vib(60); },
    hint: function () { tone(NT.e2, 0.12, 'sine', 0.07); tone(NT.a * 2, 0.18, 'sine', 0.06, 0.09); },
    pop: function (combo) {
      var k = Math.min(combo || 1, 6), f = 520 * Math.pow(1.26, k - 1);
      tone(f, 0.14, 'sine', 0.1, 0, f * 1.5); tone(f * 2, 0.1, 'triangle', 0.04, 0.03);
    },
    win: function () {
      [NT.c, NT.e, NT.g, NT.c2].forEach(function (f, i) { tone(f, 0.22, 'triangle', 0.1, i * 0.09); });
      tone(NT.e2, 0.4, 'sine', 0.07, 0.36); vib([30, 40, 60]);
    },
    lose: function () { [NT.g, NT.e, NT.c].forEach(function (f, i) { tone(f * 0.6, 0.25, 'sine', 0.09, i * 0.14); }); },
    isOn: function () { return on; },
    set: function (v) {
      on = !!v; try { localStorage.setItem(KEY, on ? '1' : '0'); } catch (e) {}
      paint(); if (on) SFX.tap();
    }
  };
  function paint() {
    document.querySelectorAll('[data-sfx]').forEach(function (b) {
      var short = b.getAttribute('data-sfx') === 'short', ic = on ? '\uD83D\uDD0A' : '\uD83D\uDD07';
      b.textContent = short ? ic : ic + (on ? ' Sons activés' : ' Sons coupés');
      b.setAttribute('aria-pressed', on ? 'true' : 'false');
    });
  }
  document.addEventListener('click', function (e) { if (e.target.closest && e.target.closest('[data-sfx]')) SFX.set(!on); });
  paint();

  /* ---------- effets visuels : particules, texte flottant, confettis ---------- */
  function host() { return document.querySelector('dialog[open]') || document.body; }
  function mk(x, y, cls, text) {
    var h = host(), d = document.createElement('div'), abs = h !== document.body;
    d.className = 'fxp' + (abs ? ' abs' : '') + (cls ? ' ' + cls : '');
    if (text) d.textContent = text;
    var px = x, py = y;
    if (abs) { var r = h.getBoundingClientRect(); px = x - r.left; py = y - r.top; }
    d.style.left = px + 'px'; d.style.top = py + 'px';
    h.appendChild(d);
    return d;
  }
  function go(d, frames, ms) {
    var a = d.animate(frames, { duration: ms, easing: 'cubic-bezier(.2,.7,.3,1)', fill: 'forwards' });
    a.onfinish = a.oncancel = function () { if (d.parentNode) d.parentNode.removeChild(d); };
  }
  var COLORS = ['#ff5d8f', '#ffd166', '#06d6a0', '#4cc9f0', '#b388ff', '#ff9f43'];
  function burst(x, y, n, big) {
    if (reduce) return;
    for (var i = 0; i < n; i++) {
      var d = mk(x, y, '', ''), s = big ? 7 + Math.random() * 6 : 5 + Math.random() * 4;
      d.style.width = s + 'px'; d.style.height = (big ? s * 1.6 : s) + 'px';
      d.style.background = COLORS[(Math.random() * COLORS.length) | 0];
      d.style.borderRadius = big ? '2px' : '50%'; d.style.marginLeft = d.style.marginTop = (-s / 2) + 'px';
      var ang = Math.random() * Math.PI * 2, dist = (big ? 70 : 28) + Math.random() * (big ? 120 : 32);
      var dx = Math.cos(ang) * dist, dy = Math.sin(ang) * dist + (big ? 60 : 0);
      go(d, [{ transform: 'translate(0,0) rotate(0) scale(1)', opacity: 1 },
             { transform: 'translate(' + dx + 'px,' + dy + 'px) rotate(' + ((Math.random() * 540) | 0) + 'deg) scale(.4)', opacity: 0 }],
         (big ? 900 : 520) + Math.random() * 300);
    }
  }
  window.SFX = SFX;
  window.FX = {
    burst: function (x, y, n) { burst(x, y, n || 8, false); },
    confetti: function (x, y) { burst(x, y, 34, true); },
    float: function (text, x, y) {
      if (reduce) return;
      var d = mk(x, y, 'fxt', text); d.style.transform = 'translate(-50%,-50%)';
      go(d, [{ transform: 'translate(-50%,-50%) scale(.7)', opacity: 0 },
             { transform: 'translate(-50%,-90%) scale(1.15)', opacity: 1, offset: .25 },
             { transform: 'translate(-50%,-220%) scale(1)', opacity: 0 }], 950);
    },
    shake: function (el) {
      if (reduce || !el || !el.animate) return;
      el.animate([{ transform: 'translateX(0)' }, { transform: 'translateX(-7px)' }, { transform: 'translateX(7px)' },
                  { transform: 'translateX(-5px)' }, { transform: 'translateX(0)' }], { duration: 300 });
    }
  };
})();
