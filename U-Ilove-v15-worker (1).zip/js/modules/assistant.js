/* U&I — js/modules/assistant.js
   Assistant X.Uni (Groq puis Gemini) */
(function(){ try {
  /* Relais Cloudflare (optionnel) : adresse du Worker, ex. 'https://assistant.moncompte.workers.dev'. Vide = chaque personne colle sa propre clé Gemini gratuite dans ⚙. */
  var AI_FN = '';
  var MODEL_OPTS = [
    { id: 'auto', short: 'Auto', label: 'X.Uni Auto — le plus adapté', note: 'X.Uni choisit la meilleure version disponible et change tout seul si l’une est en panne.' },
    { id: 'gemini-2.5-flash', short: 'Flash', label: 'X.Uni Flash — équilibré', note: 'Bonne qualité et rapide. Idéal pour les cours et les explications.' },
    { id: 'gemini-2.5-flash-lite', short: 'Lite', label: 'X.Uni Lite — le plus rapide', note: 'Réponses très rapides et plus de questions par jour, un peu moins détaillées.' },
    { id: 'gemini-flash-latest', short: 'Plus', label: 'X.Uni Plus — le plus récent', note: 'Dernière génération de Gemini. Plus intelligent, mais peut être plus lent.' }
  ];
  function chosenModel() { try { var m = localStorage.getItem('uandi-ai-model') || 'auto'; return MODEL_OPTS.some(function (o) { return o.id === m; }) ? m : 'auto'; } catch (e) { return 'auto'; } }
  function modelOrder(id) {
    var base = ['gemini-2.5-flash', 'gemini-2.5-flash-lite', 'gemini-flash-latest'];
    if (id && id !== 'auto') base = [id].concat(base.filter(function (x) { return x !== id; }));
    return base;
  }
  var MODELS = modelOrder(chosenModel());
  var CLD_NAME = 'hjnf54dr', CLD_PRESET = 'uandi_upload', CLD_BASE = 'https://res.cloudinary.com/' + CLD_NAME + '/';
  var LK = 'uandi-ai-mem', KK = 'uandi-ai-key';
  var $ = function (s) { return document.querySelector(s); };
  var P = $('#aiP'), logEl = $('#aiLog'), inEl = $('#aiIn'), sendB = $('#aiSend'), sel = $('#aiLes'), sheet = $('#aiSheet');
  var mem = { facts: '', msgs: [], t: 0, chats: [], id: '', act: 0 }, autoNote = false, IDLE_MS = 5 * 60 * 1000, busy = false, turns = 0, dirty = false, saving = false, flushing = false, sync = '';
  function valid(m) { return m && typeof m.t === 'string' && m.t && (m.r === 'user' || m.r === 'assistant'); }
  /* ---------- Plusieurs conversations : la courante est dans mem.msgs, les autres dans mem.chats ---------- */
  function newId() { return Date.now().toString(36) + Math.random().toString(36).slice(2, 6); }
  function mk(c) {
    c = c || {};
    return {
      facts: String(c.facts || '').slice(0, 2000),
      msgs: (Array.isArray(c.msgs) ? c.msgs : []).filter(valid).slice(-40),
      t: c.t || 0, id: c.id ? String(c.id) : newId(), act: c.act || 0,
      chats: (Array.isArray(c.chats) ? c.chats : []).filter(function (x) { return x && x.id && Array.isArray(x.msgs); }).map(function (x) {
        return { id: String(x.id), title: String(x.title || 'Conversation').slice(0, 60), t: x.t || 0, msgs: x.msgs.filter(valid).slice(-30) };
      }).filter(function (x) { return x.msgs.length; }).slice(0, 15)
    };
  }
  function cTitle(msgs) {
    var f = (msgs || []).filter(function (m) { return m.r === 'user'; })[0]; if (!f) return 'Conversation';
    var L = { resume: 'Résumé', quiz: 'Quiz', devoirs: 'Devoirs', explique: 'Explique-moi' };
    var k = Object.keys(PROMPTS).filter(function (x) { return PROMPTS[x] === f.t; })[0]; if (k) return L[k] + ' de la leçon';
    var t = f.t.replace(/\s+/g, ' ').trim(); return t.length > 42 ? t.slice(0, 42) + '…' : t;
  }
  function archive() {
    if (!mem.msgs.length) return;
    var id = mem.id || newId();
    mem.chats = (mem.chats || []).filter(function (c) { return c.id !== id; });
    mem.chats.unshift({ id: id, title: cTitle(mem.msgs), t: mem.act || mem.t || Date.now(), msgs: mem.msgs.slice(-30) });
    mem.chats = mem.chats.slice(0, 15);
  }
  function fresh() { archive(); mem.msgs = []; mem.id = newId(); mem.act = Date.now(); }
  /* 5 minutes sans toucher à X.Uni : la prochaine fois, on repart sur une nouvelle conversation */
  function idleCheck() {
    if (busy || !mem.msgs.length) return false;
    var last = mem.act || mem.t || 0;
    if (!last || Date.now() - last < IDLE_MS) return false;
    fresh(); autoNote = true; dirty = true; saveLocal(); return true;
  }
  try { var c = JSON.parse(localStorage.getItem(LK) || 'null'); if (c && typeof c === 'object') mem = mk(c); } catch (e) {}
  try { var old = JSON.parse(localStorage.getItem('uandi-ai-chat') || 'null'); if (old && old.length && !mem.msgs.length) mem.msgs = old.filter(valid); } catch (e) {}
  function saveLocal(stamp) { if (stamp !== false) mem.t = Date.now(); try { localStorage.setItem(LK, JSON.stringify(mem)); } catch (e) {} }
  function uid() { try { var u = firebase.auth().currentUser; return u && u.uid; } catch (e) { return null; } }
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function md(s) {
    var h = esc(s).replace(/```[a-z]*\n?([\s\S]*?)```/g, function (_, c) { return '<pre>' + c.trim() + '</pre>'; });
    return h.split(/(<pre>[\s\S]*?<\/pre>)/).map(function (seg) {
      if (seg.indexOf('<pre>') === 0) return seg;
      seg = seg.replace(/`([^`\n]+)`/g, '<code>$1</code>').replace(/\*\*([^*\n]+)\*\*/g, '<b>$1</b>');
      return seg.split('\n').map(function (ln) {
        var m;
        if ((m = ln.match(/^\s*#{1,4}\s+(.*)/))) return '<div class="ai-h">' + m[1] + '</div>';
        if ((m = ln.match(/^\s*[-*•]\s+(.*)/))) return '<div class="ai-li">• ' + m[1] + '</div>';
        if ((m = ln.match(/^\s*(\d+[.)])\s+(.*)/))) return '<div class="ai-li">' + m[1] + ' ' + m[2] + '</div>';
        return ln ? ln + '<br>' : '<br>';
      }).join('');
    }).join('').replace(/(<br>)+$/, '');
  }
  function bubble(r, html, cls) { var d = document.createElement('div'); d.className = 'ai-b ' + (cls || (r === 'user' ? 'u' : 'a')); if (r === 'user') d.textContent = html; else d.innerHTML = html; logEl.appendChild(d); return d; }
  function down() { logEl.scrollTop = logEl.scrollHeight; }
  function paint(force) {
    var keep = force ? [] : Array.prototype.filter.call(logEl.children, function (n) { return n.dataset && n.dataset.keep; });
    logEl.textContent = '';
    if (!mem.msgs.length && !keep.length) {
      var h = document.createElement('div'); h.className = 'ai-hi';
      h.innerHTML = '<h3>Salut, moi c’est X.Uni 👋</h3>Pose-moi une question, ou choisis une leçon puis touche Résumé, Quiz, Devoirs ou Explique-moi.' + (autoNote ? '<p class="ai-note">Nouvelle conversation (5 min d’absence). L’ancienne est dans l’historique 🕘</p>' : '');
      logEl.appendChild(h); return;
    }
    mem.msgs.forEach(function (m) { bubble(m.r, m.r === 'user' ? m.t : md(m.t)); });
    keep.forEach(function (n) { logEl.appendChild(n); });
    down();
  }
  function fillLessons() {
    var st = window.uandiStudy, cur = sel.value, list = st ? st.list() : [];
    sel.textContent = '';
    var o0 = document.createElement('option'); o0.value = ''; o0.textContent = 'Aucune (question libre)'; sel.appendChild(o0);
    list.forEach(function (l) { var o = document.createElement('option'); o.value = l.id; o.textContent = l.name; sel.appendChild(o); });
    var want = cur || (st && st.cur()) || '';
    sel.value = list.some(function (l) { return l.id === want; }) ? want : '';
  }

  /* ---------- IA : clé personnelle (direct Gemini) ou relais Cloudflare ---------- */
  var KEYURL = 'https://console.groq.com/keys';
  function fail(text, link, retryText) {
    var d = bubble('assistant', esc(text) + (link ? '<br><a class="ai-link" href="' + KEYURL + '" target="_blank" rel="noopener">👉 Créer ma clé gratuite</a>' : '') + (retryText ? '<br><button type="button" class="ai-retry">↻ Réessayer</button>' : ''), 'e');
    d.dataset.keep = '1';
    var rb = d.querySelector('.ai-retry');
    if (rb) rb.addEventListener('click', function () { d.remove(); ask(retryText, true); });
    down(); return d;
  }
  var SEND_ICO = '<svg viewBox="0 0 24 24"><path d="M12 19V5M6 11l6-6 6 6"/></svg>';
  var STOP_ICO = '<svg viewBox="0 0 24 24"><rect x="7" y="7" width="10" height="10" rx="2" fill="currentColor" stroke="none"/></svg>';
  var req = null;
  function setBusy(b) {
    busy = b; sendB.disabled = false; sendB.classList.toggle('stop', b);
    sendB.innerHTML = b ? STOP_ICO : SEND_ICO; sendB.setAttribute('aria-label', b ? 'Arrêter la réponse' : 'Envoyer');
    if (b && P.hidden) pill('busy');
  }
  /* pastille flottante : visible quand X.Uni est fermé mais réfléchit encore */
  var pillEl = null;
  function pill(st) {
    return; /* désactivé : le chargement reste dans la bulle de réponse, même si on ferme puis rouvre X.Uni */
    if (!pillEl) {
      var css = document.createElement('style');
      css.textContent = '#aiPill{position:fixed;left:50%;bottom:calc(18px + env(safe-area-inset-bottom,0px));transform:translateX(-50%);z-index:99999;display:flex;align-items:center;gap:10px;padding:11px 18px;border-radius:999px;border:0;background:#1f1f2b;color:#fff;font:600 14px system-ui,sans-serif;box-shadow:0 6px 24px rgba(0,0,0,.35);cursor:pointer}#aiPill[hidden]{display:none}#aiPill .ai-dots{margin:0}#aiPill .ai-dots i{background:#fff}';
      document.head.appendChild(css);
      pillEl = document.createElement('button'); pillEl.id = 'aiPill'; pillEl.type = 'button'; pillEl.hidden = true;
      pillEl.addEventListener('click', function () { open(); });
      document.body.appendChild(pillEl);
    }
    if (st === 'busy') pillEl.innerHTML = 'X.Uni réfléchit <span class="ai-dots"><i></i><i></i><i></i></span>';
    else if (st === 'done') pillEl.innerHTML = '✓ X.Uni a répondu — toucher pour voir';
    pillEl.hidden = !st;
  }
  function stopReq() { if (req) { req.userStop = true; req.abort(); } }
  async function gen(system, messages, maxTok) {
    var key = ''; try { key = (localStorage.getItem(KK) || '').trim(); } catch (e) {}
    var gk0 = groqKey();
    if (!key && !AI_FN && !gk0) throw { code: 'setup' };
    var msgs = messages.slice(); while (msgs.length && msgs[0].role !== 'user') msgs.shift();
    var ctl = new AbortController(), to = setTimeout(function () { ctl.abort(); }, 45000), r, j = {};
    try {
      /* Groq d'abord ; si indisponible, on bascule sur Gemini */
      if (gk0) {
        var GMS = await groqModels(gk0, ctl.signal), gr0 = null;
        for (var gi0 = 0; gi0 < GMS.length; gi0++) {
          try {
            gr0 = await fetch('https://api.groq.com/openai/v1/chat/completions', {
              method: 'POST', signal: ctl.signal, headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + gk0 },
              body: JSON.stringify({ model: GMS[gi0], temperature: 0.6, max_tokens: (maxTok || 1500) + 800, reasoning_effort: /gpt-oss/.test(GMS[gi0]) ? 'low' : undefined,
                messages: [{ role: 'system', content: system }].concat(msgs.map(function (m) { return { role: m.role === 'assistant' ? 'assistant' : 'user', content: m.text }; })) })
            });
          } catch (e0) { if (ctl.signal.aborted) throw e0; gr0 = null; continue; }
          if (gr0.status === 429 || gr0.status >= 500 || gr0.status === 404 || gr0.status === 400) continue;
          break;
        }
        if (gr0 && gr0.ok) {
          var gj0 = {}; try { gj0 = await gr0.json(); } catch (e1) {}
          var gt0 = String((gj0.choices && gj0.choices[0] && gj0.choices[0].message && gj0.choices[0].message.content) || '').trim();
          if (gt0) return gt0;
        }
        if (!key && !AI_FN) throw !gr0 ? { code: 'net' } : gr0.status === 429 ? { code: 'rate' } : (gr0.status === 401 || gr0.status === 403) ? { code: 'key' } : { code: 'down', status: gr0.status };
      }
      if (key) {
        var gbody = JSON.stringify({
          systemInstruction: { parts: [{ text: system }] },
          contents: msgs.map(function (m) { return { role: m.role === 'assistant' ? 'model' : 'user', parts: [{ text: m.text }] }; }),
          generationConfig: { temperature: 0.6, maxOutputTokens: maxTok || 1500 }
        });
        for (var mi = 0; mi < MODELS.length; mi++) {
          r = await fetch('https://generativelanguage.googleapis.com/v1beta/models/' + MODELS[mi] + ':generateContent', {
            method: 'POST', signal: ctl.signal, headers: { 'Content-Type': 'application/json', 'x-goog-api-key': key }, body: gbody
          });
          if (r.status !== 404 && r.status !== 500 && r.status !== 503) break;
        }
      } else {
        r = await fetch(AI_FN, { method: 'POST', signal: ctl.signal, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ system: system, messages: msgs, maxTokens: maxTok || 1500 }) });
      }
      try { j = await r.json(); } catch (e) {}
    } catch (e) { if (e && e.code) throw e; throw { code: e && e.name === 'AbortError' ? 'slow' : 'net' }; }
    finally { clearTimeout(to); }
    if (r.status === 429) throw { code: 'rate' };
    var emsg = (j && j.error && j.error.message) || '';
    if (key && (r.status === 403 || (r.status === 400 && /api key/i.test(emsg)))) throw { code: 'key' };
    if (!r.ok) throw { code: 'down', status: r.status, msg: emsg };
    var out = key
      ? ((j.candidates && j.candidates[0] && j.candidates[0].content && j.candidates[0].content.parts) || []).map(function (p) { return p.text || ''; }).join('')
      : (j.reply || '');
    return String(out).trim();
  }
  /* réponse en direct : le texte s'affiche au fur et à mesure (beaucoup plus rapide à l'œil) */
  async function genStream(system, messages, maxTok, onText, ctl) {
    var key = ''; try { key = (localStorage.getItem(KK) || '').trim(); } catch (e) {}
    var gk = groqKey();
    if (!key && !AI_FN && !gk) throw { code: 'setup' };
    var msgs = messages.slice(); while (msgs.length && msgs[0].role !== 'user') msgs.shift();
    ctl = ctl || new AbortController(); ctl.last = Date.now();
    var to = setTimeout(function () { ctl.abort(); }, 120000), r, full = '';
    var wd = setInterval(function () { if (Date.now() - ctl.last > (full ? 20000 : 25000)) { ctl.stall = true; ctl.abort(); } }, 3000);
    try {
      /* Groq d'abord (très rapide) ; si indisponible, on bascule sur Gemini sans rien dire */
      var gst = 0, gerr = '';
      if (gk) {
        var GM = await groqModels(gk, ctl.signal);
        for (var gi = 0; gi < GM.length && !full; gi++) {
          try {
            var gr = await fetch('https://api.groq.com/openai/v1/chat/completions', {
              method: 'POST', signal: ctl.signal, headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + gk },
              body: JSON.stringify({ model: GM[gi], stream: true, temperature: 0.6, max_tokens: (maxTok || 1500) + 800, reasoning_effort: /gpt-oss/.test(GM[gi]) ? 'low' : undefined,
                messages: [{ role: 'system', content: system }].concat(msgs.map(function (m) { return { role: m.role === 'assistant' ? 'assistant' : 'user', content: m.text }; })) })
            });
            gst = gr.status;
            if (!gr.ok) { try { var gej = await gr.clone().json(); gerr += GM[gi] + ': ' + String((gej.error && gej.error.message) || gej.error || gr.status) + ' | '; } catch (e) { gerr += GM[gi] + ': ' + gr.status + ' | '; } }
            if (!gr.ok || !gr.body || !gr.body.getReader) { if (gr.status === 429 || gr.status >= 500 || gr.status === 404 || gr.status === 400) continue; break; }
            var grd = gr.body.getReader(), gdec = new TextDecoder(), gbuf = '';
            for (;;) {
              var gx = await grd.read(); if (gx.done) break;
              ctl.last = Date.now();
              gbuf += gdec.decode(gx.value, { stream: true });
              var gls = gbuf.split('\n'); gbuf = gls.pop();
              for (var gl = 0; gl < gls.length; gl++) {
                var gln = gls[gl]; if (gln.indexOf('data:') !== 0) continue;
                var gt = gln.slice(5).trim(); if (!gt || gt === '[DONE]') continue;
                var go; try { go = JSON.parse(gt); } catch (e) { continue; }
                if (go.error) { gerr = String(go.error.message || go.error); continue; }
                var gch = go.choices && go.choices[0] && go.choices[0].delta && go.choices[0].delta.content;
                if (gch) { full += gch; onText(full); }
              }
            }
            if (full) break;
            continue;
          } catch (ge) {
            if (ctl.signal.aborted) throw ge;
            if (full) break;
          }
        }
        if (full) return full.trim();
        ctl.last = Date.now();
        if (!key && !AI_FN) throw gst === 429 ? { code: 'rate' } : gst === 401 || gst === 403 ? { code: 'key' } : { code: gst ? 'down' : 'net', status: gst, msg: gerr };
      }
      if (key) {
        for (var att = 0; att < 3; att++) {
        var ML = ctl.models || MODELS;
        for (var mi = 0; mi < ML.length; mi++) {
          var gc = { temperature: 0.6, maxOutputTokens: maxTok || 1500 };
          if (/^gemini-2\.5/.test(ML[mi])) gc.thinkingConfig = { thinkingBudget: 0 };
          r = await fetch('https://generativelanguage.googleapis.com/v1beta/models/' + ML[mi] + ':streamGenerateContent?alt=sse', {
            method: 'POST', signal: ctl.signal, headers: { 'Content-Type': 'application/json', 'x-goog-api-key': key },
            body: JSON.stringify({
              systemInstruction: { parts: [{ text: system }] },
              contents: msgs.map(function (m) { return { role: m.role === 'assistant' ? 'model' : 'user', parts: [{ text: m.text }] }; }),
              generationConfig: gc
            })
          });
          if (r.status !== 404 && r.status !== 429 && r.status !== 500 && r.status !== 503 && !(r.status === 400 && mi < ML.length - 1)) break;
        }
          if ((r.status === 503 || r.status === 500 || r.status === 429) && att < 2) {
            if (ctl.onRetry) ctl.onRetry(att + 1, r.status);
            ctl.last = Date.now();
            await new Promise(function (ok) { setTimeout(ok, (r.status === 429 ? 6000 : 1500) * (att + 1)); });
            ctl.last = Date.now();
            continue;
          }
          break;
        }
      } else {
        r = await fetch(AI_FN, { method: 'POST', signal: ctl.signal, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ system: system, messages: msgs, maxTokens: maxTok || 1500, stream: true }) });
      }
      if (r.status === 429) throw { code: 'rate' };
      if (!r.ok) {
        var j = {}; try { j = await r.json(); } catch (e) {}
        var emsg = (j && j.error && (j.error.message || (typeof j.error === 'string' && j.error))) || '';
        if (key && (r.status === 403 || (r.status === 400 && /api key/i.test(emsg)))) throw { code: 'key' };
        throw { code: 'down', status: r.status, msg: String(emsg) };
      }
      var ct = r.headers.get('content-type') || '';
      if (ct.indexOf('event-stream') < 0 || !r.body || !r.body.getReader) {
        var j2 = {}; try { j2 = await r.json(); } catch (e) {}
        full = (j2.reply || '').trim(); if (full) onText(full); return full;
      }
      var rd = r.body.getReader(), dec = new TextDecoder(), buf = '';
      for (;;) {
        var x = await rd.read(); if (x.done) break;
        ctl.last = Date.now();
        buf += dec.decode(x.value, { stream: true });
        var lines = buf.split('\n'); buf = lines.pop();
        for (var i = 0; i < lines.length; i++) {
          var ln = lines[i]; if (ln.indexOf('data:') !== 0) continue;
          var t = ln.slice(5).trim(); if (!t || t === '[DONE]') continue;
          var o; try { o = JSON.parse(t); } catch (e) { continue; }
          var ps = (o.candidates && o.candidates[0] && o.candidates[0].content && o.candidates[0].content.parts) || [];
          var ch = ps.map(function (p) { return p.text || ''; }).join('');
          if (ch) { full += ch; onText(full); }
        }
      }
      return full.trim();
    } catch (e) {
      if (e && e.code) throw e;
      if (full) return full.trim();
      throw { code: ctl.userStop ? 'stop' : ctl.stall ? 'stall' : e && e.name === 'AbortError' ? 'slow' : 'net' };
    } finally { clearTimeout(to); clearInterval(wd); }
  }
  var BASE = 'Tu es X.Uni, l’assistant d’étude de l’application U&I, pour des étudiants. Si on te demande ton nom, tu t’appelles X.Uni. Réponds dans la langue de l’élève (français par défaut), de façon claire, chaleureuse et précise. ' +
    'Explique étape par étape avec des exemples simples. Quand tu fais un quiz, pose UNE question à la fois, attends la réponse, corrige gentiment, puis continue. ' +
    'Pour les devoirs, ne donne la correction que si on te la demande. Tu peux aussi aider sur des questions de la vie de tous les jours. Si tu n’es pas sûr, dis-le. ' +
    'N’invente jamais de faits sur le cours : appuie-toi sur la leçon fournie quand il y en a une. Reste concis : va à l’essentiel, listes courtes, gras pour les mots importants.';
  /* ---------- Leçon : on n'envoie à l'IA que les morceaux utiles ---------- */
  var LES_MAX = 6000, CH_LEN = 900;
  var STOP = ' le la les un une des du de et en au aux ce ces cet cette son sa ses mon ma mes ton ta tes que qui quoi dont ou où est sont etre avoir pas pour par sur dans avec sans plus moins tout tous toute toutes mais donc car comme ainsi alors faire fait peux peut veux dis donne moi toi nous vous ils elles il elle je tu on se ne y a ai as va quel quelle quels quelles cette sur sous entre vers chez leur leurs aussi tres bien si oui non explique expliquer exemple '.split(' ');
  function norm(t) { return String(t || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, ''); }
  function words(t) { return (norm(t).match(/[a-z0-9_]{3,}/g) || []).filter(function (w) { return STOP.indexOf(w) < 0; }); }
  function chunkLesson(text) {
    var paras = String(text).split(/\n\s*\n/), out = [], cur = '';
    function push() { if (cur.trim()) out.push(cur.trim()); cur = ''; }
    paras.forEach(function (pa) {
      while (pa.length > CH_LEN * 1.5) {
        var cut = pa.lastIndexOf('\n', CH_LEN); if (cut < CH_LEN / 2) cut = pa.lastIndexOf('. ', CH_LEN) + 1; if (cut < CH_LEN / 2) cut = pa.lastIndexOf(' ', CH_LEN); if (cut < CH_LEN / 2) cut = CH_LEN;
        if (cur) push(); out.push(pa.slice(0, cut).trim()); pa = pa.slice(cut);
      }
      if (cur && (cur.length + pa.length) > CH_LEN) push();
      cur += (cur ? '\n\n' : '') + pa;
    });
    push();
    return out.filter(Boolean);
  }
  function pickLesson(text) {
    text = String(text || '');
    if (text.length <= LES_MAX) return text;
    var chunks = chunkLesson(text); if (chunks.length < 2) return text.slice(0, LES_MAX);
    var last = mem.msgs[mem.msgs.length - 1], isChip = !!(last && last.r === 'user' && Object.keys(PROMPTS).some(function (k) { return PROMPTS[k] === last.t; }));
    var q = {};
    if (!isChip) {
      mem.msgs.slice(-4).forEach(function (m, i, a) { var wgt = (m.r === 'user' && i === a.length - 1) ? 4 : 1; words(m.t.slice(0, 600)).forEach(function (w) { q[w] = Math.max(q[w] || 0, wgt); }); });
    }
    var scores = chunks.map(function (c) {
      var n = norm(c), sc = 0; Object.keys(q).forEach(function (w) { if (n.indexOf(w) >= 0) sc += q[w]; }); return sc;
    });
    var chosen = {}, used = 0, N = chunks.length;
    function take(i) { if (chosen[i] || used + chunks[i].length > LES_MAX) return false; chosen[i] = 1; used += chunks[i].length; return true; }
    var anyHit = scores.some(function (x) { return x > 0; });
    if (anyHit) {
      take(0);
      chunks.map(function (c, i) { return i; }).sort(function (a, b) { return scores[b] - scores[a] || a - b; }).forEach(function (i) { if (scores[i] > 0) take(i); });
      /* on ajoute les morceaux voisins pour garder le contexte */
      Object.keys(chosen).map(Number).forEach(function (i) { if (used < LES_MAX * 0.7) { if (i + 1 < N) take(i + 1); if (i > 0) take(i - 1); } });
    } else {
      /* pas de mot-clé (Résumé, Quiz…) : morceaux répartis sur toute la leçon */
      var per = Math.max(2, Math.floor(LES_MAX / (text.length / N))), step = N / Math.min(per, N);
      for (var k = 0; k < Math.min(per, N); k++) take(Math.min(N - 1, Math.floor(k * step)));
      take(N - 1);
    }
    var res = '', prev = -2;
    Object.keys(chosen).map(Number).sort(function (a, b) { return a - b; }).forEach(function (i) {
      res += (i === prev + 1 || !res ? '' : '\n[…]\n') + (res && i === prev + 1 ? '\n\n' : '') + chunks[i]; prev = i;
    });
    return '(Extraits de la leçon choisis pour cette question ; […] marque un passage non envoyé.)\n' + res;
  }
  function sysPrompt(les) {
    var s = BASE;
    if (mem.facts) s += '\n\nCE QUE TU SAIS DÉJÀ DE CET ÉLÈVE (ta mémoire, utilise-la naturellement sans la réciter) :\n' + mem.facts.slice(0, 800);
    if (les && les.text) s += '\n\nLEÇON DE L’ÉLÈVE — « ' + String(les.name || 'Sans titre').slice(0, 120) + ' » :\n' + pickLesson(les.text);
    return s;
  }

  /* ---------- Mémoire : Cloudinary (fichier JSON) + Firestore (pointeur) ---------- */
  function status() {
    var el = $('#aiSync'); if (!el) return;
    el.textContent = !uid() ? 'Mémoire gardée sur ce téléphone seulement (connecte-toi pour la sauvegarder en ligne).'
      : sync === 'ok' ? 'Mémoire sauvegardée en ligne ✓'
      : sync === 'err' ? 'Sauvegarde en ligne impossible pour l’instant (règles Firestore ou réseau). Elle reste sur ce téléphone.'
      : 'Mémoire prête.';
  }
  async function cloudLoad() {
    var id = uid(); if (!id) { status(); return; }
    try {
      var d = await firebase.firestore().collection('aiMemory').doc(id).get();
      if (d.exists) {
        var x = d.data();
        if (x && typeof x.url === 'string' && x.url.indexOf(CLD_BASE) === 0 && (x.t || 0) > (mem.t || 0)) {
          var r = await fetch(x.url, { cache: 'no-store' }), j = await r.json();
          if (j && typeof j === 'object') {
            var pa = mem.act || 0; mem = mk(j); mem.t = x.t; mem.act = Math.max(mem.act || 0, pa);
            saveLocal(false); if (!P.hidden) paint();
          }
        } else if ((mem.t || 0) > (x && x.t || 0)) dirty = true;
      } else if (mem.facts || mem.msgs.length) dirty = true;
      sync = 'ok';
    } catch (e) { sync = 'err'; }
    status();
  }
  async function cloudSave() {
    var id = uid(); if (!id || saving) { status(); return; }
    saving = true;
    try {
      var fd = new FormData();
      fd.append('file', new Blob([JSON.stringify({ facts: mem.facts, msgs: mem.msgs.slice(-30), t: mem.t, id: mem.id, act: mem.act, chats: (mem.chats || []).slice(0, 10).map(function (c) { return { id: c.id, title: c.title, t: c.t, msgs: c.msgs.slice(-20) }; }) })], { type: 'application/json' }), 'memoire.json');
      fd.append('upload_preset', CLD_PRESET);
      var r = await fetch('https://api.cloudinary.com/v1_1/' + CLD_NAME + '/raw/upload', { method: 'POST', body: fd });
      var j = await r.json();
      if (!j || typeof j.secure_url !== 'string' || j.secure_url.indexOf(CLD_BASE) !== 0) throw new Error('cloudinary');
      await firebase.firestore().collection('aiMemory').doc(id).set({ url: j.secure_url, t: mem.t });
      dirty = false; sync = 'ok';
    } catch (e) { sync = 'err'; }
    saving = false; status();
  }
  async function updateFacts() {
    if (!turns) return;
    var recent = mem.msgs.slice(-8).map(function (m) { return (m.r === 'user' ? 'Élève : ' : 'Assistant : ') + m.t.slice(0, 600); }).join('\n');
    var sys = 'Tu tiens la mémoire de X.Uni, un assistant d’étude. À partir de la mémoire actuelle et des derniers échanges, écris la mémoire mise à jour : prénom ou surnom, niveau ou filière, matières et leçons travaillées, points faibles, façon d’expliquer préférée, objectifs, infos utiles sur sa vie. ' +
      'Garde seulement des faits durables, sans détails inutiles ni informations sensibles (mots de passe, adresses, numéros). Maximum 900 caractères, texte brut, une ligne par fait. Réponds uniquement avec la mémoire.';
    try {
      var t = await gen(sys, [{ role: 'user', text: 'MÉMOIRE ACTUELLE :\n' + (mem.facts || '(vide)') + '\n\nDERNIERS ÉCHANGES :\n' + recent }], 500);
      if (t) { mem.facts = t.slice(0, 1200); turns = 0; dirty = true; saveLocal(); }
    } catch (e) {}
  }
  async function flush(force) {
    if (flushing) return; flushing = true;
    try { if (turns >= (force ? 2 : 4)) await updateFacts(); if (dirty) await cloudSave(); } finally { flushing = false; }
  }

  /* ---------- Écran ---------- */
  function verTag() { var m = chosenModel(), o = MODEL_OPTS.filter(function (x) { return x.id === m; })[0]; $('#aiVer').textContent = o ? o.short : ''; }
  var GLIST = null, GLIST_T = 0;
  async function groqModels(k, sig) {
    var pref = ['openai/gpt-oss-120b', 'openai/gpt-oss-20b', 'qwen/qwen3.6-27b'];
    if (GLIST && Date.now() - GLIST_T < 600000) return GLIST;
    try {
      var r = await fetch('https://api.groq.com/openai/v1/models', { headers: { 'Authorization': 'Bearer ' + k }, signal: sig });
      if (!r.ok) return pref;
      var j = await r.json(), ids = (j.data || []).map(function (m) { return m.id; }).filter(function (id) { return id && !/whisper|guard|safeguard|tts|orpheus|embed|allam|compound|prompt/i.test(id); });
      if (!ids.length) return pref;
      var out = pref.filter(function (m) { return ids.indexOf(m) >= 0; });
      ids.forEach(function (id) { if (out.indexOf(id) < 0 && out.length < 5) out.push(id); });
      GLIST = out.length ? out : pref; GLIST_T = Date.now();
      return GLIST;
    } catch (e) { if (sig && sig.aborted) throw e; return pref; }
  }
  function groqKey() { try { return (localStorage.getItem('uandi-groq-key') || '').trim(); } catch (e) { return ''; } }
  function savedKey() { try { return (localStorage.getItem(KK) || '').trim(); } catch (e) { return ''; } }
  function refreshKeyUI() {
    var v = $('#aiKey').value.trim(), k = savedKey();
    $('#aiKeyHelp').hidden = !!v;
    $('#aiKeyOk').hidden = !(k && v === k);
    $('#aiKey').type = (k && v === k) ? 'password' : 'text';
    var gv = $('#aiGroq').value.trim(), gs = groqKey();
    $('#aiGroqHelp').hidden = !!gv;
    $('#aiGroqOk').hidden = !(gs && gv === gs);
    $('#aiGroq').type = (gs && gv === gs) ? 'password' : 'text';
  }
  function modelNote() { var o = MODEL_OPTS.filter(function (x) { return x.id === $('#aiModel').value; })[0]; $('#aiModelNote').textContent = o ? o.note : ''; }
  function fillModels() {
    var m = $('#aiModel'); m.textContent = '';
    MODEL_OPTS.forEach(function (o) { var op = document.createElement('option'); op.value = o.id; op.textContent = o.label; m.appendChild(op); });
    m.value = chosenModel(); modelNote();
  }
  function open() { pill(''); if (!busy) Array.prototype.forEach.call(logEl.querySelectorAll('.ai-b.e'), function (n) { n.remove(); }); verTag(); fillLessons(); idleCheck(); mem.act = Date.now(); saveLocal(false); P.hidden = false; document.body.style.overflow = 'hidden'; paint(); cloudLoad(); }
  function close() { if (busy) pill('busy'); mem.act = Date.now(); saveLocal(false); P.hidden = true; sheet.hidden = true; histSheet.hidden = true; document.body.style.overflow = ''; flush(true); }
  var PROMPTS = {
    resume: 'Résumé de cette leçon, très court (maximum 150 mots) : idées clés et définitions à retenir, en liste à puces.',
    quiz: 'Quiz sur cette leçon : 5 questions au total, mais pose UNIQUEMENT la question 1 maintenant (une phrase, avec 3 choix A/B/C si utile), sans rien d’autre. J’attends ma réponse.',
    devoirs: 'Donne-moi 5 exercices courts sur cette leçon, de difficulté croissante, une ligne chacun, sans la correction.',
    explique: 'Explique cette leçon simplement, en 150 mots maximum, avec un exemple, puis pose-moi une seule question pour vérifier que j’ai compris.'
  };
  async function ask(text, retry, auto, fast) {
    if (busy || !text) return;
    setBusy(true); autoNote = false; mem.act = Date.now();
    var again = false;
    var lastM = mem.msgs[mem.msgs.length - 1], okDone = false;
    if (!retry && !(lastM && lastM.r === 'user' && lastM.t === text)) { mem.msgs.push({ r: 'user', t: text }); mem.msgs = mem.msgs.slice(-40); saveLocal(); }
    Array.prototype.forEach.call(logEl.querySelectorAll('.ai-b.e'), function (n) { n.remove(); });
    paint();
    var wait = bubble('assistant', '<span class="ai-dots"><i></i><i></i><i></i></span>'); wait.dataset.keep = '1'; down();
    var hint = setTimeout(function () { if (wait.isConnected && wait.querySelector('.ai-dots')) wait.insertAdjacentHTML('beforeend', '<div class="ai-wait">Ça prend du temps… tu peux arrêter avec le bouton ■.</div>'); }, 12000);
    var les = sel.value && window.uandiStudy ? window.uandiStudy.text(sel.value) : null;
    req = new AbortController();
    if (fast && chosenModel() === 'auto') req.models = ['gemini-2.5-flash-lite', 'gemini-2.5-flash', 'gemini-flash-latest'];
    req.onRetry = function (n, st) {
      if (!wait.isConnected || !wait.querySelector('.ai-dots')) return;
      var h = wait.querySelector('.ai-wait');
      if (!h) { wait.insertAdjacentHTML('beforeend', '<div class="ai-wait"></div>'); h = wait.querySelector('.ai-wait'); }
      h.textContent = st === 429 ? 'Beaucoup de demandes en même temps, X.Uni patiente et réessaie tout seul…' : 'Le service est très sollicité en ce moment, X.Uni réessaie…';
    };
    try {
      var raf = 0, curTxt = '';
      var rep = await genStream(sysPrompt(les), mem.msgs.slice(-6).map(function (m) { return { role: m.r, text: m.t.length > 1500 ? m.t.slice(0, 1500) + '…' : m.t }; }), fast ? 800 : 1500, function (txt) {
        curTxt = txt; if (raf) return;
        raf = requestAnimationFrame(function () { raf = 0; wait.innerHTML = md(curTxt); down(); });
      }, req);
      if (raf) cancelAnimationFrame(raf);
      if (!rep) rep = 'Je n’ai pas pu répondre à celle-ci. Reformule ta question ?';
      wait.innerHTML = md(rep); wait.removeAttribute('data-keep'); down(); okDone = true;
      mem.act = Date.now(); mem.msgs.push({ r: 'assistant', t: rep }); saveLocal(); dirty = true; turns++;
      if (turns >= 4) flush(false);
    } catch (e) {
      wait.remove(); var c = e && e.code;
      if (c === 'setup') { fail('Pour activer X.Uni, crée ta clé Groq gratuite (ça prend 1 minute), puis colle-la dans les réglages (bouton en haut).', true); sheet.hidden = false; status(); }
      else if (c === 'key') fail('Ta clé est refusée. Vérifie ta clé Groq dans les réglages (bouton en haut) ou crées-en une nouvelle.', true);
      else if (c === 'rate') fail('Trop de demandes pour le moment : la version gratuite est limitée. Patiente une minute, puis appuie sur Réessayer.', false, text);
      else if (c === 'stop') fail('Réponse arrêtée.', false, text);
      else if (c === 'stall') { if (!auto) again = true; else fail('La connexion a été coupée (l’appli était peut-être en arrière-plan).', false, text); }
      else if (c === 'slow') fail('Ça prend trop de temps. Réessaie avec une question plus courte.', false, text);
      else if (c === 'net') fail('Pas de connexion à X.Uni. Vérifie ton réseau et réessaie.', false, text);
      else if (e && (e.status === 503 || e.status === 500)) fail('Les serveurs sont très sollicités en ce moment. Réessaie dans quelques secondes.', false, text);
      else fail('X.Uni ne répond pas pour l’instant. Réessaie dans un moment.' + (e && e.status ? ' (erreur ' + e.status + (e.msg ? ' : ' + e.msg.slice(0, 300) : '') + ')' : ''), false, text);
    } finally { clearTimeout(hint); req = null; setBusy(false); if (P.hidden) pill(okDone ? 'done' : ''); }
    if (again) return ask(text, true, true);
  }
  $('#aiForm').addEventListener('submit', function (e) {
    e.preventDefault();
    if (busy) { stopReq(); return; }
    var t = inEl.value.trim(); if (!t) return;
    inEl.value = ''; inEl.style.height = 'auto'; ask(t);
  });
  inEl.addEventListener('focus', function () { down(); setTimeout(down, 120); setTimeout(down, 350); setTimeout(down, 700); });
  inEl.addEventListener('click', function () { setTimeout(down, 300); });
  if (window.visualViewport) window.visualViewport.addEventListener('resize', function () { if (!P.hidden && document.activeElement === inEl) { down(); setTimeout(down, 80); } });
  inEl.addEventListener('input', function () { inEl.style.height = 'auto'; inEl.style.height = Math.min(120, inEl.scrollHeight) + 'px'; });

  $('#aiChips').addEventListener('click', function (e) {
    var b = e.target.closest('button[data-p]'); if (!b) return;
    if (busy) return;
    if (!sel.value) { mem.msgs.push({ r: 'assistant', t: 'Choisis d’abord une leçon dans la liste « Leçon » ci-dessus. Pour en ajouter une : bouton +, puis Étudier, puis Importer.' }); saveLocal(); paint(); return; }
    ask(PROMPTS[b.dataset.p], false, false, true);
  });
  $('#aiClose').addEventListener('click', close);
  var histSheet = $('#aiHistSheet');
  function newChat() {
    if (busy) return;
    if (!mem.msgs.length) { autoNote = false; paint(true); return; }
    updateFacts(); /* lit la conversation tout de suite, répond en arrière-plan */
    fresh(); autoNote = false; dirty = true; saveLocal(); paint(true); cloudSave();
  }
  function fmtDate(t) { try { return new Date(t).toLocaleString('fr-FR', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }); } catch (e) { return ''; } }
  var selMode = false, selIds = {};
  function selCount() { return Object.keys(selIds).length; }
  function histUi() {
    $('#aiHistNew').hidden = selMode;
    $('#aiHistSel').textContent = selMode ? 'Annuler la sélection' : 'Choisir des conversations à supprimer';
    var d = $('#aiHistDel'); d.hidden = !selMode; d.disabled = !selCount(); d.textContent = 'Supprimer (' + selCount() + ')';
    histPaint();
  }
  function histPaint() {
    var box = $('#aiHistList'); box.textContent = '';
    var rows = [];
    if (mem.msgs.length) rows.push({ id: mem.id, title: cTitle(mem.msgs), t: mem.act || mem.t, cur: true });
    (mem.chats || []).forEach(function (c) { rows.push({ id: c.id, title: c.title, t: c.t }); });
    $('#aiHistSel').hidden = !rows.length;
    if (!rows.length) { var e = document.createElement('p'); e.className = 'ai-note'; e.textContent = 'Aucune conversation pour l’instant.'; box.appendChild(e); return; }
    rows.forEach(function (r) {
      var row = document.createElement('div'); row.className = 'ai-hrow' + (r.cur ? ' cur' : '') + (selMode && selIds[r.id] ? ' on' : '');
      var b = document.createElement('button'); b.type = 'button'; b.className = 'ai-hmain'; b.dataset.id = r.id;
      if (selMode) { var ck = document.createElement('span'); ck.className = 'ai-hck'; ck.textContent = selIds[r.id] ? '☑' : '☐'; ck.style.flex = 'none'; b.appendChild(ck); }
      var tx = document.createElement('span');
      var bt = document.createElement('b'); bt.textContent = r.title;
      var sm = document.createElement('small'); sm.textContent = (r.cur ? 'En cours · ' : '') + fmtDate(r.t);
      tx.appendChild(bt); tx.appendChild(sm); b.appendChild(tx); row.appendChild(b);
      box.appendChild(row);
    });
  }
  function selDelete() {
    var ids = Object.keys(selIds); if (!ids.length) return;
    if (!confirm('Supprimer ' + ids.length + ' conversation' + (ids.length > 1 ? 's' : '') + ' ? C’est définitif.')) return;
    var cur = !!selIds[mem.id];
    mem.chats = (mem.chats || []).filter(function (c) { return !selIds[c.id]; });
    if (cur) { mem.msgs = []; mem.id = newId(); mem.act = Date.now(); autoNote = false; paint(true); }
    selMode = false; selIds = {}; dirty = true; saveLocal(); histUi(); cloudSave();
  }
  function openChat(id) {
    if (busy) return;
    if (id === mem.id) { histSheet.hidden = true; return; }
    var i = -1; (mem.chats || []).forEach(function (c, k) { if (c.id === id) i = k; });
    if (i < 0) return;
    archive();
    var j = -1; mem.chats.forEach(function (c, k) { if (c.id === id) j = k; });
    var c = mem.chats.splice(j, 1)[0];
    mem.msgs = c.msgs.slice(); mem.id = c.id; mem.act = Date.now(); autoNote = false;
    dirty = true; saveLocal(); histSheet.hidden = true; paint(true); cloudSave();
  }
  $('#aiNew').addEventListener('click', newChat);
  $('#aiHistB').addEventListener('click', function () { selMode = false; selIds = {}; histUi(); histSheet.hidden = false; });
  $('#aiHistSel').addEventListener('click', function () { selMode = !selMode; selIds = {}; histUi(); });
  $('#aiHistDel').addEventListener('click', selDelete);
  $('#aiHistClose').addEventListener('click', function () { histSheet.hidden = true; });
  histSheet.addEventListener('click', function (e) { if (e.target === histSheet) histSheet.hidden = true; });
  $('#aiHistNew').addEventListener('click', function () { histSheet.hidden = true; newChat(); });
  $('#aiHistList').addEventListener('click', function (e) {
    var b = e.target.closest('button[data-id]'); if (!b) return;
    var id = b.dataset.id;
    if (selMode) {
      if (id === mem.id && busy) return;
      if (selIds[id]) delete selIds[id]; else selIds[id] = 1;
      histUi(); return;
    }
    openChat(id);
  });
  $('#aiCfg').addEventListener('click', function () {
    $('#aiKey').value = savedKey(); $('#aiGroq').value = groqKey(); refreshKeyUI(); fillModels();
    $('#aiFacts').value = mem.facts; status(); sheet.hidden = false;
  });
  $('#aiKey').addEventListener('input', refreshKeyUI);
  $('#aiGroq').addEventListener('input', refreshKeyUI);
  $('#aiModel').addEventListener('change', modelNote);
  $('#aiShClose').addEventListener('click', function () { sheet.hidden = true; });
  $('#aiSave').addEventListener('click', function () {
    try { var k = $('#aiKey').value.trim(); if (k) localStorage.setItem(KK, k); else localStorage.removeItem(KK); } catch (e) {}
    try { var gq = $('#aiGroq').value.trim(); if (gq) localStorage.setItem('uandi-groq-key', gq); else localStorage.removeItem('uandi-groq-key'); } catch (e) {}
    try { localStorage.setItem('uandi-ai-model', $('#aiModel').value); } catch (e) {}
    MODELS = modelOrder(chosenModel()); verTag(); refreshKeyUI();
    var f = $('#aiFacts').value.trim().slice(0, 1200);
    if (f !== mem.facts) { mem.facts = f; dirty = true; saveLocal(); cloudSave(); }
    sheet.hidden = true;
  });
  $('#aiWipe').addEventListener('click', function () {
    if (!confirm('Effacer toute la mémoire de X.Uni et la conversation ?')) return;
    mem = mk({ t: Date.now() }); autoNote = false; turns = 0; dirty = true; saveLocal(false); $('#aiFacts').value = ''; paint(true); cloudSave();
  });
  document.addEventListener('visibilitychange', function () {
    if (document.visibilityState === 'hidden') { if (!P.hidden) { mem.act = Date.now(); saveLocal(false); } if (dirty || turns) flush(true); return; }
    if (!P.hidden && idleCheck()) { histSheet.hidden = true; paint(true); }
    if (busy && req && Date.now() - (req.last || 0) > 4000) { req.stall = true; req.abort(); }
  });
  window.uandiAI = { open: open, close: close };
} catch (e) { console.warn('Assistant IA :', e); } })();
