/* U&I — js/modules/etudier.js
   Module Étudier : importer, résumer, quiz, devoirs */
(function(){try{
var $=function(s){return document.querySelector(s)},KEY='uandi-study';
var S={lessons:[],cur:null,fs:1.05,pos:{},view:'text',hits:[],hi:-1,reading:false,t:1500,tm:0};
try{var d0=JSON.parse(localStorage.getItem(KEY)||'{}');S.lessons=d0.lessons||[];S.cur=d0.cur||null;S.fs=d0.fs||1.05}catch(e){}
var tt;function toast(m){var t=$('#stToast');t.textContent=m;t.classList.add('on');clearTimeout(tt);tt=setTimeout(function(){t.classList.remove('on')},2600)}
function lesson(){return S.lessons.filter(function(l){return l.id===S.cur})[0]}

/* ---------- Stockage (IndexedDB : grande capacité, images comprises) ---------- */
var DB=null;
function idbOpen(){return new Promise(function(ok,ko){try{var r=indexedDB.open('uandi-study-db',1);r.onupgradeneeded=function(){r.result.createObjectStore('kv')};r.onsuccess=function(){ok(r.result)};r.onerror=function(){ko(r.error)};r.onblocked=function(){ko(new Error('blocked'))}}catch(e){ko(e)}})}
function kv(mode,fn){return new Promise(function(ok,ko){if(!DB)return ko(new Error('nodb'));var tx=DB.transaction('kv',mode),r=fn(tx.objectStore('kv'));tx.oncomplete=function(){ok(r&&r.result)};tx.onerror=tx.onabort=function(){ko(tx.error||new Error('tx'))}})}
function kvGet(k){return kv('readonly',function(s){return s.get(k)})}
function kvSet(k,v){return kv('readwrite',function(s){return s.put(v,k)})}
function kvDel(k){return kv('readwrite',function(s){return s.delete(k)})}
function lsSave(){try{localStorage.setItem(KEY,JSON.stringify({lessons:S.lessons,cur:S.cur,fs:S.fs}))}catch(e){toast('Mémoire pleine : supprime une leçon')}}
function saveMeta(){if(!DB)return lsSave();return kvSet('meta',{ids:S.lessons.map(function(l){return l.id}),cur:S.cur,fs:S.fs,pos:S.pos}).catch(function(){toast('Sauvegarde impossible')})}
function saveLesson(l){if(!DB){lsSave();return Promise.resolve()}return kvSet('l:'+l.id,l).catch(function(){toast('Mémoire pleine : supprime une leçon')})}
function save(){return saveMeta()}

/* ---------- Outils texte ---------- */
function esc(s){return String(s).replace(/[&<>"]/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]})}
function unesc(s){return s.replace(/&quot;/g,'"').replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&amp;/g,'&')}
function txt(h){var t=document.createElement('template');t.innerHTML=String(h).replace(/<br>/g,' ');return(t.content.textContent||'').replace(/\s+/g,' ').trim()}
function trimH(h){return h.replace(/^(?:\s|<br>|\u2003|&nbsp;)+|(?:\s|<br>|\u2003|&nbsp;)+$/g,'')}
function okSrc(u){return /^data:image\/(png|jpe?g|gif|webp|bmp|svg\+xml)/i.test(u)||/^https?:\/\//i.test(u)}
function imgTag(src,alt){return'<img src="'+esc(src)+'"'+(alt?' alt="'+esc(alt)+'"':'')+'>'}
function mkTable(rows){
  var h='<table>',x=[];
  rows.forEach(function(r){h+='<tr>';var xr=[];
    r.forEach(function(c){var tg=c.th?'th':'td';h+='<'+tg+(c.cs>1?' colspan="'+c.cs+'"':'')+(c.rs>1?' rowspan="'+c.rs+'"':'')+'>'+(c.h||'')+'</'+tg+'>';if(c.x)xr.push(c.x)});
    h+='</tr>';if(xr.length)x.push(xr.join(', '))});
  return{t:'tbl',h:h+'</table>',x:x.join('. ')}}
function blocksHtml(bs){return bs.map(function(b){
  if(b.t==='tbl')return b.h;
  if(b.t==='img')return imgTag(b.src);
  if(b.t==='h')return'<b>'+esc(b.x)+'</b>';
  if(b.t==='li')return(b.mk?esc(b.mk)+'&nbsp;':'')+(b.h||esc(b.x));
  return b.h||esc(b.x)}).join('<br>')}

/* ---------- Images : réduction avant stockage ---------- */
function blobToUrl(b){return new Promise(function(ok){var r=new FileReader();r.onload=function(){ok(r.result)};r.onerror=function(){ok(null)};r.readAsDataURL(b)})}
function shrink(blob,max){return new Promise(function(ok){
  max=max||1400;var u=URL.createObjectURL(blob),im=new Image();
  im.onload=function(){try{
    var w=im.naturalWidth,h=im.naturalHeight,k=Math.min(1,max/Math.max(w,h));
    if(k===1&&blob.size<300000){URL.revokeObjectURL(u);blobToUrl(blob).then(ok);return}
    var c=document.createElement('canvas');c.width=Math.max(1,Math.round(w*k));c.height=Math.max(1,Math.round(h*k));
    var g=c.getContext('2d'),jpg=blob.type==='image/jpeg';
    if(jpg){g.fillStyle='#fff';g.fillRect(0,0,c.width,c.height)}
    g.drawImage(im,0,0,c.width,c.height);URL.revokeObjectURL(u);
    var out=jpg?c.toDataURL('image/jpeg',.82):c.toDataURL('image/png');
    if(!jpg&&out.length>800000){var c2=document.createElement('canvas');c2.width=c.width;c2.height=c.height;var g2=c2.getContext('2d');g2.fillStyle='#fff';g2.fillRect(0,0,c.width,c.height);g2.drawImage(c,0,0);out=c2.toDataURL('image/jpeg',.82)}
    ok(out)}catch(e){ok(null)}};
  im.onerror=function(){URL.revokeObjectURL(u);ok(null)};im.src=u})}

/* ---------- Texte brut / Markdown / texte collé (tableaux, listes, titres) ---------- */
function mdInline(s){
  var h=esc(s);
  h=h.replace(/`([^`]+)`/g,'<code>$1</code>');
  h=h.replace(/\*\*([^*]+)\*\*|__([^_]+)__/g,function(m,a,b){return'<b>'+(a||b)+'</b>'});
  h=h.replace(/(^|[^*\w])\*([^*\s][^*]*)\*(?!\*)/g,'$1<i>$2</i>');
  h=h.replace(/~~([^~]+)~~/g,'<s>$1</s>');
  h=h.replace(/\[([^\]]+)\]\(([^)]+)\)/g,'$1');
  return h}
function plain(s){return s.replace(/\*\*|__|`/g,'').replace(/(^|\s)\*(\S[^*]*)\*/g,'$1$2')}
function parseCSV(t){
  var first=t.split('\n')[0]||'',dl=[',',';','\t','|'].map(function(c){return[c,first.split(c).length]}).sort(function(a,b){return b[1]-a[1]})[0][0];
  var rows=[],row=[],f='',q=false;
  for(var i=0;i<t.length;i++){var c=t[i];
    if(q){if(c==='"'){if(t[i+1]==='"'){f+='"';i++}else q=false}else f+=c}
    else if(c==='"')q=true;
    else if(c===dl){row.push(f);f=''}
    else if(c==='\n'||c==='\r'){if(c==='\r'&&t[i+1]==='\n')i++;row.push(f);f='';rows.push(row);row=[]}
    else f+=c}
  if(f!==''||row.length){row.push(f);rows.push(row)}
  rows=rows.filter(function(r){return r.join('').trim()!==''});if(!rows.length)return[];
  var n=Math.max.apply(null,rows.map(function(r){return r.length}));
  return[mkTable(rows.map(function(r,ri){var cs=[];for(var k=0;k<n;k++){var v=(r[k]||'').trim();cs.push({h:esc(v),x:v,th:ri===0})}return cs}))]}
function parseText(src){
  var L=src.replace(/\r/g,'').replace(/\u00a0/g,' ').split('\n'),B=[],buf=[],i;
  function flush(){if(!buf.length)return;
    var avg=buf.reduce(function(a,s){return a+s.length},0)/buf.length;
    if(buf.length>1&&avg>=58){var s=buf.join(' ').replace(/\s+/g,' ').trim();B.push({t:'p',x:plain(s),h:mdInline(s)})}
    else B.push({t:'p',x:buf.map(plain).join(' '),h:buf.map(mdInline).join('<br>')});
    buf=[]}
  function tabCells(l){return l.replace(/[ \r]+$/,'').split('\t').map(function(c){return c.trim()})}
  function gapCells(l){return l.trim().split(/ {2,}|\t/)}
  function mdCells(l){return l.trim().replace(/^\|/,'').replace(/\|$/,'').split('|').map(function(c){return c.trim()})}
  function depth(sp){return Math.min(3,Math.floor(sp.replace(/\t/g,'  ').length/2))}
  function tableFrom(rows,hdr){
    var n=Math.max.apply(null,rows.map(function(r){return r.length}));
    return mkTable(rows.map(function(r,ri){var cs=[];for(var k=0;k<n;k++){var v=r[k]||'';cs.push({h:mdInline(v),x:plain(v),th:hdr&&ri===0})}return cs}))}
  for(i=0;i<L.length;i++){
    var raw=L[i],s=raw.trim(),hasTab=raw.indexOf('\t')>-1;
    if(!s&&!hasTab){flush();continue}
    if(!s)continue;
    if(/^```/.test(s)){flush();var code=[];i++;while(i<L.length&&!/^```/.test(L[i].trim())){code.push(L[i]);i++}
      var ct=code.join('\n');if(ct.trim())B.push({t:'p',c:'pre',x:ct,h:esc(ct)});continue}
    /* tableau Markdown */
    if(s.indexOf('|')>-1&&i+1<L.length&&L[i+1].indexOf('-')>-1&&/^\s*\|?[\s:|-]*-{2,}[\s:|-]*\|?\s*$/.test(L[i+1])){
      flush();var rows=[mdCells(s)];i+=2;
      while(i<L.length&&L[i].trim()&&L[i].indexOf('|')>-1){rows.push(mdCells(L[i]));i++}
      i--;B.push(tableFrom(rows,true));continue}
    /* tableau copié depuis Word / Excel / un site : colonnes séparées par des tabulations */
    if(hasTab){
      var g=[],j=i;
      while(j<L.length){
        if(L[j].indexOf('\t')>-1){g.push(tabCells(L[j]));j++}
        else if(L[j].trim()&&L[j].trim().length<60&&g.length&&j+1<L.length&&L[j+1].indexOf('\t')>-1){g.push([L[j].trim()]);j++}
        else break}
      var mxc=Math.max.apply(null,g.map(function(r){return r.length}));
      if(g.length>=2||mxc>=3){flush();
        var hdr=g.length>1&&g[0].length>=2&&g[0].every(function(c){return c!==''});
        B.push(tableFrom(g,hdr));i=j-1;continue}}
    /* colonnes séparées par plusieurs espaces (3 lignes de suite minimum) */
    var gc=gapCells(raw);
    if(gc.length>=2&&gc.every(function(c){return c.length<45})){
      var j2=i,rr=[];
      while(j2<L.length&&L[j2].trim()&&gapCells(L[j2]).length===gc.length){rr.push(gapCells(L[j2]));j2++}
      if(rr.length>=3){flush();B.push(tableFrom(rr,true));i=j2-1;continue}}
    /* citation */
    if(/^>\s?/.test(s)){flush();var q=[];while(i<L.length&&/^>\s?/.test(L[i].trim())){q.push(L[i].trim().replace(/^>\s?/,''));i++}i--;
      var qs=q.join(' ').trim();if(qs)B.push({t:'p',c:'q',x:plain(qs),h:mdInline(qs)});continue}
    /* image Markdown */
    var im=s.match(/^!\[([^\]]*)\]\(([^)\s]+)\)$/);
    if(im&&okSrc(im[2])){flush();B.push({t:'img',src:im[2],x:im[1]});continue}
    if(/^(-{3,}|\*{3,}|_{3,})$/.test(s)){flush();continue}
    var m=s.match(/^(#{1,6})\s+(.+)/),lv=0,x=s;
    if(m){lv=m[1].length;x=m[2]}
    else if(s.length<90&&!/[.;,:]$/.test(s)){
      var n=s.match(/^(\d+(?:\.\d+)*|[IVXL]+)[.)]?\s+\S/);
      if(n&&/^\d/.test(n[1]))lv=n[1].split('.').length;
      else if(n)lv=1;
      else if(/^(chapitre|partie|section|le[cç]on|unité|module|titre|introduction|conclusion|résumé|définition|exemple|exercice)\b/i.test(s))lv=1;
      else if(s.length>3&&s===s.toUpperCase()&&/[A-ZÀ-Ý]{3}/.test(s))lv=1;
      else if(s.length<70&&!buf.length&&(!L[i-1]||!L[i-1].trim())&&(!L[i+1]||!L[i+1].trim())&&/^[A-ZÀ-Ý]/.test(s))lv=2}
    if(lv){flush();B.push({t:'h',l:Math.min(lv,4),x:plain(x).trim()});continue}
    var bl=raw.match(/^(\s*)([-*•–·▪●◦])\s+(.+)/);
    if(bl){flush();B.push({t:'li',d:depth(bl[1]),mk:'•',x:plain(bl[3]),h:mdInline(bl[3])});continue}
    var nl=raw.match(/^(\s*)(\d+[.)]|[a-zA-Z][.)])\s+(.+)/);
    if(nl){flush();B.push({t:'li',d:depth(nl[1]),mk:nl[2],x:plain(nl[3]),h:mdInline(nl[3])});continue}
    buf.push(s)}
  flush();return B}

/* ---------- HTML (fichiers .html et contenu riche collé) ---------- */
var SKIP=/^(script|style|noscript|head|template|iframe|object|embed|button|select|input|textarea|audio|video|canvas|map|link|meta)$/;
var BLK=/^(address|article|aside|blockquote|body|caption|center|dd|details|div|dl|dt|fieldset|figcaption|figure|footer|form|h[1-6]|header|hr|html|li|main|nav|ol|p|pre|section|summary|table|tbody|thead|tfoot|tr|ul)$/;
function hidden(n){return n.hidden||/display\s*:\s*none|visibility\s*:\s*hidden/i.test(n.getAttribute('style')||'')}
function svgTag(n){try{var s=new XMLSerializer().serializeToString(n);if(!/xmlns=/.test(s))s=s.replace('<svg','<svg xmlns="http://www.w3.org/2000/svg"');return imgTag('data:image/svg+xml;charset=utf-8,'+encodeURIComponent(s))}catch(e){return''}}
function inl(n){
  if(n.nodeType===3)return esc(n.nodeValue.replace(/\s+/g,' '));
  if(n.nodeType!==1)return'';
  var tg=n.tagName.toLowerCase();
  if(SKIP.test(tg)||hidden(n))return'';
  if(tg==='br')return'<br>';
  if(tg==='img'){var s=n.getAttribute('src')||'';return okSrc(s)?imgTag(s,n.getAttribute('alt')):''}
  if(tg==='svg')return svgTag(n);
  var st=(n.getAttribute('style')||'').toLowerCase(),h='';
  for(var c=n.firstChild;c;c=c.nextSibling)h+=inl(c);
  if(!h)return'';
  var w=function(t,s){return'<'+t+'>'+s+'</'+t+'>'};
  if(tg==='sup')h=w('sup',h);else if(tg==='sub')h=w('sub',h);
  if(/^(code|kbd|tt|samp)$/.test(tg))h=w('code',h);
  if(/^(s|strike|del)$/.test(tg)||/line-through/.test(st))h=w('s',h);
  if(tg==='u'||tg==='ins'||/text-decoration[^;]*underline/.test(st))h=w('u',h);
  if(/^(i|em|cite|dfn|var)$/.test(tg)||/font-style\s*:\s*italic/.test(st))h=w('i',h);
  if(/^(b|strong)$/.test(tg)||/font-weight\s*:\s*(bold|[6-9]00)/.test(st))h=w('b',h);
  if(tg==='mark')h='<span class="hl">'+h+'</span>';
  return h}
function cellHtml(c){
  var out='';
  for(var k=c.firstChild;k;k=k.nextSibling){
    if(k.nodeType===1){
      var tg=k.tagName.toLowerCase();
      if(SKIP.test(tg)||hidden(k))continue;
      if(tg==='table'){var tb=tableOf(k);if(tb)out+=tb.h;continue}
      if(/^(p|div|li|ul|ol|h[1-6]|blockquote|pre|section|tr|dd|dt)$/.test(tg)){
        var s=cellHtml(k);if(s){if(tg==='li')s='• '+s;out+=(out&&!/<br>$/.test(out)?'<br>':'')+s+'<br>'}continue}}
    out+=inl(k)}
  return trimH(out)}
function tableOf(t){
  var trs=[];
  for(var c=t.firstElementChild;c;c=c.nextElementSibling){
    var tg=c.tagName.toLowerCase();
    if(tg==='tr')trs.push(c);
    else if(/^(thead|tbody|tfoot)$/.test(tg))for(var r=c.firstElementChild;r;r=r.nextElementSibling)if(r.tagName.toLowerCase()==='tr')trs.push(r)}
  var rows=[];
  trs.forEach(function(tr){var row=[],inHead=tr.parentNode&&tr.parentNode.tagName.toLowerCase()==='thead';
    for(var c=tr.firstElementChild;c;c=c.nextElementSibling){
      var tg=c.tagName.toLowerCase();if(tg!=='td'&&tg!=='th')continue;
      var h=cellHtml(c);
      row.push({h:h,x:txt(h),cs:Math.min(50,+c.getAttribute('colspan')||1),rs:Math.min(200,+c.getAttribute('rowspan')||1),th:tg==='th'||inHead})}
    rows.push(row)});
  return rows.length?mkTable(rows):null}
function parseHTML(html){
  var doc=new DOMParser().parseFromString(html,'text/html'),B=[],buf='',cls='';
  function flush(){var h=trimH(buf);buf='';if(!h)return;var x=txt(h);
    if(x){var b={t:'p',h:h,x:x};if(cls)b.c=cls;B.push(b)}
    else h.replace(/<img [^>]*src="([^"]*)"[^>]*>/g,function(m,s){B.push({t:'img',src:unesc(s),x:''})})}
  function liOf(c,d,mk){
    var h='',subs=[],tabs=[];
    for(var k=c.firstChild;k;k=k.nextSibling){
      if(k.nodeType===1){var tg=k.tagName.toLowerCase();
        if(tg==='ul'||tg==='ol'){subs.push(k);continue}
        if(tg==='table'){var tb=tableOf(k);if(tb)tabs.push(tb);continue}
        if(/^(p|div|section)$/.test(tg)){var s=cellHtml(k);if(s)h+=(h?'<br>':'')+s;continue}}
      h+=inl(k)}
    h=trimH(h);var x=txt(h);
    if(x||/<img/.test(h))B.push({t:'li',d:Math.min(d,4),mk:mk,h:h,x:x});
    tabs.forEach(function(t){B.push(t)});
    subs.forEach(function(s){listOf(s,d+1)})}
  function listOf(l,d){
    var ord=l.tagName.toLowerCase()==='ol',n=+(l.getAttribute('start')||1);
    for(var c=l.firstElementChild;c;c=c.nextElementSibling){
      if(c.tagName.toLowerCase()!=='li'||hidden(c))continue;
      liOf(c,d,ord?(n++)+'.':['•','◦','▪'][d%3])}}
  function walk(n,d){
    for(var c=n.firstChild;c;c=c.nextSibling){
      if(c.nodeType===3){buf+=esc(c.nodeValue.replace(/\s+/g,' '));continue}
      if(c.nodeType!==1)continue;
      var tg=c.tagName.toLowerCase();
      if(SKIP.test(tg)||hidden(c))continue;
      if(tg==='br'){buf+='<br>';continue}
      if(/^h[1-6]$/.test(tg)){flush();var x=txt(inl(c));if(x)B.push({t:'h',l:Math.min(+tg[1],4),x:x});continue}
      if(tg==='table'){flush();var cap=c.querySelector('caption');if(cap){var ct=txt(inl(cap));if(ct)B.push({t:'p',x:ct,h:'<b>'+esc(ct)+'</b>'})}var tb=tableOf(c);if(tb)B.push(tb);continue}
      if(tg==='ul'||tg==='ol'){flush();listOf(c,0);continue}
      if(tg==='pre'){flush();var pt=c.textContent.replace(/\n+$/,'');if(pt.trim())B.push({t:'p',c:'pre',x:pt,h:esc(pt)});continue}
      if(tg==='blockquote'){flush();var sv=cls;cls='q';walk(c);flush();cls=sv;continue}
      if(tg==='svg'){buf+=svgTag(c);continue}
      if(tg==='img'){buf+=inl(c);continue}
      if(tg==='hr'){flush();continue}
      if(tg==='caption')continue;
      if(BLK.test(tg)){flush();walk(c);flush();continue}
      buf+=inl(c)}}
  walk(doc.body||doc.documentElement);flush();
  return B}

/* ---------- ZIP + DOCX (tableaux, listes, images, zones de texte, notes) ---------- */
function zipOpen(buf){
  var v=new DataView(buf),u=new Uint8Array(buf),i=buf.byteLength-22;
  while(i>=0&&v.getUint32(i,true)!==0x06054b50)i--;
  if(i<0)throw new Error('zip');
  var n=v.getUint16(i+10,true),p=v.getUint32(i+16,true),idx={};
  for(var k=0;k<n;k++){
    var nl=v.getUint16(p+28,true),el=v.getUint16(p+30,true),cl=v.getUint16(p+32,true);
    var nm=new TextDecoder().decode(u.subarray(p+46,p+46+nl));
    idx[nm]={m:v.getUint16(p+10,true),cs:v.getUint32(p+20,true),lo:v.getUint32(p+42,true)};
    p+=46+nl+el+cl}
  function bytes(name){var e=idx[name];if(!e)return Promise.resolve(null);
    var st=e.lo+30+v.getUint16(e.lo+26,true)+v.getUint16(e.lo+28,true),data=u.subarray(st,st+e.cs);
    if(e.m===0)return Promise.resolve(data);
    var ds=new DecompressionStream('deflate-raw'),w=ds.writable.getWriter();w.write(data);w.close();
    return new Response(ds.readable).arrayBuffer().then(function(b){return new Uint8Array(b)})}
  return{bytes:bytes,text:function(n){return bytes(n).then(function(b){return b?new TextDecoder().decode(b):null})}}}
function A(n,l){if(!n)return null;var a=n.attributes;for(var i=0;i<a.length;i++)if(a[i].localName===l)return a[i].value;return null}
function W(n,name){if(!n)return null;for(var c=n.firstElementChild;c;c=c.nextElementSibling)if(c.localName===name)return c;return null}
function isOn(rp,n){var e=W(rp,n);if(!e)return false;var v=A(e,'val');return!(v!==null&&/^(0|false|off|none)$/i.test(v))}
function alpha(n){var s='';while(n>0){n--;s=String.fromCharCode(65+n%26)+s;n=Math.floor(n/26)}return s}
function roman(n){var r=[[1000,'M'],[900,'CM'],[500,'D'],[400,'CD'],[100,'C'],[90,'XC'],[50,'L'],[40,'XL'],[10,'X'],[9,'IX'],[5,'V'],[4,'IV'],[1,'I']],s='';r.forEach(function(p){while(n>=p[0]){s+=p[1];n-=p[0]}});return s}
function fmtNum(n,f){switch(f){case'decimalZero':return(n<10?'0':'')+n;case'lowerLetter':return alpha(n).toLowerCase();case'upperLetter':return alpha(n);case'lowerRoman':return roman(n).toLowerCase();case'upperRoman':return roman(n);default:return''+n}}
function normPath(p){var o=[];p.split('/').forEach(function(s){if(s==='..')o.pop();else if(s&&s!=='.')o.push(s)});return o.join('/')}
function parseDocx(buf){
  var Z=zipOpen(buf);
  return Promise.all(['word/document.xml','word/_rels/document.xml.rels','word/styles.xml','word/numbering.xml','word/footnotes.xml','word/endnotes.xml'].map(function(n){return Z.text(n)})).then(function(r){
    if(!r[0])throw new Error('docx');
    var XP=function(s){return s?new DOMParser().parseFromString(s,'application/xml'):null};
    var D=XP(r[0]),R=XP(r[1]),ST=XP(r[2]),NU=XP(r[3]),FN=XP(r[4]),EN=XP(r[5]);
    var rel={};
    if(R)Array.prototype.forEach.call(R.getElementsByTagName('Relationship'),function(e){
      if(/\/image$/.test(e.getAttribute('Type')||'')&&e.getAttribute('TargetMode')!=='External'){
        var t=e.getAttribute('Target')||'';rel[e.getAttribute('Id')]=t.charAt(0)==='/'?t.slice(1):normPath('word/'+t)}});
    var used={};r[0].replace(/\b\w+:(?:embed|id)="([^"]+)"/g,function(m,id){if(rel[id])used[id]=1});
    var imgs={},MIME={png:'image/png',jpg:'image/jpeg',jpeg:'image/jpeg',gif:'image/gif',bmp:'image/bmp',webp:'image/webp'};
    var jobs=Object.keys(used).map(function(id){
      var mime=MIME[(rel[id].split('.').pop()||'').toLowerCase()];
      if(!mime){imgs[id]=null;return Promise.resolve()}
      return Z.bytes(rel[id]).then(function(b){return b?shrink(new Blob([b],{type:mime})):null}).then(function(u){imgs[id]=u},function(){imgs[id]=null})});
    return Promise.all(jobs).then(function(){return buildDocx(D,ST,NU,FN,EN,imgs)})})}
function buildDocx(D,ST,NU,FN,EN,imgs){
  /* styles */
  var sty={},sc={};
  if(ST)Array.prototype.forEach.call(ST.getElementsByTagNameNS('*','style'),function(s){
    var id=A(s,'styleId');if(!id)return;
    var pp=W(s,'pPr'),rp=W(s,'rPr'),ol=pp&&W(pp,'outlineLvl'),np=pp&&W(pp,'numPr'),ni=np&&W(np,'numId'),il=np&&W(np,'ilvl');
    sty[id]={n:A(W(s,'name'),'val')||'',b:A(W(s,'basedOn'),'val'),ol:ol?+A(ol,'val'):null,num:ni?A(ni,'val'):null,il:il?+A(il,'val'):null,r:{b:isOn(rp,'b'),i:isOn(rp,'i'),u:isOn(rp,'u')}}});
  function sInfo(id){
    if(sc[id])return sc[id];
    var o={h:0,num:null,il:0,r:{}},chain=[],k=id,g=0;
    while(k&&sty[k]&&g++<8){chain.push(sty[k]);k=sty[k].b}
    for(var j=chain.length-1;j>=0;j--){var s=chain[j],m=/^(?:heading|titre)\s*(\d)$/i.exec(s.n);
      if(m)o.h=+m[1];else if(/^(title|titre)$/i.test(s.n))o.h=1;else if(/^(subtitle|sous-titre)$/i.test(s.n))o.h=2;
      if(s.ol!==null)o.h=s.ol<9?s.ol+1:0;
      if(s.num!==null){o.num=s.num;if(s.il!==null)o.il=s.il}
      for(var f in s.r)if(s.r[f])o.r[f]=1}
    return sc[id]=o}
  /* numérotation */
  var absN={},numMap={},ctr={};
  if(NU){
    Array.prototype.forEach.call(NU.getElementsByTagNameNS('*','abstractNum'),function(an){
      var lv={};for(var l=an.firstElementChild;l;l=l.nextElementSibling){if(l.localName!=='lvl')continue;
        var st=W(l,'start');lv[+A(l,'ilvl')]={f:A(W(l,'numFmt'),'val')||'decimal',t:A(W(l,'lvlText'),'val')||'',s:st?+A(st,'val'):1}}
      absN[A(an,'abstractNumId')]=lv});
    Array.prototype.forEach.call(NU.getElementsByTagNameNS('*','num'),function(n){
      var ov={};for(var o=n.firstElementChild;o;o=o.nextElementSibling){if(o.localName!=='lvlOverride')continue;var so=W(o,'startOverride');if(so)ov[+A(o,'ilvl')]=+A(so,'val')}
      numMap[A(n,'numId')]={a:A(W(n,'abstractNumId'),'val'),ov:ov}})}
  function marker(numId,il){
    var nm=numMap[numId];if(!nm)return'•';
    var lvs=absN[nm.a]||{},lv=lvs[il];if(!lv)return'•';
    var c=ctr[numId]||(ctr[numId]=[]),st=nm.ov[il]!==undefined?nm.ov[il]:lv.s;
    c[il]=c[il]===undefined?st:c[il]+1;for(var j=il+1;j<10;j++)c[j]=undefined;
    if(lv.f==='bullet')return['•','◦','▪'][il%3];
    if(lv.f==='none')return'';
    var out=lv.t.replace(/%(\d)/g,function(m,d){var k=+d-1,L=lvs[k]||lv,v=c[k]===undefined?L.s:c[k];return fmtNum(v,L.f)});
    return out||(fmtNum(c[il],lv.f)+'.')}
  var fnRefs=[];
  function inTx(el,root){for(var p=el.parentNode;p&&p!==root;p=p.parentNode)if(p.localName==='txbxContent'||p.localName==='Fallback')return true;return false}
  function media(c,out){
    var ids=[],bl=c.getElementsByTagNameNS('*','blip'),im=c.getElementsByTagNameNS('*','imagedata'),i;
    for(i=0;i<bl.length;i++)if(!inTx(bl[i],c))ids.push(A(bl[i],'embed'));
    for(i=0;i<im.length;i++)if(!inTx(im[i],c))ids.push(A(im[i],'id'));
    ids.forEach(function(id){if(!id||imgs[id]===undefined)return;
      if(imgs[id])out.extra.push({t:'img',src:imgs[id],x:''});
      else out.extra.push({t:'p',h:'<i>[image non affichable]</i>',x:'[image non affichable]'})});
    var tb=c.getElementsByTagNameNS('*','txbxContent');
    for(i=0;i<tb.length;i++){if(inTx(tb[i],c))continue;
      var bs=blocksOf(tb[i]);bs.forEach(function(b){out.extra.push(b)})}}
  function runOf(rn,out){
    var rp=W(rn,'rPr'),fl={b:isOn(rp,'b'),i:isOn(rp,'i'),u:isOn(rp,'u')&&!/^none$/i.test(A(W(rp,'u'),'val')||''),s:isOn(rp,'strike')||isOn(rp,'dstrike')};
    var rs=rp&&W(rp,'rStyle');if(rs){var ri=sInfo(A(rs,'val')).r;if(ri.b)fl.b=true;if(ri.i)fl.i=true;if(ri.u)fl.u=true}
    var va=rp&&W(rp,'vertAlign'),vv=va&&A(va,'val'),hl=rp&&W(rp,'highlight'),hv=hl&&A(hl,'val'),s='',t='';
    (function vis(n){
      for(var c=n.firstElementChild;c;c=c.nextElementSibling){var l=c.localName;
        if(l==='t'){s+=esc(c.textContent);t+=c.textContent}
        else if(l==='tab'||l==='ptab'){s+='\u2003';t+=' '}
        else if(l==='br'||l==='cr'){var ty=A(c,'type');if(ty!=='page'&&ty!=='column'){s+='<br>';t+=' '}}
        else if(l==='noBreakHyphen'){s+='\u2011';t+='-'}
        else if(l==='footnoteReference'||l==='endnoteReference'){fnRefs.push({k:l==='endnoteReference'?'e':'f',id:A(c,'id')});var nn=fnRefs.length;s+='<sup>['+nn+']</sup>';t+='['+nn+']'}
        else if(l==='drawing'||l==='pict'||l==='object')media(c,out);
        else if(l==='AlternateContent'){var ch=null,fb=null;for(var k=c.firstElementChild;k;k=k.nextElementSibling){if(k.localName==='Choice')ch=k;else if(k.localName==='Fallback')fb=k}vis(ch||fb||c)}}})(rn);
    if(!s)return;
    if(vv==='superscript')s='<sup>'+s+'</sup>';else if(vv==='subscript')s='<sub>'+s+'</sub>';
    if(fl.s)s='<s>'+s+'</s>';if(fl.u)s='<u>'+s+'</u>';if(fl.i)s='<i>'+s+'</i>';if(fl.b)s='<b>'+s+'</b>';
    if(hv&&hv!=='none')s='<span class="hl">'+s+'</span>';
    out.h+=s;out.x+=t}
  var INL=/^(hyperlink|smartTag|ins|moveTo|fldSimple|sdt|sdtContent|customXml|dir|bdo)$/;
  function inlineKids(n,out){
    for(var c=n.firstElementChild;c;c=c.nextElementSibling){var l=c.localName;
      if(l==='r')runOf(c,out);
      else if(INL.test(l))inlineKids(c,out);
      else if(l==='AlternateContent'){var ch=null,fb=null;for(var k=c.firstElementChild;k;k=k.nextElementSibling){if(k.localName==='Choice')ch=k;else if(k.localName==='Fallback')fb=k}inlineKids(ch||fb||c,out)}
      else if(l==='oMath'||l==='oMathPara'){var tx=c.textContent;out.h+=esc(tx);out.x+=tx}}
    return out}
  function paraBlocks(p,B){
    var pPr=W(p,'pPr'),ps=pPr&&W(pPr,'pStyle'),si=sInfo(ps?A(ps,'val'):'Normal'),np=pPr&&W(pPr,'numPr'),numId=null,il=0;
    if(np){var ni=W(np,'numId'),li=W(np,'ilvl');numId=ni?A(ni,'val'):null;il=li?+A(li,'val'):0;if(numId===null&&si.num){numId=si.num}}
    else if(si.num){numId=si.num;il=si.il||0}
    var mk=(numId&&numId!=='0')?marker(numId,il):null;
    var o=inlineKids(p,{h:'',x:'',extra:[]}),hl=si.h,ol=pPr&&W(pPr,'outlineLvl');
    if(ol){var v=+A(ol,'val');hl=v<9?v+1:0}
    var x=o.x.replace(/\s+/g,' ').trim();
    if(x){
      if(hl)B.push({t:'h',l:Math.min(hl,4),x:(mk?mk+' ':'')+x});
      else if(mk!==null)B.push({t:'li',d:Math.min(il,4),mk:mk,x:x,h:trimH(o.h)});
      else B.push({t:'p',x:x,h:trimH(o.h)})}
    o.extra.forEach(function(b){B.push(b)})}
  function tableBlock(tbl,B){
    var rows=[],open={};
    for(var tr=tbl.firstElementChild;tr;tr=tr.nextElementSibling){
      if(tr.localName!=='tr')continue;
      var trp=W(tr,'trPr'),hdr=!!(trp&&W(trp,'tblHeader')),row=[],col=0,gb=trp&&W(trp,'gridBefore');
      if(gb)col+=+A(gb,'val')||0;
      for(var tc=tr.firstElementChild;tc;tc=tc.nextElementSibling){
        if(tc.localName!=='tc')continue;
        var tp=W(tc,'tcPr'),gs=tp&&W(tp,'gridSpan'),cs=gs?(+A(gs,'val')||1):1,vm=tp&&W(tp,'vMerge');
        if(vm&&A(vm,'val')!=='restart'){var op=open[col];if(op)op.rs++;col+=cs;continue}
        var bs=blocksOf(tc),cell={h:blocksHtml(bs),x:bs.map(function(b){return b.x||''}).join(' ').trim(),cs:cs,rs:1,th:hdr};
        row.push(cell);open[col]=vm?cell:null;col+=cs}
      rows.push(row)}
    if(rows.length)B.push(mkTable(rows))}
  function blocksOf(root){
    var B=[];
    for(var c=root.firstElementChild;c;c=c.nextElementSibling){var l=c.localName;
      if(l==='p')paraBlocks(c,B);
      else if(l==='tbl')tableBlock(c,B);
      else if(l==='sdt'){var sc2=W(c,'sdtContent');if(sc2)blocksOf(sc2).forEach(function(b){B.push(b)})}
      else if(l==='customXml'||l==='ins'||l==='moveTo')blocksOf(c).forEach(function(b){B.push(b)})}
    return B}
  var body=D.getElementsByTagNameNS('*','body')[0];
  var B=blocksOf(body);
  if(fnRefs.length){
    var fm={f:{},e:{}};
    [[FN,'footnote','f'],[EN,'endnote','e']].forEach(function(a){if(!a[0])return;
      Array.prototype.forEach.call(a[0].getElementsByTagNameNS('*',a[1]),function(el){fm[a[2]][A(el,'id')]=blocksOf(el)})});
    var notes=[];
    fnRefs.forEach(function(rf,k){var bs=fm[rf.k][rf.id]||[],h=bs.map(function(b){return b.h||esc(b.x||'')}).join(' '),x=bs.map(function(b){return b.x||''}).join(' ').trim();
      if(x)notes.push({t:'p',x:'['+(k+1)+'] '+x,h:'<sup>['+(k+1)+']</sup> '+h})});
    if(notes.length){B.push({t:'h',l:2,x:'Notes'});notes.forEach(function(b){B.push(b)})}}
  return{blocks:B}}

/* ---------- PowerPoint (.pptx) : diapositives, tableaux, images, puces, notes ---------- */
function parsePptx(buf){
  var Z=zipOpen(buf),XP=function(s){return s?new DOMParser().parseFromString(s,'application/xml'):null};
  function relMap(x){var m={};if(x)Array.prototype.forEach.call(x.getElementsByTagName('Relationship'),function(e){m[e.getAttribute('Id')]={t:e.getAttribute('Type')||'',g:e.getAttribute('Target')||'',ext:e.getAttribute('TargetMode')==='External'}});return m}
  return Promise.all([Z.text('ppt/presentation.xml'),Z.text('ppt/_rels/presentation.xml.rels')]).then(function(r){
    if(!r[0])throw new Error('pptx');
    var P=XP(r[0]),R=relMap(XP(r[1])),paths=[],ids=P.getElementsByTagNameNS('*','sldId');
    for(var i=0;i<ids.length;i++){var at=ids[i].attributes,rid=null;for(var q=0;q<at.length;q++)if(at[q].localName==='id'&&/relationships/.test(at[q].namespaceURI||''))rid=at[q].value;var rl=R[rid];if(rl&&!rl.ext)paths.push(rl.g.charAt(0)==='/'?rl.g.slice(1):normPath('ppt/'+rl.g))}
    if(!paths.length)throw new Error('pptx vide');
    var B=[],chain=Promise.resolve();
    paths.forEach(function(path,idx){chain=chain.then(function(){
      toast('Lecture du PowerPoint… '+(idx+1)+'/'+paths.length);
      var dir=path.replace(/[^/]+$/,''),file=path.split('/').pop();
      return Promise.all([Z.text(path),Z.text(dir+'_rels/'+file+'.rels')]).then(function(s){
        if(!s[0])return;
        var rel=relMap(XP(s[1])),used={},MIME={png:'image/png',jpg:'image/jpeg',jpeg:'image/jpeg',gif:'image/gif',bmp:'image/bmp',webp:'image/webp'},imgs={};
        s[0].replace(/\b\w+:(?:embed|id)="([^"]+)"/g,function(m,id){if(rel[id]&&/\/image$/.test(rel[id].t)&&!rel[id].ext)used[id]=1});
        var jobs=Object.keys(used).map(function(id){
          var pth=rel[id].g.charAt(0)==='/'?rel[id].g.slice(1):normPath(dir+rel[id].g),mime=MIME[(pth.split('.').pop()||'').toLowerCase()];
          if(!mime){imgs[id]=null;return Promise.resolve()}
          return Z.bytes(pth).then(function(b){return b?shrink(new Blob([b],{type:mime})):null}).then(function(u){imgs[id]=u},function(){imgs[id]=null})});
        var notePath=null;for(var k in rel)if(/\/notesSlide$/.test(rel[k].t))notePath=normPath(dir+rel[k].g);
        return Promise.all(jobs.concat([notePath?Z.text(notePath):Promise.resolve(null)])).then(function(res){
          var nx=res[res.length-1];
          slideBlocks(XP(s[0]),imgs,nx?XP(nx):null,idx+1,B)})})})});
    return chain.then(function(){return{blocks:B}})})}
function slideBlocks(D,imgs,N,num,B){
  var ctr;
  function phOf(sp){var ph=sp.getElementsByTagNameNS('*','ph')[0];return ph?{t:A(ph,'type')||'',i:A(ph,'idx')}:null}
  function posOf(n){var x=null,k;
    for(k=n.firstElementChild;k;k=k.nextElementSibling){if(/^(spPr|grpSpPr)$/.test(k.localName)||k.localName==='xfrm'){x=k.localName==='xfrm'?k:W(k,'xfrm');if(x)break}}
    var o=x&&W(x,'off');return o?{y:+A(o,'y')||0,x:+A(o,'x')||0}:{y:0,x:0}}
  function parasOf(tx,isBody,out){
    ctr=[];
    for(var p=tx.firstElementChild;p;p=p.nextElementSibling){
      if(p.localName!=='p')continue;
      var pr=W(p,'pPr'),lvl=pr?(+A(pr,'lvl')||0):0,h='',t='';
      for(var c=p.firstElementChild;c;c=c.nextElementSibling){
        var l=c.localName;
        if(l==='br'){h+='<br>';t+=' '}
        else if(l==='r'||l==='fld'){
          var tn=W(c,'t'),s=tn?tn.textContent:'';if(!s)continue;
          var rp=W(c,'rPr'),e=esc(s);
          if(rp){var bl=+A(rp,'baseline')||0,u=A(rp,'u');
            if(bl>0)e='<sup>'+e+'</sup>';else if(bl<0)e='<sub>'+e+'</sub>';
            if(/strike/i.test(A(rp,'strike')||''))e='<s>'+e+'</s>';
            if(u&&u!=='none')e='<u>'+e+'</u>';
            if(A(rp,'i')==='1')e='<i>'+e+'</i>';
            if(A(rp,'b')==='1')e='<b>'+e+'</b>'}
          h+=e;t+=s}}
      h=trimH(h);var x=t.replace(/\s+/g,' ').trim();if(!x)continue;
      var mk=null;
      if(pr&&!W(pr,'buNone')){
        var bc=W(pr,'buChar'),ba=W(pr,'buAutoNum');
        if(ba){ctr[lvl]=(ctr[lvl]||0)+1;for(var j=lvl+1;j<9;j++)ctr[j]=0;
          var ty=A(ba,'type')||'arabicPeriod',n=ctr[lvl];
          mk=/alpha/i.test(ty)?(/Uc/.test(ty)?alpha(n):alpha(n).toLowerCase()):/roman/i.test(ty)?(/Uc/.test(ty)?roman(n):roman(n).toLowerCase()):''+n;
          mk+=/Paren/.test(ty)?(/Both/.test(ty)?')':')'):'.'}
        else if(bc)mk=['•','◦','▪'][lvl%3];
        else if(isBody)mk=['•','◦','▪'][lvl%3]}
      else if(!pr&&isBody)mk='•';
      out.push(mk!==null?{t:'li',d:Math.min(lvl,4),mk:mk,x:x,h:h}:{t:'p',x:x,h:h})}}
  function tableOfFrame(tbl){
    var rows=[],fr=W(tbl,'tblPr'),first=fr&&A(fr,'firstRow')==='1';
    for(var tr=tbl.firstElementChild;tr;tr=tr.nextElementSibling){
      if(tr.localName!=='tr')continue;var row=[];
      for(var tc=tr.firstElementChild;tc;tc=tc.nextElementSibling){
        if(tc.localName!=='tc')continue;
        if(A(tc,'hMerge')==='1'||A(tc,'vMerge')==='1'){continue}
        var tx=W(tc,'txBody'),ps=[];if(tx)parasOf(tx,false,ps);
        row.push({h:ps.map(function(b){return b.h}).join('<br>'),x:ps.map(function(b){return b.x}).join(' '),cs:+A(tc,'gridSpan')||1,rs:+A(tc,'rowSpan')||1,th:!!first&&rows.length===0})}
      rows.push(row)}
    return rows.length?mkTable(rows):null}
  function items(tree,out){
    for(var c=tree.firstElementChild;c;c=c.nextElementSibling){
      var l=c.localName,pos=posOf(c),bl=[];
      if(l==='sp'){
        var tx=W(c,'txBody'),ph=phOf(c);
        if(ph&&/^(sldNum|dt|ftr|hdr)$/.test(ph.t))continue;
        if(tx){var isT=ph&&/^(title|ctrTitle)$/.test(ph.t),body=ph&&!isT&&(ph.t===''||/^(body|obj)$/.test(ph.t));
          var ps=[];parasOf(tx,!!body,ps);
          if(isT&&ps.length){out.push({y:-1,x:0,title:ps.map(function(b){return b.x}).join(' '),b:[]});continue}
          bl=ps}}
      else if(l==='pic'){
        var bp=c.getElementsByTagNameNS('*','blip')[0],id=bp&&A(bp,'embed');
        if(id&&imgs[id])bl=[{t:'img',src:imgs[id],x:''}];else if(id)bl=[{t:'p',x:'[image non affichable]',h:'<i>[image non affichable]</i>'}]}
      else if(l==='graphicFrame'){
        var xf=W(c,'xfrm'),o=xf&&W(xf,'off');if(o)pos={y:+A(o,'y')||0,x:+A(o,'x')||0};
        var tb=c.getElementsByTagNameNS('*','tbl')[0];
        if(tb){var t=tableOfFrame(tb);if(t)bl=[t]}
        else if(c.getElementsByTagNameNS('*','chart').length)bl=[{t:'p',x:'[graphique non affiché]',h:'<i>[graphique non affiché]</i>'}]
        else if(c.getElementsByTagNameNS('*','relIds').length)bl=[{t:'p',x:'[schéma SmartArt non affiché]',h:'<i>[schéma SmartArt non affiché]</i>'}]}
      else if(l==='grpSp'){var sub=[];items(c,sub);sub.forEach(function(s){s.y=pos.y;s.x=Math.max(pos.x,0)+s.x*0;out.push(s)});continue}
      else if(l==='AlternateContent'){var ch=W(c,'Choice');if(ch)items(ch,out);continue}
      if(bl.length)out.push({y:pos.y,x:pos.x,b:bl})}}
  var tree=D.getElementsByTagNameNS('*','spTree')[0],out=[];
  if(tree)items(tree,out);
  var title='';out.forEach(function(o){if(o.title&&!title)title=o.title});
  var rest=out.filter(function(o){return!o.title&&o.b.length});
  rest.forEach(function(o,i){o.i=i});
  rest.sort(function(a,b){return Math.abs(a.y-b.y)>200000?a.y-b.y:(a.x!==b.x?a.x-b.x:a.i-b.i)});
  if(!title){for(var q=0;q<rest.length;q++){var f0=rest[q].b[0];
    if(f0&&f0.t==='p'&&f0.x.length<90){title=f0.x;rest[q].b.shift();break}
    if(f0&&f0.t!=='p')break}}
  B.push({t:'h',l:1,x:num+'. '+(title||'Diapositive '+num)});
  rest.forEach(function(o){o.b.forEach(function(b){B.push(b)})});
  if(N){var nt=[],sps=N.getElementsByTagNameNS('*','sp');
    for(var i=0;i<sps.length;i++){var ph=phOf(sps[i]);if(ph&&ph.t==='body'){var tx=W(sps[i],'txBody');if(tx){var ps=[];parasOf(tx,false,ps);ps.forEach(function(p){nt.push(p.x)})}}}
    var ntx=nt.join(' ').trim();
    if(ntx)B.push({t:'p',x:'Notes : '+ntx,h:'<i><b>Notes :</b> '+esc(ntx)+'</i>'})}}

/* ---------- PDF : texte + tableaux + schémas/images + pages d'origine ---------- */
function loadPdfJs(){
  if(window.pdfjsLib)return Promise.resolve(window.pdfjsLib);
  return new Promise(function(ok,ko){var s=document.createElement('script');
    s.src='https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js';
    s.onload=function(){pdfjsLib.GlobalWorkerOptions.workerSrc='https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';ok(pdfjsLib)};
    s.onerror=ko;document.head.appendChild(s)})}
var PDF_MAXG=80;
function cropCv(cv,r,q){var c=document.createElement('canvas');c.width=Math.max(1,r.x1-r.x0);c.height=Math.max(1,r.y1-r.y0);c.getContext('2d').drawImage(cv,r.x0,r.y0,c.width,c.height,0,0,c.width,c.height);var u=c.toDataURL('image/jpeg',q||.86);c.width=c.height=0;return u}
function pdfCellText(its){
  its=its.slice().sort(function(a,b){return Math.abs(a.vy-b.vy)>a.hp*.5?a.vy-b.vy:a.vx-b.vx});
  var lines=[],L=null;
  its.forEach(function(i){
    if(L&&Math.abs(L.vy-i.vy)<=i.hp*.5){L.t+=(i.vx-L.ex>i.hp*.15?' ':'')+i.s;L.ex=i.vx+i.w}
    else{L={vy:i.vy,t:i.s,ex:i.vx+i.w};lines.push(L)}});
  return lines.map(function(l){return l.t.replace(/\s+/g,' ').trim()}).filter(Boolean)}
/* grille d'un tableau à partir des traits dessinés (pixels hors texte) */
function pdfGrid(d,W,H,r,its){
  function dk(x,y){if(x<0||y<0||x>=W||y>=H)return false;var p=(y*W+x)*4;return d[p]<205||d[p+1]<205||d[p+2]<205}
  function cl(a){var o=[];a.sort(function(x,y){return x-y}).forEach(function(v){if(o.length&&v-o[o.length-1]<7)o[o.length-1]=(o[o.length-1]+v)/2;else o.push(v)});return o}
  function scan(horiz,a0,a1,b0,b1,thr){
    var out=[],run=null;
    for(var a=a0;a<a1;a++){var c=0;for(var b=b0;b<b1;b++)if(horiz?dk(b,a):dk(a,b))c++;
      if(c>=thr*(b1-b0)){if(run&&a===run.e+1)run.e=a;else{run={s:a,e:a};out.push(run)}}}
    return out.filter(function(q){return q.e-q.s<8}).map(function(q){return(q.s+q.e)/2})}
  var rw=r.x1-r.x0,rh=r.y1-r.y0,hl=cl(scan(true,r.y0,r.y1,r.x0,r.x1,.55)),vl=cl(scan(false,r.x0,r.x1,r.y0,r.y1,.55));
  if(!hl.length||hl[0]-r.y0>8)hl.unshift(r.y0);if(r.y1-hl[hl.length-1]>8)hl.push(r.y1);
  if(!vl.length||vl[0]-r.x0>8)vl.unshift(r.x0);if(r.x1-vl[vl.length-1]>8)vl.push(r.x1);
  var nr=hl.length-1,nc=vl.length-1;
  if(nr<1||nc<1||nr*nc<2||nr>80||nc>20)return null;
  function frac(x0,y0,x1,y1){var n=0,t=0,i,k;
    if(x0===x1){for(i=Math.ceil(y0);i<=y1;i++){t++;for(k=-2;k<=2;k++)if(dk(Math.round(x0)+k,i)){n++;break}}}
    else{for(i=Math.ceil(x0);i<=x1;i++){t++;for(k=-2;k<=2;k++)if(dk(i,Math.round(y0)+k)){n++;break}}}
    return t?n/t:1}
  var cov=[],cells=[],rr,cc,k;
  for(rr=0;rr<nr;rr++){cov.push([]);for(cc=0;cc<nc;cc++)cov[rr].push(-1)}
  for(rr=0;rr<nr;rr++)for(cc=0;cc<nc;cc++){
    if(cov[rr][cc]>=0)continue;
    var cs=1,rs=1;
    while(cc+cs<nc&&cov[rr][cc+cs]<0&&frac(vl[cc+cs],hl[rr]+3,vl[cc+cs],hl[rr+1]-3)<.4)cs++;
    while(rr+rs<nr){var gap=true;
      for(k=cc;k<cc+cs;k++){if(cov[rr+rs][k]>=0||frac(vl[k]+3,hl[rr+rs],vl[k+1]-3,hl[rr+rs])>=.4){gap=false;break}}
      if(!gap)break;rs++}
    var id=cells.length;cells.push({r:rr,c:cc,cs:cs,rs:rs,its:[]});
    for(var a=rr;a<rr+rs;a++)for(var b=cc;b<cc+cs;b++)cov[a][b]=id}
  its.forEach(function(i){
    var cx=i.vx+i.w/2,cy=i.vy-i.hp*.35,c2=0,r2=0;
    for(k=0;k<nc;k++)if(cx>=vl[k])c2=k;
    for(k=0;k<nr;k++)if(cy>=hl[k])r2=k;
    cells[cov[r2][c2]].its.push(i)});
  var rows=[];for(rr=0;rr<nr;rr++)rows.push([]);
  cells.forEach(function(c){var ls=pdfCellText(c.its);
    rows[c.r].push({c:c.c,h:ls.map(esc).join('<br>'),x:ls.join(' '),cs:c.cs,rs:c.rs})});
  rows.forEach(function(r){r.sort(function(a,b){return a.c-b.c})});
  var hdr=nr>=2&&rows[0].length>=2&&rows[0].every(function(c){return c.x});
  rows[0].forEach(function(c){c.th=hdr});
  return mkTable(rows)}
function pdfAnalyse(cv,it,sc,lines){
  var W=cv.width,H=cv.height,m=document.createElement('canvas');m.width=W;m.height=H;
  var mg=m.getContext('2d',{willReadFrequently:true});mg.drawImage(cv,0,0);mg.fillStyle='#fff';
  it.forEach(function(i){mg.fillRect(Math.floor(i.vx-2),Math.floor(i.vy-i.hp*.98-2),Math.ceil(i.w+4),Math.ceil(i.hp*1.3+4))});
  var d=mg.getImageData(0,0,W,H).data,G=6,gw=Math.ceil(W/G),gh=Math.ceil(H/G),ink=new Uint8Array(gw*gh),x,y;
  for(y=0;y<H;y++){var row=y*W*4,gy=((y/G)|0)*gw;for(x=0;x<W;x++){var p=row+x*4;if(d[p]<205||d[p+1]<205||d[p+2]<205)ink[gy+((x/G)|0)]=1}}
  var D=2,dil=new Uint8Array(gw*gh),gx,dy,dx,yy,xx;
  for(gy=0;gy<gh;gy++)for(gx=0;gx<gw;gx++)if(ink[gy*gw+gx])for(dy=-D;dy<=D;dy++)for(dx=-D;dx<=D;dx++){yy=gy+dy;xx=gx+dx;if(yy>=0&&yy<gh&&xx>=0&&xx<gw)dil[yy*gw+xx]=1}
  var lab=new Int32Array(gw*gh),comps=[],cnt=0,s0;
  for(s0=0;s0<gw*gh;s0++){
    if(!dil[s0]||lab[s0])continue;
    var st=[s0],bx0=1e9,by0=1e9,bx1=-1,by1=-1,n=0;lab[s0]=++cnt;
    while(st.length){var q=st.pop(),qx=q%gw,qy=(q/gw)|0;
      if(ink[q]){n++;if(qx<bx0)bx0=qx;if(qx>bx1)bx1=qx;if(qy<by0)by0=qy;if(qy>by1)by1=qy}
      for(dy=-1;dy<=1;dy++)for(dx=-1;dx<=1;dx++){xx=qx+dx;yy=qy+dy;if(xx<0||yy<0||xx>=gw||yy>=gh)continue;var k=yy*gw+xx;if(dil[k]&&!lab[k]){lab[k]=cnt;st.push(k)}}}
    if(n)comps.push({x0:bx0*G,y0:by0*G,x1:Math.min(W,(bx1+1)*G),y1:Math.min(H,(by1+1)*G),n:n})}
  comps=comps.filter(function(c){var w=c.x1-c.x0,h=c.y1-c.y0;
    return w>=50&&h>=40&&c.n/((w/G)*(h/G))>=.02&&!(w>.92*W&&h>.92*H)});
  comps.sort(function(a,b){return(b.x1-b.x0)*(b.y1-b.y0)-(a.x1-a.x0)*(a.y1-a.y0)});
  comps=comps.slice(0,12).sort(function(a,b){return a.y0-b.y0});
  var regs=comps.map(function(c){
    var its=it.filter(function(i){var cx=i.vx+i.w/2,cy=i.vy-i.hp*.35;return cx>=c.x0-4&&cx<=c.x1+4&&cy>=c.y0-4&&cy<=c.y1+4});
    var pad={x0:Math.max(0,c.x0-8),y0:Math.max(0,c.y0-8),x1:Math.min(W,c.x1+8),y1:Math.min(H,c.y1+8)};
    var url=cropCv(cv,pad),tb=null;
    try{tb=pdfGrid(d,W,H,c,its)}catch(e){tb=null}
    var all=pdfCellText(its).join(' '),b;
    if(tb){tb.o=url;b=tb}else b={t:'img',src:url,x:all};
    return{x0:pad.x0,y0:pad.y0,x1:pad.x1,y1:pad.y1,b:b}});
  lines.forEach(function(L){var cx=(L.items[0].vx+L.items[L.items.length-1].vx+L.items[L.items.length-1].w)/2,cy=L.vy-L.h*sc*.35;
    for(var i=0;i<regs.length;i++){var r=regs[i];if(cx>=r.x0&&cx<=r.x1&&cy>=r.y0&&cy<=r.y1){L.cons=1;break}}});
  var tw=Math.min(1000,W),th=document.createElement('canvas');th.width=tw;th.height=Math.round(H*tw/W);
  var tg=th.getContext('2d');tg.fillStyle='#fff';tg.fillRect(0,0,th.width,th.height);tg.drawImage(cv,0,0,th.width,th.height);
  var pg=th.toDataURL('image/jpeg',.72);th.width=th.height=0;m.width=m.height=0;
  return{regs:regs,pg:pg}}
function pdfPage(pg,n,total){
  var v1=pg.getViewport({scale:1}),sc=Math.min(3,Math.max(1,1200/v1.width)),vp=pg.getViewport({scale:sc});
  return pg.getTextContent().then(function(c){
    var it=c.items.filter(function(i){return i.str&&i.str.trim()}).map(function(i){
      var p=vp.convertToViewportPoint(i.transform[4],i.transform[5]),h=Math.abs(i.transform[3])||i.height||10,w=i.width||i.str.length*h*.5;
      return{s:i.str,x:i.transform[4],y:i.transform[5],h:h,vx:p[0],vy:p[1],w:w*sc,hp:h*sc}});
    it.sort(function(a,b){return Math.abs(a.y-b.y)>2?b.y-a.y:a.x-b.x});
    var lines=[];
    it.forEach(function(i){var L=lines[lines.length-1];
      if(L&&Math.abs(L.y-i.y)<=2.5){L.t+=(i.x-L.ex>1.5?' ':'')+i.s;L.ex=i.x+i.s.length*i.h*.5;L.h=Math.max(L.h,i.h);L.items.push(i)}
      else lines.push({t:i.s,y:i.y,h:i.h,ex:i.x+i.s.length*i.h*.5,items:[i],vy:i.vy})});
    var PD={lines:lines,regs:[],sc:sc,pg:null};
    if(n>PDF_MAXG)return PD;
    var cv=document.createElement('canvas');cv.width=Math.round(vp.width);cv.height=Math.round(vp.height);
    var g=cv.getContext('2d',{willReadFrequently:true});g.fillStyle='#fff';g.fillRect(0,0,cv.width,cv.height);
    return pg.render({canvasContext:g,canvas:cv,viewport:vp}).promise.then(function(){
      try{var a=pdfAnalyse(cv,it,sc,lines);PD.regs=a.regs;PD.pg=a.pg}catch(e){console.warn('Analyse PDF :',e)}
      cv.width=cv.height=0;return PD},function(){return PD})})}
function parsePdf(buf){
  return loadPdfJs().then(function(lib){return lib.getDocument({data:buf}).promise}).then(function(pdf){
    var pages=[],chain=Promise.resolve();
    for(var n=1;n<=pdf.numPages;n++)(function(n){chain=chain.then(function(){
      toast('Lecture du PDF… '+n+'/'+pdf.numPages);
      return pdf.getPage(n).then(function(pg){return pdfPage(pg,n,pdf.numPages)}).then(function(pd){pages.push(pd)})})})(n);
    return chain.then(function(){return pages})}).then(function(pages){
    var freq={},rep={};
    pages.forEach(function(P){var seen={};P.lines.forEach(function(L){var k=Math.round(L.h);freq[k]=(freq[k]||0)+L.t.length;
      var key=L.t.replace(/\d+/g,'#').trim();if(!seen[key]){seen[key]=1;rep[key]=(rep[key]||0)+1}})});
    var body=10,mx=0;for(var k in freq)if(freq[k]>mx){mx=freq[k];body=+k}
    var B=[],buf=[],last=null;
    function flush(){if(buf.length){var s=buf.join(' ').replace(/(\w)- (\w)/g,'$1$2').replace(/\s+/g,' ').trim();B.push({t:'p',x:s,h:esc(s)});buf=[]}}
    pages.forEach(function(P){last=null;var regs=P.regs,ri=0;
      function put(lim){while(ri<regs.length&&regs[ri].y0<=lim){flush();B.push(regs[ri].b);last=null;ri++}}
      P.lines.forEach(function(L){
        put(L.vy-L.h*P.sc+3);
        if(L.cons)return;
        var t=L.t.trim(),key=t.replace(/\d+/g,'#');
        if(!t||/^\d{1,3}$/.test(t)||(pages.length>=3&&rep[key]>=pages.length*.5&&t.length<80))return;
        var r=L.h/body,lv=0;
        if(t.length<130&&r>=1.15)lv=r>=1.6?1:r>=1.3?2:3;
        else if(t.length<90&&!/[.;,:]$/.test(t)&&(/^(\d+(\.\d+)*[.)]?\s+\S)/.test(t)||/^(chapitre|partie|section|le[cç]on|unité|module|introduction|conclusion)\b/i.test(t)||(t.length>3&&t===t.toUpperCase()&&/[A-ZÀ-Ý]{3}/.test(t))))lv=/^\d+\.\d+/.test(t)?2:1;
        if(lv){flush();var pv=B[B.length-1];
          if(pv&&pv.t==='h'&&pv.l===lv&&!buf.length&&last&&last.h===L.h&&last.hd)pv.x+=' '+t;else B.push({t:'h',l:lv,x:t});
          last={h:L.h,y:L.y,hd:1};return}
        if(last&&!last.hd&&last.y-L.y>L.h*1.9)flush();
        if(last&&last.hd)flush();
        buf.push(t);last={h:L.h,y:L.y,hd:0}});
      put(1e9);flush()});
    var pg=pages.map(function(p){return p.pg}).filter(Boolean);
    if(!B.length&&pg.length)B=pg.map(function(u,i){return{t:'img',src:u,x:'Page '+(i+1)}});
    return{blocks:B,pg:pg}})}

/* ---------- Import ---------- */
function addLesson(name,B,extra){
  if(!B.length){toast('Aucun contenu trouvé dans ce fichier');return}
  var l={id:'l'+Date.now(),name:name,blocks:B,stars:[],pos:0};
  if(extra&&extra.pg&&extra.pg.length)l.pg=extra.pg;
  S.lessons.unshift(l);S.cur=l.id;S.view='text';
  saveLesson(l).then(saveMeta);render();
  var nh=0,nt=0,ni=0;B.forEach(function(b){if(b.t==='h')nh++;else if(b.t==='tbl')nt++;else if(b.t==='img')ni++});
  toast(nh+' titres, '+nt+' tableau'+(nt>1?'x':'')+', '+ni+' image'+(ni>1?'s':''))}
function addRes(n){return function(r){addLesson(n,r.blocks,r)}}
function importFile(f){
  var n=f.name.replace(/\.[^.]+$/,''),ext=(f.name.split('.').pop()||'').toLowerCase(),bad=function(m){return function(e){console.error(e);toast(m)}};
  if(f.type==='application/pdf')ext='pdf';
  else if(/^image\//.test(f.type)&&!/^(png|jpe?g|webp|gif|bmp)$/.test(ext))ext='png';
  else if(!/^(pdf|docx|pptx|ppt|txt|md|markdown|html|htm|csv|tsv|json|png|jpe?g|webp|gif|bmp)$/.test(ext)&&f.type&&f.type.indexOf('text')!==0){toast('Format non pris en charge : utilise PDF, DOCX, PPTX, TXT, MD, HTML, CSV ou une image');return}
  if(ext==='pptx')f.arrayBuffer().then(parsePptx).then(addRes(n)).catch(bad('Impossible de lire ce .pptx'));
  else if(ext==='ppt')toast('Ancien format .ppt non pris en charge : enregistre-le en .pptx ou en PDF');
  else if(ext==='docx')f.arrayBuffer().then(parseDocx).then(addRes(n)).catch(bad('Impossible de lire ce .docx'));
  else if(ext==='pdf')f.arrayBuffer().then(parsePdf).then(addRes(n)).catch(bad('Impossible de lire ce PDF (connexion requise la 1re fois)'));
  else if(/^(png|jpe?g|webp|gif|bmp)$/.test(ext))shrink(f,1800).then(function(u){if(u)addLesson(n,[{t:'img',src:u,x:n}]);else toast('Image illisible')});
  else f.text().then(function(t){
    var B;
    if(ext==='csv'||ext==='tsv')B=parseCSV(t.replace(/\r/g,''));
    else if(ext==='json'){try{t=JSON.stringify(JSON.parse(t),null,2)}catch(e){}B=[{t:'p',c:'pre',x:t,h:esc(t)}]}
    else if(/^(htm|html)$/.test(ext)||/^\s*<(!doctype|html)/i.test(t))B=parseHTML(t);
    else B=parseText(t);
    addLesson(n,B)})}

/* ---------- Affichage ---------- */
var body=$('#stBody');
function fill(e,b){
  e.textContent='';
  if(b.t==='img'){var im=document.createElement('img');im.alt=b.x||'';im.loading='lazy';im.src=b.src;e.appendChild(im);return}
  if(b.t==='tbl'){e.innerHTML=b.h;
    if(b.o){var bt=document.createElement('button');bt.type='button';bt.className='st-orig';bt.dataset.orig='1';bt.textContent='📷 Voir l’original';e.appendChild(bt);
      var oi=document.createElement('img');oi.className='oimg';oi.loading='lazy';oi.src=b.o;e.appendChild(oi)}
    return}
  if(b.h)e.innerHTML=b.h;else e.textContent=b.x}
function render(){
  var l=lesson();body.textContent='';body.style.fontSize=S.fs+'rem';S.hits=[];S.hi=-1;$('#stCnt').textContent='';
  $('#stTitle').textContent=l?l.name:'Étudier';
  var pb=document.querySelector('.st-chip[data-a="pages"]');if(pb)pb.classList.toggle('on',S.view==='pages');
  if(!l){body.innerHTML='<div class="st-empty"><h3>Importe ta leçon</h3><p>Fichier .pdf, .docx, .pptx, .txt, .md, .html, .csv ou image — ou colle ton texte.<br>Les titres et les tableaux sont détectés automatiquement.</p><button class="st-big" data-a="import">Importer un fichier</button><button class="st-big" data-a="paste">Coller du texte</button></div>';return}
  var f=document.createDocumentFragment();
  if(S.view==='pages'&&l.pg&&l.pg.length){
    l.pg.forEach(function(u,k){var e=document.createElement('div');e.className='stb img pgv';
      var c=document.createElement('div');c.className='pgn';c.textContent='Page '+(k+1)+' / '+l.pg.length;
      var im=document.createElement('img');im.loading='lazy';im.src=u;e.appendChild(c);e.appendChild(im);f.appendChild(e)});
    body.appendChild(f);body.scrollTop=0;return}
  var st={};l.stars.forEach(function(i){st[i]=1});
  l.blocks.forEach(function(b,i){var e=document.createElement('div');e.dataset.i=i;
    var c='stb ';
    if(b.t==='h')c+='h h'+b.l;
    else if(b.t==='tbl')c+='tbl';
    else if(b.t==='img')c+='img';
    else c+='p'+(b.t==='li'?' li':'')+(b.c?' '+b.c:'')+(st[i]?' star':'');
    e.className=c;
    if(b.t==='li'){e.dataset.mk=b.mk||'';e.style.setProperty('--d',b.d||0)}
    fill(e,b);f.appendChild(e)});
  body.appendChild(f);body.scrollTop=S.pos[l.id]||l.pos||0;search()}
function norm(s){var o='';for(var i=0;i<s.length;i++){var c=s[i].normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();o+=c.length===1?c:s[i].toLowerCase()[0]}return o}
function markIn(e,q){
  var w=document.createTreeWalker(e,NodeFilter.SHOW_TEXT,null),ns=[],n;
  while((n=w.nextNode()))ns.push(n);
  ns.forEach(function(t){var s=t.nodeValue,nn=norm(s),at=nn.indexOf(q);if(at<0)return;
    var f=document.createDocumentFragment(),p=0;
    while(at>-1){f.appendChild(document.createTextNode(s.slice(p,at)));var m=document.createElement('mark');m.textContent=s.slice(at,at+q.length);f.appendChild(m);p=at+q.length;at=nn.indexOf(q,p)}
    f.appendChild(document.createTextNode(s.slice(p)));t.parentNode.replaceChild(f,t)})}
function search(){
  var l=lesson();if(!l)return;var q=norm($('#stQ').value.trim());S.hits=[];S.hi=-1;
  Array.prototype.forEach.call(body.children,function(e){
    var b=l.blocks[e.dataset.i];if(!b||b.t==='img')return;
    if(e.querySelector('mark')){var cls=e.className;fill(e,b);e.className=cls}
    if(q)markIn(e,q)});
  S.hits=Array.prototype.filter.call(body.querySelectorAll('mark'),function(m){return m.offsetParent});
  $('#stCnt').textContent=q?(S.hits.length?'0/'+S.hits.length:'0 résultat'):'';
  if(S.hits.length)go(1)}
function go(d){
  if(!S.hits.length)return;if(S.hits[S.hi])S.hits[S.hi].classList.remove('cur');
  S.hi=(S.hi+d+S.hits.length)%S.hits.length;var m=S.hits[S.hi];m.classList.add('cur');
  m.scrollIntoView({block:'center',behavior:'smooth'});$('#stCnt').textContent=(S.hi+1)+'/'+S.hits.length}
function zoom(src){var z=$('#stZoom'),im=z.querySelector('img');im.style.width='';
  im.onload=function(){var vw=window.innerWidth;im.style.width=Math.min(Math.max(vw,im.naturalWidth),vw*3)+'px'};
  im.src=src;z.classList.add('on');z.scrollTop=0;z.scrollLeft=0}
function unzoom(){var z=$('#stZoom');z.classList.remove('on');z.querySelector('img').removeAttribute('src')}

/* ---------- Feuille (sommaire, bibliothèque, coller) ---------- */
function sheet(h){$('#stSheetIn').innerHTML=h;$('#stSheet').hidden=false}
function closeSheet(){$('#stSheet').hidden=true}
function toc(){var l=lesson();if(!l)return toast('Importe d’abord une leçon');
  var h='<h3>Sommaire</h3>',n=0;l.blocks.forEach(function(b,i){if(b.t==='h'){n++;h+='<button class="st-row" data-go="'+i+'" style="padding-left:'+(8+(b.l-1)*16)+'px"><span>'+esc(b.x)+'</span></button>'}});
  sheet(n?h:'<h3>Aucun titre détecté</h3>')}
function lib(){var h='<h3>Mes leçons</h3>';
  if(!S.lessons.length)h+='<p style="color:var(--muted)">Aucune leçon enregistrée.</p>';
  S.lessons.forEach(function(l){h+='<div class="st-row"><span data-open="'+l.id+'" style="cursor:pointer">'+esc(l.name)+'</span><small>'+l.blocks.length+' blocs</small><button class="st-ic" data-del="'+l.id+'" aria-label="Supprimer"><svg viewBox="0 0 24 24"><path d="M5 7h14M10 7V4h4v3M7 7l1 13h8l1-13"/></svg></button></div>'});
  sheet(h)}
var rich=null;
function paste(){rich=null;sheet('<h3>Coller une leçon</h3><input type="text" id="stPN" placeholder="Nom de la leçon"><textarea id="stPT" placeholder="Colle ton texte ici… (les tableaux copiés depuis Word, Excel, Google Docs ou un site sont conservés)"></textarea><div class="st-ps" id="stPS"></div><button class="st-big" id="stPOk">Ajouter</button>')}
function richStat(){var s=$('#stPS');if(!s)return;
  if(!rich){s.textContent='';return}
  var t=0,i=0;rich.forEach(function(b){if(b.t==='tbl')t++;else if(b.t==='img')i++});
  s.textContent='✓ Mise en forme conservée : '+t+' tableau'+(t>1?'x':'')+', '+i+' image'+(i>1?'s':'')}

/* ---------- Actions ---------- */
function speak(i){
  var l=lesson();if(!S.reading||!l||i>=l.blocks.length){S.reading=false;set('read',false);return}
  var b=l.blocks[i],e=body.children[i];if(!e||!e.offsetParent||!b.x){speak(i+1);return}
  e.scrollIntoView({block:'center',behavior:'smooth'});var u=new SpeechSynthesisUtterance((b.t==='li'&&b.mk?b.mk+' ':'')+b.x);u.lang='fr-FR';u.onend=function(){speak(i+1)};speechSynthesis.speak(u)}
/* lecture vocale de secours (navigateurs sans synthèse vocale) : voix Gemini avec la clé de X.Uni */
var TT={ctx:null,src:null,id:0,mem:{}};
function ttsKey(){try{return (localStorage.getItem('uandi-ai-key')||'').trim()}catch(e){return''}}
function ttsStop(){TT.id++;try{if(TT.src){TT.src.onended=null;TT.src.stop()}}catch(e){}TT.src=null}
function ttsGrp(l,i){var t='',n=i;while(n<l.blocks.length&&t.length<700){var b=l.blocks[n];if(b.x)t+=((b.t==='li'&&b.mk?b.mk+' ':'')+b.x+'. ');n++}return{text:t.trim().slice(0,1500),next:Math.max(n,i+1)}}
function ttsGet(text){
  if(TT.mem[text])return TT.mem[text];
  var key=ttsKey();if(!key)return Promise.reject('key');
  var body=JSON.stringify({contents:[{parts:[{text:'Lis ce texte à voix haute en français, d’un ton naturel et posé : '+text}]}],generationConfig:{responseModalities:['AUDIO'],speechConfig:{voiceConfig:{prebuiltVoiceConfig:{voiceName:'Kore'}}}}});
  function once(n){return fetch('https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-preview-tts:generateContent',{method:'POST',headers:{'Content-Type':'application/json','x-goog-api-key':key},body:body}).then(function(r){
    if(r.status===429&&n<2)return new Promise(function(ok){setTimeout(ok,7000)}).then(function(){return once(n+1)});
    if(r.status===403||r.status===400)throw 'key';if(!r.ok)throw 'net';return r.json()}).then(function(j){
    var d=j&&j.candidates&&j.candidates[0]&&j.candidates[0].content&&j.candidates[0].content.parts&&j.candidates[0].content.parts[0]&&j.candidates[0].content.parts[0].inlineData;
    if(!d||!d.data)throw 'net';var bin=atob(d.data),len=bin.length>>1,f=new Float32Array(len);
    for(var k=0;k<len;k++){var v=bin.charCodeAt(2*k)|(bin.charCodeAt(2*k+1)<<8);if(v>32767)v-=65536;f[k]=v/32768}
    return f})}
  var pr=once(0);TT.mem[text]=pr;pr.catch(function(){delete TT.mem[text]});return pr}
function ttsFail(w){S.reading=false;set('read',false);toast(w==='key'?'Ajoute ta clé Gemini dans les réglages de X.Uni pour activer la voix':'La voix n’a pas pu démarrer, réessaie dans un instant')}
function ttsSpeak(i,id){
  var l=lesson();if(!S.reading||id!==TT.id||!l||i>=l.blocks.length){if(id===TT.id){S.reading=false;set('read',false)}return}
  var g=ttsGrp(l,i);if(!g.text){ttsSpeak(g.next,id);return}
  var e=body.children[i];if(e&&e.scrollIntoView)e.scrollIntoView({block:'center',behavior:'smooth'});
  toast('Chargement de la voix…');
  ttsGet(g.text).then(function(f){
    if(!S.reading||id!==TT.id)return;
    var ab=TT.ctx.createBuffer(1,f.length,24000);ab.getChannelData(0).set(f);
    var src=TT.ctx.createBufferSource();src.buffer=ab;src.connect(TT.ctx.destination);TT.src=src;
    src.onended=function(){ttsSpeak(g.next,id)};src.start();
    var nx=ttsGrp(l,g.next);if(nx.text)ttsGet(nx.text).catch(function(){});
  }).catch(function(w){if(id===TT.id)ttsFail(w)})}
function set(a,on){var b=document.querySelector('.st-chip[data-a="'+a+'"]');if(b)b.classList.toggle('on',on)}
function tick(){S.t--;var m=Math.floor(S.t/60),s=S.t%60,b=document.querySelector('[data-a=timer]');
  if(S.t<=0){clearInterval(S.tm);S.tm=0;S.t=1500;b.classList.remove('on');b.textContent='⏱ 25:00';toast('Pause ! 25 min d’étude terminées');if(navigator.vibrate)navigator.vibrate([200,100,200]);return}
  b.textContent='⏱ '+m+':'+('0'+s).slice(-2)}
var act={
  import:function(){$('#stFile').click()},paste:paste,lib:lib,toc:toc,
  pages:function(){var l=lesson();if(!l)return toast('Importe d’abord une leçon');
    if(!l.pg||!l.pg.length)return toast('Les pages d’origine ne sont disponibles que pour les PDF importés');
    S.view=S.view==='pages'?'text':'pages';render()},
  titles:function(){var o=body.classList.toggle('only-t');set('titles',o);search()},
  stars:function(){var o=body.classList.toggle('only-s');set('stars',o)},
  mask:function(){var o=body.classList.toggle('mask');set('mask',o);if(!o)body.querySelectorAll('.rev').forEach(function(e){e.classList.remove('rev')});toast(o?'Touche un paragraphe pour le révéler':'Mode révision désactivé')},
  read:function(){var native='speechSynthesis' in window;
    if(S.view!=='text')return toast('Repasse en mode texte pour la lecture vocale');
    if(S.reading){S.reading=false;ttsStop();if(native)speechSynthesis.cancel();set('read',false);return}
    if(!lesson())return toast('Importe d’abord une leçon');
    var top=body.getBoundingClientRect().top,i=0;for(;i<body.children.length;i++)if(body.children[i].getBoundingClientRect().bottom>top+10)break;
    if(native){S.reading=true;set('read',true);speak(i);return}
    if(!ttsKey())return toast('Ajoute ta clé Gemini dans les réglages de X.Uni pour activer la voix');
    try{TT.ctx=TT.ctx||new(window.AudioContext||window.webkitAudioContext)();TT.ctx.resume()}catch(e){return toast('Lecture vocale indisponible')}
    S.reading=true;set('read',true);TT.id++;ttsSpeak(i,TT.id)},
  timer:function(){var b=document.querySelector('[data-a=timer]');
    if(S.tm){clearInterval(S.tm);S.tm=0;b.classList.remove('on');toast('Minuteur en pause')}else{S.tm=setInterval(tick,1000);b.classList.add('on');toast('Concentration : 25 min')}},
  fm:function(){S.fs=Math.max(.8,S.fs-.1);body.style.fontSize=S.fs+'rem';save()},
  fp:function(){S.fs=Math.min(2,S.fs+.1);body.style.fontSize=S.fs+'rem';save()}
};
var P=$('#stP');
function open(){P.hidden=false;document.body.style.overflow='hidden';sync();render()}
function close(){P.hidden=true;document.body.style.overflow='';ttsStop();if(window.speechSynthesis)speechSynthesis.cancel();S.reading=false;unzoom();sync()}
/* le bouton n'existe que dans l'écran Discussions, à côté du bouton + */
function sync(){var c=document.getElementById('viewList'),ap=document.getElementById('app'),inChat=!!c&&!c.hidden&&!!ap&&!ap.hidden;
  $('#stFab').classList.toggle('on',inChat&&P.hidden);if(!inChat&&!P.hidden)close()}
new MutationObserver(sync).observe(document.body,{attributes:true,attributeFilter:['hidden'],subtree:true});sync();
$('#stFab').addEventListener('click',open);$('#stClose').addEventListener('click',close);
window.uandiStudy={open:open,
  list:function(){return S.lessons.map(function(l){return{id:l.id,name:l.name}})},
  cur:function(){return S.cur},
  text:function(id){var l=S.lessons.filter(function(x){return x.id===id})[0];if(!l)return null;
    var t=(l.blocks||[]).map(function(b){if(!b||b.t==='img'||!b.x)return'';return(b.t==='h'?'\n'+new Array((b.l||1)+1).join('#')+' ':'')+b.x}).filter(Boolean).join('\n');
    return{name:l.name,text:t}}};

$('#stZClose').addEventListener('click',unzoom);
$('#stSrch').addEventListener('click',function(){var b=$('#stSBar');b.hidden=!b.hidden;$('#stSrch').classList.toggle('on',!b.hidden);if(!b.hidden)$('#stQ').focus();else{$('#stQ').value='';search()}});
$('#stQ').addEventListener('input',search);
$('#stQ').addEventListener('keydown',function(e){if(e.key==='Enter'){e.preventDefault();go(e.shiftKey?-1:1)}});
$('#stNext').addEventListener('click',function(){go(1)});$('#stPrev').addEventListener('click',function(){go(-1)});
$('#stFile').addEventListener('change',function(e){var f=e.target.files[0];e.target.value='';if(f)importFile(f)});
/* collage : on garde les tableaux / images / mise en forme si le presse-papiers les contient */
P.addEventListener('paste',function(e){
  if(!e.target||e.target.id!=='stPT')return;
  var cd=e.clipboardData;if(!cd)return;
  var h=cd.getData('text/html'),files=cd.files&&cd.files.length?Array.prototype.slice.call(cd.files).filter(function(f){return/^image\//.test(f.type)}):[];
  if(h&&/<(table|img|ul|ol|li|h[1-6])[\s>]|<(b|strong|i|em|u)[\s>]|font-weight\s*:\s*(bold|[6-9]00)|text-decoration[^;"]*underline/i.test(h)){
    var B=parseHTML(h);setTimeout(function(){if(B.length){rich=B;richStat()}},0)}
  else if(files.length){e.preventDefault();
    Promise.all(files.map(function(f){return shrink(f,1800)})).then(function(us){us.forEach(function(u){if(u){rich=(rich||[]).concat([{t:'img',src:u,x:''}])}});richStat()})}});
P.addEventListener('input',function(e){if(e.target&&e.target.id==='stPT'){rich=null;richStat()}});
P.addEventListener('click',function(e){
  var t=e.target,a=t.closest('[data-a]');if(a&&act[a.dataset.a]){act[a.dataset.a]();return}
  if(t.id==='stSheet'){closeSheet();return}
  var g=t.closest('[data-go]');if(g){closeSheet();if(S.view!=='text'){S.view='text';render()}var el=body.children[g.dataset.go];if(el){el.scrollIntoView({block:'start',behavior:'smooth'});el.classList.remove('flash');void el.offsetWidth;el.classList.add('flash')}return}
  var o=t.closest('[data-open]');if(o){S.cur=o.dataset.open;S.view='text';save();closeSheet();render();return}
  var dl=t.closest('[data-del]');if(dl){if(confirm('Supprimer cette leçon ?')){var id=dl.dataset.del;S.lessons=S.lessons.filter(function(l){return l.id!==id});if(S.cur===id)S.cur=S.lessons[0]?S.lessons[0].id:null;if(DB)kvDel('l:'+id).catch(function(){});save();closeSheet();render()}return}
  if(t.id==='stPOk'){
    var x=$('#stPT').value,nm=$('#stPN').value.trim(),B=(rich&&rich.length)?rich:(x.trim()?parseText(x):[]);
    if(B.length){closeSheet();rich=null;addLesson(nm||'Leçon '+(S.lessons.length+1),B)}return}
  var ob=t.closest('[data-orig]');if(ob){var tb=ob.closest('.stb');if(tb){tb.classList.toggle('showo');ob.textContent=tb.classList.contains('showo')?'📋 Voir le tableau':'📷 Voir l’original'}return}
  if(t.tagName==='IMG'&&body.contains(t)){zoom(t.src);return}
  var p=t.closest('.stb.p');if(p&&body.contains(p)){var l=lesson();if(!l||window.getSelection().toString())return;
    if(body.classList.contains('mask')){p.classList.toggle('rev');return}
    var i=+p.dataset.i,k=l.stars.indexOf(i);if(k>-1)l.stars.splice(k,1);else l.stars.push(i);p.classList.toggle('star');saveLesson(l)}});
var sv;body.addEventListener('scroll',function(){
  var m=body.scrollHeight-body.clientHeight;$('#stProg').style.width=(m>0?body.scrollTop/m*100:0)+'%';
  clearTimeout(sv);sv=setTimeout(function(){var l=lesson();if(l&&S.view==='text'){S.pos[l.id]=body.scrollTop;save()}},600)},{passive:true});

/* ---------- Démarrage : chargement des leçons enregistrées ---------- */
idbOpen().then(function(db){DB=db;return kvGet('meta')}).then(function(m){
  if(m){
    return Promise.all(m.ids.map(function(id){return kvGet('l:'+id)})).then(function(ls){
      S.lessons=ls.filter(Boolean);S.cur=m.cur;S.fs=m.fs||S.fs;S.pos=m.pos||{};
      if(!lesson())S.cur=S.lessons[0]?S.lessons[0].id:null})}
  if(S.lessons.length){/* migration depuis l'ancien stockage */
    return Promise.all(S.lessons.map(saveLesson)).then(function(){return saveMeta()}).then(function(){try{localStorage.removeItem(KEY)}catch(e){}})}
}).catch(function(e){console.warn('Stockage étude :',e);DB=null}).then(function(){if(!P.hidden)render()});
}catch(e){console.warn('Module étude :',e)}})();
