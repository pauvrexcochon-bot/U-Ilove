/* U&I — js/ui/onglets.js
   Barre d’onglets et navigation entre les écrans */
(function () {
  var $ = function (id) { return document.getElementById(id); };
  var app = $('app'), nav = $('tabbar');
  var views = { chats: 'viewList', news: 'viewNews', music: 'viewMusic', game: 'viewGame' };
  var openers = { news: 'openNews', music: 'openMusic', game: 'openGame' };
  var backs = { news: 'nwBack', music: 'musicBack', game: 'gameBack' };
  function cur() {
    if (app.hidden) return null;
    for (var k in views) { var v = $(views[k]); if (v && !v.hidden) return k; }
    return null;
  }
  function sync() {
    var c = cur();
    nav.hidden = !c;
    var nt = nav.querySelector('.tab[data-t="news"]');
    if (nt) nt.hidden = !!(window.newsBlocked && window.newsBlocked());
    document.body.classList.toggle('hasnav', !!c);
    nav.querySelectorAll('.tab').forEach(function (b) {
      if (b.dataset.t === c) b.setAttribute('aria-current', 'page'); else b.removeAttribute('aria-current');
    });
    var n = document.querySelectorAll('#chats .chatrow.unread').length, bd = nav.querySelector('.tabbadge');
    bd.hidden = !n; bd.textContent = n > 9 ? '9+' : String(n);
  }
  function go(t) {
    if (t === 'set') { $('openSet').click(); return; }
    var c = cur();
    if (!c || c === t) return;
    if (t === 'chats') { if (c !== 'chats') { var bb = $(backs[c]); bb.dataset.force = '1'; bb.click(); } return; }
    if (openers[t]) $(openers[t]).click();
  }
  nav.addEventListener('click', function (e) {
    var b = e.target.closest('.tab');
    if (b) go(b.dataset.t);
  });
  document.addEventListener('newsaccess', function () {
    if (window.newsBlocked && window.newsBlocked() && cur() === 'news') { var nb = $('nwBack'); nb.dataset.force = '1'; nb.click(); }
    sync();
  });
  var mo = new MutationObserver(sync);
  ['app', 'viewList', 'viewChat', 'viewMusic', 'viewNews', 'viewGame', 'login'].forEach(function (id) {
    var n = $(id); if (n) mo.observe(n, { attributes: true, attributeFilter: ['hidden'] });
  });
  mo.observe($('chats'), { childList: true, subtree: true, attributes: true, attributeFilter: ['class'] });
  var lo = $('setLogout');
  if (lo) lo.addEventListener('click', function () { $('settings').close(); $('logout').click(); });
  sync();
})();
