/* U&I — js/ui/clavier.js
   Suit la hauteur visible quand le clavier s’ouvre */
(function () {
  var vv = window.visualViewport; if (!vv) return;
  var root = document.documentElement;
  function sync() {
    var kb = window.innerHeight - vv.height;
    if (kb > 100) { root.style.setProperty('--vvh', vv.height + 'px'); }
    else { root.style.removeProperty('--vvh'); }
    if (kb > 100) window.scrollTo(0, 0);
    var log = document.getElementById('log');
    if (log && document.activeElement && document.activeElement.id === 'msg') {
      requestAnimationFrame(function () { log.scrollTop = log.scrollHeight; });
    }
  }
  vv.addEventListener('resize', sync);
  vv.addEventListener('scroll', function () { if (window.innerHeight - vv.height > 100) window.scrollTo(0, 0); });
  document.addEventListener('focusin', function (e) { if (e.target && e.target.id === 'msg') setTimeout(sync, 250); });
})();
