/* U&I — js/ui/retours-tactiles.js
   Ondulations et petites vibrations au toucher */
(function () {
  try {
    var RIP = '.ghost,.vact,.nwpost,.primary,.mok,.frbtns button,.send:not(.mic)';
    var HAP = RIP + ',.tab,.nwtab,.chatrow';
    var reduce = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
    function buzz(p) { try { if (navigator.vibrate) navigator.vibrate(p); } catch (e) {} }
    function closest(t, sel) { return t && t.closest ? t.closest(sel) : null; }

    /* 1) toucher : ondulation + petite vibration */
    document.addEventListener('pointerdown', function (e) {
      var h = closest(e.target, HAP);
      if (!h || h.disabled) return;
      buzz(6);
      var b = closest(e.target, RIP);
      if (!b || reduce) return;
      var r = b.getBoundingClientRect(), d = Math.max(r.width, r.height) * 2;
      var s = document.createElement('span');
      s.className = 'fx-rip';
      s.style.cssText = 'width:' + d + 'px;height:' + d + 'px;left:' + (e.clientX - r.left - d / 2) + 'px;top:' + (e.clientY - r.top - d / 2) + 'px';
      b.classList.add('fx-rip-host');
      b.appendChild(s);
      setTimeout(function () { if (s.parentNode) s.parentNode.removeChild(s); }, 520);
    }, true);

    /* 2) envoi de message */
    var lastSend = 0;
    function sentFx() {
      var ta = document.getElementById('msg'), sb = document.getElementById('send');
      if (!ta || !sb || ta.disabled || !ta.value.trim() || Date.now() - lastSend < 250) return;
      lastSend = Date.now();
      buzz(12);
      sb.classList.remove('fx-sent'); void sb.offsetWidth; sb.classList.add('fx-sent');
      setTimeout(function () { sb.classList.remove('fx-sent'); }, 450);
    }
    var form = document.getElementById('composer');
    if (form) form.addEventListener('submit', sentFx, true);
    var msg = document.getElementById('msg');
    if (msg) msg.addEventListener('keydown', function (e) {
      if (e.key === 'Enter' && !e.shiftKey && !e.isComposing && window.matchMedia && matchMedia('(pointer: fine)').matches) sentFx();
    }, true);

    /* 3) amis : Ajouter / Accepter -> « ✓ », Refuser / Annuler -> la ligne glisse */
    document.addEventListener('click', function (e) {
      var b = closest(e.target, '#frBody .frbtns button');
      if (!b || b.disabled) return;
      var t = (b.textContent || '').trim(), row = closest(b, '.frrow');
      if (t === 'Ajouter' || t === 'Accepter') {
        b.textContent = t === 'Ajouter' ? 'Envoyé' : 'Ami';
        b.classList.add('fx-done'); buzz([10, 40, 14]);
        setTimeout(function () {
          var er = document.getElementById('frErr');
          if (er && !er.hidden && b.isConnected) { b.classList.remove('fx-done'); b.textContent = t; }
        }, 2200);
      } else if ((t === 'Refuser' || t === 'Annuler') && row) {
        row.classList.add('fx-out'); buzz(8);
      }
    });

    /* 4) commentaires : bouton « en cours » puis le nouveau commentaire apparaît en surbrillance */
    var pending = 0, known = {};
    function snap() { known = {}; document.querySelectorAll('.nwc[data-cid]').forEach(function (n) { known[n.dataset.cid] = 1; }); }
    function startCm(btn) {
      var inp = btn && btn.parentNode && btn.parentNode.querySelector('.nwcinput');
      if (!inp || !inp.value.trim()) return;
      snap(); pending = Date.now(); buzz(10);
      btn.classList.add('fx-busy');
      setTimeout(function () { if (btn.isConnected) btn.classList.remove('fx-busy'); }, 4000);
    }
    document.addEventListener('click', function (e) { var b = closest(e.target, '.nwpost'); if (b) startCm(b); }, true);
    document.addEventListener('keydown', function (e) {
      if (e.key !== 'Enter' || !e.target || !e.target.classList || !e.target.classList.contains('nwcinput')) return;
      startCm(e.target.parentNode.querySelector('.nwpost'));
    }, true);
    new MutationObserver(function () {
      if (!pending) return;
      if (Date.now() - pending > 6000) { pending = 0; return; }
      var hit = false;
      document.querySelectorAll('.nwc[data-cid]').forEach(function (n) {
        if (!known[n.dataset.cid]) { n.classList.add('fx-new'); hit = true; }
      });
      if (hit) { pending = 0; buzz([8, 30, 8]); }
    }).observe(document.body, { childList: true, subtree: true });
  } catch (err) { /* les retours visuels ne doivent jamais casser l'appli */ }
})();
