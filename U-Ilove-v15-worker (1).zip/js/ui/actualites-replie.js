/* U&I — js/ui/actualites-replie.js
   Actualités : l’en-tête se replie quand on fait défiler */
(function(){
  var pane=document.getElementById('nwPaneFeed'),feed=document.getElementById('nwFeed');
  if(!pane||!feed)return;
  var last=0,lock=0,box=pane.querySelector(':scope>.nwbox');
  function set(on){pane.classList.toggle('nw-collapse',on);lock=Date.now()+380;}
  feed.addEventListener('scroll',function(){
    var y=feed.scrollTop,d=y-last,col=pane.classList.contains('nw-collapse');
    last=y;
    if(Date.now()<lock)return;
    if(pane.classList.contains('open')||(box&&box.contains(document.activeElement))){if(col)set(false);return;}
    if(!col&&d>8&&y>40&&feed.scrollHeight-feed.clientHeight>260)set(true);
    else if(col&&y<=2)set(false);
  },{passive:true});
  feed.addEventListener('pointerdown',function(){if(feed.scrollTop<=2&&pane.classList.contains('nw-collapse'))set(false);},true);
})();
