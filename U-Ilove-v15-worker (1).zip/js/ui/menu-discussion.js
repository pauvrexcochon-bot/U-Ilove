/* U&I — js/ui/menu-discussion.js
   Menu « ⋯ » de la discussion */
(function () {
  var menu = document.getElementById('chatMenu'), themes = document.getElementById('themes'), more = document.getElementById('moreBtn');
  if (!menu) return;
  function closeMenu() { menu.hidden = true; more.setAttribute('aria-expanded', 'false'); }
  menu.addEventListener('click', function (e) {
    var b = e.target.closest('.ghost');
    if (!b || b.id === 'delChat') return;
    setTimeout(closeMenu, 0);
  });
  document.addEventListener('click', function (e) {
    var t = e.target;
    if (t.closest('#chatMenu, #moreBtn, #themes, #themeBtn')) return;
    if (!menu.hidden) closeMenu();
    if (themes && !themes.hidden) themes.hidden = true;
  });
})();
