/* U&I — js/ui/reglages-recherche.js
   Réglages : recherche et sous-titres en direct */
(function () { try {
  var dlg = document.getElementById('settings'); if (!dlg || dlg.dataset.sxs) return; dlg.dataset.sxs = '1';
  var h2 = dlg.querySelector('h2'); if (!h2) return;
  var wrap = document.createElement('div'); wrap.className = 'sxs';
  wrap.innerHTML = '<input type="search" id="sxSearch" placeholder="Rechercher un réglage…" autocomplete="off" autocapitalize="none" spellcheck="false" aria-label="Rechercher un réglage"><p class="sxe" id="sxEmpty" hidden>Aucun réglage trouvé.</p>';
  h2.after(wrap);
  var KW = {
    'Application': 'installer appli ecran accueil telecharger',
    'Photo de profil': 'photo avatar image',
    'Mon nom': 'pseudo prenom nom changer',
    'Style': 'theme couleur skin nuit clair foret rose neant',
    'Apparence': 'sombre clair auto mode',
    'Verrouillage': 'code pin empreinte securite cadenas',
    'Mon anniversaire': 'date fete',
    'Confidentialité': 'statut en ligne vu lu invisible prive',
    'Badge': 'createur certifie',
    'Outils': 'comptes statistiques signalements annonce',
    'Mot de passe': 'securite recuperation code',
    'Notifications': 'notification push son vibration voix sourdine silence ne pas deranger alerte calme',
    'Espace': 'stockage photos liberer place',
    'Compte': 'supprimer effacer compte'
  };
  function norm(t) { return String(t || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().trim(); }
  function secs() { return Array.prototype.slice.call(dlg.querySelectorAll('.sec.sx')); }
  function titleOf(sec) { var b = sec.querySelector('.sxh b'); return b ? b.textContent.trim() : ''; }
  function keyOf(sec) { var t = titleOf(sec), k = ''; Object.keys(KW).forEach(function (x) { if (t.indexOf(x) === 0) k = KW[x]; }); return k; }
  var inp = document.getElementById('sxSearch');
  inp.addEventListener('input', function () {
    var q = norm(inp.value), shown = [];
    secs().forEach(function (sec) {
      if (sec.hidden) return;
      var sm = sec.querySelector('.sxh small'), hay = norm(titleOf(sec) + ' ' + (sm ? sm.textContent : '') + ' ' + keyOf(sec));
      var ok = !q || q.split(/\s+/).every(function (w) { return hay.indexOf(w) !== -1; });
      sec.classList.toggle('sx-off', !ok); if (ok) shown.push(sec);
    });
    document.getElementById('sxEmpty').hidden = !q || shown.length > 0;
    if (q && shown.length === 1 && !shown[0].classList.contains('open')) { var h = shown[0].querySelector('.sxh'); if (h) h.click(); }
  });
  function sub(title, text) {
    secs().forEach(function (sec) { if (titleOf(sec).indexOf(title) === 0) { var sm = sec.querySelector('.sxh small'); if (sm && text) sm.textContent = text; } });
  }
  function pressed(sel) { var b = dlg.querySelector(sel + ' button[aria-pressed="true"]'); return b ? b.textContent.trim() : ''; }
  function live() {
    sub('Style', pressed('#skinSeg'));
    sub('Apparence', pressed('#modeSeg'));
    var off = document.getElementById('lockOff'); sub('Verrouillage', off && !off.hidden ? 'Code actif' : 'Pas de code');
    var a = document.getElementById('hideOnBtn'), v = document.getElementById('hideSeenBtn'), hid = [];
    if (a && a.getAttribute('aria-pressed') === 'true') hid.push('Statut masqué');
    if (v && v.getAttribute('aria-pressed') === 'true') hid.push('« Vu » masqué');
    sub('Confidentialité', hid.length ? hid.join(' · ') : 'Tout visible');
  }
  new MutationObserver(function () { if (dlg.open) { live(); inp.value = ''; inp.dispatchEvent(new Event('input')); } }).observe(dlg, { attributes: true, attributeFilter: ['open'] });
  dlg.addEventListener('click', function () { setTimeout(live, 80); });
  live();
} catch (e) { console.warn('Réglages (recherche) :', e); } })();
