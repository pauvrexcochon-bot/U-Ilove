/* U&I — js/ui/animations.js
   Fluidité : animations pilotées par le DOM */
/* ============ Fluidité : animations pilotées par le DOM ============ */
(function () {
  'use strict';
  var RMQ = window.matchMedia ? matchMedia('(prefers-reduced-motion: reduce)') : null;
  function reduced() { return !!(RMQ && RMQ.matches); }
  var $ = function (id) { return document.getElementById(id); };
  var SPRING = (getComputedStyle(document.documentElement).getPropertyValue('--spring-soft') || '').trim() || 'cubic-bezier(.3,1.2,.5,1)';
  function anim(el, kf, opt) {
    if (!el.animate || reduced()) return;
    try { opt.easing = SPRING; el.animate(kf, opt); }
    catch (e) { try { opt.easing = 'ease-out'; el.animate(kf, opt); } catch (e2) {} }
  }
  function raf(fn) { var q = 0; return function () { cancelAnimationFrame(q); q = requestAnimationFrame(fn); }; }

  /* 1. Barre d'onglets : pastille qui glisse */
  function tabIndicator() {
    var nav = $('tabbar'); if (!nav) return;
    var ind = document.createElement('i'); ind.className = 'tabind'; ind.setAttribute('aria-hidden', 'true');
    nav.insertBefore(ind, nav.firstChild);
    var placed = false;
    function place() {
      var t = nav.querySelector('.tab[aria-current="page"]');
      if (!t || nav.hidden || !t.offsetWidth) { ind.classList.remove('on'); placed = false; return; }
      if (!placed) ind.style.transition = 'none';
      ind.style.translate = t.offsetLeft + 'px 0'; ind.style.width = t.offsetWidth + 'px';
      ind.classList.add('on');
      if (!placed) { ind.getBoundingClientRect(); ind.style.transition = ''; placed = true; }
    }
    var sched = raf(place);
    new MutationObserver(sched).observe(nav, { attributes: true, subtree: true, attributeFilter: ['aria-current', 'hidden'] });
    window.addEventListener('resize', sched);
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(sched);
    sched();
  }

  /* 2. Onglets / segments : pastille qui glisse */
  function slideInd() {
    function setup(c) {
      if (c.dataset.si) return; c.dataset.si = '1';
      var ind = document.createElement('i'); ind.className = 'slideind'; ind.setAttribute('aria-hidden', 'true');
      c.insertBefore(ind, c.firstChild);
      var placed = false;
      function place() {
        var a = c.querySelectorAll(':scope > button[aria-selected="true"], :scope > button[aria-pressed="true"]');
        if (a.length !== 1 || !c.offsetWidth || !a[0].offsetWidth) { c.classList.remove('si'); ind.classList.remove('on'); placed = false; return; }
        var b = a[0];
        if (!placed) ind.style.transition = 'none';
        ind.style.translate = b.offsetLeft + 'px ' + b.offsetTop + 'px';
        ind.style.width = b.offsetWidth + 'px'; ind.style.height = b.offsetHeight + 'px';
        ind.style.borderRadius = getComputedStyle(b).borderRadius;
        c.classList.add('si'); ind.classList.add('on');
        if (!placed) { ind.getBoundingClientRect(); ind.style.transition = ''; placed = true; }
      }
      var sched = raf(place);
      new MutationObserver(sched).observe(c, { attributes: true, subtree: true, attributeFilter: ['aria-selected', 'aria-pressed', 'hidden'] });
      if (window.ResizeObserver) new ResizeObserver(sched).observe(c);
      sched();
    }
    function scan() { document.querySelectorAll('.tabs:not([data-si]), .seg:not([data-si])').forEach(setup); }
    scan();
    var t = 0;
    new MutationObserver(function () { clearTimeout(t); t = setTimeout(scan, 250); }).observe(document.body, { childList: true, subtree: true });
  }

  /* 3. Messages : chaque nouveau message arrive en douceur */
  function logAnim() {
    var log = $('log'); if (!log) return;
    var seen = Object.create(null), ent = Object.create(null), cold = true;
    function reset() { seen = Object.create(null); ent = Object.create(null); cold = true; }
    var vc = $('viewChat');
    if (vc) new MutationObserver(reset).observe(vc, { attributes: true, attributeFilter: ['hidden'] });
    new MutationObserver(function () {
      var rows = log.querySelectorAll('.row[data-id]'), now = performance.now(), i, id;
      if (!rows.length) { if (log.querySelector('.empty')) cold = false; return; }
      var first = -1;
      for (i = 0; i < rows.length; i++) if (seen[rows[i].dataset.id]) { first = i; break; }
      if (first < 0 && Object.keys(seen).length) { reset(); }
      var fresh = [];
      for (i = 0; i < rows.length; i++) {
        id = rows[i].dataset.id;
        if (seen[id]) continue;
        seen[id] = 1;
        if (cold) fresh.push(i);
        else if (first < 0 || i > first) ent[id] = now;   /* ajout en bas */
      }
      if (cold) {
        var from = Math.max(0, rows.length - 7);
        fresh.forEach(function (k) { if (k >= from) ent[rows[k].dataset.id] = now + (k - from) * 36; });
        cold = false;
      }
      for (i = 0; i < rows.length; i++) {
        id = rows[i].dataset.id;
        if (ent[id] === undefined) continue;
        var dt = ent[id] - now;
        if (dt > -600) { rows[i].classList.add('enter'); rows[i].style.animationDelay = dt + 'ms'; }
        else delete ent[id];
      }
    }).observe(log, { childList: true });
  }

  /* 4. Liste des discussions : cascade à l'ouverture + déplacements fluides */
  function listAnim() {
    var ul = $('chats'), vl = $('viewList'); if (!ul || !vl) return;
    var intro = true, pos = Object.create(null);
    new MutationObserver(function () { if (!vl.hidden) intro = true; }).observe(vl, { attributes: true, attributeFilter: ['hidden'] });
    function key(li) { var b = li.firstElementChild; if (!b || !b.dataset) return null; return b.dataset.gid ? 'g' + b.dataset.gid : (b.dataset.uid ? 'u' + b.dataset.uid : null); }
    new MutationObserver(function () {
      if (vl.hidden) { pos = Object.create(null); return; }
      var rows = [], i, k, li, items = ul.children;
      for (i = 0; i < items.length; i++) { k = key(items[i]); if (k) rows.push([k, items[i]]); }
      if (!rows.length) return;
      var had = Object.keys(pos).length;
      if (intro) {
        intro = false;
        rows.forEach(function (r, n) { if (n < 12) { r[1].classList.add('rowin'); r[1].style.setProperty('--i', n); } });
      } else if (had) {
        rows.forEach(function (r) {
          if (r[0] in pos) {
            var dy = pos[r[0]] - r[1].offsetTop;
            if (Math.abs(dy) > 3) anim(r[1], [{ translate: '0 ' + dy + 'px' }, { translate: '0 0' }], { duration: 520 });
          } else anim(r[1], [{ opacity: 0, scale: .92, translate: '0 -10px' }, { opacity: 1, scale: 1, translate: '0 0' }], { duration: 480 });
        });
      }
      pos = Object.create(null);
      rows.forEach(function (r) { pos[r[0]] = r[1].offsetTop; });
    }).observe(ul, { childList: true });
  }

  /* 5. Fenêtres : fermeture animée */
  function dialogs() {
    var oClose = HTMLDialogElement.prototype.close, oShow = HTMLDialogElement.prototype.showModal;
    HTMLDialogElement.prototype.close = function (rv) {
      var d = this;
      if (!d.open || d.id === 'lockDlg' || reduced()) return oClose.call(d, rv);
      if (d.dataset.closing) return;
      d.dataset.closing = '1'; d.classList.add('closing');
      d._ct = setTimeout(function () {
        d.classList.remove('closing'); delete d.dataset.closing; d._ct = 0;
        oClose.call(d, rv);
      }, 190);
    };
    HTMLDialogElement.prototype.showModal = function () {
      var d = this;
      if (d.dataset.closing) { clearTimeout(d._ct); d.classList.remove('closing'); delete d.dataset.closing; d._ct = 0; return; }
      return oShow.call(d);
    };
    document.addEventListener('cancel', function (e) {
      var d = e.target;
      if (d && d.tagName === 'DIALOG' && d.id !== 'lockDlg' && !reduced()) { e.preventDefault(); d.close(); }
    }, true);
  }

  function safe(f) { try { f(); } catch (e) {} }
  function init() { safe(tabIndicator); safe(slideInd); safe(logAnim); safe(listAnim); safe(function () { if (window.HTMLDialogElement) dialogs(); }); }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
