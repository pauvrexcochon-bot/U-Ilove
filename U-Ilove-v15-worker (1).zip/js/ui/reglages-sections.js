/* U&I — js/ui/reglages-sections.js
   Réglages : regroupe les blocs en sections repliables */
(function () { try {
  var dlg = document.getElementById('settings'); if (!dlg || dlg.dataset.sx) return; dlg.dataset.sx = '1';
  var I = {
    user: '<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 4-6 8-6s8 2 8 6"/>',
    pencil: '<path d="M4 20h4L19 9l-4-4L4 16z"/>',
    palette: '<path d="M12 3a9 9 0 1 0 0 18c1.5 0 2-1 1.5-2.2-.5-1.2.3-2.3 1.7-2.3H17a4 4 0 0 0 4-4c0-5-4-9.5-9-9.500z"/><circle cx="7.5" cy="11" r="1"/><circle cx="11" cy="7.5" r="1"/><circle cx="16" cy="8.5" r="1"/>',
    sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M2 12h2M20 12h2M5 5l1.5 1.500M17.5 17.500L19 19M5 19l1.5-1.500M17.5 6.500L19 5"/>',
    lock: '<rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>',
    cake: '<path d="M4 20h16v-6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2z"/><path d="M12 12V8M12 4v1"/>',
    shield: '<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/>',
    badge: '<circle cx="12" cy="9" r="5"/><path d="M9 13.500L8 21l4-2 4 2-1-7.5"/>',
    tools: '<path d="M14 6a4 4 0 0 0 5 5l-9 9a2 2 0 0 1-3-3z"/><path d="M14 6l3-3 3 3-3 3"/>',
    key: '<circle cx="8" cy="14" r="4"/><path d="M11 11l9-8M16 6l3 3"/>',
    bell: '<path d="M6 17v-6a6 6 0 0 1 12 0v6l2 2H4z"/><path d="M10 21h4"/>',
    box: '<path d="M3 7l9-4 9 4v10l-9 4-9-4z"/><path d="M3 7l9 4 9-4M12 11v10"/>',
    trash: '<path d="M5 7h14M10 7V4h4v3M7 7l1 13h8l1-13"/>',
    download: '<path d="M12 4v11M7 11l5 5 5-5M5 20h14"/>',
    chev: '<path d="M9 6l6 6-6 6"/>'
  };
  var M = {
    'Application': ['download', 'Installer sur ce téléphone'],
    'Photo de profil': ['user', 'Changer ou retirer ta photo'],
    'Mon nom': ['pencil', 'Modifier ton nom'],
    'Style': ['palette', 'Défaut, Nuit, Clair, Forêt…'],
    'Apparence': ['sun', 'Auto, clair ou sombre'],
    'Verrouillage': ['lock', 'Code et empreinte'],
    'Mon anniversaire': ['cake', 'Visible par tes amis'],
    'Confidentialité': ['shield', 'Statut en ligne et « Vu »'],
    'Badge créateur': ['badge', 'Activer ton badge'],
    'Outils créateur': ['tools', 'Comptes et statistiques'],
    'Mot de passe': ['key', 'Changer et récupérer'],
    'Notifications': ['bell', 'Push, son et ne pas déranger'],
    'Espace': ['box', 'Libérer de la place'],
    'Compte': ['trash', 'Supprimer mon compte']
  };
  function svg(n) { return '<svg viewBox="0 0 24 24" aria-hidden="true">' + I[n] + '</svg>'; }
  var all = [];
  function closeAll(except) {
    all.forEach(function (x) { if (x.sec !== except) { x.body.hidden = true; x.h.setAttribute('aria-expanded', 'false'); x.sec.classList.remove('open'); } });
  }
  Array.prototype.forEach.call(dlg.children, function (sec) {
    if (!sec.classList || !sec.classList.contains('sec')) return;
    var l = null; Array.prototype.forEach.call(sec.children, function (c) { if (!l && c.classList.contains('lbl')) l = c; });
    if (!l) return;
    var t = l.textContent.trim(), m = null;
    Object.keys(M).forEach(function (k) { if (t.indexOf(k) === 0) m = M[k]; });
    if (!m) m = ['user', ''];
    var body = document.createElement('div'); body.className = 'sxb'; body.hidden = true;
    while (sec.firstChild) body.appendChild(sec.firstChild);
    l.style.display = 'none';
    var h = document.createElement('button'); h.type = 'button'; h.className = 'sxh'; h.setAttribute('aria-expanded', 'false');
    h.innerHTML = '<span class="sxi">' + svg(m[0]) + '</span><span class="sxt"><b></b><small></small></span><span class="sxc">' + svg('chev') + '</span>';
    h.querySelector('b').textContent = t; h.querySelector('small').textContent = m[1];
    sec.appendChild(h); sec.appendChild(body); sec.classList.add('sx');
    if (t.indexOf('Compte') === 0) sec.classList.add('dg');
    all.push({ sec: sec, h: h, body: body });
    h.addEventListener('click', function () {
      var open = body.hidden;
      closeAll(sec);
      body.hidden = !open; h.setAttribute('aria-expanded', open ? 'true' : 'false'); sec.classList.toggle('open', open);
      if (open) setTimeout(function () { try { sec.scrollIntoView({ block: 'nearest', behavior: 'smooth' }); } catch (e) {} }, 60);
    });
  });
  dlg.addEventListener('close', function () { closeAll(null); });
} catch (e) { console.warn('Réglages :', e); } })();
