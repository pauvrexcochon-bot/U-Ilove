/* U&I — js/ui/bouton-plus.js
   Bouton « + » du champ de message */
(function(){ try {
  var $=function(s){return document.querySelector(s)};
  var plus='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg>';
  var pen='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 20h4L19 9l-4-4L4 16zM13.5 6.5l4 4"/></svg>';
  var comp=$('#composer'), pic=$('#pic');
  if(comp && pic && !$('#plusBtn')){
    var pb=document.createElement('button'); pb.type='button'; pb.id='plusBtn'; pb.className='send mic';
    pb.setAttribute('aria-label','Plus : photo'); pb.setAttribute('aria-expanded','false'); pb.innerHTML=plus;
    comp.insertBefore(pb, comp.firstChild);
    pb.addEventListener('click',function(){ var o=comp.classList.toggle('plus-open'); pb.setAttribute('aria-expanded',o?'true':'false'); });
    pic.addEventListener('click',function(){ comp.classList.remove('plus-open'); pb.setAttribute('aria-expanded','false'); });
    ['docBtn','musBtn'].forEach(function(id){ var db=document.getElementById(id); if(db) db.addEventListener('click',function(){ comp.classList.remove('plus-open'); pb.setAttribute('aria-expanded','false'); }); });
    comp.addEventListener('submit',function(){ comp.classList.remove('plus-open'); });
  }
  var m3=$('#m3Open'), br=$('#brOpen'), sfx=$('#sfxBtn');
  if(m3 && br && sfx && m3.parentNode){
    var hub=document.createElement('div'); hub.className='ghub';
    m3.parentNode.insertBefore(hub,m3); hub.appendChild(m3); hub.appendChild(br); hub.appendChild(sfx);
  }
  function fab(id,label,html,fn){ var b=document.createElement('button'); b.type='button'; b.id=id; b.className='fxfab'; b.setAttribute('aria-label',label); b.innerHTML=html; b.addEventListener('click',fn); document.body.appendChild(b); return b; }
  var SPARK='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8zM19 16l.8 2.2L22 19l-2.2.8L19 22l-.8-2.2L16 19l2.2-.8z"/></svg>';
  var BOOK='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 5.5A2.5 2.5 0 0 1 6.5 3H20v16H6.5A2.5 2.5 0 0 0 4 21.5zM4 5.5V21.5M8 7h8M8 11h6"/></svg>';
  var fmenu=document.createElement('div'); fmenu.id='fabMenu';
  fmenu.innerHTML='<button type="button" id="fmAi">'+SPARK+'X.Uni</button><button type="button" id="fmSt">'+BOOK+'Étudier</button>';
  document.body.appendChild(fmenu);
  function closeMenu(){ fmenu.classList.remove('on'); var f=$('#fabNew'); if(f){ f.classList.remove('open'); f.setAttribute('aria-expanded','false'); } }
  var fl=fab('fabNew','X.Uni et étude',plus,function(e){ e.stopPropagation(); var o=fmenu.classList.toggle('on'); fl.classList.toggle('open',o); fl.setAttribute('aria-expanded',o?'true':'false'); });
  fl.setAttribute('aria-haspopup','true'); fl.setAttribute('aria-expanded','false');
  fmenu.addEventListener('click',function(e){ var b=e.target.closest('button'); if(!b) return; closeMenu(); if(b.id==='fmAi'&&window.uandiAI) window.uandiAI.open(); if(b.id==='fmSt'&&window.uandiStudy) window.uandiStudy.open(); });
  document.addEventListener('click',function(e){ if(fmenu.classList.contains('on') && !e.target.closest('#fabMenu,#fabNew')) closeMenu(); });
  var fn=fab('fabLetter','Écrire une lettre',pen+'<span>Écrire</span>',function(){
    var p=$('#nwPaneFeed'); if(!p) return; var o=p.classList.toggle('open');
    if(o){ var t=$('#nwText'); if(t) setTimeout(function(){ t.focus(); },120); }
  });
  function sync(){
    var vl=$('#viewList'), vn=$('#viewNews'), pf=$('#nwPaneFeed'), ap=$('#app'), lg=!!ap && !ap.hidden;
    fl.classList.toggle('on', lg && !!vl && !vl.hidden);
    if(!(lg && vl && !vl.hidden)) closeMenu();
    fn.classList.toggle('on', lg && !!vn && !vn.hidden && !!pf && !pf.hidden);
  }
  new MutationObserver(sync).observe(document.body,{attributes:true,attributeFilter:['hidden'],subtree:true});
  sync();
} catch(e) { /* l'interface ne doit jamais casser l'appli */ } })();
