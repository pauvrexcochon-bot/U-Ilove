/* U&I — js/ui/animations-actualites.js
   Fluidité : animations des actualités */
(function () {
  var feed = document.getElementById('nwFeed'), vn = document.getElementById('viewNews');
  if (!feed) return;
  var rm = window.matchMedia ? matchMedia('(prefers-reduced-motion: reduce)') : null;
  var cards = Object.create(null), cms = Object.create(null), opens = Object.create(null), ent = Object.create(null), cold = true;
  function reset() { cards = Object.create(null); cms = Object.create(null); opens = Object.create(null); ent = Object.create(null); cold = true; }
  if (vn) new MutationObserver(reset).observe(vn, { attributes: true, attributeFilter: ['hidden'] });
  new MutationObserver(function () {
    if (rm && rm.matches) return;
    var now = performance.now(), list = feed.querySelectorAll(':scope > .nwcard[data-id]'), i, id, k = 0;
    for (i = 0; i < list.length; i++) {
      var card = list[i]; id = card.dataset.id;
      if (!cards[id]) { cards[id] = 1; if (cold) { if (k < 6) ent['k' + id] = now + (k++) * 55; } else ent['k' + id] = now; }
      var box = card.querySelector(':scope > .nwcm'), cs = card.querySelectorAll('.nwc[data-cid]'), j;
      if (box) {
        var fresh = !opens[id]; opens[id] = 1;
        if (fresh && !cold) ent['b' + id] = now;
        for (j = 0; j < cs.length; j++) {
          var ck = id + ':' + cs[j].dataset.cid;
          if (!cms[ck]) { cms[ck] = 1; if (fresh) { if (j < 8) ent['c' + ck] = now + 90 + j * 45; } else ent['c' + ck] = now; }
        }
      } else if (opens[id]) { delete opens[id]; Object.keys(cms).forEach(function (q) { if (q.indexOf(id + ':') === 0) delete cms[q]; }); }
    }
    cold = false;
    function apply(el, key) {
      var t = ent[key]; if (t === undefined) return;
      var dt = t - now;
      if (dt > -650) { el.classList.add('fxin'); el.style.animationDelay = dt + 'ms'; } else delete ent[key];
    }
    for (i = 0; i < list.length; i++) {
      id = list[i].dataset.id; apply(list[i], 'k' + id);
      var b2 = list[i].querySelector(':scope > .nwcm'); if (b2) apply(b2, 'b' + id);
      var c2 = list[i].querySelectorAll('.nwc[data-cid]');
      for (var m = 0; m < c2.length; m++) apply(c2[m], 'c' + id + ':' + c2[m].dataset.cid);
    }
  }).observe(feed, { childList: true, subtree: true });
  /* changement de thème / mode : fondu des couleurs */
  var swapT = 0, root = document.documentElement;
  new MutationObserver(function () {
    if (rm && rm.matches) return;
    root.classList.add('themeswap'); clearTimeout(swapT);
    swapT = setTimeout(function () { root.classList.remove('themeswap'); }, 650);
  }).observe(root, { attributes: true, attributeFilter: ['data-skin', 'data-eff', 'data-ct', 'data-bg'] });
})();
