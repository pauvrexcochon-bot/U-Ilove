/* U&I — js/ui/bande-notes.js
   Bande des notes des amis */
(function(){ try {
  var chats=document.getElementById('chats'); if(!chats||!chats.parentNode) return;
  var strip=document.createElement('div'); strip.id='noteStrip'; strip.hidden=true;
  strip.setAttribute('aria-label','Notes de tes amis'); chats.parentNode.insertBefore(strip,chats);
  var raf=0;
  function build(){
    raf=0; strip.textContent='';
    var rings=chats.querySelectorAll('.chatrow .avatar.ring');
    rings.forEach(function(a){
      var row=a.closest('.chatrow'), it=document.createElement('button'), c=a.cloneNode(true), l=document.createElement('span');
      it.type='button'; it.className='nsitem'; c.removeAttribute('id'); l.textContent=(row&&row.dataset.name)||'';
      it.appendChild(c); it.appendChild(l); it.addEventListener('click',function(){ a.click(); }); strip.appendChild(it);
    });
    strip.hidden=!rings.length;
  }
  new MutationObserver(function(){ if(!raf) raf=requestAnimationFrame(build); }).observe(chats,{childList:true,subtree:true,attributes:true,attributeFilter:['class']});
  build();
} catch(e) { /* ne casse jamais l'appli */ } })();
