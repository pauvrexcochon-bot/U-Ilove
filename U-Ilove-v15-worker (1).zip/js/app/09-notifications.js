/* U&I — js/app/09-notifications.js
   Alertes, préférences de notifications, panneau des réglages, ouverture depuis une notification
   (fait partie de l’appli : assemblée par js/boot/loader.js dans une seule fermeture) */
  /* ---------- alertes : son, vibration, notification ---------- */
  var audioCtx = null;
  function beep() {
    try {
      audioCtx = audioCtx || new (window.AudioContext || window.webkitAudioContext)();
      var o = audioCtx.createOscillator(), g = audioCtx.createGain();
      o.type = 'sine'; o.frequency.value = 880;
      g.gain.setValueAtTime(0.08, audioCtx.currentTime);
      g.gain.exponentialRampToValueAtTime(0.0001, audioCtx.currentTime + 0.25);
      o.connect(g); g.connect(audioCtx.destination);
      o.start(); o.stop(audioCtx.currentTime + 0.25);
    } catch (e) {}
  }
  var NOTIF_TITLE = 'Vous avez un nouveau message U&I \u2764\uFE0F\u200D\uD83E\uDE79';
  /* ---------- préférences de notifications (propres à cet appareil) ---------- */
  var NP_DEF = { msg: 1, friends: 1, news: 1, sound: 1, vib: 1, quiet: 0, qFrom: '22:00', qTo: '07:00', muteUntil: 0 };
  function npGet() {
    var o = {}; try { o = JSON.parse(store('uandi-np') || '{}') || {}; } catch (e) {}
    var r = {}; for (var k in NP_DEF) r[k] = (k in o) ? o[k] : NP_DEF[k];
    return r;
  }
  function npSet(k, v) { var p = npGet(); p[k] = v; store('uandi-np', JSON.stringify(p)); npSync(); }
  function npMin(t) { var m = /^(\d\d):(\d\d)$/.exec(t || ''); return m ? (+m[1]) * 60 + (+m[2]) : 0; }
  function npQuiet() {
    var p = npGet(); if (p.muteUntil > Date.now()) return true;
    if (!p.quiet) return false;
    var d = new Date(), n = d.getHours() * 60 + d.getMinutes(), a = npMin(p.qFrom), b = npMin(p.qTo);
    if (a === b) return false;
    return a < b ? (n >= a && n < b) : (n >= a || n < b);
  }
  function npOn(kind) { return !!npGet()[kind]; }
  /* le service worker lit ces réglages (IndexedDB) : pendant « ne pas déranger », les push arrivent sans son */
  function npSync() {
    try {
      var p = JSON.stringify(npGet()), rq = indexedDB.open('uandi-np', 1);
      rq.onupgradeneeded = function () { rq.result.createObjectStore('kv'); };
      rq.onsuccess = function () { try { rq.result.transaction('kv', 'readwrite').objectStore('kv').put(p, 'np'); } catch (e) {} };
    } catch (e) {}
  }
  /* son + vibration selon les réglages ; renvoie false si l'appareil doit rester silencieux */
  function fx() {
    if (npQuiet()) return false;
    if (npOn('sound')) beep();
    if (npOn('vib')) { try { if (navigator.vibrate) navigator.vibrate(120); } catch (e) {} }
    return true;
  }
  function voiceOn() { return store('uandi-voice') !== '0'; }
  var speakU = null, frVoice = null, speechOk = false;
  function pickVoice() {
    try {
      var vs = speechSynthesis.getVoices() || [];
      frVoice = vs.filter(function (v) { return /^fr/i.test(v.lang); })[0] || null;
    } catch (e) {}
  }
  try {
    if (window.speechSynthesis) {
      pickVoice();
      if (speechSynthesis.addEventListener) speechSynthesis.addEventListener('voiceschanged', pickVoice);
    }
  } catch (e) {}
  /* les navigateurs n'autorisent la voix qu'après un premier geste : on la « débloque » au premier appui */
  function unlockSpeech() {
    if (speechOk) return; speechOk = true;
    try {
      var u = new SpeechSynthesisUtterance(' '); u.volume = 0; u.lang = 'fr-FR';
      speechSynthesis.speak(u);
    } catch (e) {}
  }
  var lastUnlock = 0;
  function reUnlock() {
    var now = Date.now();
    if (!window.speechSynthesis || now - lastUnlock < 30000) return;
    lastUnlock = now;
    try {
      var ss = window.speechSynthesis;
      if (ss.paused) ss.resume();
      if (!ss.speaking && !ss.pending) { var u = new SpeechSynthesisUtterance(' '); u.volume = 0; u.lang = 'fr-FR'; ss.speak(u); }
    } catch (e) {}
    if (!frVoice) pickVoice();
  }
  ['pointerdown', 'keydown', 'touchstart'].forEach(function (ev) { document.addEventListener(ev, unlockSpeech, { once: true, passive: true }); document.addEventListener(ev, reUnlock, { passive: true }); });
  function speakNew(force, onFail) {
    try {
      var ss = window.speechSynthesis;
      if (!ss) { if (onFail) onFail('non pris en charge par ce navigateur'); return; }
      var inCall = false; try { inCall = typeof C !== 'undefined' && !!C.role; } catch (e) {}
      if (!force && (!voiceOn() || inCall)) return;
      if (!frVoice) pickVoice();
      var attempt = 0;
      function say(useVoice) {
        var u = new SpeechSynthesisUtterance('Vous avez un nouveau message'), started = false, failed = false;
        u.lang = 'fr-FR'; u.volume = 1; u.rate = 1; u.pitch = 1;
        if (useVoice && frVoice) u.voice = frVoice;
        u.onstart = function () { started = true; };
        u.onerror = function (ev) {
          var er = ev && ev.error;
          if (er === 'canceled' || er === 'interrupted') return;
          failed = true;
          if (attempt++ < 1) { try { ss.cancel(); } catch (x) {} setTimeout(function () { say(false); }, 200); }
          else if (onFail) onFail(er || 'erreur');
        };
        speakU = u;
        try { ss.speak(u); } catch (e) { if (onFail) onFail('lecture impossible'); return; }
        /* certains téléphones laissent la voix en attente sans rien dire : on relance une fois, sans voix imposée */
        setTimeout(function () {
          if (started || failed || ss.speaking) return;
          if (attempt++ < 1) { try { ss.cancel(); } catch (x) {} setTimeout(function () { say(false); }, 200); }
          else if (onFail) onFail('aucune voix française installée ou volume média à zéro');
        }, 1600);
      }
      try { if (ss.paused) ss.resume(); } catch (e) {}
      if (ss.speaking || ss.pending) { ss.cancel(); setTimeout(function () { say(true); }, 200); }
      else say(true);
    } catch (e) { if (onFail) onFail('erreur'); }
  }
  function voiceFail(why) {
    try { showToast(null, 'Voix indisponible', 'Cause : ' + why + '. Sur Android : Réglages \u2192 Synthèse vocale \u2192 installe ou choisis le français, puis vérifie le volume média.'); } catch (e) {}
  }
  function paintVoiceSeg() {
    var on = voiceOn() ? '1' : '0';
    document.querySelectorAll('#voiceSeg button').forEach(function (b) { b.setAttribute('aria-pressed', b.dataset.v === on ? 'true' : 'false'); });
  }
  $('#voiceSeg').addEventListener('click', function (e) {
    var b = e.target.closest('button'); if (!b) return;
    store('uandi-voice', b.dataset.v); paintVoiceSeg();
    if (b.dataset.v === '1') speakNew(true, voiceFail); else { try { speechSynthesis.cancel(); } catch (x) {} }
  });
  paintVoiceSeg();
  function sysNotify(name, text, chatId, silent) {
    try {
      if (!('Notification' in window) || Notification.permission !== 'granted') return;
      var opt = { body: (name ? cap(name) + ' : ' : '') + (text || ''), tag: 'uandi-' + (chatId || 'msg'), renotify: !silent && !(PUSH && PUSH.token), icon: 'icon-192.png', badge: 'icon-192.png', data: { chat: chatId || '' } };
      if (silent) opt.silent = true; else if (npOn('vib')) opt.vibrate = [120, 60, 120];
      var plain = function () { try { new Notification(NOTIF_TITLE, opt); } catch (e) {} };
      if ('serviceWorker' in navigator) navigator.serviceWorker.getRegistration().then(function (r) { if (r) r.showNotification(NOTIF_TITLE, opt); else plain(); }).catch(plain); else plain();
    } catch (e) {}
  }
  function notifyIncoming(m) {
    if (!npOn('msg')) return;
    var loud = fx();
    if (document.hidden && !(PUSH && PUSH.token)) sysNotify(state.chat ? state.chat.name : '', m.text, state.chat ? state.chat.id : '', !loud);
    if (loud) speakNew();
  }
  $('#notifTest').addEventListener('click', function () {
    /* la voix part tout de suite, dans le geste du doigt (sinon le navigateur la bloque) */
    if (voiceOn()) speakNew(true, voiceFail);
    var go = function () {
      beep(); try { if (navigator.vibrate) navigator.vibrate(120); } catch (e) {}
      sysNotify('U&I', 'Ceci est un test de notification.'); showToast(null, 'U&I', 'Ceci est un test de notification.');
    };
    try {
      if ('Notification' in window && Notification.permission === 'default') Notification.requestPermission().then(function () { go(); pushSetup().then(pushReport); }, go); else { go(); pushSetup().then(pushReport); }
    } catch (e) { go(); }
  });
  document.addEventListener('click', function askNotif() {
    document.removeEventListener('click', askNotif);
    try { if ('Notification' in window && Notification.permission === 'default') Notification.requestPermission().then(function () { pushSetup(); }); } catch (e) {}
  });

  /* ---------- panneau Notifications des réglages ---------- */
  function npMsg(t) { var m = $('#nMsg'); if (m) m.textContent = t || ''; }
  function npPaint() {
    var st = $('#nStat'); if (!st) return;
    var perm = ('Notification' in window) ? Notification.permission : 'unsupported', t, sub, k;
    if (perm === 'unsupported') { k = 'bad'; t = 'Non pris en charge'; sub = 'Ouvre U&I dans Chrome ou installe l’appli sur l’écran d’accueil.'; }
    else if (perm === 'denied') { k = 'bad'; t = 'Bloquées'; sub = 'Autorise-les dans les réglages du téléphone : Applis › U&I › Notifications (ou Chrome › Paramètres du site).'; }
    else if (perm === 'default') { k = 'warn'; t = 'Pas encore activées'; sub = 'Appuie sur « Activer » pour recevoir les messages même appli fermée.'; }
    else if (PUSH.token) { k = 'ok'; t = 'Actives, même appli fermée'; sub = npQuiet() ? 'Mode silencieux en ce moment.' : 'Cet appareil est enregistré.'; }
    else { k = 'warn'; t = 'Autorisées, push non enregistré'; sub = PUSH.err ? 'Cause : ' + PUSH.err : 'Enregistrement en cours…'; }
    if (PUSH.lastSend) sub += ' Dernier envoi : ' + PUSH.lastSend + '.';
    st.setAttribute('data-s', k); $('#nStatT').textContent = t; $('#nStatS').textContent = sub;
    var en = $('#nEnable'); en.hidden = !(perm === 'default' || (perm === 'granted' && !PUSH.token));
    en.textContent = perm === 'granted' ? 'Réessayer l’enregistrement' : 'Activer les notifications';
    $('#pushTest').hidden = !PUSH.token;
    var p = npGet();
    document.querySelectorAll('#notifSec [data-np]').forEach(function (i) { i.checked = !!p[i.getAttribute('data-np')]; });
    $('#npFrom').value = p.qFrom; $('#npTo').value = p.qTo; $('#npTimes').hidden = !p.quiet;
    $('#npMuteInfo').textContent = p.muteUntil > Date.now() ? 'Sourdine jusqu’à ' + new Date(p.muteUntil).toLocaleString('fr-FR', { weekday: 'short', hour: '2-digit', minute: '2-digit' }) + '.' : '';
    var sm = document.querySelector('#notifSec .sxh small');
    if (sm) sm.textContent = k === 'ok' ? (npQuiet() ? 'Actives · mode silencieux' : 'Actives, même appli fermée') : t;
  }
  document.querySelectorAll('#notifSec [data-np]').forEach(function (i) {
    i.addEventListener('change', function () { npSet(i.getAttribute('data-np'), i.checked ? 1 : 0); npPaint(); });
  });
  $('#npFrom').addEventListener('change', function () { npSet('qFrom', this.value || '22:00'); npPaint(); });
  $('#npTo').addEventListener('change', function () { npSet('qTo', this.value || '07:00'); npPaint(); });
  $('#npMute').addEventListener('click', function (e) {
    var b = e.target.closest('button'); if (!b) return;
    var m = b.dataset.m, t = 0, d = new Date();
    if (m === '1') t = Date.now() + 36e5; else if (m === '8') t = Date.now() + 288e5;
    else if (m === 'tom') { d.setDate(d.getDate() + 1); d.setHours(8, 0, 0, 0); t = d.getTime(); }
    npSet('muteUntil', t); npPaint();
  });
  $('#nEnable').addEventListener('click', function () {
    npMsg('Activation…');
    var go = function () { return pushSetup().then(function () { npPaint(); npMsg(PUSH.token ? 'Notifications activées sur cet appareil ✅' : 'Échec : ' + (PUSH.err || 'inconnu')); }); };
    try { if ('Notification' in window && Notification.permission === 'default') Notification.requestPermission().then(go, go); else go(); } catch (e) { go(); }
  });
  /* test réel : le message part quand tu quittes l'appli, donc la notification arrive appli en arrière-plan ou fermée */
  $('#pushTest').addEventListener('click', function () {
    if (!PUSH.url || !PUSH.token || !auth.currentUser) { npMsg('Active d’abord les notifications.'); return; }
    auth.currentUser.getIdToken().then(function (tok) {
      npMsg('Prêt. Quitte maintenant l’appli (écran d’accueil) : le test part tout seul et la notification arrive en quelques secondes.');
      var done = false, fire = function () {
        if (!document.hidden || done) return;
        done = true; document.removeEventListener('visibilitychange', fire);
        try {
          fetch(PUSH.url + '/notify', { method: 'POST', headers: { Authorization: 'Bearer ' + tok, 'Content-Type': 'application/json' }, body: JSON.stringify({ to: [state.me], title: NOTIF_TITLE, body: 'Test réussi ✅ : les notifications marchent appli fermée.', chat: '' }) })
            .then(function (r) { PUSH.lastSend = 'test HTTP ' + r.status; }).catch(function () {});
        } catch (e) {}
      };
      document.addEventListener('visibilitychange', fire);
      setTimeout(function () { document.removeEventListener('visibilitychange', fire); if (!done) { npMsg('Test annulé : tu n’as pas quitté l’appli. Réessaie.'); } }, 60000);
    }).catch(function (e) { npMsg('Erreur : ' + ((e && (e.code || e.message)) || e)); });
  });
  new MutationObserver(function () { if ($('#settings').open) npPaint(); }).observe($('#settings'), { attributes: true, attributeFilter: ['open'] });
  npSync();
  /* toucher une notification ouvre la bonne discussion (appli fermée : ?chat=… ; appli ouverte : message du service worker) */
  var PENDING_CHAT = ''; try { PENDING_CHAT = new URLSearchParams(location.search).get('chat') || ''; } catch (e) {}
  function openChatById(id) {
    if (!id || id === 'news' || id === 'friends') return false;
    var c = chatOf(id); if (!c) return false;
    if (c.group) { openChat('', c.title || 'Groupe', c); return true; }
    var other = (c.members || []).filter(function (x) { return x !== state.me; })[0];
    if (!other) return false;
    openChat(other, (c.names && c.names[other]) || ''); return true;
  }
  if ('serviceWorker' in navigator) navigator.serviceWorker.addEventListener('message', function (e) {
    var d = e.data || {};
    if (d.type === 'uandi-open' && d.chat && !openChatById(d.chat)) PENDING_CHAT = d.chat;
  });

  var lastSeenWrite = 0;
  function markSeen() {
    if (!state.chat || document.hidden || !state.chatsById[state.chat.id]) return;
    var now = Date.now();
    if (now - lastSeenWrite < 1500) return;
    lastSeenWrite = now;
    var patch = {}; patch['seen.' + state.me] = now;
    fs.collection('chats').doc(state.chat.id).update(patch).catch(function () {});
  }

  /* rendu incrémental : une ligne n'est reconstruite que si ce qui l'affecte a changé (plus de clignotement, scroll et lecteurs vocaux conservés) */
  var RC = {}, RCchat = '', RCready = false;
  function buildRow(m, next, joinPrev, joinNext, mine, rx, rxN, myRx) {
    var row = el('div', 'row ' + (mine ? 'mine' : 'theirs') +
      (joinPrev ? '' : ' first') + (joinNext ? '' : ' last') +
      (state.open.has(m.id) ? ' open' : '') + (rxN ? ' liked' : '') + (RCready ? ' in' : ''));
    row.dataset.id = m.id;
    if (!mine && !joinPrev) {
      var gcc = chatOf(state.chat.id), sn = gcc && gcc.names && gcc.names[m.uid];
      row.appendChild(withBadge(el('div', 'sname', cap(nickOf(gcc, m.uid) || sn || (!state.chat.group && state.chat.name) || 'Membre')), m.uid));
    }
    var wrap = el('div', 'bwrap');
    if (!mine) {
      row.classList.add('gav');
      if (!joinNext) {
        var gc2 = chatOf(state.chat.id), gnm = nickOf(gc2, m.uid) || (gc2 && gc2.names && gc2.names[m.uid]) || (!state.chat.group && state.chat.name) || 'Membre';
        var gav = el('div', 'avatar gavatar'); paintPhoto(gav, m.uid, gnm); loadPhoto(m.uid);
        wrap.appendChild(gav);
      }
    }
    var bub = el('div', 'bubble' + (m.audio ? ' voice' : '') + (m.img ? ' photo' : '') + (m.file ? ' filemsg' : ''));
    if (m.audio) {
      if (m.music) bub.appendChild(el('div', 'mtag', '♪ ' + m.music));
      bub.appendChild(voiceUI(m));
    }
    else if (m.img) {
      var pim = PIMG[m.id];
      if (!pim) { pim = PIMG[m.id] = el('img', 'pimg'); pim.alt = 'Photo'; pim.decoding = 'async'; pim.src = m.img; }
      bub.appendChild(pim);
    } else if (m.file) { bub.appendChild(fileCard(m)); } else bub.textContent = m.text;
    if (m.reply && typeof m.reply.t === 'string') bub.insertBefore(quoteEl(m.reply), bub.firstChild);
    wrap.appendChild(bub);
    var rxs = rxN ? rxSummary(rx) : '';
    if (rxN) wrap.appendChild(el('span', 'badge rx' + (RXSIG[m.id] !== undefined && RXSIG[m.id] !== rxs ? ' pop' : ''), rxs));
    RXSIG[m.id] = rxs;
    row.appendChild(wrap);
    if (state.picker === m.id) row.appendChild(freshPicker(pickerEl(myRx, mine && !m.audio && !m.img && !m.file), m.id)); else if (HOLD.shown === m.id) HOLD.shown = null;

    var meta = el('div', 'meta');
    meta.appendChild(el('span', '', timeFmt.format(new Date(m.ts)) + (m.edited ? ' · modifié' : '')));
    if (!isSys(m)) { var rp = el('button', 'rpl', 'Répondre'); rp.type = 'button'; meta.appendChild(rp); }
    if (!m.audio && !m.img && !m.file) {
      var cp = el('button', 'copy', 'Copier');
      cp.type = 'button';
      meta.appendChild(cp);
    }
    if (mine && (!next || isSys(next))) {
      var cs = state.chat && state.chats.filter(function (c) { return c.id === state.chat.id; })[0];
      var otherSeen = (cs && cs.seen && cs.seen[state.chat.other]) || 0;
      var opr = notePres[state.chat.other];
      if (otherSeen >= m.ts && !hideSeenOn() && !(opr && opr.hideSeen)) meta.appendChild(el('span', 'seenmark', '· Vu ' + timeFmt.format(new Date(otherSeen))));
    }
    var del = el('button', 'del', 'Supprimer');
    del.type = 'button';
    meta.appendChild(del);
    row.appendChild(meta);
    return row;
  }
  function rowSig(m, next, joinPrev, joinNext, mine, rx, myRx) {
    var gcc = chatOf(state.chat.id), sn = gcc && gcc.names && gcc.names[m.uid];
    var nm = nickOf(gcc, m.uid) || sn || (!state.chat.group && state.chat.name) || '';
    var seen = '';
    if (mine && (!next || isSys(next))) {
      var cs = state.chats.filter(function (c) { return c.id === state.chat.id; })[0];
      var opr = notePres[state.chat.other];
      seen = ((cs && cs.seen && cs.seen[state.chat.other]) || 0) + (hideSeenOn() ? 'h' : '') + (opr && opr.hideSeen ? 'o' : '');
    }
    var ph = photos[m.uid]; ph = ph ? ph.length : 0;
    var bd = ''; try { bd = JSON.stringify([badges[m.uid] || 0, verifs[m.uid] || 0]); } catch (e) {}
    return [m.id, m.uid, m.text, m.ts, m.edited ? 1 : 0, m.audio ? m.audio.length : 0, m.dur, m.music, m.img ? m.img.length : 0, m.file ? m.file.d.length + '|' + m.file.g : 0,
      m.reply ? m.reply.id + '|' + m.reply.uid + '|' + m.reply.t : '', JSON.stringify(rx), myRx, mine ? 1 : 0, joinPrev ? 1 : 0, joinNext ? 1 : 0,
      state.open.has(m.id) ? 1 : 0, state.picker === m.id ? 1 : 0, (next && !isSys(next)) ? 1 : 0, nm, ph, bd, seen, state.chat.group ? 1 : 0].join('\u0001');
  }
  function render() {
    var wasNear = nearBottom();
    var want = [];
    var cid = state.chat ? state.chat.id : '';
    if (cid !== RCchat) { RC = {}; RCchat = cid; RCready = false; }
    var used = {};
    function cached(key, sig, build) {
      used[key] = 1;
      var c = RC[key];
      if (c && c.sig === sig) return c.node;
      var node = build();
      RC[key] = { sig: sig, node: node };
      return node;
    }
    if (state.dead) {
      var d = el('div', 'empty');
      d.appendChild(el('strong', '', 'Discussion indisponible'));
      d.appendChild(document.createTextNode(state.dead));
      want.push(d);
    } else if (!state.loaded) {
      want.push(el('div', 'loading', 'Chargement des messages…'));
    } else if (!visibleMsgs().length) {
      var e = el('div', 'empty');
      e.appendChild(el('strong', '', 'Dis bonjour à ' + cap(state.chat ? state.chat.name : '')));
      e.appendChild(document.createTextNode('Votre premier message apparaîtra ici, en direct.'));
      want.push(e);
    } else {
      var FIVE = 5 * 60 * 1000, msgs = visibleMsgs();
      if (state.more) {
        want.push(cached('more', '1', function () {
          var ob = el('button', 'ghost', 'Charger les messages précédents');
          ob.type = 'button'; ob.style.cssText = 'align-self:center;margin:8px 0';
          ob.addEventListener('click', function () { if (state.loadOlder) state.loadOlder(); });
          return ob;
        }));
      }
      for (var i = 0; i < msgs.length; i++) {
        var m = msgs[i], prev = msgs[i - 1], next = msgs[i + 1];
        var newDay = !prev || new Date(prev.ts).toDateString() !== new Date(m.ts).toDateString();
        if (newDay) {
          var dl = dayLabel(m.ts);
          want.push(cached('d' + m.id, dl, function () { return el('div', 'day', dl); }));
        }
        if (isSys(m)) { var stx = m.text.slice(1); want.push(cached('s' + m.id, stx, function () { return el('div', 'sysnote', stx); })); continue; }
        var joinPrev = prev && !isSys(prev) && !newDay && prev.uid === m.uid && m.ts - prev.ts < FIVE;
        var joinNext = next && !isSys(next) && next.uid === m.uid &&
          new Date(next.ts).toDateString() === new Date(m.ts).toDateString() && next.ts - m.ts < FIVE;
        var mine = m.uid === state.me;
        var rx = reactionsOf(m), rxN = Object.keys(rx).length, myRx = rx[state.me] || '';
        (function (m, next, joinPrev, joinNext, mine, rx, rxN, myRx) {
          want.push(cached('r' + m.id, rowSig(m, next, joinPrev, joinNext, mine, rx, myRx), function () {
            return buildRow(m, next, joinPrev, joinNext, mine, rx, rxN, myRx);
          }));
        })(m, next, joinPrev, joinNext, mine, rx, rxN, myRx);
      }
    }
    Object.keys(RC).forEach(function (k) { if (!used[k]) delete RC[k]; });
    if (state.loaded && !state.dead) RCready = true;
    /* mise à jour minimale du DOM : on ne déplace/retire que ce qui diffère */
    var cur = logEl.firstChild;
    for (var j = 0; j < want.length; j++) {
      var nd = want[j];
      if (cur === nd) cur = cur.nextSibling;
      else logEl.insertBefore(nd, cur);
    }
    while (cur) { var nx = cur.nextSibling; logEl.removeChild(cur); cur = nx; }
    if (state.stick || wasNear) { scrollBottom(); state.stick = false; }
    if (state.loaded && !state.dead) SCROLL_WARM = true;
  }

  function autosize() {
    var prevH = ta.offsetHeight;
    ta.style.height = 'auto';
    var nextH = Math.min(ta.scrollHeight, 152);
    if (prevH && prevH !== nextH) { ta.style.height = prevH + 'px'; ta.getBoundingClientRect(); }
    ta.style.height = nextH + 'px';
    var c = $('#count'), n = ta.value.length;
    c.hidden = n < 1500;
    c.textContent = n + ' / 2000';
    c.classList.toggle('warn', n >= 1900);
  }

  async function send() {
    var text = ta.value.trim();
    var chat = state.chat;
    if (!text || !state.me || !chat || ta.disabled) return;
    if (state.editing) { saveEdit(text); return; }
    ta.value = '';
    autosize();
    store('uandi-draft-' + chat.id, null);
    setTyping(false);
    showErr('');
    state.stick = true;
    try {
      var chatRef = fs.collection('chats').doc(chat.id);
      var msgRef = chatRef.collection('messages').doc();
      var ts = Date.now();
      var exists = !!state.chatsById[chat.id];
      if (!exists) { exists = (await chatRef.get()).exists; }
      var batch = fs.batch();
      batch.set(msgRef, withReply({ uid: state.me, sts: SV(), text: text, ts: ts }));
      var last = { lastText: text.slice(0, 120), lastTs: ts, lastUid: state.me };
      if (exists) {
        last['seen.' + state.me] = ts;
        var inv0 = (chatOf(chat.id) || {}).invite;
        if (inv0) {
          if (inv0.from === state.me) {
            if (inv0.st === 'declined') { var e1 = new Error('inv'); e1.inv = 'Cette personne a refusé ton invitation.'; throw e1; }
            if ((inv0.n || 0) >= INV_MAX) { var e2 = new Error('inv'); e2.inv = 'Invitation : ' + INV_MAX + ' messages maximum tant qu’elle n’est pas acceptée.'; throw e2; }
            last['invite.n'] = firebase.firestore.FieldValue.increment(1);
          } else last.invite = firebase.firestore.FieldValue.delete();
        }
        batch.update(chatRef, last);
      } else {
        var names = {}; names[state.me] = myName(); names[chat.other] = chat.name;
        var seen = {}; seen[state.me] = ts;
        batch.set(chatRef, {
          members: [state.me, chat.other], names: names,
          lastText: last.lastText, lastTs: ts, lastUid: state.me, seen: seen
        });
      }
      await batch.commit();
      state.chatsById[chat.id] = true;
      pushNotify(chat, text);
    } catch (e) {
      ta.value = text;
      autosize();
      showErr(e && e.inv ? e.inv : 'Message non envoyé. Vérifie ta connexion et réessaie.');
    }
  }

  async function toggleLike(id) {
    if (!state.chat || busy.has(id)) return;
    var m = state.msgs.find(function (x) { return x.id === id; });
    var now = !(m && m.likes && m.likes[state.me] === true);
    busy.add(id);
    try {
      var patch = {}; patch['likes.' + state.me] = now;
      await fs.collection('chats').doc(state.chat.id).collection('messages').doc(id).update(patch);
    } catch (e) {
      showErr('Le cœur n’a pas pu être enregistré.');
    } finally { busy.delete(id); }
  }

