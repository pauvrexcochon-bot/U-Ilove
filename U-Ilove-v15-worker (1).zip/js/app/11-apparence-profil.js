/* U&I — js/app/11-apparence-profil.js
   Mode sombre, thèmes de chat, photos de profil, surnom, changer mon nom
   (fait partie de l’appli : assemblée par js/boot/loader.js dans une seule fermeture) */
  /* ---------- mode sombre, thèmes de chat, photos de profil ---------- */
  var modeMq = window.matchMedia ? matchMedia('(prefers-color-scheme: dark)') : null;
  var SKIN_EFF = { nuit: 'dark', foret: 'dark', clair: 'light', rose: 'light', neant: 'dark' };
  var SKIN_FONT = { nuit: 'Roboto:wght@400;500;700', clair: 'Roboto:wght@400;500;700', foret: 'Roboto:wght@400;500;700', rose: 'Roboto:wght@400;500;700', neant: 'Roboto:wght@400;500;700' };
  var SKIN_BAR = { nuit: '#0A0C10', clair: '#FFFFFF', foret: '#0C1613', rose: '#FFE9F1', neant: '#070304' };
  var ICON_GLYPH = { w: 862.27, h: 1000.00, d: 'M843.1 5.1 L840.6 4.5 L838.0 6.2 L827.8 23.1 L821.1 31.2 L814.7 37.7 L806.7 43.6 L790.6 51.9 L783.3 58.3 L777.1 66.0 L771.0 75.2 L766.6 83.3 L763.6 91.4 L762.1 99.5 L761.6 108.8 L761.8 122.7 L763.1 131.9 L765.6 141.2 L770.9 156.2 L786.3 192.1 L792.7 210.6 L795.9 225.7 L797.0 245.4 L796.0 260.4 L794.6 269.7 L790.8 282.4 L786.7 292.8 L780.2 304.4 L771.2 317.1 L762.4 327.4 L754.6 334.0 L750.0 336.3 L746.5 336.9 L743.1 336.3 L739.6 334.8 L733.8 330.6 L716.4 314.5 L704.9 305.2 L692.1 297.2 L667.8 284.0 L655.1 278.8 L610.0 264.6 L593.8 261.9 L542.8 259.3 L526.6 259.8 L476.9 264.1 L436.3 271.4 L391.2 281.8 L370.4 289.5 L312.5 314.5 L302.1 320.4 L280.1 334.7 L248.8 356.4 L207.2 392.7 L197.1 402.8 L187.9 413.2 L156.9 451.4 L146.8 465.3 L125.0 503.5 L112.8 526.6 L106.2 542.8 L87.6 600.7 L79.4 643.5 L78.0 655.1 L76.7 675.9 L76.4 697.9 L76.9 716.4 L79.5 743.1 L88.7 782.4 L98.7 809.0 L113.2 840.3 L114.6 846.0 L114.0 850.6 L111.1 856.1 L106.2 861.3 L72.9 889.5 L46.3 914.4 L24.7 936.3 L9.8 953.7 L3.7 964.1 L1.8 969.9 L0.9 975.7 L1.0 981.5 L2.1 987.1 L4.0 991.2 L6.9 994.6 L11.8 997.3 L17.4 998.5 L55.6 1000.0 L68.3 999.7 L77.5 998.7 L83.1 997.3 L88.0 994.5 L91.0 991.2 L93.5 986.0 L97.1 965.3 L101.6 947.9 L105.3 937.5 L112.1 923.6 L119.9 910.9 L129.1 899.4 L137.8 891.2 L141.2 889.1 L144.7 887.9 L150.5 888.1 L156.2 890.7 L187.5 913.5 L201.4 921.8 L216.4 929.6 L241.9 940.0 L266.2 948.2 L275.5 950.7 L314.8 958.4 L344.9 960.5 L392.4 960.5 L447.9 957.3 L458.3 955.7 L483.8 949.8 L527.8 938.6 L550.9 929.4 L599.5 907.0 L627.3 890.8 L662.0 868.0 L695.6 839.6 L712.0 822.9 L739.7 785.9 L747.5 774.3 L754.2 761.6 L769.5 728.0 L775.0 713.0 L783.2 677.1 L785.8 660.9 L786.9 645.8 L785.5 626.2 L782.7 613.4 L776.7 599.5 L768.3 587.1 L763.4 582.0 L758.0 577.6 L743.1 568.9 L729.2 563.1 L713.0 558.8 L703.7 557.3 L695.6 556.8 L675.9 558.1 L660.9 561.3 L638.9 569.0 L623.8 577.9 L609.2 589.8 L597.5 603.0 L588.4 616.9 L582.1 630.8 L578.7 642.4 L577.6 653.9 L577.9 675.9 L579.8 687.5 L585.3 706.0 L599.6 743.1 L603.4 756.9 L604.8 767.4 L605.1 777.8 L604.0 791.7 L602.0 804.4 L598.3 818.3 L592.9 832.2 L587.2 842.6 L578.9 854.1 L570.1 863.7 L560.2 872.1 L546.3 881.6 L533.6 888.6 L512.7 897.0 L487.3 903.8 L471.1 906.6 L454.9 907.4 L437.5 906.4 L421.3 902.7 L406.2 897.2 L391.2 888.3 L377.4 877.0 L364.7 863.4 L355.0 849.5 L346.0 832.2 L337.2 809.0 L333.8 797.5 L326.7 761.6 L325.6 751.2 L326.0 743.1 L327.7 737.3 L330.3 732.8 L333.9 728.5 L340.3 722.5 L574.1 531.9 L589.1 520.5 L604.2 511.6 L629.6 498.4 L644.7 492.2 L669.0 484.0 L684.0 480.4 L721.1 476.4 L733.8 472.9 L739.5 470.3 L745.0 466.8 L750.0 462.3 L754.3 457.0 L758.4 450.2 L761.5 443.3 L765.8 428.2 L766.9 416.7 L765.9 386.6 L767.0 380.8 L769.3 376.3 L773.6 370.7 L780.1 364.5 L835.6 318.1 L847.1 307.7 L852.2 302.0 L856.3 296.3 L858.6 291.7 L860.2 285.9 L861.1 275.5 L861.2 221.1 L862.3 192.1 L862.2 171.3 L861.3 152.8 L861.7 137.7 L860.9 64.8 L859.3 55.6 L851.7 37.0 L846.6 11.8 L845.1 7.8Z M524.2 306.1 L529.5 309.6 L534.2 314.2 L538.7 320.7 L542.6 328.7 L545.1 335.6 L547.1 343.8 L549.6 366.9 L549.6 403.9 L548.1 427.1 L546.0 447.9 L543.1 467.6 L537.0 497.7 L534.8 505.8 L532.3 511.5 L529.4 516.0 L524.9 521.4 L509.3 535.3 L343.8 669.2 L338.1 672.7 L333.8 674.1 L330.1 673.6 L327.6 671.2 L326.4 667.5 L326.2 662.0 L327.0 653.9 L334.9 603.0 L344.3 557.9 L353.0 524.3 L362.3 491.9 L372.1 461.8 L388.1 421.3 L400.7 394.7 L415.1 369.2 L430.8 347.2 L444.5 332.7 L463.0 318.0 L478.0 308.6 L485.0 305.8 L491.9 304.0 L502.3 302.6 L510.4 302.5 L517.4 303.5Z' };
  var ICON_COL = {"": ["#060914", ["#B8F4FF", "#5CE1FF", "#8B5CFF"]], "nuit": ["#0A0C10", ["#C4DBFF", "#6EA8FF", "#4F86F0"]], "clair": ["#E6F4F2", ["#34D6C2", "#14958A", "#0F766E"]], "foret": ["#0C1613", ["#B5F5DA", "#4FD1A1", "#33B88A"]], "rose": ["#FFE9F1", ["#FF9EC4", "#E0457B", "#B02A63"]], "neant": ["#070304", ["#FFC2C8", "#FF3B4E", "#B3122A"]]};
  function drawIcon(size, k, rounded) {
    var c = document.createElement('canvas'); c.width = c.height = size;
    var x = c.getContext('2d'), col = ICON_COL[k] || ICON_COL[''];
    x.fillStyle = col[0];
    if (rounded && x.roundRect) { x.beginPath(); x.roundRect(0, 0, size, size, size * 0.225); x.fill(); } else x.fillRect(0, 0, size, size);
    var h = size * 0.6, sc = h / ICON_GLYPH.h, w = ICON_GLYPH.w * sc, ox = (size - w) / 2, oy = (size - h) / 2;
    var g = x.createLinearGradient(ox, oy, ox + w, oy + h);
    g.addColorStop(0, col[1][0]); g.addColorStop(0.5, col[1][1]); g.addColorStop(1, col[1][2]);
    x.save(); x.translate(ox, oy); x.scale(sc, sc); x.fillStyle = g;
    x.fill(new Path2D(ICON_GLYPH.d), 'evenodd'); x.restore();
    return c.toDataURL('image/png');
  }
  var iconSkin = null;
  function setIcons(k) {
    k = ICON_COL[k] ? k : '';
    if (iconSkin === k) return;
    try {
      var fav = document.querySelector('link[rel="icon"]'), ap = document.querySelector('link[rel="apple-touch-icon"]'), mf = document.querySelector('link[rel="manifest"]');
      if (fav) fav.href = drawIcon(128, k, true);
      if (ap) ap.href = drawIcon(180, k, false);
      if (mf) {
        var mj = JSON.stringify({
          name: 'U&I', short_name: 'U&I', start_url: location.pathname + location.search, scope: location.pathname.replace(/[^\/]*$/, ''),
          display: 'standalone', background_color: '#060914', theme_color: '#060914',
          icons: [{ src: drawIcon(192, k, false), sizes: '192x192', type: 'image/png', purpose: 'any' }, { src: drawIcon(512, k, false), sizes: '512x512', type: 'image/png', purpose: 'any' }]
        });
        mf.href = 'data:application/manifest+json;base64,' + btoa(unescape(encodeURIComponent(mj)));
      }
      iconSkin = k;
    } catch (e) {}
  }

  function applyMode() {
    var m = store('uandi-mode') || 'dark', k = store('uandi-skin');
    if (!SKIN_EFF[k]) k = '';
    var root = document.documentElement;
    root.dataset.eff = k ? SKIN_EFF[k] : (m === 'auto' ? (modeMq && modeMq.matches ? 'dark' : 'light') : m);
    if (k) root.dataset.skin = k; else delete root.dataset.skin;
    if (k && !document.getElementById('skinfont-' + k)) {
      var lk = document.createElement('link');
      lk.id = 'skinfont-' + k; lk.rel = 'stylesheet';
      lk.href = 'https://fonts.googleapis.com/css2?family=' + SKIN_FONT[k] + '&display=swap';
      document.head.appendChild(lk);
    }
    var tc = document.querySelector('meta[name="theme-color"]');
    if (tc) tc.setAttribute('content', k ? SKIN_BAR[k] : '#060914');
    (window.requestIdleCallback || function (fn) { setTimeout(fn, 400); })(function () { setIcons(k); });
    document.querySelectorAll('#modeSeg button').forEach(function (b) {
      b.setAttribute('aria-pressed', b.dataset.m === m ? 'true' : 'false');
    });
    document.querySelectorAll('#skinSeg button').forEach(function (b) {
      b.setAttribute('aria-pressed', (b.dataset.k || '') === k ? 'true' : 'false');
    });
    var ms = document.getElementById('modeSec');
    if (ms) ms.hidden = !!k;
  }
  if (modeMq && modeMq.addEventListener) modeMq.addEventListener('change', applyMode);
  $('#modeSeg').addEventListener('click', function (e) {
    var b = e.target.closest('button'); if (!b) return;
    store('uandi-mode', b.dataset.m);
    applyMode();
  });
  $('#skinSeg').addEventListener('click', function (e) {
    var b = e.target.closest('button'); if (!b) return;
    store('uandi-skin', b.dataset.k || null);
    applyMode();
  });
  applyMode();

  function applyChatTheme(id) {
    var t = id ? store('uandi-ct-' + id) : null;
    viewChat.dataset.ct = t || ''; document.documentElement.dataset.ct = t || '';
    document.querySelectorAll('#themes .sw').forEach(function (b) {
      b.setAttribute('aria-pressed', (b.dataset.ct || '') === (t || '') ? 'true' : 'false');
    });
  }
  /* ---------- surnom (comme Messenger) ---------- */
  $('#nickBtn').addEventListener('click', function () {
    var f = $('#nickForm');
    f.hidden = !f.hidden; $('#nickErr').hidden = true;
    if (!f.hidden && state.chat) { $('#nickIn').value = nickOf(chatOf(state.chat.id), state.chat.other); $('#nickIn').focus(); }
  });
  $('#nickForm').addEventListener('submit', async function (ev) {
    ev.preventDefault();
    var chat = state.chat, err = $('#nickErr'), btn = $('#nickSave');
    if (!chat) return;
    err.hidden = true;
    var raw = $('#nickIn').value.replace(/\s+/g, ' ').trim();
    var cur = chatOf(chat.id), old = nickOf(cur, chat.other);
    if (raw === old) { $('#nickForm').hidden = true; return; }
    var real = (cur && cur.names && cur.names[chat.other]) || chat.name;
    var who = cap(old || real);
    var note = raw ? cap(myName()) + ' a défini le surnom de ' + cap(real) + ' : ' + raw
                   : cap(myName()) + ' a retiré le surnom de ' + who;
    btn.disabled = true;
    try {
      var ts = Date.now(), ref = fs.collection('chats').doc(chat.id), upd = {};
      upd['nicks.' + chat.other] = raw ? raw : firebase.firestore.FieldValue.delete();
      upd.lastText = note; upd.lastTs = ts; upd.lastUid = state.me; upd['seen.' + state.me] = ts;
      var batch = fs.batch();
      batch.update(ref, upd);
      batch.set(ref.collection('messages').doc(), { uid: state.me, sts: SV(), text: SYS + note, ts: ts });
      await batch.commit();
      chat.name = raw || real; $('#chatName').textContent = cap(chat.name);
      paintPhoto($('#chatAvatar'), chat.other, chat.name);
      $('#nickForm').hidden = true;
    } catch (e) {
      var code = (e && e.code) || '';
      err.textContent = code === 'not-found' ? 'La discussion n’existe pas encore : envoie d’abord un message, puis reviens mettre le surnom.'
        : code === 'permission-denied' ? 'Refusé par les règles Firestore (permission-denied) : les règles publiées ne sont pas à jour.'
        : 'Le surnom n’a pas pu être enregistré (' + (code || (e && e.message) || 'erreur inconnue') + ').';
      err.hidden = false;
    } finally { btn.disabled = false; }
  });

  $('#moreBtn').addEventListener('click', function () { var m = $('#chatMenu'); m.hidden = !m.hidden; this.setAttribute('aria-expanded', String(!m.hidden)); });
  $('#themeBtn').addEventListener('click', function () { var t = $('#themes'); t.hidden = !t.hidden; });
  function applyBg(id) {
    var v = id ? store('uandi-bg-' + id) : null;
    if (v) document.documentElement.dataset.bg = v; else delete document.documentElement.dataset.bg;
    document.querySelectorAll('#themes .bgsw').forEach(function (b) {
      b.setAttribute('aria-pressed', (b.dataset.bg || '') === (v || '') ? 'true' : 'false');
    });
  }
  $('#themes').addEventListener('click', function (e) {
    var b = e.target.closest('.bgsw'); if (!b || !state.chat) return;
    store('uandi-bg-' + state.chat.id, b.dataset.bg || null);
    applyBg(state.chat.id);
  });
  $('#themes').addEventListener('click', function (e) {
    var b = e.target.closest('.sw'); if (!b || !state.chat) return;
    store('uandi-ct-' + state.chat.id, b.dataset.ct || null);
    applyChatTheme(state.chat.id);
  });

  var photos = {}, photoReq = {}, setDlg = $('#settings');
  function paintPhoto(node, uid, name) {
    if (node.id === 'chatAvatar' && state.chat && state.chat.group) { paintGroupAv(node, chatOf(state.chat.id)); return; }
    paintAvatar(node, name);
    var p = photos[uid];
    if (p) { node.textContent = ''; node.style.background = 'center / cover no-repeat url("' + p + '")'; }
  }
  function loadPhoto(uid) {
    if (!uid || photoReq[uid]) return;
    photoReq[uid] = 1;
    fs.collection('presence').doc(uid).get().then(function (d) {
      var v = d.exists ? d.data().photo : null;
      photos[uid] = typeof v === 'string' ? v : null;
      if (state.view === 'list') renderList();
      if (state.view === 'chat' && state.chat) render();
      if (state.chat && state.chat.other === uid) paintPhoto($('#chatAvatar'), uid, state.chat.name);
      if (setDlg.open && uid === state.me) paintPhoto($('#setAvatar'), uid, state.username);
      if (giDlg.open) renderGroupInfo();
      if (typeof frDlg !== 'undefined' && frDlg && frDlg.open) frRender();
      if (typeof ucDlg !== 'undefined' && ucDlg && ucDlg.open) ucRender();
      if (typeof nwRender === 'function' && NW && NW.cm && Object.keys(NW.open || {}).some(function (k) { return NW.open[k]; })) nwRender();
    }).catch(function () { photoReq[uid] = 0; });
  }
  function fileToPhoto(file) {
    return new Promise(function (ok, ko) {
      var img = new Image(), url = URL.createObjectURL(file);
      img.onload = function () {
        var S = 160, c = document.createElement('canvas'), m = Math.min(img.width, img.height);
        c.width = c.height = S;
        c.getContext('2d').drawImage(img, (img.width - m) / 2, (img.height - m) / 2, m, m, 0, 0, S, S);
        URL.revokeObjectURL(url);
        ok(c.toDataURL('image/jpeg', 0.8));
      };
      img.onerror = function () { URL.revokeObjectURL(url); ko(); };
      img.src = url;
    });
  }
  async function savePhoto(data) {
    var err = $('#photoErr'); err.hidden = true;
    try {
      await fs.collection('presence').doc(state.me).set({
        name: myName(), seen: hideOn() ? 0 : Date.now(),
        photo: data || firebase.firestore.FieldValue.delete()
      }, { merge: true });
      photos[state.me] = data || null;
      paintPhoto($('#setAvatar'), state.me, state.username);
      updateMyNote();
      if (state.view === 'list') renderList();
    } catch (e) {
      err.textContent = 'La photo n’a pas pu être enregistrée (connexion ou règles Firestore).';
      err.hidden = false;
    }
  }
  $('#openSet').addEventListener('click', function () {
    $('#photoErr').hidden = true;
    paintPhoto($('#setAvatar'), state.me, state.username);
    loadPhoto(state.me);
    applyMode();
    paintNick();
    setDlg.showModal();
  });
  $('#setClose').addEventListener('click', function () { setDlg.close(); });

  /* ---------- changer mon nom : une fois tous les 7 jours ---------- */
  var NICK_WAIT = 7 * 86400000;
  function nickLeft() { return Math.max(0, (state.nickAt || 0) + NICK_WAIT - Date.now()); }
  function paintNick() {
    var left = nickLeft(), h = $('#myNickHint'), b = $('#myNickGo'), i = $('#myNickIn');
    i.placeholder = cap(myName());
    if (left > 0) {
      var d = Math.ceil(left / 86400000);
      h.textContent = 'Prochain changement possible dans ' + d + ' jour' + (d > 1 ? 's' : '') + '.';
      b.disabled = true; i.disabled = true;
    } else {
      h.textContent = 'Tu peux changer ton nom une fois tous les 7 jours.';
      b.disabled = false; i.disabled = false;
    }
  }
  $('#myNickGo').addEventListener('click', function () {
    var err = $('#myNickErr'), n = $('#myNickIn').value.replace(/\s+/g, ' ').trim();
    err.hidden = true;
    if (nickLeft() > 0) { paintNick(); return; }
    if (n.length < 2 || n.length > 24) { err.textContent = 'Le nom doit faire entre 2 et 24 caractères.'; err.hidden = false; return; }
    if (n.toLowerCase() === String(myName()).toLowerCase()) { err.textContent = 'C’est déjà ton nom.'; err.hidden = false; return; }
    var now = Date.now();
    state.nick = n; state.nickAt = now;
    store('uandi-nick-' + state.me, JSON.stringify({ n: n, t: now }));
    writePresence({ nick: n, nickAt: now });
    /* met à jour mon nom dans mes discussions (écritures seulement, aucune lecture) */
    state.chats.forEach(function (c) {
      var upd = {}; upd['names.' + state.me] = n;
      fs.collection('chats').doc(c.id).update(upd).catch(function () {});
    });
    $('#myNickIn').value = '';
    renderList(); paintNick();
  });
  $('#photoPick').addEventListener('click', function () { $('#photoFile').click(); });
  $('#photoDel').addEventListener('click', function () { savePhoto(null); });
  $('#photoFile').addEventListener('change', function (e) {
    var f = e.target.files && e.target.files[0]; e.target.value = '';
    if (!f) return;
    fileToPhoto(f).then(savePhoto, function () {
      var err = $('#photoErr'); err.textContent = 'Image illisible.'; err.hidden = false;
    });
  });

