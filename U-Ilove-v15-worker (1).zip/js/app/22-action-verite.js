/* U&I — js/app/22-action-verite.js
   Action ou vérité multijoueur
   (fait partie de l’appli : assemblée par js/boot/loader.js dans une seule fermeture) */
  /* ---------- Action ou vérité multijoueur ---------- */
  (function () {
    var $td = function (id) { return document.getElementById(id); };
    var td = { unsub: null, roomUnsub: null, rooms: [], roomId: null, room: null, chosenType: '', spinning: false };
    var defaults = {
      action: ['Fais une imitation amusante pendant 10 secondes.', 'Raconte une blague ou invente-en une.', 'Chante quelques secondes d’une chanson que tu connais.', 'Fais un compliment sincère à un joueur.', 'Décris ton humeur avec trois emojis.', 'Fais une pose drôle pendant cinq secondes.'],
      truth: ['Quel est un petit objectif que tu veux atteindre ?', 'Quelle chanson écoutes-tu en boucle en ce moment ?', 'Quel est un souvenir qui te fait sourire ?', 'Quelle qualité apprécies-tu chez un ami ?', 'Quel talent aimerais-tu apprendre ?', 'Quelle est une chose amusante que peu de gens savent sur toi ?']
    };
    function tdSafeName(p) { return (p && p.name) ? String(p.name).slice(0, 32) : 'Joueur'; }
    function tdMyName() {
      var mode = $td('tdNameMode').value;
      if (mode === 'anon') return '🎭 Anonyme';
      if (mode === 'pseudo') return ($td('tdPseudo').value.trim() || 'Joueur mystère').slice(0, 24);
      return (typeof myName === 'function' ? myName() : state.username) || 'Joueur';
    }
    function tdMsg(s) { $td('tdStatus').textContent = s || ''; }
    function tdShowPanel(show) { $td('tdPanel').hidden = !show; $td('tdEntry').hidden = show; var b=document.querySelector('#nwPaneFeed .nwbox'), f=$td('nwFeed'); if(b)b.hidden=show; if(f)f.hidden=show; }
    function tdInRoom(on) {
      var c=document.querySelector('#tdPanel .td-create'), l=$td('tdRooms');
      if (c) c.hidden=!!on; if (l) l.hidden=!!on;
      if (on) { var rm=$td('tdRoom'); if (rm && rm.scrollIntoView) setTimeout(function(){ rm.scrollIntoView({behavior:'smooth',block:'start'}); },50); }
    }
    function tdListenRooms() {
      if (td.unsub) td.unsub();
      if (!state.me || !fs) return;
      td.unsub = fs.collection('truthDareRooms').orderBy('createdAt', 'desc').limit(15).onSnapshot(function (snap) {
        td.rooms = []; snap.forEach(function (d) { var x=d.data(); if (x && (x.status === 'waiting' || x.status === 'playing') && (x.players || []).length > 0 && Date.now() - (x.createdAt || 0) < 86400000) td.rooms.push(Object.assign({id:d.id},x)); });
        tdRenderRooms(); tdRenderPosts();
        if (td.roomId && !td.roomUnsub) { var found=td.rooms.filter(function(r){return r.id===td.roomId;})[0]; if(found) tdRenderRoom(found); }
      }, function (e) { tdMsg('Impossible de charger les parties. Vérifie les règles Firestore de truthDareRooms.'); });
    }
    function tdAgo(ts) {
      var m = Math.max(0, Math.floor((Date.now() - (ts || 0)) / 60000));
      return m < 1 ? 'à l’instant' : m < 60 ? m + ' min' : Math.floor(m / 60) + ' h';
    }
    function tdRenderPosts() {
      var feed = $td('nwFeed'); if (!feed) return;
      var box = $td('tdPosts');
      if (!box) { box = document.createElement('div'); box.id = 'tdPosts'; box.className = 'td-posts'; }
      if (feed.firstChild !== box) feed.insertBefore(box, feed.firstChild);
      var keep = feed.scrollTop;
      box.textContent = '';
      td.rooms.forEach(function (r) {
        var ps = r.players || [], host = ps[0], mine = ps.some(function (p) { return p.uid === state.me; });
        var card = document.createElement('article'); card.className = 'td-post';
        var head = document.createElement('div'); head.className = 'td-post-head';
        var av = document.createElement('span'); av.className = 'td-post-av'; av.textContent = '🎲';
        var who = document.createElement('div'); who.className = 'td-post-who';
        var b = document.createElement('b'); b.textContent = tdSafeName(host) + ' lance une partie';
        var sm = document.createElement('small'); sm.textContent = 'Action ou vérité · ' + tdAgo(r.createdAt);
        who.appendChild(b); who.appendChild(sm);
        var pill = document.createElement('span'); pill.className = 'td-pill' + (r.status === 'playing' ? ' on' : ''); pill.textContent = r.status === 'playing' ? 'En cours' : 'Ouverte';
        head.appendChild(av); head.appendChild(who); head.appendChild(pill);
        var info = document.createElement('p'); info.className = 'td-post-info';
        info.textContent = ps.length + ' joueur' + (ps.length > 1 ? 's' : '') + ' · ' + (r.startAt && r.startAt > Date.now() ? 'début prévu le ' + new Date(r.startAt).toLocaleString([], { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' }) : 'prête à jouer');
        var chips = document.createElement('div'); chips.className = 'td-post-players';
        ps.slice(0, 5).forEach(function (p) { var c = document.createElement('span'); c.className = 'td-player'; var i = document.createElement('i'); i.textContent = (tdSafeName(p).trim().charAt(0) || '?').toUpperCase(); var n = document.createElement('span'); n.textContent = tdSafeName(p); c.appendChild(i); c.appendChild(n); chips.appendChild(c); });
        if (ps.length > 5) { var more = document.createElement('span'); more.className = 'td-player'; more.textContent = '+' + (ps.length - 5); chips.appendChild(more); }
        var btn = document.createElement('button'); btn.type = 'button'; btn.className = 'nwpost td-post-btn'; btn.textContent = mine ? 'Retourner dans la partie' : 'Rejoindre la partie';
        btn.addEventListener('click', function () { tdShowPanel(true); tdJoin(r.id); });
        card.appendChild(head); card.appendChild(info); card.appendChild(chips); card.appendChild(btn);
        box.appendChild(card);
      });
      box.hidden = !td.rooms.length;
      feed.scrollTop = keep;
    }
    window.__tdPosts = function () { try { tdRenderPosts(); } catch (e) {} };
    window.__tdStart = function () { if (!td.unsub) tdListenRooms(); };
    window.__tdStop = function () { if (td.unsub) { td.unsub(); td.unsub = null; } td.rooms = []; var b = $td('tdPosts'); if (b) b.remove(); };
    function tdRenderRooms() {
      var box=$td('tdRooms'); box.textContent='';
      if (!td.rooms.length) { var p=document.createElement('p'); p.className='td-muted'; p.textContent='Aucune partie ouverte pour le moment. Crée la première !'; box.appendChild(p); return; }
      td.rooms.forEach(function(r){
        var card=document.createElement('div'); card.className='td-room-item';
        var title=document.createElement('b'); title.textContent='🎲 '+(r.title || 'Action ou vérité'); card.appendChild(title);
        var meta=document.createElement('span'); meta.className='td-room-meta'; meta.textContent=(r.players||[]).length+' joueur(s) · '+(r.startAt && r.startAt>Date.now()?'Début prévu : '+new Date(r.startAt).toLocaleString():'Prête à jouer'); card.appendChild(meta);
        var btn=document.createElement('button'); btn.type='button'; btn.className='nwpost'; btn.textContent='Rejoindre'; btn.addEventListener('click',function(){tdJoin(r.id);}); card.appendChild(btn); box.appendChild(card);
      });
    }
    function tdCreate() {
      if (!state.me) { tdMsg('Connecte-toi pour créer une partie.'); return; }
      var startRaw=$td('tdStart').value, startAt=startRaw ? new Date(startRaw).getTime() : Date.now();
      if (!Number.isFinite(startAt) || startAt < Date.now()-60000) { tdMsg('Choisis une heure future, ou laisse le champ vide pour commencer maintenant.'); return; }
      tdMsg('Création de la partie…');
      var player={uid:state.me,name:tdMyName(),joinedAt:Date.now()};
      fs.collection('truthDareRooms').add({title:'Action ou vérité',creator:state.me,createdAt:Date.now(),startAt:startAt,status:'waiting',players:[player],turn:null,history:[]})
      .then(function(ref){tdMsg('Partie créée ! Les autres peuvent la rejoindre.');return tdJoin(ref.id);})
      .catch(function(e){tdMsg('Création impossible : '+(e.message||'vérifie les règles Firestore.'));});
    }
    function tdJoin(id) {
      if (!state.me) { tdMsg('Connecte-toi pour rejoindre une partie.'); return; }
      var ref=fs.collection('truthDareRooms').doc(id);
      ref.get().then(function(doc){
        if(!doc.exists) throw new Error('Cette partie n’existe plus.');
        var r=doc.data(); if(r.status==='finished') throw new Error('Cette partie est terminée.');
        if((r.kicked||[]).indexOf(state.me)>=0) throw new Error('L’hôte t’a retiré de cette partie.');
        var players=(r.players||[]).slice();
        if(!players.some(function(p){return p.uid===state.me;})) players.push({uid:state.me,name:tdMyName(),joinedAt:Date.now()});
        return ref.update({players:players}).then(function(){
          if(td.roomUnsub) td.roomUnsub(); tdGvStop(); td.spinSeen=null; td.firstSnap=true; td.spinning=false; td.roomId=id; tdShowPanel(true); $td('tdRoom').hidden=false; tdInRoom(true); tdMsg('Tu as rejoint la partie.');
          td.roomUnsub=ref.onSnapshot(function(d){if(!d.exists){tdMsg('Cette partie a été supprimée.');$td('tdRoom').hidden=true;tdInRoom(false);return;}td.room=Object.assign({id:d.id},d.data());tdRenderRoom(td.room);td.firstSnap=false;},function(){tdMsg('Connexion à la partie interrompue.');});
        });
      }).catch(function(e){tdMsg(e.message||'Impossible de rejoindre cette partie.');});
    }
    function tdExit(msg) {
      tdVoiceStopAll(); tdGvStop();
      if(td.roomUnsub)td.roomUnsub();td.roomUnsub=null;td.roomId=null;td.room=null;
      $td('tdRoom').hidden=true;tdInRoom(false);tdMsg(msg||'');
    }
    function tdStop() {
      var r=td.room;if(!r||!td.roomId||r.creator!==state.me)return;
      if(!window.confirm('Arrêter la partie pour tous les joueurs ?'))return;
      fs.collection('truthDareRooms').doc(td.roomId).update({status:'finished',turn:null,finishedAt:Date.now()})
      .then(function(){tdExit('Partie arrêtée.');}).catch(function(){tdMsg('Impossible d’arrêter la partie.');});
    }
    function tdRenderRoom(r) {
      if(!r)return;
      if(r.status==='finished'){ if(td.roomId===r.id) tdExit('La partie a été arrêtée.'); return; }
      if(td.roomId===r.id && (r.kicked||[]).indexOf(state.me)>=0){ tdExit('L’hôte t’a retiré de la partie.'); return; }
      td.room=r;
      var stopBtn=$td('tdStop'); if(stopBtn) stopBtn.hidden=r.creator!==state.me;
      $td('tdRoomTitle').textContent='Action ou vérité';
      $td('tdRoomState').textContent=r.status==='playing'?'● En cours':'● En attente';$td('tdRoomState').className='td-pill'+(r.status==='playing'?' on':'');
      $td('tdRoomInfo').textContent=(r.startAt>Date.now()?'Début prévu le '+new Date(r.startAt).toLocaleString():'La partie peut commencer')+' · '+(r.players||[]).length+' joueur(s)';
      var ps=r.players||[], n=ps.length, turn=r.turn, isCreator=r.creator===state.me;
      tdSyncBottle(r);
      var reveal=!!turn && turn.phase!=='spin' && !td.spinning;
      var wheel=$td('tdPlayers'); wheel.textContent='';
      ps.forEach(function(p,k){
        var ang=k*2*Math.PI/n, seat=document.createElement('div');
        var live=reveal && turn.phase!=='done';
        seat.className='td-seat'+(p.uid===state.me?' itsme':'')+(live&&turn.targetUid===p.uid?' target':'')+(live&&turn.pickerUid===p.uid?' picker':'');
        seat.style.left=(50+39*Math.sin(ang)).toFixed(2)+'%'; seat.style.top=(50-39*Math.cos(ang)).toFixed(2)+'%';
        var av=document.createElement('i'); av.textContent=(tdSafeName(p).trim().charAt(0)||'?').toUpperCase();
        var nm=document.createElement('span'); nm.textContent=tdSafeName(p);if(p.uid===state.me)seat.title='Toi';
        seat.appendChild(av); seat.appendChild(nm); wheel.appendChild(seat);
      });
      var started=!r.startAt || Date.now()>=r.startAt;
      var tgt=turn?ps.filter(function(p){return p.uid===turn.targetUid;})[0]:null, pck=turn?ps.filter(function(p){return p.uid===turn.pickerUid;})[0]:null;
      var orphan=!!turn && turn.phase!=='done' && turn.phase!=='spin' && (!tgt||!pck);
      var idle=!turn || turn.phase==='done' || orphan;
      var canSpin=isCreator && n>=2 && started && !td.spinning && !td.busy && idle;
      $td('tdSpin').disabled=!canSpin;
      $td('tdSpin').textContent=n<2?'En attente d’un autre joueur…':!started?'Début programmé':!isCreator?'Seul le créateur lance la bouteille':(!idle||td.spinning)?'Tour en cours…':'🌀 Faire tourner la bouteille';
      ['tdChooseControls','tdPickerControls','tdTargetControls','tdPromptBox','tdAnswerText','tdVoteBox','tdVoteBtns'].forEach(function(id){$td(id).hidden=true;});
      $td('tdTurn').hidden=!reveal;
      if(reveal){
        var tn=tdSafeName(tgt), pn=tdSafeName(pck), me=state.me, isT=turn.targetUid===me, isP=turn.pickerUid===me;
        var kind=turn.type==='action'?'une action':'une question';
        var key=turn.phase+':'+turn.at+':'+(turn.attempt||0), fresh=td.lastPhase!==key;
        var voters=ps.filter(function(p){return p.uid!==turn.targetUid;}), votes=turn.votes||{}, vOk=0, vNo=0;
        voters.forEach(function(p){if(votes[p.uid]==='ok')vOk++;else if(votes[p.uid]==='no')vNo++;});
        var ansEl=$td('tdAnswerText'); ansEl.classList.remove('bad');
        if(orphan){
          $td('tdTurnText').textContent='Un joueur a quitté le tour. Le créateur peut relancer la bouteille.';
        } else if(turn.phase==='choose'){
          $td('tdTurnText').textContent=isT?'La bouteille t’a désigné(e) ! Action ou vérité ?':tn+' a été désigné(e) par la bouteille et choisit : action ou vérité ?';
          $td('tdChooseControls').hidden=!isT;
          if(isT&&fresh)tdMsg('C’est à toi de choisir : Action ou Vérité ?');
        } else if(turn.phase==='ask'){
          $td('tdTurnText').textContent=tn+' a choisi '+(turn.type==='action'?'🔥 ACTION':'💬 VÉRITÉ')+'. '+(isP?'À toi de lui proposer ':pn+' doit lui proposer ')+kind+'.';
          $td('tdPickerControls').hidden=!isP;
          $td('tdPromptLabel').textContent=turn.type==='action'?'Quelle action doit-'+'il/elle faire ?':'Quelle question lui poses-tu ?';
          if(isP&&fresh)tdMsg('Écris '+kind+' pour '+tn+'.');
        } else if(turn.phase==='answer'){
          $td('tdTurnText').textContent=isT?'À toi de répondre !':tn+' doit répondre.';
          $td('tdPromptBox').hidden=false; $td('tdPromptText').textContent=(turn.type==='action'?'🔥 ACTION : ':'💬 VÉRITÉ : ')+turn.prompt;
          $td('tdTargetControls').hidden=!isT;
          if(turn.rejected){ansEl.hidden=false;ansEl.classList.add('bad');ansEl.textContent='❌ Le groupe n’est pas satisfait de : « '+turn.rejected+' »'+(isT?'\nRecommence ta réponse.':'\n'+tn+' doit refaire sa réponse.');}
          if(isT&&fresh)tdMsg(turn.rejected?'Réponse refusée par le groupe : refais-la.':'Écris ta réponse. Les autres devront l’approuver.');
        } else if(turn.phase==='vote'){
          $td('tdTurnText').textContent=isT?'Ta réponse est envoyée : les autres votent…':tn+' a répondu. Approuves-tu sa réponse ?';
          $td('tdPromptBox').hidden=false; $td('tdPromptText').textContent=(turn.type==='action'?'🔥 ACTION : ':'💬 VÉRITÉ : ')+turn.prompt;
          ansEl.hidden=false; ansEl.textContent='✍️ '+tn+' : '+turn.answer;
          $td('tdVoteBox').hidden=false;
          var mine=votes[me], canVote=!isT&&!mine&&voters.some(function(p){return p.uid===me;});
          $td('tdVoteBtns').hidden=!canVote;
          $td('tdVoteInfo').textContent='✅ '+vOk+' · ❌ '+vNo+' · en attente : '+(voters.length-vOk-vNo)+(mine?' — ton vote : '+(mine==='ok'?'✅':'❌'):'');
          if(canVote&&fresh)tdMsg('Vote : approuves-tu la réponse de '+tn+' ?');
          tdVoteTick();
          if(isCreator&&!td.voting&&(voters.length===0||vOk*2>voters.length||vNo*2>=voters.length))tdVote(null);
        } else if(turn.phase==='done'){
          $td('tdTurnText').textContent='✅ Réponse approuvée par le groupe ! Vous pouvez tourner à nouveau.';
          $td('tdPromptBox').hidden=false; $td('tdPromptText').textContent=(turn.type==='action'?'🔥 ACTION : ':'💬 VÉRITÉ : ')+(turn.prompt||'');
          if(turn.answer){ansEl.hidden=false;ansEl.textContent='✍️ '+tn+' : '+turn.answer+'\n(✅ '+vOk+' · ❌ '+vNo+')';}
        }
        td.lastPhase=key;
      }
      tdChatRender(r,reveal);
      tdHostRender(r);
      tdGvSync(r);
      tdVoiceSync(r,reveal);
    }
    /* ---------- vocal du salon : seul celui qui doit parler a le micro, tout le monde écoute ----------
       Signalisation WebRTC dans le document de la partie (champs voice / vc) : aucune nouvelle règle Firestore. */
    function tdIce(){ return (typeof ICE!=='undefined'&&ICE)||{iceServers:[{urls:'stun:stun.l.google.com:19302'}]}; }
    function tdRef(){ return fs.collection('truthDareRooms').doc(td.roomId); }
    function tdGather(pc){
      return new Promise(function(ok){
        if(pc.iceGatheringState==='complete')return ok();
        var done=false;
        function fin(){ if(done)return; done=true; pc.removeEventListener('icegatheringstatechange',chk); ok(); }
        function chk(){ if(pc.iceGatheringState==='complete')fin(); }
        pc.addEventListener('icegatheringstatechange',chk); setTimeout(fin,3000);
      });
    }
    function tdVoiceStopAll(){ tdGvStop(); }
    /* rappel pour le joueur dont c'est le tour de parler (le vocal du salon, lui, écoute en continu) */
    function tdVoiceSync(r,reveal){
      var t=r.turn, me=state.me, spk=null;
      if(reveal&&t&&!td.spinning){ if(t.phase==='ask')spk=t.pickerUid; else if(t.phase==='answer')spk=t.targetUid; }
      var box=$td('tdVoice'), mic=$td('tdMicBtn'), info=$td('tdVoiceInfo'), G=td.gv;
      if(!spk||!G){ box.hidden=true; return; }
      var sp=(r.players||[]).filter(function(p){return p.uid===spk;})[0], nm=tdSafeName(sp);
      box.hidden=false;
      if(spk===me){
        mic.hidden=false; mic.textContent=G.talk?'⏹ Couper le micro':'🎙️ Parler'; mic.classList.toggle('on',!!G.talk);
        info.textContent=G.talk?'🎙️ Micro actif : le salon t’entend.':(t.phase==='ask'?'🎙️ À toi : appuie sur « Parler » pour dire ta proposition (puis écris-la pour l’envoyer).':'🎙️ À toi : appuie sur « Parler » pour répondre (puis écris ta réponse pour la faire voter).');
      } else {
        mic.hidden=true;
        var live=tdGvPeers(r).some(function(x){return x.u===spk&&x.k;});
        info.textContent=live?'🔊 '+nm+' parle… (tu l’entends automatiquement)':'🔇 '+nm+' n’a pas encore activé son micro. Tu l’entendras dès qu’elle ou il parlera.';
      }
    }
    /* ---------- vocal du salon : tout le monde écoute en continu, on appuie sur « Parler » pour parler ----------
       Maillage WebRTC (8 max). Signalisation dans le document de la partie (champs gvp = présence, gv = offres/réponses) : aucune nouvelle règle Firestore.
       Chaque liaison est ouverte dès l'arrivée dans le salon (écoute seule) ; le micro n'est branché (replaceTrack) que pour ceux qui ont le droit de t'entendre. */
    var GV_MAX=8, GV_HB=20000, GV_STALE=150000;
    function tdGvLsKey(){ return 'tdGvPrefs_'+(state.me||''); }
    function tdGvSave(){ var G=td.gv; if(!G)return; try{ localStorage.setItem(tdGvLsKey(),JSON.stringify({allow:G.allow,allowAll:G.allowAll,hush:G.hush,deaf:G.deaf})); }catch(e){} }
    function tdGvLoad(G){ try{ var p=JSON.parse(localStorage.getItem(tdGvLsKey())||'null'); if(p){ G.allow=p.allow||{}; G.allowAll=p.allowAll!==false; G.hush=p.hush||{}; G.deaf=!!p.deaf; } }catch(e){} }
    document.addEventListener('pointerdown',function(){ var b=document.getElementById('tdGvAudios'); if(!td.gvNeedTap||!b)return; td.gvNeedTap=false; var as=b.querySelectorAll('audio'); for(var i=0;i<as.length;i++){ try{ var pr=as[i].play(); if(pr&&pr.catch)pr.catch(function(){ td.gvNeedTap=true; }); }catch(e){} } if(td.gv)tdGvUi(true); },true);
    function tdK(u){ return String(u).replace(/[^A-Za-z0-9_-]/g,'_'); }
    function tdGvKey(off,ans){ return tdK(off)+'__'+tdK(ans); }
    function tdGvPeers(r){
      var P=(r&&r.gvp)||{}, now=Date.now(), ps=(r&&r.players)||[], out=[];
      Object.keys(P).forEach(function(k){ var x=P[k]; if(!x||!x.u||!x.s||!x.t||now-x.t>GV_STALE)return; if(!ps.some(function(p){return p.uid===x.u;}))return; out.push(x); });
      out.sort(function(a,b){ return (Number(a.s)-Number(b.s))||(a.u<b.u?-1:1); });
      return out;
    }
    function tdGvAllowed(u){ var G=td.gv; if(!G)return false; return G.allow[u]!==undefined?G.allow[u]:G.allowAll; }
    function tdGvPresence(){
      var G=td.gv; if(!G||!td.roomId)return Promise.resolve();
      var o={}; o['gvp.'+tdK(state.me)]={u:state.me,s:G.sid,t:Date.now(),k:G.talk?1:0};
      return tdRef().update(o);
    }
    function tdGvApplyAudio(){
      var G=td.gv, box=$td('tdGvAudios'); if(!G||!box)return;
      var as=box.querySelectorAll('audio');
      for(var i=0;i<as.length;i++){ var u=as[i].getAttribute('data-u'); as[i].muted=!!(G.deaf||G.hush[u]); }
    }
    function tdGvAudioFor(uid,stream){
      var box=$td('tdGvAudios'), id='tdGvA_'+tdK(uid), a=document.getElementById(id);
      if(!a){ a=document.createElement('audio'); a.id=id; a.setAttribute('data-u',uid); a.autoplay=true; a.setAttribute('playsinline',''); box.appendChild(a); }
      a.srcObject=stream; tdGvApplyAudio();
      var pr=a.play(); if(pr&&pr.catch)pr.catch(function(){ td.gvNeedTap=true; tdGvUi(); });
    }
    function tdGvWatch(uid,stream){
      var G=td.gv; if(!G)return;
      try{
        var AC=window.AudioContext||window.webkitAudioContext; if(!AC)return; if(!G.ac)G.ac=new AC();
        var src=G.ac.createMediaStreamSource(stream), an=G.ac.createAnalyser(); an.fftSize=256; src.connect(an);
        G.an[uid]={an:an,buf:new Uint8Array(an.fftSize)};
      }catch(e){}
    }
    /* branche / débranche le micro sur chaque liaison selon « qui m'entend » */
    function tdGvApplyTracks(){
      var G=td.gv; if(!G)return;
      Object.keys(G.pcs).forEach(function(u){
        var rec=G.pcs[u]; if(!rec.sender)return;
        var want=(G.talk&&G.track&&tdGvAllowed(u))?G.track:null;
        if(rec.cur!==want){ rec.cur=want; try{ rec.sender.replaceTrack(want).catch(function(){}); }catch(e){} }
      });
    }
    function tdGvDrop(uid){
      var G=td.gv; if(!G)return;
      var rec=G.pcs[uid];
      if(rec){
        if(!rec.conn){ G.fails[uid]=(G.fails[uid]||0)+1; G.next[uid]=Date.now()+Math.min(60000,4000*Math.pow(2,G.fails[uid]-1)); }
        try{rec.pc.close();}catch(e){} delete G.pcs[uid];
      }
      delete G.an[uid];
      var a=document.getElementById('tdGvA_'+tdK(uid)); if(a&&a.parentNode)a.parentNode.removeChild(a);
    }
    function tdGvPc(uid,sa,offerer){
      var G=td.gv, pc=new RTCPeerConnection(tdIce()), rec={pc:pc,sa:sa,t:Date.now(),conn:false,ans:false,sender:null,cur:null};
      if(offerer){ var tr=pc.addTransceiver('audio',{direction:'sendrecv'}); rec.sender=tr.sender; }
      pc.ontrack=function(e){ var st=(e.streams&&e.streams[0])||new MediaStream([e.track]); tdGvAudioFor(uid,st); tdGvWatch(uid,st); };
      pc.onconnectionstatechange=function(){
        if(td.gv!==G||G.pcs[uid]!==rec)return; var st=pc.connectionState;
        if(st==='connected'){
          rec.conn=true; G.fails[uid]=0;
          if(rec.off&&rec.key){ var o={}; o['gv.'+rec.key]=firebase.firestore.FieldValue.delete(); tdRef().update(o).catch(function(){}); }
          tdGvApplyTracks(); tdGvUi();
        } else if(st==='failed'||st==='closed'){ tdGvDrop(uid); }
      };
      G.pcs[uid]=rec; return rec;
    }
    function tdGvOffer(peer){
      var G=td.gv, rec=tdGvPc(peer.u,peer.s,true), key=tdGvKey(state.me,peer.u), n=String(Date.now());
      rec.key=key; rec.n=n; rec.off=true;
      rec.pc.createOffer().then(function(o){return rec.pc.setLocalDescription(o);}).then(function(){return tdGather(rec.pc);}).then(function(){
        if(td.gv!==G||G.pcs[peer.u]!==rec)return;
        var o={}; o['gv.'+key]={so:G.sid,sa:peer.s,n:n,o:rec.pc.localDescription.sdp}; return tdRef().update(o);
      }).catch(function(){ if(td.gv===G&&G.pcs[peer.u]===rec)tdGvDrop(peer.u); });
    }
    function tdGvAnswer(peer,key,x){
      var G=td.gv; tdGvDrop(peer.u);
      var rec=tdGvPc(peer.u,peer.s,false); rec.key=key; rec.n=x.n;
      rec.pc.setRemoteDescription({type:'offer',sdp:x.o}).then(function(){
        var tr=rec.pc.getTransceivers().filter(function(t){return t.receiver&&t.receiver.track&&t.receiver.track.kind==='audio';})[0];
        if(tr){ tr.direction='sendrecv'; rec.sender=tr.sender; }
        return rec.pc.createAnswer();
      }).then(function(a){return rec.pc.setLocalDescription(a);}).then(function(){return tdGather(rec.pc);}).then(function(){
        if(td.gv!==G||G.pcs[peer.u]!==rec)return;
        tdGvApplyTracks();
        var o={}; o['gv.'+key+'.a']=rec.pc.localDescription.sdp; o['gv.'+key+'.an']=x.n; return tdRef().update(o);
      }).catch(function(){ if(td.gv===G&&G.pcs[peer.u]===rec)tdGvDrop(peer.u); });
    }
    function tdGvStart(){
      var G=td.gv={sid:String(Date.now()),stream:null,track:null,talk:false,pcs:{},handled:{},an:{},allow:{},allowAll:true,hush:{},deaf:false,n:0,full:false,fails:{},next:{}};
      tdGvLoad(G);
      G.hb=setInterval(function(){ if(td.gv===G)tdGvPresence().catch(function(){}); },GV_HB);
      G.tick=setInterval(tdGvTick,250);
      tdGvPresence().catch(function(){});
    }
    function tdGvSync(r){
      var G=td.gv, me=state.me;
      if(!G&&r&&td.roomId&&r.id===td.roomId&&r.status!=='finished'&&window.RTCPeerConnection&&(r.players||[]).some(function(p){return p.uid===me;})){ tdGvStart(); G=td.gv; }
      if(G&&r&&td.roomId){
        var all=tdGvPeers(r), ranked=all.slice(0,GV_MAX), mine=all.some(function(x){return x.u===me;});
        G.full=mine&&!ranked.some(function(x){return x.u===me;});
        var peers=G.full?[]:ranked.filter(function(x){return x.u!==me;}), P={};
        peers.forEach(function(x){P[x.u]=x;});
        Object.keys(G.pcs).forEach(function(u){ var rec=G.pcs[u], p=P[u]; if(!p||p.s!==rec.sa||(!rec.conn&&Date.now()-rec.t>20000))tdGvDrop(u); });
        peers.forEach(function(p){
          var rec=G.pcs[p.u];
          if(me<p.u){
            if(!rec){ if(!G.next[p.u]||Date.now()>=G.next[p.u])tdGvOffer(p); }
            else if(!rec.ans){ var x=r.gv&&r.gv[rec.key]; if(x&&x.a&&x.an===rec.n&&x.so===G.sid){ rec.ans=true; rec.pc.setRemoteDescription({type:'answer',sdp:x.a}).catch(function(){ tdGvDrop(p.u); }); } }
          } else {
            var key=tdGvKey(p.u,me), y=r.gv&&r.gv[key];
            if(y&&y.o&&y.n&&y.sa===G.sid&&y.so===p.s&&!G.handled[key+':'+y.n]&&(!rec||rec.n!==y.n)){ G.handled[key+':'+y.n]=1; tdGvAnswer(p,key,y); }
          }
        });
      }
      tdGvUi();
    }
    function tdGvTog(on,fn){
      var b=document.createElement('button'); b.type='button'; b.className='td-gv-tog '+(on?'on':'off'); b.textContent=on?'Oui':'Non'; b.setAttribute('aria-pressed',on?'true':'false');
      b.addEventListener('click',fn); return b;
    }
    function tdGvUi(force){
      var r=td.room, box=$td('tdGv'); if(!box)return;
      var G=td.gv, me=state.me, ps=(r&&r.players)||[];
      box.hidden=!(r&&td.roomId&&window.RTCPeerConnection&&ps.some(function(p){return p.uid===me;})&&G);
      if(box.hidden)return;
      var peers=tdGvPeers(r).filter(function(x){return x.u!==me;}), list=[{u:me,k:G.talk?1:0,self:1,conn:1}];
      peers.forEach(function(x){ list.push({u:x.u,k:x.k,conn:!!(G.pcs[x.u]&&G.pcs[x.u].conn)}); });
      var sig=list.map(function(x){return x.u+':'+(x.k?1:0)+':'+(x.conn?1:0);}).join(',');
      if(force||td.gvSig!==sig){
        td.gvSig=sig; var pb=$td('tdGvPeople'); pb.textContent='';
        list.forEach(function(x){
          var pl=ps.filter(function(p){return p.uid===x.u;})[0], full=tdSafeName(pl);
          var c=document.createElement('span'); c.className='td-gv-chip'; c.setAttribute('data-u',x.u);
          var i=document.createElement('i'); i.textContent=(full.trim().charAt(0)||'?').toUpperCase();
          var n=document.createElement('span'); n.textContent=(x.self?'Toi':full)+(x.k?' 🎙️':'')+((!x.self&&!x.conn)?' ⏳':'');
          c.appendChild(i); c.appendChild(n); pb.appendChild(c);
        });
      }
      var others=ps.filter(function(p){return p.uid!==me;}), nAllowed=others.filter(function(p){return tdGvAllowed(p.uid);}).length, txt;
      if(G.full) txt='Vocal complet ('+GV_MAX+' personnes max).';
      else if(G.talk) txt=!others.length?'Micro actif. Personne d’autre dans le salon pour l’instant.':(nAllowed===others.length?'Micro actif : tout le salon t’entend.':(nAllowed===0?'Micro actif, mais personne ne t’entend (voir Réglages).':'Micro actif : '+nAllowed+' personne'+(nAllowed>1?'s':'')+' sur '+others.length+' t’entend'+(nAllowed>1?'ent':'')+'.'));
      else txt='Tu entends tout le salon. Appuie sur « Parler » pour te faire entendre.';
      $td('tdGvInfo').textContent=txt;
      var tk=$td('tdGvTalk'); tk.textContent=G.talk?'⏹ Couper le micro':'🎙️ Parler'; tk.classList.toggle('on',!!G.talk); tk.disabled=!!td.gvBusy||G.full;
      $td('tdGvSpk').textContent=td.gvNeedTap?'🔊 Touche pour écouter':(G.deaf?'🔇 Son coupé':'🔊 Son actif');
      $td('tdGvCfg').textContent=td.gvCfg?'✖ Fermer':'⚙️ Réglages';
      $td('tdGvSet').hidden=!td.gvCfg;
      if(td.gvCfg){
        var onl={}; peers.forEach(function(x){onl[x.u]=1;});
        var rsig=others.map(function(p){return p.uid+':'+(tdGvAllowed(p.uid)?1:0)+(G.hush[p.uid]?1:0)+(onl[p.uid]?1:0);}).join(',');
        if(force||td.gvRowSig!==rsig){
          td.gvRowSig=rsig; var rows=$td('tdGvRows'); rows.textContent='';
          if(!others.length){ var e=document.createElement('p'); e.className='td-muted'; e.textContent='Personne d’autre dans le salon.'; rows.appendChild(e); }
          else {
            var h=document.createElement('div'); h.className='td-gv-row head'; ['','M’entend','Je l’entends'].forEach(function(t){ var sp=document.createElement('span'); sp.textContent=t; h.appendChild(sp); }); rows.appendChild(h);
            others.forEach(function(p){
              var row=document.createElement('div'); row.className='td-gv-row';
              var nm=document.createElement('span'); nm.className='nm'; nm.textContent=tdSafeName(p)+(onl[p.uid]?'':' (hors ligne)'); row.appendChild(nm);
              row.appendChild(tdGvTog(tdGvAllowed(p.uid),function(){ G.allow[p.uid]=!tdGvAllowed(p.uid); tdGvSave(); tdGvApplyTracks(); tdGvUi(true); }));
              row.appendChild(tdGvTog(!G.hush[p.uid],function(){ G.hush[p.uid]=!G.hush[p.uid]; tdGvSave(); tdGvApplyAudio(); tdGvUi(true); }));
              rows.appendChild(row);
            });
          }
        }
      }
    }
    function tdGvTick(){
      var G=td.gv; if(!G)return; G.n=(G.n||0)+1;
      if(G.ac&&G.ac.state==='suspended'){ try{G.ac.resume();}catch(e){} }
      var chips=$td('tdGvPeople').children;
      Object.keys(G.an).forEach(function(u){
        var o=G.an[u], dev=0; try{ o.an.getByteTimeDomainData(o.buf); }catch(e){ return; }
        for(var i=0;i<o.buf.length;i++){ var v=Math.abs(o.buf[i]-128); if(v>dev)dev=v; }
        var sp=dev>12;
        for(var k=0;k<chips.length;k++) if(chips[k].getAttribute('data-u')===u) chips[k].classList.toggle('speaking',sp);
      });
      if(G.n%16===0&&td.room)tdGvSync(td.room);
    }
    function tdGvTalkStop(){
      var G=td.gv; if(!G||!G.talk)return; G.talk=false;
      tdGvApplyTracks();
      try{ if(G.stream)G.stream.getTracks().forEach(function(t){t.stop();}); }catch(e){}
      G.stream=null; G.track=null; delete G.an[state.me];
      tdGvPresence().catch(function(){}); tdGvUi(true); if(td.room)tdVoiceSync(td.room,!!td.room.turn);
    }
    function tdGvTalkStart(){
      var G=td.gv; if(!G||G.talk||td.gvBusy)return;
      if(!navigator.mediaDevices||!window.RTCPeerConnection){ tdMsg('Ton navigateur ne permet pas le micro : écris plutôt.'); return; }
      td.gvBusy=true; tdGvUi();
      var gm=(typeof getMic==='function')?getMic:function(c){return navigator.mediaDevices.getUserMedia(c);};
      gm({audio:{echoCancellation:true,noiseSuppression:true,autoGainControl:true}}).then(function(st){
        if(td.gv!==G){ try{st.getTracks().forEach(function(t){t.stop();});}catch(e){} return; }
        G.stream=st; G.track=st.getAudioTracks()[0]; G.talk=true;
        tdGvWatch(state.me,st); tdGvApplyTracks();
        return tdGvPresence();
      }).catch(function(){ tdMsg('Micro indisponible : autorise le micro dans ton navigateur, ou écris.'); })
      .then(function(){ td.gvBusy=false; tdGvUi(true); if(td.room)tdVoiceSync(td.room,!!td.room.turn); });
    }
    function tdGvTalkToggle(){ var G=td.gv; if(!G)return; if(G.talk)tdGvTalkStop(); else tdGvTalkStart(); }
    function tdGvStop(){
      var G=td.gv; if(!G)return; td.gv=null; td.gvSig=null; td.gvRowSig=null; td.gvCfg=false; td.gvNeedTap=false;
      var _rw=$td('tdGvRows'), _pp=$td('tdGvPeople'); if(_rw)_rw.textContent=''; if(_pp)_pp.textContent='';
      clearInterval(G.hb); clearInterval(G.tick);
      Object.keys(G.pcs).forEach(function(u){ try{G.pcs[u].pc.close();}catch(e){} });
      try{if(G.stream)G.stream.getTracks().forEach(function(t){t.stop();});}catch(e){}
      try{if(G.ac)G.ac.close();}catch(e){}
      var ab=$td('tdGvAudios'); if(ab)ab.textContent='';
      var r=td.room;
      if(r&&td.roomId){
        var me=tdK(state.me), o={}; o['gvp.'+me]=firebase.firestore.FieldValue.delete();
        Object.keys(r.gv||{}).forEach(function(k){ if(k.indexOf(me+'__')===0||k.slice(-(me.length+2))==='__'+me)o['gv.'+k]=firebase.firestore.FieldValue.delete(); });
        try{ tdRef().update(o).catch(function(){}); }catch(e){}
      }
      td.gvNeedTap=false; var bx=$td('tdGv'); if(bx)bx.hidden=true;
    }
    /* ---- bouteille synchronisée : tout le monde voit le même tour, le créateur seul le lance ---- */
    var TD_SPIN_MS=3600;
    function tdBadge(txt,ms){ var b=$td('tdSpinBadge'); if(!b)return; clearTimeout(td.badgeT); b.textContent=txt||''; b.classList.toggle('on',!!txt); if(txt&&ms)td.badgeT=setTimeout(function(){b.classList.remove('on');},ms); }
    function tdAng(r,uid){var ps=r.players||[];for(var k=0;k<ps.length;k++)if(ps[k].uid===uid)return k*360/ps.length;return null;}
    function tdSetRot(deg,anim){var b=$td('tdBottle');b.style.transition=anim?'transform '+TD_SPIN_MS+'ms cubic-bezier(.17,.67,.12,1)':'none';b.style.transform='rotate('+deg+'deg)';if(!anim)void b.offsetWidth;td.rot=deg;}
    function tdEndSpin(){
      var r=td.room;
      if(!r||r.creator!==state.me||!r.turn||r.turn.phase!=='spin'||td.ending||!td.roomId)return;
      td.ending=true;
      fs.collection('truthDareRooms').doc(td.roomId).update({turn:Object.assign({},r.turn,{phase:'choose'})}).catch(function(){}).finally(function(){td.ending=false;});
    }
    function tdSyncBottle(r){
      if(td.spinning)return;
      var t=r.turn, base=td.rot||0;
      if(!t){var m=((base%360)+360)%360; if(m>.01&&m<359.99)tdSetRot(base+360-m,false); return;}
      var ang=tdAng(r,t.targetUid); if(ang===null)return;
      var fwd=(((ang-base)%360)+360)%360;
      if(t.phase==='spin' && t.spinId && t.spinId!==td.spinSeen){
        td.spinSeen=t.spinId;
        var age=Date.now()-t.spinId;
        if(!td.firstSnap || (age>-12000 && age<12000)){
          td.spinning=true; tdMsg('La bouteille tourne…');
          var hp=(r.players||[]).filter(function(p){return p.uid===r.creator;})[0];
          tdBadge('🌀 '+tdSafeName(hp)+' fait tourner la bouteille…'); $td('tdWheel').classList.add('spinning');
          tdSetRot(base+(t.spins||4)*360+fwd,true);
          var sid=t.spinId;
          setTimeout(function(){
            td.spinning=false; $td('tdWheel').classList.remove('spinning');
            var cr=td.room; if(!cr)return;
            if(cr.turn&&cr.turn.spinId===sid){ var tp=(cr.players||[]).filter(function(p){return p.uid===cr.turn.targetUid;})[0]; if(tp)tdBadge('🎯 '+tdSafeName(tp)+(cr.turn.targetUid===state.me?' : c’est toi !':' est désigné(e) !'),4500); }
            if(cr.creator===state.me && cr.turn && cr.turn.spinId===sid && cr.turn.phase==='spin') tdEndSpin();
            tdRenderRoom(cr);
          },TD_SPIN_MS+150);
          return;
        }
        tdSetRot(base+fwd,false);
        if(r.creator===state.me)tdEndSpin();
        return;
      }
      if(t.phase==='spin' && t.spinId && Date.now()-t.spinId>TD_SPIN_MS+2500 && r.creator===state.me)tdEndSpin();
      if(fwd>.01&&fwd<359.99)tdSetRot(base+fwd,false);
    }
    /* ---------- mini-chat : réservé aux joueurs NON désignés par la bouteille ----------
       Stocké dans le champ tchat du document de la partie, rattaché au tour (turnAt) et vidé à chaque tirage.
       Le joueur désigné ne reçoit aucun rendu : son DOM est vidé et le champ n'est jamais lu pour lui. */
    function tdChatRender(r,reveal){
      var box=$td('tdChat'), list=$td('tdChatList'), t=r.turn, me=state.me, ps=r.players||[];
      var inGame=ps.some(function(p){return p.uid===me;});
      var tOk=!!t&&ps.some(function(p){return p.uid===t.targetUid;}), pOk=!!t&&ps.some(function(p){return p.uid===t.pickerUid;});
      var can=!!reveal&&!!t&&t.phase!=='spin'&&t.targetUid!==me&&inGame&&tOk&&pOk;
      if(!can){ box.hidden=true; list.textContent=''; td.chatSig=''; return; }
      var tgt=ps.filter(function(p){return p.uid===t.targetUid;})[0], pck=ps.filter(function(p){return p.uid===t.pickerUid;})[0];
      var isP=t.pickerUid===me, done=t.phase==='done';
      var msgs=(r.tchat||[]).filter(function(m){return m&&m.turnAt===t.at&&typeof m.text==='string';}).sort(function(a,b){return a.at-b.at;}).slice(-60);
      box.hidden=false; $td('tdChatForm').hidden=done;
      $td('tdChatHint').textContent=(isP?'Les autres te soufflent des idées. ':'Souffle des idées à '+tdSafeName(pck)+'. ')+'🙈 '+tdSafeName(tgt)+' ne voit rien. Le chat se vide au prochain tour.';
      var sig=r.id+'|'+t.at+'|'+t.phase+'|'+t.pickerUid+'|'+me+'|'+msgs.length+'|'+(msgs.length?msgs[msgs.length-1].at:0);
      if(td.chatSig===sig) return;
      var first=!td.chatSig, atBottom=list.scrollHeight-list.scrollTop-list.clientHeight<40;
      td.chatSig=sig; list.textContent='';
      if(!msgs.length){ var e=document.createElement('div'); e.className='td-chat-empty'; e.textContent='Aucune idée pour l’instant.'; list.appendChild(e); }
      msgs.forEach(function(m){
        var d=document.createElement('div'); d.className='td-chat-msg'+(m.uid===me?' mine':'');
        var b=document.createElement('b'); b.textContent=String(m.name||'Joueur').slice(0,32)+(m.uid===t.pickerUid?' · 🎯':''); d.appendChild(b);
        var x=document.createElement('span'); x.textContent=m.text; d.appendChild(x);
        if(isP&&t.phase==='ask'&&m.uid!==me){
          var u=document.createElement('button'); u.type='button'; u.className='td-chat-use'; u.textContent='↗ Utiliser';
          u.addEventListener('click',function(){ var ta=$td('tdPrompt'); ta.value=m.text; try{ta.focus();}catch(e){} });
          d.appendChild(u);
        }
        list.appendChild(d);
      });
      if(first||atBottom) list.scrollTop=list.scrollHeight;
    }
    function tdChatSend(){
      var r=td.room, t=r&&r.turn, inp=$td('tdChatInput'), txt=inp.value.trim();
      if(!txt||!t||!td.roomId||!state.me) return;
      if(t.phase==='spin'||t.phase==='done'||t.targetUid===state.me) return;
      var ps=r.players||[], mine=ps.filter(function(p){return p.uid===state.me;})[0]; if(!mine) return;
      var now=Date.now(); if(td.chatLast&&now-td.chatLast<500) return; td.chatLast=now;
      var m={uid:state.me,name:tdSafeName(mine),text:txt.slice(0,140),at:now,turnAt:t.at};
      inp.value='';
      fs.collection('truthDareRooms').doc(td.roomId).update({tchat:firebase.firestore.FieldValue.arrayUnion(m)})
      .catch(function(){ tdMsg('Message non envoyé.'); if(!inp.value) inp.value=txt; });
    }
    function tdSpin() {
      var r=td.room;if(!r||td.spinning||td.busy)return;
      if(r.creator!==state.me){tdMsg('Seul le créateur de la partie peut faire tourner la bouteille.');return;}
      var ps=(r.players||[]); if(ps.length<2){tdMsg('Il faut au moins deux joueurs.');return;}
      if(r.startAt>Date.now()){tdMsg('La partie commencera à l’heure prévue.');return;}
      if(r.turn && r.turn.phase!=='done'){var _t=ps.some(function(p){return p.uid===r.turn.targetUid;}),_p=ps.some(function(p){return p.uid===r.turn.pickerUid;});if(_t&&_p){tdMsg('Terminez le tour actuel avant de tourner la bouteille.');return;}}
      td.busy=true; $td('tdSpin').disabled=true;
      var target=ps[Math.floor(Math.random()*ps.length)];
      var others=ps.filter(function(p){return p.uid!==target.uid;}); var picker=others[Math.floor(Math.random()*others.length)];
      var id=Date.now(), ref=fs.collection('truthDareRooms').doc(td.roomId);
      ref.update({status:'playing',turn:{phase:'spin',spinId:id,spins:4+Math.floor(Math.random()*3),targetUid:target.uid,pickerUid:picker.uid,type:'',prompt:'',answer:'',at:id},voice:null,vc:{},tchat:[],history:(r.history||[]).concat([{targetUid:target.uid,pickerUid:picker.uid,at:id}]).slice(-30)})
      .catch(function(e){tdMsg('Erreur pendant le tirage : '+(e.message||''));})
      .finally(function(){td.busy=false; if(td.room)tdRenderRoom(td.room);});
    }
    function tdUpd(turn,extra,okMsg,errMsg){
      var o=Object.assign({turn:turn},extra||{});
      return fs.collection('truthDareRooms').doc(td.roomId).update(o).then(function(){if(okMsg)tdMsg(okMsg);}).catch(function(e){tdMsg(errMsg+(e&&e.message?' ('+e.message+')':''));});
    }
    function tdChoose(type) {
      var r=td.room; if(!r||!r.turn||r.turn.phase!=='choose'||r.turn.targetUid!==state.me)return;
      tdUpd(Object.assign({},r.turn,{phase:'ask',type:type}),null,type==='action'?'Action choisie !':'Vérité choisie !','Choix impossible');
    }
    function tdSendPrompt() {
      var r=td.room; if(!r||!r.turn||r.turn.phase!=='ask'||r.turn.pickerUid!==state.me)return;
      var type=r.turn.type||'truth', prompt=$td('tdPrompt').value.trim();
      if(!prompt){var list=defaults[type]||defaults.truth;prompt=list[Math.floor(Math.random()*list.length)];}
      tdUpd(Object.assign({},r.turn,{phase:'answer',prompt:prompt.slice(0,240),by:state.me}),null,'Proposition envoyée !','Envoi impossible').then(function(){$td('tdPrompt').value='';});
    }
    function tdFinish() {
      var r=td.room; if(!r||!r.turn||r.turn.phase!=='answer'||r.turn.targetUid!==state.me)return;
      var ans=$td('tdAnswer').value.trim();
      if(!ans){tdMsg('Écris ta réponse avant de l’envoyer.');return;}
      tdUpd(Object.assign({},r.turn,{phase:'vote',answer:ans.slice(0,500),votes:{},voteAt:Date.now()}),null,'Réponse envoyée : les autres votent.','Impossible d’envoyer la réponse').then(function(){$td('tdAnswer').value='';});
    }
    /* vote : approuvé si la majorité approuve ; sinon (égalité comprise) le joueur doit refaire */
    function tdVote(v,timedOut) {
      if(!td.roomId||td.voting||!fs.runTransaction)return;
      td.voting=true;
      var ref=fs.collection('truthDareRooms').doc(td.roomId);
      fs.runTransaction(function(tx){return tx.get(ref).then(function(d){
        if(!d.exists)return;
        var room=d.data(), t=room.turn; if(!t||t.phase!=='vote')return;
        var voters=(room.players||[]).filter(function(p){return p.uid!==t.targetUid;});
        var votes=Object.assign({},t.votes||{});
        if(v){ if(t.targetUid===state.me||votes[state.me]||!voters.some(function(p){return p.uid===state.me;}))return; votes[state.me]=v; }
        if(timedOut){ if(!t.voteAt||Date.now()<t.voteAt+TD_VOTE_MS)return; voters.forEach(function(p){ if(!votes[p.uid])votes[p.uid]='ok'; }); }
        var ok=0,no=0; voters.forEach(function(p){if(votes[p.uid]==='ok')ok++;else if(votes[p.uid]==='no')no++;});
        var V=voters.length, nt;
        if(V===0||ok*2>V) nt=Object.assign({},t,{votes:votes,phase:'done',result:'done'});
        else if(no*2>=V) nt=Object.assign({},t,{votes:{},phase:'answer',attempt:(t.attempt||0)+1,rejected:t.answer,answer:''});
        else nt=Object.assign({},t,{votes:votes});
        if(!v&&nt.phase==='vote')return;
        var upd={turn:nt};
        if(nt.phase==='done')upd.history=(room.history||[]).concat([{targetUid:t.targetUid,pickerUid:t.pickerUid,type:t.type,prompt:t.prompt,answer:t.answer,approve:ok,reject:no,result:'done',at:Date.now()}]).slice(-50);
        tx.update(ref,upd);
      });}).catch(function(e){tdMsg('Vote impossible'+(e&&e.message?' ('+e.message+')':''));}).then(function(){td.voting=false;},function(){td.voting=false;});
    }
    /* ---------- compte à rebours du vote : 20 s, puis les absents comptent comme « approuvé » ---------- */
    var TD_VOTE_MS=20000;
    function tdVoteTick(){
      var r=td.room, t=r&&r.turn, box=$td('tdVoteTimer');
      if(!t||t.phase!=='vote'||!t.voteAt||$td('tdRoom').hidden||td.spinning){ if(box)box.hidden=true; return; }
      var me=state.me, ps=r.players||[], left=t.voteAt+TD_VOTE_MS-Date.now(), sec=Math.max(0,Math.ceil(left/1000));
      var isVoter=t.targetUid!==me&&ps.some(function(p){return p.uid===me;}), mine=(t.votes||{})[me];
      box.hidden=false;
      $td('tdTimerBar').style.width=Math.max(0,Math.min(100,left/TD_VOTE_MS*100)).toFixed(1)+'%';
      var tx=$td('tdTimerTxt'); tx.classList.toggle('low',left>0&&left<=6000);
      tx.textContent=left<=0?'⏱ Temps écoulé…':'⏱ '+sec+' s'+(isVoter&&!mine?' · sans vote, tu comptes comme ✅':' avant la fin du vote');
      if(left<=0&&!td.voting&&(!td.voteTry||Date.now()-td.voteTry>1500)&&(r.creator===me||left<=-3000)){ td.voteTry=Date.now(); tdVote(null,true); }
    }
    /* ---------- l'hôte peut retirer des joueurs ---------- */
    function tdHostRender(r){
      var box=$td('tdHost'), list=$td('tdHostList'), me=state.me;
      var others=(r.players||[]).filter(function(p){return p.uid!==me;});
      if(r.creator!==me||!others.length){ box.hidden=true; list.textContent=''; td.hostSig=''; return; }
      box.hidden=false;
      var sig=r.id+'|'+others.map(function(p){return p.uid+':'+tdSafeName(p);}).join(',');
      if(td.hostSig===sig)return; td.hostSig=sig; list.textContent='';
      others.forEach(function(p){
        var row=document.createElement('div'); row.className='td-host-row';
        var n=document.createElement('span'); n.textContent=tdSafeName(p);
        var b=document.createElement('button'); b.type='button'; b.className='td-host-kick'; b.textContent='Retirer';
        b.addEventListener('click',function(){ tdKick(p.uid); });
        row.appendChild(n); row.appendChild(b); list.appendChild(row);
      });
    }
    function tdKick(uid){
      var r=td.room; if(!r||!td.roomId||r.creator!==state.me||uid===state.me||td.kicking||!fs.runTransaction)return;
      var p=(r.players||[]).filter(function(x){return x.uid===uid;})[0]; if(!p)return;
      var name=tdSafeName(p);
      if(!window.confirm('Retirer '+name+' du salon ? Cette personne ne pourra pas revenir.'))return;
      td.kicking=true; var ref=fs.collection('truthDareRooms').doc(td.roomId);
      fs.runTransaction(function(tx){return tx.get(ref).then(function(d){
        if(!d.exists)return; var room=d.data(); if(room.creator!==state.me)return;
        var ps=(room.players||[]).filter(function(x){return x.uid!==uid;});
        var kicked=(room.kicked||[]).filter(function(x){return x!==uid;}).concat([uid]);
        tx.update(ref,{players:ps,kicked:kicked});
      });}).then(function(){tdMsg(name+' a été retiré(e) du salon.');},function(){tdMsg('Impossible de retirer ce joueur.');}).then(function(){td.kicking=false;});
    }
    function tdLeave() {
      tdVoiceStopAll(); tdGvStop();
      var r=td.room;if(r&&td.roomId){var ps=(r.players||[]).filter(function(p){return p.uid!==state.me;});fs.collection('truthDareRooms').doc(td.roomId).update({players:ps}).catch(function(){});}
      if(td.roomUnsub)td.roomUnsub();td.roomUnsub=null;td.roomId=null;td.room=null;$td('tdRoom').hidden=true;tdInRoom(false);tdMsg('Tu as quitté la partie.');
    }
    $td('tdOpen').addEventListener('click',function(){tdShowPanel(true);tdListenRooms();tdMsg('Choisis une partie ou crée la tienne.');});
    $td('tdClose').addEventListener('click',function(){tdShowPanel(false);});
    $td('tdCreate').addEventListener('click',tdCreate);
    $td('tdNameMode').addEventListener('change',function(){$td('tdPseudo').hidden=this.value!=='pseudo';});
    $td('tdSpin').addEventListener('click',tdSpin);
    $td('tdStop').addEventListener('click',tdStop);
    $td('tdAction').addEventListener('click',function(){tdChoose('action');});
    $td('tdTruth').addEventListener('click',function(){tdChoose('truth');});
    $td('tdSendPrompt').addEventListener('click',tdSendPrompt);
    $td('tdDone').addEventListener('click',function(){tdFinish();});
    $td('tdMicBtn').addEventListener('click',function(){ var G=td.gv; if(G&&!G.talk){ G.allow={}; G.allowAll=true; } tdGvTalkToggle(); });
    $td('tdApprove').addEventListener('click',function(){tdVote('ok');});
    $td('tdReject').addEventListener('click',function(){tdVote('no');});
    $td('tdLeave').addEventListener('click',tdLeave);
    $td('tdChatSend').addEventListener('click',tdChatSend);
    window.setInterval(tdVoteTick,500);
    $td('tdGvTalk').addEventListener('click',function(){ tdGvTalkToggle(); });
    $td('tdGvSpk').addEventListener('click',function(){
      var G=td.gv; if(!G)return;
      if(td.gvNeedTap){ td.gvNeedTap=false; var as=$td('tdGvAudios').querySelectorAll('audio'); for(var i=0;i<as.length;i++){ try{as[i].play();}catch(e){} } }
      else { G.deaf=!G.deaf; tdGvSave(); tdGvApplyAudio(); }
      tdGvUi();
    });
    $td('tdGvCfg').addEventListener('click',function(){ td.gvCfg=!td.gvCfg; tdGvUi(true); });
    $td('tdGvAll').addEventListener('click',function(){ var G=td.gv; if(!G)return; G.allow={}; G.allowAll=true; tdGvSave(); tdGvApplyTracks(); tdGvUi(true); });
    $td('tdGvNone').addEventListener('click',function(){ var G=td.gv; if(!G)return; G.allow={}; G.allowAll=false; tdGvSave(); tdGvApplyTracks(); tdGvUi(true); });
    window.addEventListener('pagehide',function(){tdVoiceStopAll();tdGvStop();if(td.unsub)td.unsub();if(td.roomUnsub)td.roomUnsub();});
  })();

