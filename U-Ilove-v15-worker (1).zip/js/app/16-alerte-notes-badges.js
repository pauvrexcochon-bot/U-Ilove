/* U&I — js/app/16-alerte-notes-badges.js
   Alerte dans le site, notes, badge créateur
   (fait partie de l’appli : assemblée par js/boot/loader.js dans une seule fermeture) */
  /* ---------- notification dans le site ---------- */
  var toastEl = $('#toast'), toastTimer = null, toastHideT = null, toastTarget = null, knownTs = {};
  function hideToast() {
    clearTimeout(toastTimer);
    toastEl.classList.remove('show');
    clearTimeout(toastHideT);
    toastHideT = setTimeout(function () { toastEl.hidden = true; }, 320);
  }
  var toastFr = false;
  function showToast(uid, name, text) {
    toastFr = false;
    clearTimeout(toastTimer); clearTimeout(toastHideT);
    toastTarget = uid ? { uid: uid, name: name } : null;
    toastEl.replaceChildren(el('span', 'tn', NOTIF_TITLE), el('span', 'tm', (name ? cap(name) + ' : ' : '') + (text || '')));
    toastEl.hidden = false;
    void toastEl.offsetWidth;
    toastEl.classList.add('show');
    toastTimer = setTimeout(hideToast, Math.min(15000, 5000 + String(text || '').length * 40));
  }
  function incomingElsewhere(id, c) {
    var other = (c.members || []).filter(function (x) { return x !== state.me; })[0];
    if (!other) return;
    var name = c.group ? (c.title || 'Groupe') : ((c.names && c.names[other]) || 'Nouveau message');
    var text = c.lastText || '';
    if (!npOn('msg')) return;
    var loud = fx();
    if (loud) speakNew();
    var show = function (full) { if (document.hidden) sysNotify(name, full, id, !loud); else showToast(other, name, full); };
    fs.collection('chats').doc(id).collection('messages').orderBy('ts', 'desc').limit(1).get()
      .then(function (q) { var d = q.docs[0] && q.docs[0].data(); show(d && typeof d.text === 'string' && d.text.charAt(0) !== SYS ? d.text : text); })
      .catch(function () { show(text); });
  }
  toastEl.addEventListener('click', function () {
    if (toastFr) { toastFr = false; hideToast(); frOpen('req'); return; }
    var t = toastTarget; hideToast();
    if (!t) return;
    if (state.view === 'game') { stopGame(); viewGame.hidden = true; }
    if (state.view === 'music') viewMusic.hidden = true;
    openChat(t.uid, t.name);
  });

  /* ---------- notes (visibles 24 h dans la liste) ---------- */
  /* ---------- badge créateur (activé avec une clé dans les réglages) ---------- */
  var BADGE_HASH = '6edc33a2368bb74356032f1ec792d2dd5c0e6d67a677a4e32732bbc7878dfec3', badges = {};
  var BADGE_TXT = '\u2713 Cr\u00e9ateur', verifs = {}, CERT_TXT = '\u2713 Certifi\u00e9';
  function paintBadge(b, cert) { b.textContent = cert ? CERT_TXT : BADGE_TXT; b.title = cert ? 'Compte certifi\u00e9' : 'Cr\u00e9ateur de U&I'; b.setAttribute('aria-label', b.title); }
  /* musiques partagées : tout le monde y a accès, sauf les certifiés (le créateur autorise certains certifiés) */
  var musicOks = {};
  function musicShared() {
    try {
      if (!state.me) return false;
      if (badges[state.me]) return true;
      var cert = (state.me in verifs) ? verifs[state.me] === true : localStorage.getItem('uandi-cert-' + state.me) === '1';
      if (!cert) return true;
      return (state.me in musicOks) ? musicOks[state.me] === true : localStorage.getItem('uandi-musicok-' + state.me) === '1';
    } catch (e) { return false; }
  }
  function badgeEl(uid) { var c = !badges[uid] && verifs[uid], b = el('span', 'ubadge' + (c ? ' cert' : '')); paintBadge(b, c); return b; }
  /* Actualités : visibles par tous ; chacun peut masquer l'onglet pour son compte avec le champ caché des réglages */
  var NEWS_KEY = 'uandi-news-off-';
  /* comptes certifiés : onglet Actualités masqué d'office (sauf s'ils sont aussi créateurs). Créateur : le code bascule. */
  function newsBlocked() {
    try {
      if (!state.me) return false;
      if (!badges[state.me]) {
        var cert = (state.me in verifs) ? verifs[state.me] === true : localStorage.getItem('uandi-cert-' + state.me) === '1';
        if (cert) return true;
      }
      return localStorage.getItem(NEWS_KEY + state.me) === '1';
    } catch (e) { return false; }
  }
  window.newsBlocked = newsBlocked;
  /* mode discret (code secret) : masque les outils créateur et les discussions anonymes */
  function stealthOn() { try { return !!state.me && localStorage.getItem(NEWS_KEY + state.me) === '1'; } catch (e) { return false; } }
  function creatorOn() { return !!badges[state.me] && !stealthOn(); }
  function newsAccess() { document.dispatchEvent(new Event('newsaccess')); }
  function newsCodeCheck(force) {
    var f = $('#newsCode'); if (!f) return;
    var v = f.value.trim().normalize('NFC').replace('\u2714', '\u2713');
    if (v !== 'Xil.lyam\u2713') { if (force) f.value = ''; return; }
    f.value = '';
    try {
      if (newsBlocked()) localStorage.removeItem(NEWS_KEY + state.me); else localStorage.setItem(NEWS_KEY + state.me, '1');
    } catch (e) {}
    stealthApply();
    newsAccess();
  }
  /* applique le mode discret tout de suite : ferme les fenêtres créateur, coupe les écoutes, vide les discussions anonymes */
  function stealthApply() {
    var hide = stealthOn();
    paintBadgeSec();
    try { if (crDlg.open) crDlg.close(); if (accDlg.open) accDlg.close(); } catch (e) {}
    if (typeof apCheck === 'function') apCheck();
    if (newsBlocked()) { try { atStop(); } catch (e) {} }
    if (typeof nwRender === 'function') nwRender();
    if (hide && state.view === 'news') { var nb = $('#nwBack'); if (nb) { nb.dataset.force = '1'; nb.click(); } }
  }
  var badgeReq = {};
  function ensureBadge(uid) {
    if (!uid || badgeReq[uid] || uid === state.me || (typeof noteSubs !== 'undefined' && noteSubs[uid])) return;
    badgeReq[uid] = 1;
    fs.collection('presence').doc(uid).get().then(function (d) {
      var v = d.exists ? d.data() : {}, b = v.badge === true, c = v.verified === true;
      if (!!badges[uid] === b && !!verifs[uid] === c) return;
      badges[uid] = b; verifs[uid] = c;
      if (!(b || c)) return;
      if (state.view === 'list') renderList();
      if (typeof nwRender === 'function' && NW && Object.keys(NW.open || {}).some(function (k) { return NW.open[k]; })) nwRender();
      if (frDlg.open) frRender();
      if (ucDlg.open) ucRender();
      if (nvDlg.open && nvTarget && nvTarget.uid === uid) { $('#nvName').textContent = cap(nvTarget.name); withBadge($('#nvName'), uid); }
    }).catch(function () { badgeReq[uid] = 0; });
  }
  function withBadge(node, uid) { if (badges[uid] || verifs[uid]) node.appendChild(badgeEl(uid)); return node; }
  function updateChatBadge() {
    var b = $('#chatBadge'); if (!b) return;
    var o = state.chat && !state.chat.group ? state.chat.other : null, on = !!(o && (badges[o] || verifs[o]));
    b.hidden = !on; b.textContent = ''; b.className = 'ubadge' + (on && !badges[o] ? ' cert' : ''); if (on) paintBadge(b, !badges[o]);
  }
  function sha256(t) {
    return crypto.subtle.digest('SHA-256', new TextEncoder().encode(t)).then(function (b) {
      return Array.prototype.map.call(new Uint8Array(b), function (x) { return ('0' + x.toString(16)).slice(-2); }).join('');
    });
  }
  function paintBadgeSec() {
    var on = !!badges[state.me];
    $('#badgeState').textContent = on ? 'Badge actif : il s\u2019affiche \u00e0 c\u00f4t\u00e9 de ton nom pour tout le monde.' : 'Entre ta cl\u00e9 pour afficher le badge \u00ab Cr\u00e9ateur \u00bb \u00e0 c\u00f4t\u00e9 de ton nom.';
    $('#badgeKey').hidden = on; $('#badgeGo').hidden = on; $('#badgeOff').hidden = !on;
    $('#creatorSec').hidden = !on || stealthOn(); $('#badgeSec').hidden = on && stealthOn(); $('#myUid').textContent = state.me || '';
  }
  function badgeErr(t) { var e = $('#badgeErr'); e.textContent = t || ''; e.hidden = !t; }
  function badgeRefresh() {
    paintBadgeSec(); newsAccess();
    if (state.view === 'list') renderList();
    else if (state.view === 'chat') { updateChatBadge(); if (state.chat && state.chat.group) render(); }
  }
  function setBadge(on) {
    badgeErr('');
    return fs.collection('presence').doc(state.me).set({ name: myName(), badge: on ? true : firebase.firestore.FieldValue.delete() }, { merge: true })
      .then(function () { badges[state.me] = on; badgeRefresh(); })
      .catch(function () { badgeErr('Impossible d\u2019enregistrer le badge (connexion ou r\u00e8gles Firestore).'); });
  }
  $('#badgeGo').addEventListener('click', function () {
    var k = $('#badgeKey').value.trim().normalize('NFC');
    if (!k) { badgeErr('Entre ta cl\u00e9.'); return; }
    if (!(window.crypto && crypto.subtle)) { badgeErr('V\u00e9rification impossible : ouvre le site en https.'); return; }
    sha256(k).then(function (h) {
      if (h !== BADGE_HASH) { badgeErr('Cl\u00e9 incorrecte.'); return; }
      $('#badgeKey').value = ''; setBadge(true);
    });
  });
  $('#badgeOff').addEventListener('click', function () { setBadge(false); });
  $('#openSet').addEventListener('click', function () { badgeErr(''); paintBadgeSec(); });
  $('#newsCode').addEventListener('input', function () { newsCodeCheck(false); });
  $('#newsCode').addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); newsCodeCheck(true); } });
