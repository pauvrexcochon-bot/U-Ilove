/* U&I — js/app/19-musique.js
   Musique, musiques partagées, partage dans une discussion
   (fait partie de l’appli : assemblée par js/boot/loader.js dans une seule fermeture) */
  /* ---------- musique (fichiers de ton appareil) ---------- */
  var viewMusic = $('#viewMusic'), mAu = new Audio(), mDbP = null, mMsgT = null, mClearT = null;
  var M = { tracks: [], cur: -1, shuffle: false, repeat: 'off', loaded: false, seekAt: 0, edit: -1, draft: '', focusEdit: false };
  mAu.preload = 'auto';

  function mDb() {
    if (mDbP) return mDbP;
    mDbP = new Promise(function (ok, ko) {
      if (!window.indexedDB) { ko(new Error('noidb')); return; }
      var r = indexedDB.open('uandi-music-' + state.me, 1);
      r.onupgradeneeded = function () { r.result.createObjectStore('tracks', { keyPath: 'id', autoIncrement: true }); };
      r.onsuccess = function () { ok(r.result); };
      r.onerror = function () { ko(r.error); };
    });
    return mDbP;
  }
  function mTx(mode, fn) {
    return mDb().then(function (db) {
      return new Promise(function (ok, ko) {
        var tx = db.transaction('tracks', mode), res = fn(tx.objectStore('tracks'));
        tx.oncomplete = function () { ok(res ? res.result : undefined); };
        tx.onerror = tx.onabort = function () { ko(tx.error); };
      });
    });
  }
  function mName(n) { return String(n || '').replace(/\.[^.]+$/, ''); }
  function mLabel(t) { return (t && (t.title || mName(t.name))) || ''; }
  function mDecode(b) {
    var enc = b[0], body = b.subarray(1), s = '';
    try {
      if (enc === 1 || enc === 2) {
        var le = enc === 1;
        if (body.length >= 2 && body[0] === 0xFE && body[1] === 0xFF) { le = false; body = body.subarray(2); }
        else if (body.length >= 2 && body[0] === 0xFF && body[1] === 0xFE) { le = true; body = body.subarray(2); }
        s = new TextDecoder(le ? 'utf-16le' : 'utf-16be').decode(body);
      } else s = new TextDecoder(enc === 3 ? 'utf-8' : 'iso-8859-1').decode(body);
    } catch (e) { s = ''; }
    return s.replace(/\u0000/g, '').trim();
  }
  function mSync(u8, p) { return ((u8[p] & 0x7f) << 21) | ((u8[p + 1] & 0x7f) << 14) | ((u8[p + 2] & 0x7f) << 7) | (u8[p + 3] & 0x7f); }
  function mReadTitle(file) {
    if (/^audio\/(wav|x-wav|ogg|flac|webm)/.test(file.type || '')) return Promise.resolve('');
    return file.slice(0, 262144).arrayBuffer().then(function (buf) {
      var u8 = new Uint8Array(buf), d = new DataView(buf);
      if (u8.length < 10 || u8[0] !== 0x49 || u8[1] !== 0x44 || u8[2] !== 0x33) return '';
      var ver = u8[3], end = Math.min(10 + mSync(u8, 6), u8.length), pos = 10, title = '', artist = '';
      if (u8[5] & 0x40) pos += ver === 4 ? mSync(u8, 10) : d.getUint32(10) + 4;
      while (pos + 10 <= end) {
        var id = String.fromCharCode(u8[pos], u8[pos + 1], u8[pos + 2], u8[pos + 3]);
        if (!/^[A-Z0-9]{4}$/.test(id)) break;
        var size = ver === 4 ? mSync(u8, pos + 4) : d.getUint32(pos + 4), start = pos + 10;
        if (size <= 0 || start + size > u8.length) break;
        if (id === 'TIT2') title = mDecode(u8.subarray(start, start + size));
        else if (id === 'TPE1') artist = mDecode(u8.subarray(start, start + size));
        pos = start + size;
      }
      return title ? (artist ? artist + ' - ' + title : title) : '';
    }).catch(function () { return ''; });
  }
  function mIsAudio(f) {
    var t = f.type || '';
    if (t.indexOf('audio/') === 0 || /\.(mp3|m4a|aac|wav|ogg|oga|opus|flac|weba|amr|3gp)$/i.test(f.name || '')) return true;
    /* Android donne souvent un fichier sans extension et sans type : le sélecteur n'a déjà proposé que de l'audio */
    return !/^(image|text)\//.test(t) && !/^application\/(pdf|zip|json|x-zip|msword|vnd)/.test(t);
  }
  function mType(f) {
    if (f.type && f.type.indexOf('audio/') === 0) return Promise.resolve(f.type);
    return f.slice(0, 12).arrayBuffer().then(function (b) {
      var u = new Uint8Array(b), s = String.fromCharCode.apply(null, Array.prototype.slice.call(u));
      if (s.slice(0, 4) === 'OggS') return 'audio/ogg';
      if (s.slice(0, 4) === 'fLaC') return 'audio/flac';
      if (s.slice(0, 4) === 'RIFF' && s.slice(8, 12) === 'WAVE') return 'audio/wav';
      if (s.slice(4, 8) === 'ftyp') return 'audio/mp4';
      if (u[0] === 0x1A && u[1] === 0x45 && u[2] === 0xDF && u[3] === 0xA3) return 'audio/webm';
      return 'audio/mpeg';
    }).catch(function () { return 'audio/mpeg'; });
  }
  function mMsg(t) {
    $('#mMsg').textContent = t || '';
    clearTimeout(mMsgT);
    if (t) mMsgT = setTimeout(function () { $('#mMsg').textContent = ''; }, 4500);
  }
  function mMeta() {
    try {
      if (!('mediaSession' in navigator) || typeof MediaMetadata === 'undefined') return;
      var t = M.tracks[M.cur];
      navigator.mediaSession.metadata = t ? new MediaMetadata({ title: mLabel(t), artist: 'U&I' }) : null;
    } catch (e) {}
  }
  function mRender() {
    var list = $('#mList');
    list.replaceChildren();
    if (!M.tracks.length) {
      var li0 = el('li', 'empty');
      li0.appendChild(el('strong', '', 'Aucune musique'));
      li0.appendChild(document.createTextNode('Ajoute des fichiers audio de ton appareil pour les écouter ici.'));
      list.appendChild(li0);
    }
    var playing = !mAu.paused && M.cur >= 0;
    M.tracks.forEach(function (t, i) {
      var li = el('li'), row = el('div', 'mrow' + (i === M.cur ? ' on' : ''));
      if (i === M.edit) {
        var inp = el('input', 'field mfield');
        inp.type = 'text'; inp.maxLength = 80; inp.value = M.draft;
        inp.setAttribute('aria-label', 'Nom de la musique');
        var ok = el('button', 'ghost mok', 'OK');
        ok.type = 'button'; ok.dataset.i = i;
        row.appendChild(inp); row.appendChild(ok);
      } else {
        var b = el('button', 'mname', (i === M.cur && playing ? '▶ ' : '') + mLabel(t));
        b.type = 'button'; b.dataset.i = i;
        var r = el('button', 'mren', '✎');
        r.type = 'button'; r.dataset.i = i; r.setAttribute('aria-label', 'Renommer ' + mLabel(t));
        var d = el('button', 'mdel', '✕');
        d.type = 'button'; d.dataset.i = i; d.setAttribute('aria-label', 'Retirer ' + mLabel(t));
        var sh = el('button', 'mshare', '↗');
        sh.type = 'button'; sh.dataset.i = i; sh.disabled = !!M.sharing;
        sh.setAttribute('aria-label', 'Partager ' + mLabel(t) + ' dans une discussion');
        row.appendChild(b); try { mCloudBtn(row, t); } catch (e) {} row.appendChild(sh); row.appendChild(r); row.appendChild(d);
      }
      li.appendChild(row); list.appendChild(li);
    });
    if (M.focusEdit) {
      M.focusEdit = false;
      var fi = list.querySelector('.mfield');
      if (fi) { fi.focus(); fi.select(); }
    }
    var cur = M.tracks[M.cur];
    $('#mTitle').textContent = cur ? mLabel(cur) : 'Aucune musique sélectionnée';
    $('#mClear').hidden = !M.tracks.length;
    $('#mShuffle').setAttribute('aria-pressed', M.shuffle ? 'true' : 'false');
    var rp = $('#mRepeat');
    rp.setAttribute('aria-pressed', M.repeat !== 'off' ? 'true' : 'false');
    rp.innerHTML = '<svg class="ln" viewBox="0 0 24 24" aria-hidden="true"><path d="M17 2l4 4-4 4M3 11V9a3 3 0 0 1 3-3h15M7 22l-4-4 4-4M21 13v2a3 3 0 0 1-3 3H3"/></svg>' + (M.repeat === 'one' ? '<b class="r1">1</b>' : '');
    $('#mPlay').classList.toggle('playing', playing);
    $('#mPlay').setAttribute('aria-label', playing ? 'Pause' : 'Lecture');
    $('#mDisc').classList.toggle('playing', playing);
    $('#openMusic').classList.toggle('playing', playing);
    try { if ('mediaSession' in navigator) navigator.mediaSession.playbackState = playing ? 'playing' : 'paused'; } catch (e) {}
    try { mShRender(); } catch (e) {}
  }
  function mTime() {
    var d = mAu.duration, c = mAu.currentTime || 0, ok = isFinite(d) && d > 0;
    $('#mCur').textContent = fmtDur(c);
    $('#mDur').textContent = ok ? fmtDur(d) : '0:00';
    if (Date.now() - M.seekAt > 500) $('#mSeek').value = ok ? Math.round(c / d * 1000) : 0;
  }
  function mLoad() {
    if (M.loaded) return M.loading;
    M.loaded = true;
    M.loading = mTx('readonly', function (st) { return st.getAll(); }).then(function (rows) {
      (rows || []).sort(function (a, b) { return a.id - b.id; }).forEach(function (r) {
        M.tracks.push({ id: r.id, name: r.name, title: r.title || '', cid: r.cid || '', url: URL.createObjectURL(r.blob) });
      });
    }).catch(function () {
      mMsg('Ton navigateur ne peut pas garder la liste : elle sera perdue au rechargement.');
    }).then(function () { mRender(); });
    return M.loading;
  }
  async function mAdd(files) {
    files = files.filter(mIsAudio);
    if (!files.length) { mMsg('Choisis des fichiers audio (mp3, m4a, wav…).'); return; }
    var added = 0, lost = false;
    for (var i = 0; i < files.length; i++) {
      var f0 = files[i], id, title = await mReadTitle(f0), ty = await mType(f0);
      var f = f0.type === ty ? f0 : f0.slice(0, f0.size, ty);
      try {
        id = await mTx('readwrite', function (st) { return st.add({ name: f0.name, title: title, type: ty, blob: f }); });
      } catch (e) { lost = true; id = 'tmp' + Date.now() + '-' + i; }
      M.tracks.push({ id: id, name: f0.name, title: title, cid: '', url: URL.createObjectURL(f) });
      added++;
    }
    mMsg(added + (added > 1 ? ' musiques ajoutées.' : ' musique ajoutée.') + (lost ? ' Certaines ne seront pas gardées après un rechargement.' : ''));
    mRender();
  }
  function mPlay(i) {
    if (i < 0 || i >= M.tracks.length) return;
    M.cur = i;
    mAu.src = M.tracks[i].url;
    var p = mAu.play();
    if (p && p.catch) p.catch(function () { mMsg('Appuie sur lecture pour démarrer.'); });
    mMeta(); mRender();
  }
  function mToggle() {
    if (M.cur < 0) { if (M.tracks.length) mPlay(0); return; }
    if (mAu.paused) { var p = mAu.play(); if (p && p.catch) p.catch(function () {}); } else mAu.pause();
  }
  function mNext(auto) {
    var n = M.tracks.length;
    if (!n) return;
    if (auto && M.repeat === 'one') { mAu.currentTime = 0; mAu.play(); return; }
    var nx;
    if (M.shuffle && n > 1) { do { nx = Math.floor(Math.random() * n); } while (nx === M.cur); }
    else {
      nx = M.cur + 1;
      if (nx >= n) {
        if (M.repeat === 'all' || !auto) nx = 0;
        else { mAu.pause(); mAu.currentTime = 0; return; }
      }
    }
    mPlay(nx);
  }
  function mPrev() {
    var n = M.tracks.length;
    if (!n) return;
    if (mAu.currentTime > 3 || M.cur < 0) { mAu.currentTime = 0; return; }
    mPlay(M.cur <= 0 ? n - 1 : M.cur - 1);
  }
  function mRemove(i) {
    var t = M.tracks[i];
    if (!t) return;
    M.edit = -1;
    if (typeof t.id === 'number') mTx('readwrite', function (st) { return st.delete(t.id); }).catch(function () {});
    try { URL.revokeObjectURL(t.url); } catch (e) {}
    M.tracks.splice(i, 1);
    if (M.cur === i) { mAu.pause(); mAu.removeAttribute('src'); mAu.load(); M.cur = -1; mTime(); }
    else if (M.cur > i) M.cur--;
    mMeta(); mRender();
  }
  function resetMClear() {
    clearTimeout(mClearT);
    var b = $('#mClear'); b.classList.remove('sure'); b.textContent = 'Tout retirer';
  }
  function resetMusic() {
    try { mShStop(); } catch (e) {}
    try { mAu.pause(); mAu.removeAttribute('src'); mAu.load(); } catch (e) {}
    M.tracks.forEach(function (t) { try { URL.revokeObjectURL(t.url); } catch (e) {} });
    M.tracks = []; M.cur = -1; M.loaded = false; M.edit = -1;
    if (mDbP) { mDbP.then(function (db) { db.close(); }, function () {}); mDbP = null; }
    mMeta(); mRender(); mTime();
  }
  /* ---------- musiques partagées : sauvegardées sur Cloudinary, liste dans Firestore (collection « sharedMusic ») ---------- */
  var SH = { pub: {}, mine: {}, unsubs: [] };
  async function mCloudPush(t, file, title, pub) {
    try {
      if (!state.me || navigator.onLine === false || !file) { mMsg('Connecte-toi à internet pour partager.'); return; }
      if (file.size > 40 * 1048576) { mMsg('Fichier trop gros pour le cloud (40 Mo maximum).'); return; }
      var up = file;
      try {
        var nm0 = String(t.name || title || 'musique');
        if (!/\.[a-z0-9]{2,5}$/i.test(nm0)) nm0 += '.mp3';
        up = new File([file], nm0, { type: (file.type && file.type.indexOf('audio/') === 0) ? file.type : 'audio/mpeg' });
      } catch (e0) { up = file; }
      var url = await cloudUp(up, 'video');
      if (!url) { mMsg('Envoi vers le cloud impossible (' + (CLD_ERR || 'erreur') + ').'); return; }
      var data = { uid: state.me, uname: myName() || '', title: String(title || mName(t.name)).slice(0, 100), name: String(t.name || '').slice(0, 120), url: url, size: file.size, ts: Date.now(), pub: !!pub && musicShared() };
      var ref = await fs.collection('sharedMusic').add(data);
      t.cid = ref.id; SH.mine[ref.id] = data;
      if (typeof t.id === 'number') mTx('readwrite', function (st) { var g = st.get(t.id); g.onsuccess = function () { if (g.result) { g.result.cid = ref.id; st.put(g.result); } }; return g; }).catch(function () {});
      mMsg(data.pub ? 'Musique partagée avec tout le monde ☁' : 'Musique sauvegardée sur ton cloud ☁');
    } catch (e) { mMsg('Partage impossible (règles Firestore « sharedMusic » ?).'); }
  }
  /* bouton ☁ de chaque musique : partager / ne plus partager */
  function mCloudBtn(row, t) {
    if (!musicShared() || t.remote || (t.cid && !SH.mine[t.cid])) return;
    var on = !!(t.cid && SH.mine[t.cid] && SH.mine[t.cid].pub === true);
    var c = el('button', 'mcloud' + (on ? ' on' : ''), '☁'); c.type = 'button';
    c.title = on ? 'Partagée : appuie pour ne plus partager' : 'Appuie pour partager cette musique';
    c.setAttribute('aria-label', c.title); c.setAttribute('aria-pressed', on ? 'true' : 'false');
    c.disabled = !!t.up;
    c.addEventListener('click', function (e) { e.stopPropagation(); mShToggle(t); });
    row.appendChild(c);
  }
  async function mShToggle(t) {
    if (t.up || !state.me) return;
    var cur = t.cid && SH.mine[t.cid], want = !(cur && cur.pub === true);
    if (want && !musicShared()) { mMsg('Ton compte n’a pas accès au partage de musiques.'); return; }
    if (navigator.onLine === false) { mMsg('Connecte-toi à internet pour changer le partage.'); return; }
    if (!t.cid) {
      t.up = true; mRender(); mMsg('Envoi de la musique sur le cloud…');
      try { var r = await fetch(t.url), blob = await r.blob(); await mCloudPush(t, blob, mLabel(t), true); }
      catch (e) { mMsg('Envoi impossible.'); }
      t.up = false; mRender(); return;
    }
    try {
      await fs.collection('sharedMusic').doc(t.cid).update({ pub: want });
      if (SH.mine[t.cid]) SH.mine[t.cid].pub = want;
      mMsg(want ? 'Musique partagée avec tout le monde ☁' : 'Musique non partagée (elle reste dans ton cloud).');
    } catch (e) { mMsg('Changement impossible (règles Firestore « sharedMusic » ?).'); }
    mRender();
  }
  function mShStop() { SH.unsubs.forEach(function (u) { try { u(); } catch (e) {} }); SH.unsubs = []; SH.pub = {}; SH.mine = {}; }
  function mShFail() { SH.err = true; try { mShRender(); } catch (e) {} mShMsg('Chargement impossible : les règles Firestore doivent autoriser la lecture de « sharedMusic ».'); }
  function mShStart() {
    mShStop(); SH.err = false;
    if (!state.me) { mShRender(); return; }
    try {
      SH.unsubs.push(fs.collection('sharedMusic').where('uid', '==', state.me).onSnapshot(function (q) { SH.mine = {}; q.forEach(function (d) { SH.mine[d.id] = d.data(); }); mRender(); }, function () { mShFail(); }));
      if (musicShared()) SH.unsubs.push(fs.collection('sharedMusic').where('pub', '==', true).limit(300).onSnapshot(function (q) { SH.pub = {}; q.forEach(function (d) { SH.pub[d.id] = d.data(); }); mRender(); }, function () { mShFail(); }));
    } catch (e) {}
    mShRender();
  }
  window.mShRefresh = function () { if (!viewMusic.hidden) mShStart(); };
  window.addEventListener('online', function () { if (!viewMusic.hidden) mShStart(); });
  window.addEventListener('offline', function () { try { mShRender(); } catch (e) {} });
  function mShMsg(t) { var n = $('#mShMsg'); if (n) { n.textContent = t || ''; setTimeout(function () { if (n.textContent === t) n.textContent = ''; }, 4500); } }
  function mShRender() {
    var box = $('#mShared'), ul = $('#mShList'); if (!box || !ul) return;
    var all = {};
    Object.keys(SH.pub).forEach(function (k) { all[k] = SH.pub[k]; });
    Object.keys(SH.mine).forEach(function (k) { all[k] = SH.mine[k]; });
    var have = {}; M.tracks.forEach(function (t, i) { if (t.cid && !t.remote) have[t.cid] = i; });
    var ids = Object.keys(all).sort(function (a, b) { return (all[b].ts || 0) - (all[a].ts || 0); });
    var online = navigator.onLine !== false;
    if (!online) ids = ids.filter(function (k) { return k in have; });
    var can = musicShared();
    box.hidden = !state.me || (!can && !Object.keys(SH.mine).length);
    $('#mShTitle').textContent = can ? '☁ Musiques partagées' : '☁ Mon cloud';
    ul.replaceChildren();
    if (!ids.length) { var e0 = el('li', 'empty'); e0.appendChild(document.createTextNode(SH.err ? 'Impossible de charger les musiques partagées (règles Firestore « sharedMusic » : autorise la lecture).' : online ? 'Aucune musique partagée pour le moment.' : 'Hors connexion : seules les musiques téléchargées sont disponibles.')); ul.appendChild(e0); return; }
    ids.forEach(function (k) {
      var it = all[k], mine = it.uid === state.me, li = el('li'), row = el('div', 'mrow');
      var b = el('button', 'mname', (mine ? (it.pub === true ? '☁ ' : '🔒 ') : '') + (it.title || it.name || 'Musique') + (mine ? '' : ' · ' + cap(it.uname || '?')));
      b.type = 'button';
      b.addEventListener('click', function () {
        if (k in have) { mPlay(have[k]); return; }
        if (!online) { mShMsg('Hors connexion : télécharge-la d’abord.'); return; }
        var j = -1; M.tracks.forEach(function (t, n) { if (t.remote && t.cid === k) j = n; });
        if (j < 0) { M.tracks.push({ id: 'sh' + k, name: it.name || it.title, title: it.title || '', cid: k, remote: true, url: it.url }); j = M.tracks.length - 1; }
        mPlay(j);
      });
      var dl = el('button', 'mshare', k in have ? '✓' : '⬇'); dl.type = 'button';
      dl.setAttribute('aria-label', k in have ? 'Déjà sur ton appareil' : 'Télécharger sur ton appareil');
      dl.disabled = (k in have) || !online;
      dl.addEventListener('click', function () { mShSave(k, it, dl); });
      row.appendChild(b); row.appendChild(dl);
      if (mine) {
        var rm = el('button', 'mdel', '✕'); rm.type = 'button'; rm.setAttribute('aria-label', 'Retirer du cloud');
        rm.addEventListener('click', function () { if (!confirm('Retirer cette musique du cloud et du partage ? (elle reste sur ton appareil si tu l’as téléchargée)')) return; fs.collection('sharedMusic').doc(k).delete().catch(function () { mShMsg('Suppression impossible.'); }); });
        row.appendChild(rm);
      }
      li.appendChild(row); ul.appendChild(li);
    });
  }
  /* lien de secours : Cloudinary convertit en mp3 à la volée si l'original n'est pas lisible tel quel */
  function mAltUrl(u) { return (typeof u === 'string' && u.indexOf('/upload/') > 0 && u.indexOf('/upload/f_mp3/') < 0) ? u.replace('/upload/', '/upload/f_mp3/') : ''; }
  async function mGetBlob(u) {
    var list = [u], alt = mAltUrl(u); if (alt) list.push(alt);
    for (var i = 0; i < list.length; i++) {
      try { var r = await fetch(list[i]); if (r.ok) { var b = await r.blob(); if (b && b.size > 0) return b; } } catch (e) {}
    }
    return null;
  }
  async function mShSave(k, it, btn) {
    btn.disabled = true; mShMsg('Téléchargement…');
    try {
      var blob = await mGetBlob(it.url); if (!blob) throw new Error('http');
      var ty = blob.type && blob.type.indexOf('audio/') === 0 ? blob.type : 'audio/mpeg';
      var f = blob.type === ty ? blob : blob.slice(0, blob.size, ty), id;
      try { id = await mTx('readwrite', function (st) { return st.add({ name: it.name || (it.title + '.mp3'), title: it.title || '', type: ty, blob: f, cid: k }); }); } catch (e) { id = 'tmp' + Date.now(); }
      var tr = { id: id, name: it.name || it.title, title: it.title || '', cid: k, url: URL.createObjectURL(f) }, j = -1;
      M.tracks.forEach(function (t, n) { if (t.remote && t.cid === k) j = n; });
      if (j >= 0) M.tracks[j] = tr; else M.tracks.push(tr);
      mShMsg('Téléchargée : disponible sans connexion ✓'); mRender();
    } catch (e) { btn.disabled = false; mShMsg('Téléchargement impossible.'); }
  }
  /* ---------- partager une musique dans une discussion (envoyée comme un vocal) ---------- */
  var SHARE_MAX = 120, SHARE_BYTES = 650000;
  function mStatus(t) { clearTimeout(mMsgT); $('#mMsg').textContent = t || ''; if (M.sharing && M.cancelBtn) $('#mMsg').appendChild(M.cancelBtn); }
  function mShareClose() { var s = document.querySelector('.sheetbg'); if (s) s.remove(); }
  function mShareAsk(i) {
    var t = M.tracks[i];
    if (!t || M.sharing) return;
    mShareClose();
    var hid = hiddenChats();
    var chats = state.chats.slice().sort(function (a, b) { return (b.lastTs || 0) - (a.lastTs || 0); })
      .filter(function (c) { return !(hid[c.id] && (c.lastTs || 0) <= hid[c.id]); });
    var bg = el('div', 'sheetbg'), sheet = el('div', 'sheet');
    var pv = new Audio(), pvStop = null, D = 0, st = 0, en = 0;
    function close() { try { pv.pause(); } catch (e) {} clearInterval(pvStop); mShareClose(); }
    sheet.appendChild(el('h3', '', 'Partager « ' + mLabel(t) + ' »'));
    sheet.appendChild(el('p', '', 'Choisis le passage à envoyer (120 s maximum).'));
    var info = el('p', 'trinfo', 'Chargement…');
    var l1 = el('label', 'trlab', 'Début'), r1 = el('input'), v1 = el('span', 'trval', '0:00');
    var l2 = el('label', 'trlab', 'Fin'), r2 = el('input'), v2 = el('span', 'trval', '0:00');
    [r1, r2].forEach(function (r) { r.type = 'range'; r.min = 0; r.max = 1; r.step = 1; r.value = 0; r.disabled = true; });
    r1.setAttribute('aria-label', 'Début de l’extrait'); r2.setAttribute('aria-label', 'Fin de l’extrait');
    l1.appendChild(r1); l1.appendChild(v1); l2.appendChild(r2); l2.appendChild(v2);
    var prev = el('button', 'ghost', '▶ Écouter l’extrait');
    prev.type = 'button'; prev.disabled = true;
    function paint() {
      v1.textContent = fmtDur(st); v2.textContent = fmtDur(en);
      info.textContent = 'Extrait : ' + fmtDur(st) + ' → ' + fmtDur(en) + ' (' + Math.round(en - st) + ' s)';
    }
    r1.addEventListener('input', function () {
      st = +r1.value;
      if (st > en - 1) en = Math.min(D, st + 1);
      if (en - st > SHARE_MAX) en = st + SHARE_MAX;
      r2.value = en; paint();
    });
    r2.addEventListener('input', function () {
      en = +r2.value;
      if (en < st + 1) st = Math.max(0, en - 1);
      if (en - st > SHARE_MAX) st = en - SHARE_MAX;
      r1.value = st; paint();
    });
    prev.addEventListener('click', function () {
      if (!pv.paused) { pv.pause(); clearInterval(pvStop); prev.textContent = '▶ Écouter l’extrait'; return; }
      if (!mAu.paused) mAu.pause();
      pv.currentTime = st;
      pv.play().catch(function () {});
      prev.textContent = '❚❚ Arrêter';
      clearInterval(pvStop);
      pvStop = setInterval(function () {
        if (pv.paused || pv.currentTime >= en) { pv.pause(); clearInterval(pvStop); prev.textContent = '▶ Écouter l’extrait'; }
      }, 100);
    });
    pv.preload = 'metadata'; pv.src = t.url;
    mDuration(t.url).then(function (d) {
      D = Math.floor(d);
      if (!D) { info.textContent = 'Impossible de lire la durée de ce morceau.'; return; }
      st = 0; en = Math.min(D, SHARE_MAX);
      [r1, r2].forEach(function (r) { r.max = D; r.disabled = false; });
      r1.value = st; r2.value = en; prev.disabled = false; paint();
    });
    sheet.appendChild(info); sheet.appendChild(l1); sheet.appendChild(l2); sheet.appendChild(prev);
    sheet.appendChild(el('p', 'trsend', 'Envoyer à :'));
    if (!chats.length) sheet.appendChild(el('p', '', 'Aucune discussion pour l’instant. Écris d’abord à quelqu’un.'));
    chats.forEach(function (c) {
      if (c.group) return;
      var other = (c.members || []).filter(function (x) { return x !== state.me; })[0];
      var name = nickOf(c, other) || (c.names && c.names[other]) || 'Inconnu';
      var b = el('button', 'pick', cap(name));
      b.type = 'button';
      b.addEventListener('click', function () {
        if (!D) return;
        var s0 = st, e0 = en;
        close();
        mShareGo(t, { id: c.id, other: other, name: name }, s0, e0, D);
      });
      sheet.appendChild(b);
    });
    var cn = el('button', 'ghost', 'Annuler');
    cn.type = 'button'; cn.style.marginTop = '10px';
    cn.addEventListener('click', close);
    sheet.appendChild(cn);
    bg.appendChild(sheet);
    bg.addEventListener('click', function (e) { if (e.target === bg) close(); });
    document.body.appendChild(bg);
  }
  function mBlobToUrl(blob) {
    return new Promise(function (ok, ko) {
      var fr = new FileReader();
      fr.onload = function () { ok(String(fr.result)); };
      fr.onerror = function () { ko(fr.error); };
      fr.readAsDataURL(blob);
    });
  }
  function mDuration(url) {
    return new Promise(function (ok) {
      var a = new Audio(); a.preload = 'metadata';
      a.onloadedmetadata = function () { ok(isFinite(a.duration) ? a.duration : 0); };
      a.onerror = function () { ok(0); };
      a.src = url;
    });
  }
  function mCapture(t, start, end) {
    return new Promise(function (ok, ko) {
      var AC = window.AudioContext || window.webkitAudioContext, mime = pickMime();
      if (!AC || mime === null) { ko(new Error('unsupported')); return; }
      var ac = new AC(), au = new Audio(), chunks = [], t0 = 0, timer = null, done = false;
      var opts = { audioBitsPerSecond: 32000 };
      if (mime) opts.mimeType = mime;
      var mr;
      try {
        au.preload = 'auto';
        au.src = t.url;
        var src = ac.createMediaElementSource(au), dest = ac.createMediaStreamDestination();
        var quiet = ac.createGain(); quiet.gain.value = 0;
        src.connect(dest);
        src.connect(quiet); quiet.connect(ac.destination);
        mr = new MediaRecorder(dest.stream, opts);
      } catch (e) { try { ac.close(); } catch (x) {} ko(e); return; }
      var finish = function (cancel) {
        if (done) return; done = true;
        var why = cancel instanceof Error ? cancel : new Error('cancel');
        clearInterval(timer);
        try { au.pause(); } catch (e) {}
        M.shareStop = null;
        mr.onstop = function () {
          try { ac.close(); } catch (e) {}
          if (cancel) { ko(why); return; }
          ok({ blob: new Blob(chunks, { type: mr.mimeType || 'audio/webm' }), dur: (Date.now() - t0) / 1000 });
        };
        try { if (mr.state !== 'inactive') mr.stop(); else mr.onstop(); } catch (e) { mr.onstop(); }
      };
      M.shareStop = finish;
      mr.ondataavailable = function (e) { if (e.data && e.data.size) chunks.push(e.data); };
      au.onended = function () { finish(false); };
      au.onerror = function () { finish(new Error('media:' + (au.error ? au.error.code : '?'))); };
      var seek = function () {
        if (!start) return Promise.resolve();
        return new Promise(function (res) {
          var go = function () { au.addEventListener('seeked', function () { res(); }, { once: true }); au.currentTime = start; };
          if (au.readyState >= 1) go(); else au.addEventListener('loadedmetadata', go, { once: true });
        });
      };
      ac.resume().then(seek).then(function () { return au.play(); }).then(function () {
        t0 = Date.now(); mr.start(1000);
        timer = setInterval(function () {
          var s = au.currentTime - start;
          mStatus('Préparation du partage… ' + fmtDur(Math.max(0, s)) + ' / ' + fmtDur(end - start) + ' ');
          if (au.currentTime >= end || s >= SHARE_MAX) finish(false);
        }, 150);
      }).catch(function (e) { finish(new Error('play:' + ((e && e.name) || 'erreur'))); });
    });
  }
  async function mShareSend(chat, audio, dur, title) {
    var label = '🎵 ' + title.slice(0, 100), orig = audio;
    var upa = await mediaUp(audio); if (upa) audio = upa;
    async function put(val) {
      var chatRef = fs.collection('chats').doc(chat.id), msgRef = chatRef.collection('messages').doc(), ts = Date.now();
      var batch = fs.batch();
      batch.set(msgRef, { uid: state.me, sts: SV(), text: label, ts: ts, audio: val, dur: Math.round(dur), music: title.slice(0, 100) });
      var last = { lastText: label, lastTs: ts, lastUid: state.me };
      last['seen.' + state.me] = ts;
      batch.update(chatRef, last);
      await batch.commit();
    }
    try { await put(audio); }
    catch (e) { if (e && e.code === 'permission-denied' && audio !== orig) await put(orig); else throw e; }
  }
  async function mShareGo(t, chat, start, end, total) {
    if (M.sharing) return;
    M.sharing = true; mRender();
    var cancelBtn = el('button', 'ghost', 'Annuler');
    cancelBtn.type = 'button';
    cancelBtn.addEventListener('click', function () { if (M.shareStop) M.shareStop(true); else M.shareAbort = true; });
    M.cancelBtn = cancelBtn;
    var failMsg = '';
    try {
      mStatus('Préparation du partage…');
      var blob = null, dur = 0, raw = null;
      var whole = !start && end >= total;
      if (whole) { try { raw = await (await fetch(t.url)).blob(); } catch (e) {} }
      if (raw && raw.size <= SHARE_BYTES) { blob = raw; dur = await mDuration(t.url); }
      else {
        if (!mAu.paused) mAu.pause();
        var r = await mCapture(t, start || 0, end);
        blob = r.blob; dur = r.dur;
      }
      if (M.shareAbort) throw new Error('cancel');
      if (!blob || !blob.size) throw new Error('empty');
      if (blob.size > SHARE_BYTES) throw new Error('big');
      var data = await mBlobToUrl(blob);
      if (data.length > 900000) throw new Error('big');
      await mShareSend(chat, data, dur || 1, mLabel(t));
      mStatus('Envoyée à ' + cap(chat.name) + ' ✓');
      mMsgT = setTimeout(function () { $('#mMsg').textContent = ''; }, 4500);
    } catch (e) {
      var em = (e && e.message) || '';
      failMsg = em === 'cancel' ? 'Partage annulé.'
        : em === 'unsupported' ? 'Ton navigateur ne permet pas ce partage.'
        : em.indexOf('play:') === 0 ? 'Lecture bloquée par le navigateur (' + em.slice(5) + '). Touche d’abord ▶ sur un morceau puis réessaie.'
        : em.indexOf('media:') === 0 ? 'Ce fichier audio ne peut pas être lu pour le partage (code ' + em.slice(6) + ').'
        : 'Partage impossible. Vérifie ta connexion (ou les règles Firestore) et réessaie.';
    }
    M.sharing = false; M.shareAbort = false; M.shareStop = null; M.cancelBtn = null; mRender();
    if (failMsg) mMsg(failMsg);
  }
