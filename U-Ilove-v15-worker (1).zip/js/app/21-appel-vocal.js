/* U&I — js/app/21-appel-vocal.js
   Appel vocal 1-à-1 (WebRTC)
   (fait partie de l’appli : assemblée par js/boot/loader.js dans une seule fermeture) */
  /* ---------- appel vocal 1-à-1 (WebRTC, signalisation via Firestore) ---------- */
  var C = { role: null, chat: null, sid: '', pc: null, stream: null, rem: null, pend: [], sigUnsub: null, st: '', t0: 0,
            tickT: null, ringT: null, discT: null, tone: null, toneI: null, muted: false, ui: null, seen: {}, needTap: false,
            dbg: { off: 0, ans: 0, ice: 0, h: 0, s: 0, r: 0, ic: '-' } };
  function callWhy(base) { return base + (C.dbg.r === 0 ? ' · aucun relais TURN joignable (identifiants à renouveler)' : ''); }
  var CALL_PHONE = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6.6 10.8a15.1 15.1 0 006.6 6.6l2.2-2.2a1 1 0 011-.25 11.4 11.4 0 003.6.57 1 1 0 011 1V20a1 1 0 01-1 1A17 17 0 013 4a1 1 0 011-1h3.5a1 1 0 011 1c0 1.25.2 2.45.57 3.57a1 1 0 01-.25 1z"/></svg>';
  var CALL_MIC = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 14a3 3 0 003-3V5a3 3 0 00-6 0v6a3 3 0 003 3zm5-3a5 5 0 01-10 0H5a7 7 0 006 6.92V21h2v-3.08A7 7 0 0019 11z"/></svg>';
  var CALL_MUTE = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M19 11h-2c0 .9-.2 1.7-.55 2.4l1.46 1.46A6.9 6.9 0 0019 11zm-4 .17V5a3 3 0 00-5.9-.75L15 11.17zM4.27 3L3 4.27l6 6V11a3 3 0 004.1 2.8l1.7 1.7A5 5 0 017 11H5a7 7 0 006 6.92V21h2v-3.08c.9-.12 1.75-.43 2.5-.87L19.73 21 21 19.73 4.27 3z"/></svg>';

  var CALL_SPK = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 9v6h4l5 5V4L7 9H3zm13.5 3c0-1.77-1.02-3.29-2.5-4.03v8.05c1.48-.73 2.5-2.25 2.5-4.02zM14 3.23v2.06c2.89.86 5 3.54 5 6.71s-2.11 5.85-5 6.71v2.06c4.01-.91 7-4.49 7-8.77s-2.99-7.86-7-8.77z"/></svg>';
  var CALL_EAR = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M7 9v6h4l5 5V4l-5 5H7z"/></svg>';
  var EAR_RE = /earpiece|ear piece|receiver|handset|écouteur|ecouteur|combiné|combine/i, SPK_RE = /speaker|haut-parleur|haut parleur|loud/i;
  function callSpk() { return store('uandi-spk') === '1'; }
  function callRouteNote() {}
  /* sortie du son de l'appel : écouteur (discret) ou haut-parleur */
  function callRoute() {
    var a = C.rem, spk = !!C.speaker;
    try { if (navigator.audioSession) navigator.audioSession.type = 'play-and-record'; } catch (e) {}
    if (!a) return;
    if (!a.setSinkId || !navigator.mediaDevices || !navigator.mediaDevices.enumerateDevices) {
      callRouteNote('Ton navigateur ne permet pas de choisir la sortie audio : le son suit le réglage du téléphone.');
      return;
    }
    navigator.mediaDevices.enumerateDevices().then(function (ds) {
      var outs = ds.filter(function (d) { return d.kind === 'audiooutput'; }), pick = null, i;
      for (i = 0; i < outs.length && !pick; i++) {
        var lb = outs[i].label || '';
        if (spk ? SPK_RE.test(lb) : (EAR_RE.test(lb) && !SPK_RE.test(lb))) pick = outs[i];
      }
      if (!pick && !spk) for (i = 0; i < outs.length && !pick; i++) if (outs[i].deviceId === 'communications') pick = outs[i];
      if (!pick && spk) for (i = 0; i < outs.length && !pick; i++) if (outs[i].deviceId === 'default') pick = outs[i];
      if (!pick) {
        callRouteNote(spk ? '' : 'Écouteur introuvable sur cet appareil : branche un casque ou baisse le volume pour plus de discrétion.');
        return a.setSinkId('').catch(function () {});
      }
      return a.setSinkId(pick.deviceId).then(function () { callRouteNote(''); });
    }).catch(function () { callRouteNote('Impossible de changer la sortie audio sur ce navigateur.'); });
  }
  if (navigator.mediaDevices && navigator.mediaDevices.addEventListener) navigator.mediaDevices.addEventListener('devicechange', function () { if (C.role && C.rem) callRoute(); });

  function callRef(id) { return fs.collection('chats').doc(id); }
  function callDur(sec) {
    var m = Math.floor(sec / 60), r = sec % 60;
    return m + ':' + (r < 10 ? '0' : '') + r;
  }
  function callDurText(sec) {
    var m = Math.floor(sec / 60), r = sec % 60;
    return m ? m + ' min' + (r ? ' ' + r + ' s' : '') : r + ' s';
  }
  /* sonnerie (générée, aucun fichier) */
  function ringStop() {
    clearInterval(C.toneI); C.toneI = null;
    if (C.tone) { try { C.tone.close(); } catch (e) {} C.tone = null; }
    if (navigator.vibrate) { try { navigator.vibrate(0); } catch (e) {} }
  }
  function ringStart(incoming) {
    ringStop();
    try {
      var AC = window.AudioContext || window.webkitAudioContext, ac = new AC();
      C.tone = ac;
      var beep = function () {
        try {
          if (ac.state === 'suspended') ac.resume().catch(function () {});
          var o = ac.createOscillator(), g = ac.createGain(), t = ac.currentTime;
          o.type = 'sine'; o.frequency.value = incoming ? 880 : 425;
          o.connect(g); g.connect(ac.destination);
          g.gain.setValueAtTime(0.0001, t);
          g.gain.exponentialRampToValueAtTime(incoming ? 0.3 : 0.15, t + 0.05);
          g.gain.exponentialRampToValueAtTime(0.0001, t + 0.7);
          o.start(t); o.stop(t + 0.75);
          if (incoming && navigator.vibrate) navigator.vibrate([350, 150, 350]);
        } catch (e) {}
      };
      beep(); C.toneI = setInterval(beep, 2200);
    } catch (e) {}
  }
  /* notification média « Appel vocal » : aide le navigateur à garder l'appel actif écran éteint */
  function callMedia(on) {
    try {
      if (!('mediaSession' in navigator) || typeof MediaMetadata === 'undefined') return;
      if (on) {
        navigator.mediaSession.metadata = new MediaMetadata({ title: 'Appel vocal', artist: cap(C.chat.name) });
        navigator.mediaSession.playbackState = 'playing';
        try { navigator.mediaSession.setActionHandler('hangup', function () { callFinish('hang'); }); } catch (e) {}
      } else {
        try { navigator.mediaSession.setActionHandler('hangup', null); } catch (e) {}
        mMeta();
        navigator.mediaSession.playbackState = mAu.paused ? 'paused' : 'playing';
      }
    } catch (e) {}
  }
  function callWake(on) {
    try {
      if (!on) { if (C.wake) { C.wake.release(); C.wake = null; } return; }
      if (navigator.wakeLock && !C.wake) navigator.wakeLock.request('screen').then(function (w) { C.wake = w; w.addEventListener('release', function () { if (C.wake === w) C.wake = null; }); }).catch(function () {});
    } catch (e) {}
  }
  document.addEventListener('visibilitychange', function () { if (!document.hidden && C.role && C.st === 'live') callWake(true); });
  function callUi() {
    var role = C.role;
    if (!role) return;
    if (!C.ui) {
      var ui = el('div', 'callui');
      ui.setAttribute('role', 'dialog'); ui.setAttribute('aria-modal', 'true'); ui.setAttribute('aria-label', 'Appel vocal');
      document.body.appendChild(ui);
      C.ui = ui;
    }
    var ui2 = C.ui, other = C.chat.other, name = cap(C.chat.name);
    ui2.className = 'callui' + (C.st === 'ring' ? ' ringing' : '');
    ui2.replaceChildren();
    var who = el('div', 'cwho'), av = el('span', 'avatar');
    paintPhoto(av, other, C.chat.name); loadPhoto(other);
    who.appendChild(av);
    who.appendChild(el('div', 'cname', name));
    var st = el('div', 'cst'); st.id = 'callSt'; st.setAttribute('aria-live', 'polite');
    who.appendChild(st);
        var dbgE = el('div', 'cdbg'); dbgE.id = 'callDbg'; who.appendChild(dbgE);
    ui2.appendChild(who);
    var row = el('div', 'cbtns');
    var mk = function (cls, svg, label, fn) {
      var w = el('div', 'cbw'), b = el('button', 'cb ' + cls); b.type = 'button'; b.innerHTML = svg; b.setAttribute('aria-label', label);
      b.addEventListener('click', fn); w.appendChild(b); w.appendChild(el('span', '', label)); row.appendChild(w); return b;
    };
    if (role === 'callee' && C.st === 'ring') {
      mk('end', CALL_PHONE, 'Refuser', function () { callFinish('declined'); });
      mk('ok', CALL_PHONE, 'Décrocher', function () { callAccept(); });
    } else {
      var mb = mk('', C.muted ? CALL_MUTE : CALL_MIC, C.muted ? 'Micro coupé' : 'Micro', function () {
        C.muted = !C.muted;
        if (C.stream) C.stream.getAudioTracks().forEach(function (t) { t.enabled = !C.muted; });
        callUi();
      });
      if (C.muted) mb.classList.add('on');
      var sb = mk('', C.speaker ? CALL_SPK : CALL_EAR, C.speaker ? 'Haut-parleur' : 'Écouteur', function () {
        C.speaker = !C.speaker; store('uandi-spk', C.speaker ? '1' : '0');
        callRouteNote(''); callRoute(); callUi();
      });
      if (C.speaker) sb.classList.add('on');
      mk('end', CALL_PHONE, 'Raccrocher', function () { callFinish('hang'); });
    }
    ui2.appendChild(row);
    callStatus();
  }
  function callStatus(txt) {
    var e = document.getElementById('callSt'), g = document.getElementById('callDbg');
    if (g) g.textContent = C.st === 'live' ? '' : 'offre ' + (C.dbg.off ? '✓' : '…') + ' · réponse ' + (C.dbg.ans ? '✓' : '…') + ' · ice reçus ' + C.dbg.ice + ' · ICE ' + C.dbg.ic + ' · candidats h' + C.dbg.h + ' s' + C.dbg.s + ' r' + C.dbg.r + (C.dbg.err ? ' · erreur ' + C.dbg.err : '') + ' · envoyés ' + (C.dbg.sent || 0) + (C.dbg.werr ? ' ✗ ' + C.dbg.werr : '');
    if (!e) return;
    if (txt) { e.textContent = txt; return; }
    if (C.st === 'ring') e.textContent = C.role === 'caller' ? 'Ça sonne…' : 'Appel vocal entrant…';
    else if (C.st === 'conn') e.textContent = 'Connexion…';
    else if (C.st === 'lost') e.textContent = 'Connexion instable…';
    else if (C.st === 'live') e.textContent = (C.needTap ? 'Touche pour activer le son · ' : '') + callDur(Math.max(0, Math.round((Date.now() - C.t0) / 1000)));
  }
  function callPc() {
    if (C.pc) { try { C.pc.close(); } catch (e) {} }
    var pc = new RTCPeerConnection(ICE);
    C.pc = pc;
    pc.onicecandidate = function (e) {
      if (!e.candidate || C.pc !== pc) return;
      var m = / typ (host|srflx|relay)/.exec(e.candidate.candidate || '');
      if (m) C.dbg[m[1] === 'host' ? 'h' : m[1] === 'srflx' ? 's' : 'r']++;
      callStatus();
      callSig('cice', { data: JSON.stringify(e.candidate) });
    };
    pc.onicecandidateerror = function (e) { if (C.pc === pc && e && e.errorCode) { C.dbg.err = e.errorCode + (e.url ? ' ' + String(e.url).replace(/^(turns?|stuns?):/, '$1:').slice(0, 40) : ''); callStatus(); } };
    pc.oniceconnectionstatechange = function () { if (C.pc === pc) { C.dbg.ic = pc.iceConnectionState; callStatus(); } };
    pc.ontrack = function (ev) {
      if (!C.rem) { C.rem = new Audio(); C.rem.autoplay = true; }
      C.rem.srcObject = ev.streams && ev.streams[0] ? ev.streams[0] : new MediaStream([ev.track]);
      C.rem.play().then(function () { C.needTap = false; }).catch(function () { C.needTap = true; callStatus(); });
      callRoute();
    };
    pc.onconnectionstatechange = function () {
      if (C.pc !== pc) return;
      var s = pc.connectionState;
      if (s === 'connected') {
        clearTimeout(C.discT); clearTimeout(C.ringT);
        if (C.st !== 'live') {
          C.st = 'live'; C.t0 = Date.now(); ringStop(); callWake(true); callMedia(true);
          if (C.ui) C.ui.classList.remove('ringing');
          clearInterval(C.tickT); C.tickT = setInterval(callStatus, 1000);
        } else C.st = 'live';
        callStatus();
      } else if (s === 'disconnected') {
        if (C.st === 'live') { C.st = 'lost'; callStatus(); }
        clearTimeout(C.discT);
        C.discT = setTimeout(function () { if (C.pc === pc && C.st !== 'live') callFinish('ended', 'Appel coupé : connexion perdue'); }, 60000);
      } else if (s === 'failed') {
        callFinish('ended', callWhy('Connexion échouée'));
      }
    };
    return pc;
  }
  function callSig(kind, extra) {
    if (!C.chat) return Promise.resolve();
    var d = { sid: C.sid, jid: '', from: state.me, kind: kind, ts: Date.now() };
    for (var k in extra) d[k] = extra[k];
    C.dbg.sent = (C.dbg.sent || 0) + 1;
    return liveCol(C.chat.id).add(d).catch(function (e) { C.dbg.werr = kind + ':' + ((e && e.code) || 'erreur'); callStatus(); });
  }
  function callIce(c) {
    if (C.pc && C.pc.remoteDescription) C.pc.addIceCandidate(c).catch(function () {}); else C.pend.push(c);
  }
  function callFlush() {
    var pc = C.pc;
    C.pend.splice(0).forEach(function (c) { if (pc) pc.addIceCandidate(c).catch(function () {}); });
  }
  async function callSignal(d) {
    try {
      if (d.kind === 'cice') { C.dbg.ice++; callStatus(); callIce(JSON.parse(d.data)); return; }
      if (d.kind === 'canswer' && C.role === 'caller' && C.pc) {
        C.dbg.ans = 1; callStatus();
        await C.pc.setRemoteDescription(JSON.parse(d.data)); callFlush();
      } else if (d.kind === 'coffer' && C.role === 'callee' && C.pc) {
        C.dbg.off = 1; callStatus();
        await C.pc.setRemoteDescription(JSON.parse(d.data)); callFlush();
        var ans = await C.pc.createAnswer();
        await C.pc.setLocalDescription(ans);
        C.dbg.ans = 1; callStatus();
        callSig('canswer', { data: JSON.stringify({ type: ans.type, sdp: ans.sdp }) });
      }
    } catch (e) {}
  }
  function callListenSig() {
    var sid = C.sid, seen = {};
    C.sigUnsub = liveCol(C.chat.id).where('sid', '==', sid).onSnapshot(function (snap) {
      snap.docChanges().forEach(function (ch) {
        if (ch.type !== 'added' || seen[ch.doc.id] || C.sid !== sid) return;
        seen[ch.doc.id] = 1;
        var d = ch.doc.data();
        if (d && d.from !== state.me && /^c/.test(d.kind || '')) callSignal(d);
      });
    }, function () { showErr('Appel impossible (règles Firestore : autorise « liveSig »).'); callFinish('ended'); });
  }
  async function callEnsure(chat) {
    var ref = callRef(chat.id);
    if (state.chatsById[chat.id]) return ref;
    var snap = await ref.get();
    if (snap.exists) return ref;
    var names = {}; names[state.me] = myName(); names[chat.other] = chat.name;
    var seen = {}; seen[state.me] = Date.now();
    await ref.set({ members: [state.me, chat.other], names: names, lastText: '📞 Appel vocal', lastTs: Date.now(), lastUid: state.me, seen: seen });
    return ref;
  }
  async function callStart(chat) {
    if (C.role) return;
    if (!window.RTCPeerConnection || !navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) { showErr('Ton navigateur ne permet pas les appels vocaux.'); return; }
    var stream;
    try { stream = await getMic({ audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true } }); }
    catch (e) { showErr('Micro inaccessible : autorise le micro pour passer un appel. ' + MIC_HELP); return; }
    if (C.role) { stream.getTracks().forEach(function (t) { t.stop(); }); return; }
    C.dbg = { off: 0, ans: 0, ice: 0, h: 0, s: 0, r: 0, ic: '-' };
    C.speaker = callSpk(); C.routeMsg = '';
    C.role = 'caller'; C.chat = chat; C.sid = liveId(); C.stream = stream; C.pend = []; C.st = 'ring'; C.muted = false; C.needTap = false; C.t0 = 0;
    callUi(); ringStart(false);
    var sid = C.sid;
    try {
      var ref = await callEnsure(chat);
      var pc = callPc();
      stream.getTracks().forEach(function (t) { pc.addTrack(t, stream); });
      callListenSig();
      var off = await pc.createOffer();
      await pc.setLocalDescription(off);
      C.dbg.off = 1;
      await liveCol(chat.id).add({ sid: sid, jid: '', from: state.me, kind: 'coffer', ts: Date.now(), data: JSON.stringify({ type: off.type, sdp: off.sdp }) });
      await ref.update({ call: { sid: sid, from: state.me, to: chat.other, ts: Date.now(), st: 'ring' } });
    } catch (e) {
      if (C.sid === sid) { showErr('Appel impossible (' + ((e && (e.code || e.message)) || 'erreur') + ') : vérifie les règles Firestore de « chats ».'); callClose(); }
      return;
    }
    C.ringT = setTimeout(function () { if (C.sid === sid && C.role === 'caller' && C.st === 'ring') callFinish('missed'); }, 45000);
  }
  async function callAccept() {
    if (C.role !== 'callee' || C.st !== 'ring') return;
    var sid = C.sid, chat = C.chat;
    C.st = 'conn'; ringStop(); callUi();
    var stream;
    try { stream = await getMic({ audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true } }); }
    catch (e) {
      if (C.sid === sid && C.role === 'callee') { C.st = 'ring'; ringStart(true); callUi(); callStatus('Micro bloqué : ferme les bulles et fenêtres flottantes, puis appuie sur Répondre'); }
      showErr('Micro inaccessible : impossible de répondre pour l’instant. ' + MIC_HELP + ' Tu peux appuyer de nouveau sur Répondre.');
      return;
    }
    if (C.sid !== sid || C.role !== 'callee') { stream.getTracks().forEach(function (t) { t.stop(); }); return; }
    C.stream = stream;
    try {
      await fs.runTransaction(function (tx) {
        var r = callRef(chat.id);
        return tx.get(r).then(function (d) {
          var k = d.exists && d.data().call;
          if (!k || k.sid !== sid || k.st !== 'ring') throw new Error('gone');
          tx.update(r, { 'call.st': 'on', 'call.ts': Date.now() });
        });
      });
    } catch (e) { if (C.sid === sid) callClose('Appel terminé'); return; }
    if (C.sid !== sid) return;
    var pc = callPc();
    stream.getTracks().forEach(function (t) { pc.addTrack(t, stream); });
    callListenSig();
    C.ringT = setTimeout(function () { if (C.sid === sid && C.st === 'conn') callFinish('ended', callWhy('Connexion impossible')); }, 25000);
  }
  /* l'autre personne a changé l'état de l'appel */
  function callSync(k) {
    if (!C.role || k.sid !== C.sid) return;
    if (k.st === 'on' && C.role === 'caller' && C.st === 'ring') {
      C.st = 'conn'; clearTimeout(C.ringT); ringStop(); if (C.ui) C.ui.classList.remove('ringing'); callStatus();
      var sid = C.sid;
      C.ringT = setTimeout(function () { if (C.sid === sid && C.st === 'conn') callFinish('ended', callWhy('Connexion impossible')); }, 25000);
    } else if (k.st === 'declined' && C.role === 'caller') {
      var ch = C.chat; callClose('Appel refusé'); liveNotice(ch, '📞 Appel refusé');
    } else if (k.st === 'ended' || k.st === 'cancelled' || k.st === 'missed' || k.st === 'declined') {
      callClose(C.st === 'ring' ? 'Appel manqué' : 'Appel terminé');
    }
  }
  function callWatch(list) {
    if (!state.me) return;
    list.forEach(function (c) {
      var k = c.call;
      if (!k || !k.sid) return;
      if (C.role && C.sid === k.sid) { callSync(k); return; }
      if (k.st === 'ring' && k.from !== state.me && !C.seen[k.sid] && Math.abs(Date.now() - (k.ts || 0)) < 60000) {
        C.seen[k.sid] = 1;
        if (C.role) { callRef(c.id).update({ 'call.st': 'declined' }).catch(function () {}); return; }
        callIncoming(c, k);
      }
    });
  }
  function callIncoming(c, k) {
    C.dbg = { off: 0, ans: 0, ice: 0, h: 0, s: 0, r: 0, ic: '-' };
    C.speaker = callSpk(); C.routeMsg = '';
    C.role = 'callee'; C.sid = k.sid; C.st = 'ring'; C.muted = false; C.needTap = false; C.t0 = 0; C.pend = [];
    C.chat = { id: c.id, other: k.from, name: nickOf(c, k.from) || (c.names && c.names[k.from]) || 'Appel' };
    callUi(); ringStart(true);
    var sid = k.sid;
    C.ringT = setTimeout(function () { if (C.sid === sid && C.role === 'callee' && C.st === 'ring') callClose('Appel manqué'); }, 50000);
  }
  /* nous terminons l'appel : st = 'hang' | 'declined' | 'missed' | 'ended' */
  function callFinish(st, why) {
    if (!C.role) return;
    var chat = C.chat, sid = C.sid, role = C.role, was = C.st;
    var dur = C.t0 ? Math.round((Date.now() - C.t0) / 1000) : 0;
    if (st === 'hang') st = (was === 'live' || was === 'lost') ? 'ended' : (role === 'caller' ? 'cancelled' : 'declined');
    callRef(chat.id).update({ call: { sid: sid, from: role === 'caller' ? state.me : chat.other, to: role === 'caller' ? chat.other : state.me, ts: Date.now(), st: st, dur: dur, by: state.me } }).catch(function () {});
    if (st === 'ended' && dur > 0) liveNotice(chat, '📞 Appel vocal · ' + callDurText(dur));
    else if (role === 'caller' && (st === 'cancelled' || st === 'missed')) liveNotice(chat, '📞 Appel manqué');
    callClose(why || (st === 'ended' ? 'Appel terminé' : ''), why ? 10000 : 1600);
  }
  function callClose(msg, ms) {
    var chat = C.chat, sid = C.sid, role = C.role, ui = C.ui;
    clearTimeout(C.ringT); clearTimeout(C.discT); clearInterval(C.tickT);
    ringStop(); callWake(false); if (role) callMedia(false);
    if (C.sigUnsub) { try { C.sigUnsub(); } catch (e) {} }
    if (C.pc) { try { C.pc.close(); } catch (e) {} }
    if (C.stream) C.stream.getTracks().forEach(function (t) { try { t.stop(); } catch (e) {} });
    if (C.rem) { try { C.rem.pause(); C.rem.srcObject = null; } catch (e) {} }
    C.role = null; C.chat = null; C.sid = ''; C.pc = null; C.stream = null; C.rem = null; C.sigUnsub = null; C.pend = [];
    C.st = ''; C.t0 = 0; C.ui = null; C.needTap = false;
    if (role === 'caller' && chat) {
      liveCol(chat.id).where('sid', '==', sid).get().then(function (sn) {
        var b = fs.batch(); sn.forEach(function (d) { b.delete(d.ref); }); return b.commit();
      }).catch(function () {});
    }
    if (ui) {
      if (msg) {
        var e = ui.querySelector('#callSt'); if (e) e.textContent = msg;
        ui.className = 'callui'; var bt = ui.querySelector('.cbtns'); if (bt) bt.remove();
        setTimeout(function () { ui.remove(); }, ms || 1600);
      } else ui.remove();
    }
  }
  $('#callBtn').addEventListener('click', function () {
    var c = state.chat;
    if (c && !c.group) callStart({ id: c.id, other: c.other, name: c.name });
  });
  document.addEventListener('click', function (e) {
    if (C.needTap && C.rem && e.target.closest && e.target.closest('.callui')) C.rem.play().then(function () { C.needTap = false; callStatus(); }).catch(function () {});
  });
  window.addEventListener('pagehide', function () {
    if (C.role && C.chat) { try { callRef(C.chat.id).update({ 'call.st': C.role === 'caller' && C.st === 'ring' ? 'cancelled' : 'ended' }); } catch (e) {} }
  });

