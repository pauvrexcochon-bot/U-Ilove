/* U&I — js/app/27-push.js
   Notifications push (FCM via le Worker ui-push)
   (fait partie de l’appli : assemblée par js/boot/loader.js dans une seule fermeture) */
  /* ---------- notifications push (FCM via le Worker « ui-push ») ---------- */
  var PUSH = { url: ((CFG.push || {}).workerUrl || '').replace(/\/+$/, ''), key: (CFG.push || {}).vapidKey || '', token: null };
  if (PUSH.url.indexOf('COLLE') !== -1) PUSH.url = '';
  function pushCall(path, body) {
    return auth.currentUser.getIdToken().then(function (tok) {
      return fetch(PUSH.url + path, { method: 'POST', headers: { Authorization: 'Bearer ' + tok, 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    });
  }
  function pushLoadMsg() {
    if (window.firebase && firebase.messaging) return Promise.resolve(true);
    return new Promise(function (ok) {
      var s = document.createElement('script');
      s.src = 'https://www.gstatic.com/firebasejs/10.12.2/firebase-messaging-compat.js';
      s.onload = function () { ok(true); }; s.onerror = function () { ok(false); };
      setTimeout(function () { ok(false); }, 10000);
      document.head.appendChild(s);
    });
  }
  async function pushSetup() {
    PUSH.err = '';
    try {
      if (!PUSH.url || !PUSH.key) { PUSH.err = 'adresse du Worker ou clé VAPID manquante'; return; }
      if (!auth.currentUser) { PUSH.err = 'pas connecté'; return; }
      if (!('serviceWorker' in navigator) || !('Notification' in window)) { PUSH.err = 'navigateur sans notifications (ouvre dans Chrome / appli installée)'; return; }
      if (Notification.permission !== 'granted') { PUSH.err = 'permission notifications = ' + Notification.permission + ' (à autoriser dans les réglages du site)'; return; }
      if (!(await pushLoadMsg()) || !firebase.messaging.isSupported || !(await firebase.messaging.isSupported())) { PUSH.err = 'Firebase Messaging indisponible'; return; }
      var reg = await navigator.serviceWorker.register('firebase-messaging-sw.js');
      await navigator.serviceWorker.ready;
      var t = await firebase.messaging().getToken({ vapidKey: PUSH.key, serviceWorkerRegistration: reg });
      if (!t) { PUSH.err = 'jeton FCM vide'; return; }
      var r = await pushCall('/register', { token: t });
      if (!r.ok) { PUSH.err = 'le Worker a refusé l’enregistrement (HTTP ' + r.status + ')'; return; }
      PUSH.token = t;
    } catch (e) { PUSH.err = (e && (e.code || e.message)) || String(e); }
    finally { try { npPaint(); } catch (e2) {} }
  }
  function pushReport() {
    try { showToast(null, 'U&I', (PUSH.token ? 'Push OK ✅ jeton enregistré' : 'Push KO ❌ ' + PUSH.err) + (PUSH.lastSend ? ' · dernier envoi : ' + PUSH.lastSend : '')); } catch (e) {}
  }
  if ('serviceWorker' in navigator) navigator.serviceWorker.register('firebase-messaging-sw.js').catch(function () {});
  function pushUnreg() {
    if (!PUSH.token || !auth.currentUser) return Promise.resolve();
    var t = PUSH.token; PUSH.token = null;
    return Promise.race([pushCall('/unregister', { token: t }), new Promise(function (ok) { setTimeout(ok, 2500); })]).catch(function () {});
  }
  function pushNotify(chat, text) {
    try {
      if (!PUSH.url || !chat) return;
      var c = chatOf(chat.id) || {};
      var to = (c.members || [state.me, chat.other]).filter(function (u) { return u && u !== state.me; });
      if (!to.length) return;
      pushCall('/notify', { to: to, title: NOTIF_TITLE, body: cap(myName()) + ' : ' + text, chat: chat.id }).then(function (r) { PUSH.lastSend = 'message HTTP ' + r.status; }).catch(function (e) { PUSH.lastSend = 'message erreur ' + ((e && (e.code || e.message)) || e); });
    } catch (e) {}
  }
  function pushNews(text) {
    try {
      if (!PUSH.url || !auth.currentUser) return;
      fs.collection('usernames').get().then(function (sn) {
        var to = []; sn.forEach(function (d) { var v = d.data(); if (v && typeof v.uid === 'string' && v.uid !== state.me) to.push(v.uid); });
        if (!to.length) return;
        return pushCall('/notify', { to: to, title: 'U&I \uD83D\uDCF0', body: 'Nouvelle lettre dans l\u2019actualit\u00e9 : ' + String(text || '').slice(0, 80), chat: 'news' })
          .then(function (r) { PUSH.lastSend = 'actualit\u00e9 HTTP ' + r.status; });
      }).catch(function (e) { PUSH.lastSend = 'actualit\u00e9 erreur ' + ((e && (e.code || e.message)) || e); });
    } catch (e) {}
  }
  auth.onAuthStateChanged(function (user) {
    AUTH_SEEN = true;
    if (user) setTimeout(pushSetup, 3000);
    try { sessionStorage.removeItem('uandi-authretry'); } catch (e) {}
    if (user) {
      approvalGate(user);
    } else {
      apStop();
      stopSession();
      appEl.hidden = true;
      loginEl.hidden = false;
      $('#p').value = ''; $('#p2').value = '';
      document.title = BASE_TITLE;
    }
  });
