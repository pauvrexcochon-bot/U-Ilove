/* U&I — js/app/26-session-approbation.js
   Installation (PWA), session, approbation des nouveaux comptes
   (fait partie de l’appli : assemblée par js/boot/loader.js dans une seule fermeture) */
  /* ---------- installation de l'appli (PWA) ---------- */
  var installEv = null;
  window.addEventListener('beforeinstallprompt', function (e) {
    e.preventDefault();
    installEv = e;
    $('#installSec').hidden = false;
  });
  window.addEventListener('appinstalled', function () {
    installEv = null;
    $('#installSec').hidden = true;
  });
  var isStandalone = false; try { isStandalone = window.matchMedia('(display-mode: standalone)').matches || navigator.standalone === true; } catch (e) {}
  if (!isStandalone) $('#installSec').hidden = false;
  $('#installBtn').addEventListener('click', function () {
    var ev = installEv;
    if (!ev) {
      var ios = /iphone|ipad|ipod/i.test(navigator.userAgent);
      alert(ios ? 'Sur iPhone : touche le bouton Partager de Safari, puis « Sur l’écran d’accueil ».' : 'Ouvre le menu ⋮ de ton navigateur puis « Installer l’application » (ou « Ajouter à l’écran d’accueil »).');
      return;
    }
    ev.prompt();
    ev.userChoice.then(function () {}, function () {}).then(function () {
      installEv = null;
    });
  });

  /* ---------- session ---------- */
  async function ensureDirectory(uid, username) {
    try {
      var ref = fs.collection('usernames').doc(username);
      var s = await ref.get();
      if (!s.exists) await ref.set({ uid: uid });
    } catch (e) {}
  }

  function startSession(user) {
    stopSession();
    state.me = user.uid;
    state.deleting = false;
    state.username = String(user.email || '').split('@')[0];
    state.nick = ''; state.nickAt = 0;
    try { var nk = JSON.parse(store('uandi-nick-' + user.uid) || 'null'); if (nk) { state.nick = String(nk.n || ''); state.nickAt = +nk.t || 0; } } catch (e) {}
    state.chats = []; state.chatsById = {}; state.chatsLoaded = false; knownTs = {};
    loginEl.hidden = true;
    appEl.hidden = false;
    state.view = 'list';
    viewChat.hidden = true;
    viewList.hidden = false;
    renderList();
    ensureDirectory(user.uid, state.username);
    lkCheck();

    unsubChats = fs.collection('chats').where('members', 'array-contains', state.me).onSnapshot(function (snap) {
      var byId = {};
      var firstSnap = !state.chatsLoaded;
      snap.docChanges().forEach(function (ch) {
        if (ch.type === 'removed') return;
        var v = ch.doc.data(), id = ch.doc.id, prev = knownTs[id] || 0;
        knownTs[id] = v.lastTs || 0;
        if (firstSnap || !v.lastUid || v.lastUid === state.me || !(v.lastTs > prev)) return;
        if (((v.seen && v.seen[state.me]) || 0) >= v.lastTs) return;
        if (state.chat && state.chat.id === id) return;
        incomingElsewhere(id, v);
      });
      state.chats = snap.docs.map(function (d) {
        var v = d.data(); v.id = d.id; byId[d.id] = true; return v;
      });
      state.chatsById = byId;
      state.chatsLoaded = true;
      if (PENDING_CHAT && openChatById(PENDING_CHAT)) { PENDING_CHAT = ''; try { history.replaceState(history.state, '', location.pathname); } catch (e) {} }
      callWatch(state.chats);
      if (state.chat) {
        var cc = state.chats.filter(function (x) { return x.id === state.chat.id; })[0];
        if (state.chat.group) {
          if (cc) {
            state.chat.name = cc.title || 'Groupe'; $('#chatName').textContent = cap(state.chat.name);
            paintPhoto($('#chatAvatar'), '', state.chat.name); renderStatus();
            if (giDlg.open) renderGroupInfo();
          }
        } else {
        var nn = cc && (nickOf(cc, state.chat.other) || (cc.names && cc.names[state.chat.other]));
        if (nn && nn !== state.chat.name) { state.chat.name = nn; $('#chatName').textContent = cap(nn); paintPhoto($('#chatAvatar'), state.chat.other, nn); }
        }
      }
      watchNotes();
      frWatchPres();
      if (state.view === 'list') renderList();
      updateTitle();
    }, function () {
      state.chatsLoaded = true;
      state.chats = [];
      renderList();
      showNewErr('Impossible de charger les discussions. Vérifie que les règles Firestore sont publiées.');
    });

    FR.unsub = fs.collection('friendships').where('members', 'array-contains', state.me).onSnapshot(function (sn) {
      var firstFr = !FR.loaded; FR.loaded = true;
      if (!firstFr) sn.docChanges().forEach(function (ch) {
        var v = ch.doc.data();
        if (ch.type === 'added' && v.status === 'pending' && v.from !== state.me) notifyFriendReq(v);
      });
      FR.list = sn.docs.map(function (d) { var v = d.data(); v.id = d.id; return v; });
      frWatchPres(); frBadge(); bdayPaint();
      if (frDlg.open) frRender();
      if (ucDlg.open) ucRender();
    }, function () {});

    annStart();
    beat();
    hbTimer = setInterval(beat, 120000);
    stTimer = setInterval(function () { if (!document.hidden) renderStatus(); }, 2000);
    clearInterval(noteTimer);
    noteTimer = setInterval(function () { if (!document.hidden && state.view === 'list') renderList(); }, 60000);
  }

  function stopSession() {
    leaveChat();
    stopGame();
    hideToast();
    viewMusic.hidden = true;
    nwStop();
    liveStop();
    callClose();
    resetMusic();
    viewGame.hidden = true;
    if (unsubChats) unsubChats(); unsubChats = null;
    if (FR.unsub) FR.unsub(); FR.unsub = null; annStop(); FR.loaded = false;
    Object.keys(FR.presU).forEach(function (u) { try { FR.presU[u](); } catch (e) {} });
    FR.presU = {}; FR.pres = {}; FR.list = [];
    clearInterval(hbTimer); clearInterval(stTimer); clearInterval(noteTimer);
    Object.keys(noteSubs).forEach(function (k) { try { noteSubs[k](); } catch (e) {} });
    noteSubs = {}; notePres = {};
    if (AP.unsub) { try { AP.unsub(); } catch (e) {} AP.unsub = null; } AP.items = []; AP.first = true;
    state.me = null;
  }

  /* ---------- approbation des nouveaux comptes par le créateur ---------- */
  var apNew = false, AP = { items: [], unsub: null, first: true, auto: false, since: 0, setU: null, done: {} }, AG = { unsub: null };
  var AP_FN = 'https://dazzling-horse-f6d13a.netlify.app/.netlify/functions/push';
  function apPaint() {
    var b = $('#apBtn'); if (!b) return;
    b.textContent = 'Comptes à approuver' + (AP.items.length ? ' (' + AP.items.length + ')' : '');
  }
  /* approbation automatique : les comptes créés pendant la période activée sont acceptés tout seuls */
  function apAutoPaint() {
    var b = $('#apAuto'); if (!b) return;
    b.setAttribute('aria-pressed', AP.auto ? 'true' : 'false');
    b.textContent = AP.auto ? '⚡ Approbation automatique : activée (touche pour arrêter)' : '⚡ Approbation automatique : désactivée';
  }
  function apStrictPaint() {
    var b = $('#apStrict'); if (!b) return;
    b.setAttribute('aria-pressed', AP.strict ? 'true' : 'false');
    b.textContent = AP.strict ? '🔒 Mode strict : activé (touche pour désactiver)' : '🔒 Mode strict : désactivé';
  }
  $('#apStrict').addEventListener('click', function () {
    if (!creatorOn()) return;
    var on = !AP.strict, b = this;
    if (on && !confirm('Activer le mode strict ? Tout compte SANS approbation enregistrée sera bloqué. Lance d’abord « Approuver les comptes existants ».')) return;
    b.disabled = true;
    fs.collection('settings').doc('approval').set({ strict: on, strictBy: state.me, strictAt: Date.now() }, { merge: true })
      .catch(function () { showToast(null, 'Mode strict', 'Impossible : règles Firestore (écriture de « settings/approval »).'); })
      .then(function () { b.disabled = false; });
  });
  $('#apMig').addEventListener('click', async function () {
    if (!creatorOn()) return;
    var b = this, lbl = b.textContent; b.disabled = true; b.textContent = 'Migration…';
    try {
      var r = await Promise.all([fs.collection('usernames').get(), fs.collection('approvals').get()]);
      var have = {}, todo = [], seen = {};
      r[1].forEach(function (d) { have[d.id] = 1; });
      r[0].forEach(function (d) {
        var u = (d.data() || {}).uid;
        if (u && !have[u] && !seen[u]) { seen[u] = 1; todo.push({ uid: u, name: String(d.id).slice(0, 20) }); }
      });
      if (!have[state.me] && !seen[state.me]) todo.push({ uid: state.me, name: String(state.username || 'createur').slice(0, 20) });
      for (var i = 0; i < todo.length; i += 400) {
        var bt = fs.batch(), now = Date.now();
        todo.slice(i, i + 400).forEach(function (t) {
          bt.set(fs.collection('approvals').doc(t.uid), { name: t.name, status: 'approved', ts: now, by: state.me, ats: now, legacy: true });
        });
        await bt.commit();
      }
      b.textContent = todo.length + ' compte(s) approuvé(s) ✓';
    } catch (e) {
      b.textContent = 'Échec : publie d’abord les nouvelles règles Firestore';
    }
    setTimeout(function () { b.textContent = lbl; b.disabled = false; }, 4000);
  });
  function apAutoRun() {
    if (!AP.auto) return;
    AP.items.forEach(function (it) {
      if ((it.ts || 0) >= (AP.since || 0) && !AP.done[it.id]) { AP.done[it.id] = 1; apDecide(it.id, 'approved'); }
    });
  }
  $('#apAuto').addEventListener('click', function () {
    if (!creatorOn()) return;
    var on = !AP.auto, b = this; b.disabled = true;
    fs.collection('settings').doc('approval').set({ auto: on, since: Date.now(), by: state.me }, { merge: true })
      .catch(function () { showToast(null, 'Approbation auto', 'Impossible : règles Firestore (écriture de « settings/approval »).'); })
      .then(function () { b.disabled = false; });
  });
  function apCheck() {
    if (!state.me) return;
    if (!creatorOn()) {
      if (AP.unsub) { AP.unsub(); AP.unsub = null; }
      if (AP.setU) { AP.setU(); AP.setU = null; }
      AP.items = []; AP.auto = false; AP.done = {}; apPaint(); apAutoPaint(); return;
    }
    if (!AP.setU) {
      AP.setU = fs.collection('settings').doc('approval').onSnapshot(function (d) {
        var v = d.exists ? d.data() : {}, was = AP.auto;
        AP.auto = v.auto === true; AP.since = v.since || 0; AP.strict = v.strict === true; apStrictPaint();
        if (!AP.auto || !was) AP.done = {};
        apAutoPaint(); apAutoRun();
      }, function () {});
    }
    if (AP.unsub) return;
    AP.first = true;
    AP.unsub = fs.collection('approvals').where('status', '==', 'pending').onSnapshot(function (sn) {
      AP.items = sn.docs.map(function (d) { var v = d.data(); v.id = d.id; return v; }).sort(function (a, b) { return (a.ts || 0) - (b.ts || 0); });
      if (AP.first) { if (AP.items.length) showToast(null, 'Approbation', AP.items.length + ' compte' + (AP.items.length > 1 ? 's' : '') + ' en attente'); }
      else sn.docChanges().forEach(function (ch) {
        if (ch.type !== 'added') return;
        try { beep(); if (navigator.vibrate) navigator.vibrate(120); } catch (e) {}
        if (AP.auto && (ch.doc.data().ts || 0) >= (AP.since || 0)) return;
        showToast(null, 'Nouveau compte', cap(ch.doc.data().name || '') + ' attend ton approbation');
      });
      AP.first = false;
      apPaint(); apAutoRun();
      if (crDlg.open && CR.mode === 'ap') apRender();
    }, function () {});
  }
  function apDecide(id, st) {
    fs.collection('approvals').doc(id).update({ status: st, by: state.me, ats: Date.now() }).catch(function () { crErr('Action impossible (règles Firestore).'); });
  }
  function apRender() {
    var box = $('#crBody'); box.replaceChildren();
    if (!AP.items.length) { box.appendChild(el('p', 'hint', 'Aucun compte en attente.')); return; }
    AP.items.forEach(function (it) {
      var r = el('div', 'frrow aprow'), mid = el('div', 'frmid'), bx = el('div', 'frbtns');
      mid.appendChild(el('b', '', cap(it.name || '?')));
      mid.appendChild(el('small', '', it.ts ? new Date(it.ts).toLocaleString('fr-FR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' }) : ''));
      var ok = el('button', 'ghost', 'Approuver'), okc = el('button', 'ghost', 'Approuver + certifier'), no = el('button', 'ghost', 'Refuser'); ok.type = okc.type = no.type = 'button';
      ok.addEventListener('click', function () { apDecide(it.id, 'approved'); });
      okc.addEventListener('click', function () {
        fs.collection('presence').doc(it.id).set({ verified: true }, { merge: true })
          .then(function () { apDecide(it.id, 'approved'); })
          .catch(function () { crErr('Certification impossible (règles Firestore).'); });
      });
      no.addEventListener('click', function () { apDecide(it.id, 'rejected'); });
      bx.appendChild(ok); bx.appendChild(okc); bx.appendChild(no); r.appendChild(mid); r.appendChild(bx); box.appendChild(r);
    });
  }
  function apStop() { if (AG.unsub) { AG.unsub(); AG.unsub = null; } $('#apWait').hidden = true; }
  function apStrict() {
    return fs.collection('settings').doc('approval').get().then(function (d) { return d.exists && d.data().strict === true; });
  }
  function apShow(user, st) {
    stopSession();
    loginEl.hidden = true; appEl.hidden = true; $('#apWait').hidden = false;
    var rt = $('#apRetry');
    var paint = function (s) {
      $('#apMsg').textContent = s === 'rejected' ? 'Ton compte n’a pas été accepté par le créateur.'
        : s === 'error' ? 'Impossible de vérifier ton compte pour le moment. Vérifie ta connexion puis réessaie.'
        : 'Approbation par le créateur. Attends un instant…';
      rt.hidden = s !== 'error';
    };
    paint(st);
    if (st === 'error') return;
    var ref = fs.collection('approvals').doc(user.uid), creating = false;
    AG.unsub = ref.onSnapshot(function (d) {
      if (d.exists) {
        var s = d.data().status;
        if (s === 'approved') { apStop(); startSession(user); } else paint(s);
        return;
      }
      if (creating) return;
      creating = true;
      apStrict().then(function (strict) {
        if (!strict) { apStop(); startSession(user); return; }
        return ref.set({ name: String(user.email || '').split('@')[0].slice(0, 20), status: 'pending', ts: Date.now() }).then(function () { paint('pending'); });
      }).catch(function () { creating = false; paint('error'); });
    }, function () { paint('error'); });
  }
  function approvalGate(user) {
    apStop();
    var fresh = apNew; apNew = false;
    var ref = fs.collection('approvals').doc(user.uid);
    var nm = String(user.email || '').split('@')[0].slice(0, 20);
    var first = fresh
      ? fs.collection('settings').doc('approval').get()
          .then(function (d) { return d.exists && d.data().auto === true; }).catch(function () { return false; })
          .then(function (auto) {
            if (!auto) return ref.set({ name: nm, status: 'pending', ts: Date.now() }).then(function () { return 'pending'; });
            return ref.set({ name: nm, status: 'approved', auto: true, ts: Date.now() }).then(function () { return 'approved'; })
              .catch(function () { return ref.set({ name: nm, status: 'pending', ts: Date.now() }).then(function () { return 'pending'; }); });
          })
      : ref.get().then(function (d) {
          if (d.exists) return d.data().status;
          return apStrict().then(function (strict) {
            if (!strict) return 'approved';
            return ref.set({ name: nm, status: 'pending', ts: Date.now() }).then(function () { return 'pending'; });
          });
        });
    first.catch(function () { return 'error'; }).then(function (st) {
      if (!auth.currentUser || auth.currentUser.uid !== user.uid) return;
      if (st === 'approved') { startSession(user); return; }
      apShow(user, st);
      if (fresh && st === 'pending') {
        user.getIdToken().then(function (t) {
          return fetch(AP_FN, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ token: t, type: 'approval' }) });
        }).catch(function () {});
      }
    });
  }
  $('#apRetry').addEventListener('click', function () { if (auth.currentUser) approvalGate(auth.currentUser); });
  $('#apOut').addEventListener('click', function () { auth.signOut(); });

  var AUTH_SEEN = false;
  setTimeout(function () {
    if (AUTH_SEEN) return;
    var tried = false;
    try { tried = sessionStorage.getItem('uandi-authretry') === '1'; sessionStorage.setItem('uandi-authretry', '1'); } catch (e) {}
    if (!tried) { location.reload(); return; }
    loginEl.hidden = false;
    setAuthErr('Connexion impossible : le navigateur bloque le stockage du site. Quitte la navigation privée, ferme l’onglet puis rouvre le site.');
  }, 7000);
