/* U&I — js/app/24-actualites-commentaires.js
   Commentaires (réels et anonymes), commentaire vocal
   (fait partie de l’appli : assemblée par js/boot/loader.js dans une seule fermeture) */
  /* ---------- commentaires (profils réels + anonymes) ---------- */
  function nwNb(it) { var c = NW.cm[it.id]; return c && c.loaded && !c.failed ? c.items.length : (it.cc || 0); }
  function nwCmToggle(it) {
    var c = NW.cm[it.id];
    if (NW.open[it.id]) { NW.open[it.id] = false; if (c && c.unsub) c.unsub(); delete NW.cm[it.id]; nwRender(); return; }
    NW.open[it.id] = true;
    c = NW.cm[it.id] = { items: [], loaded: false, failed: false, unsub: null };
    c.unsub = fs.collection('letters').doc(it.id).collection('comments').orderBy('ts', 'asc').limit(100).onSnapshot(function (sn) {
      c.items = sn.docs.map(function (d) { var v = d.data(); v.id = d.id; return v; }); c.loaded = true; c.failed = false; nwRender();
    }, function () { c.loaded = true; c.failed = true; nwRender(); });
    nwRender();
  }
  function nwCmBox(it) {
    var c = NW.cm[it.id], creator = creatorOn(), box = el('div', 'nwcm');
    if (!c.loaded) box.appendChild(el('small', 'hint', 'Chargement…'));
    else if (c.failed) box.appendChild(el('small', 'hint', 'Commentaires indisponibles (règles Firestore : sous-collection « comments »).'));
    else if (!c.items.length) box.appendChild(el('small', 'hint', 'Aucun commentaire. Sois le premier !'));
    c.items.forEach(function (cm) {
      var real = cm.kind === 'real', mine = real ? cm.uid === state.me : !!NW.mine[cm.id];
      var row = el('div', 'nwc' + (cm.re && cm.re.id ? ' nwre' : '')), av = el('span', 'nwav'), body = el('div', 'nwcb'), top = el('div', 'nwct');
      row.dataset.cid = cm.id;
      if (real) { paintPhoto(av, cm.uid, cm.name); loadPhoto(cm.uid); } else nwAv(av, cm);
      var nmb = el('b', null, real ? cap(cm.name) : (cm.alias || 'Anonyme'));
      if (real) { withBadge(nmb, cm.uid); ensureBadge(cm.uid); }
      top.appendChild(nmb);
      top.appendChild(el('span', 'nwtag' + (real ? ' real' : ''), real ? 'Profil' : 'Anonyme'));
      top.appendChild(el('small', null, nwAgo(cm.ts || 0)));
      body.appendChild(top);
      if (cm.re && cm.re.id) {
        var rf = el('button', 'nwrefrom', '↪ en réponse à @' + (cm.re.n || '?')); rf.type = 'button';
        rf.addEventListener('click', function () {
          var rows = box.querySelectorAll('.nwc'), tg = null;
          for (var i = 0; i < rows.length; i++) if (rows[i].dataset.cid === cm.re.id) { tg = rows[i]; break; }
          if (!tg) return;
          tg.scrollIntoView({ block: 'center', behavior: 'smooth' });
          tg.classList.add('flash'); setTimeout(function () { tg.classList.remove('flash'); }, 1400);
        });
        body.appendChild(rf);
      }
      if (typeof cm.audio === 'string' && (cm.audio.indexOf(CLD_BASE) === 0 || cm.audio.indexOf('data:audio/') === 0)) body.appendChild(voiceUI(cm));
      else body.appendChild(el('p', 'nwtext', cm.text || ''));
      var ac = el('div', 'nwacts');
      ac.appendChild(nwRxBtn(cm, 'c:' + cm.id, fs.collection('letters').doc(it.id).collection('comments').doc(cm.id)));
      var rb = el('button', 'vact', '↩ Répondre'); rb.type = 'button';
      rb.addEventListener('click', function () {
        var h = real ? cm.name : (cm.alias || 'Anonyme');
        NW.replyTo[it.id] = { id: cm.id, n: h };
        var d = NW.draft[it.id] || '';
        NW.draft[it.id] = '@' + h + ' ' + d.replace(/^@\S+\s*/, '');
        nwRender();
        var f = nwFeed.querySelector('input[data-lid="' + it.id + '"]');
        if (f) { f.focus(); try { f.setSelectionRange(f.value.length, f.value.length); } catch (e) {} }
      });
      ac.appendChild(rb);
      if (!real && !mine) {
        var d = el('button', 'vact', '🎭 Discuter'); d.type = 'button';
        d.addEventListener('click', function () { atStart(cm.id, { name: cm.alias, emoji: cm.emoji, hue: cm.hue }); });
        ac.appendChild(d);
      }
      if (real && !mine) {
        var tz = el('button', 'vact', '🎭 Taquiner'); tz.type = 'button';
        tz.title = 'Lui écrire en anonyme';
        tz.addEventListener('click', function () { atStart('u:' + cm.uid, { name: cm.name, emoji: atInitial(cm.name), hue: atHue(cm.name) }, cm.uid); });
        ac.appendChild(tz);
      }
      if (mine || creator) {
        var x = el('button', 'vact vd', 'Supprimer'); x.type = 'button';
        x.addEventListener('click', function () { nwCmDelete(it, cm); });
        ac.appendChild(x);
      }
      if (NW.pick === 'c:' + cm.id) ac.appendChild(nwFresh(nwPickEl(cm, fs.collection('letters').doc(it.id).collection('comments').doc(cm.id)), 'c:' + cm.id));
      if (ac.children.length) body.appendChild(ac);
      row.appendChild(av); row.appendChild(body); box.appendChild(row);
    });
    var as = el('div', 'nwas');
    [['anon', '🎭 Anonyme'], ['real', '👤 ' + cap(myName())]].forEach(function (o) {
      var b = el('button', 'vact', o[1]); b.type = 'button'; b.setAttribute('aria-pressed', NW.as === o[0] ? 'true' : 'false');
      b.addEventListener('click', function () { NW.as = o[0]; nwRender(); });
      as.appendChild(b);
    });
    box.appendChild(as);
    var rt = NW.replyTo[it.id];
    if (rt && c.items.some(function (x) { return x.id === rt.id; })) {
      var rbar = el('div', 'nwrebar'), rsp = el('span', '', '↪ Réponse à @' + rt.n), rx = el('button', '', '✕');
      rx.type = 'button'; rx.setAttribute('aria-label', 'Annuler la réponse');
      rx.addEventListener('click', function () {
        delete NW.replyTo[it.id];
        NW.draft[it.id] = (NW.draft[it.id] || '').replace(/^@\S+\s*/, '');
        nwRender();
      });
      rbar.appendChild(rsp); rbar.appendChild(rx); box.appendChild(rbar);
    } else if (rt) delete NW.replyTo[it.id];
    var line = el('div', 'nwcin'), inp = el('input', 'nwcinput'), go = el('button', 'nwpost', 'Envoyer');
    var mk = el('button', 'vact nwcmic'); mk.type = 'button'; mk.dataset.nwrec = it.id;
    mk.setAttribute('aria-label', 'Commentaire vocal');
    mk.textContent = (NW.rec && NW.rec.lid === it.id) ? '⏹ ' + fmtDur((Date.now() - NW.rec.t0) / 1000) : '🎙️';
    mk.classList.toggle('on', !!(NW.rec && NW.rec.lid === it.id));
    mk.addEventListener('click', function () { nwRecToggle(it); });
    inp.type = 'text'; inp.maxLength = 300; inp.placeholder = NW.as === 'real' ? 'Commenter avec ton profil…' : 'Commenter en anonyme…';
    inp.value = NW.draft[it.id] || ''; inp.dataset.lid = it.id; go.type = 'button';
    inp.addEventListener('input', function () { NW.draft[it.id] = inp.value; });
    inp.addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); nwCmSend(it, inp); } });
    go.addEventListener('click', function () { nwCmSend(it, inp); });
    line.appendChild(inp); line.appendChild(mk); line.appendChild(go); box.appendChild(line);
    return box;
  }
  /* ---------- commentaire vocal : on appuie pour enregistrer, on rappuie pour envoyer (45 s max) ---------- */
  var NW_REC_MAX = 45;
  function nwRecTick() {
    var r = NW.rec; if (!r) return;
    var sec = (Date.now() - r.t0) / 1000;
    var bs = document.querySelectorAll('button[data-nwrec="' + r.lid + '"]');
    for (var i = 0; i < bs.length; i++) bs[i].textContent = '⏹ ' + fmtDur(sec);
    if (sec >= NW_REC_MAX) nwRecStop(false);
  }
  function nwRecStop(cancel) {
    var r = NW.rec; if (!r) return;
    r.cancelled = !!cancel; clearInterval(r.timer);
    try { if (r.mr.state !== 'inactive') r.mr.stop(); else nwRecDone(r); } catch (e) { nwRecDone(r); }
  }
  function nwRecDone(r) {
    clearInterval(r.timer);
    try { r.stream.getTracks().forEach(function (t) { t.stop(); }); } catch (e) {}
    if (NW.rec === r) NW.rec = null;
    nwRender();
    if (r.cancelled) return;
    var dur = (Date.now() - r.t0) / 1000;
    if (dur < 0.7 || !r.chunks.length) { nwErr('Vocal trop court.'); return; }
    var blob = new Blob(r.chunks, { type: (r.mr && r.mr.mimeType) || 'audio/webm' });
    if (blob.size > 650000) { nwErr('Vocal trop long.'); return; }
    var fr = new FileReader();
    fr.onload = function () { nwCmSend(r.it, null, { data: String(fr.result), dur: dur }); };
    fr.readAsDataURL(blob);
  }
  async function nwRecToggle(it) {
    nwErr('');
    if (NW.rec) { if (NW.rec.lid === it.id) nwRecStop(false); return; }
    if (NW.busy || banGuard()) return;
    var mime = pickMime();
    if (mime === null || !navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) { nwErr('Ton navigateur ne permet pas d’enregistrer un vocal.'); return; }
    var stream;
    try { stream = await getMic({ audio: true }); } catch (e) { nwErr('Micro refusé. Autorise le micro pour ce site dans le navigateur.'); return; }
    var opts = { audioBitsPerSecond: 24000 }; if (mime) opts.mimeType = mime;
    var mr;
    try { mr = new MediaRecorder(stream, opts); } catch (e) { stream.getTracks().forEach(function (t) { t.stop(); }); nwErr('L’enregistrement n’a pas pu démarrer.'); return; }
    var r = { mr: mr, chunks: [], stream: stream, t0: Date.now(), cancelled: false, lid: it.id, it: it, timer: null };
    mr.ondataavailable = function (e) { if (e.data && e.data.size) r.chunks.push(e.data); };
    mr.onstop = function () { nwRecDone(r); };
    mr.start(); NW.rec = r; r.timer = setInterval(nwRecTick, 250);
    nwRender();
  }
  async function nwCmSend(it, inp, voice) {
    var text = voice ? '🎤 Commentaire vocal' : inp.value.trim();
    nwErr('');
    if (!text || NW.busy) return;
    if (banGuard()) return;
    if (Date.now() - NW.cmLast < 4000) { nwErr('Patiente quelques secondes entre deux commentaires.'); return; }
    NW.busy = true;
    try {
      var real = NW.as === 'real', id = real ? null : await nwIdentity(), ts = Date.now();
      var ref = fs.collection('letters').doc(it.id).collection('comments').doc(), b = fs.batch();
      var rt = NW.replyTo[it.id], data = real ? { kind: 'real', uid: state.me, name: myName(), text: text.slice(0, 300), ts: ts }
                      : { kind: 'anon', alias: id.name, emoji: id.emoji, hue: id.hue, text: text.slice(0, 300), ts: ts };
      if (rt) data.re = { id: rt.id, n: String(rt.n).slice(0, 40) };
      if (voice) {
        var aud = await cloudUp(voice.data, 'auto');
        if (!aud) { if (voice.data.length > 600000) throw new Error('upload'); aud = voice.data; }
        data.audio = aud; data.dur = Math.round(voice.dur);
      }
      b.set(ref, data);
      if (!real) b.set(fs.collection('letterOwners').doc(ref.id), { uid: state.me, ts: ts, letter: it.id });
      await b.commit();
      if (!voice) NW.draft[it.id] = ''; delete NW.replyTo[it.id]; NW.cmLast = ts;
      fs.collection('letters').doc(it.id).update({ cc: firebase.firestore.FieldValue.increment(1) }).catch(function () {});
    } catch (e) { nwErr('Commentaire impossible (règles Firestore : voir « comments » dans les règles).'); }
    NW.busy = false; nwRender();
  }
  function nwCmDelete(it, cm) {
    if (!confirm('Supprimer ce commentaire ?')) return;
    fs.collection('letters').doc(it.id).collection('comments').doc(cm.id).delete()
      .then(function () {
        if (cm.kind !== 'real') fs.collection('letterOwners').doc(cm.id).delete().catch(function () {});
        fs.collection('letters').doc(it.id).update({ cc: firebase.firestore.FieldValue.increment(-1) }).catch(function () {});
      }).catch(function () { nwErr('Suppression impossible (connexion ou règles Firestore).'); });
  }

