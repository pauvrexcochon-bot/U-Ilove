/* U&I — js/app/08-discussion.js
   Une discussion
   (fait partie de l’appli : assemblée par js/boot/loader.js dans une seule fermeture) */
  /* ---------- une discussion ---------- */
  function pushView(st) {
    var v = state.view;
    if (v === 'music' || v === 'game' || v === 'news') history.replaceState(st, ''); else history.pushState(st, '');
  }
  function showList() {
    leaveChat();
    stopGame();
    state.view = 'list';
    viewGame.hidden = true;
    viewMusic.hidden = true;
    viewChat.hidden = true;
    viewList.hidden = false;
    renderList();
  }

  function paintGroupAv(node, g) {
    if (g && g.photo) { node.textContent = ''; node.style.background = 'center / cover no-repeat url("' + g.photo + '")'; }
    else { node.textContent = '👥'; node.style.background = GROUPBG; }
  }
  var GROUPBG = 'linear-gradient(135deg, var(--accent), var(--accent2, var(--accent)))';
  function openChat(otherUid, otherName, gc) {
    leaveChat();
    var id = gc ? gc.id : chatIdFor(state.me, otherUid);
    state.chat = { id: id, other: gc ? '' : otherUid, name: gc ? (gc.title || 'Groupe') : (nickOf(chatOf(id), otherUid) || otherName), group: !!gc };
    $('#liveBtn').hidden = false; $('#callBtn').hidden = !!gc; $('#giBtn').hidden = !gc; $('#nickBtn').hidden = !!gc; $('#nickForm').hidden = true;
    stopVoices(); RXSIG = {}; HOLD.shown = null; SCROLL_WARM = false; state.msgs = []; state.loaded = false; state.dead = null; state.lim = 20; state.paging = false;
    state.open = new Set(); state.confirm = null; state.otherPres = null;
    state.reply = null; $('#replybar').hidden = true;
    state.stick = true;
    state.view = 'chat';
    history.pushState({ chat: id }, '');
    viewList.hidden = true;
    viewChat.hidden = false;
    $('#chatName').textContent = cap(otherName);
    paintPhoto($('#chatAvatar'), otherUid, otherName); loadPhoto(otherUid);
    updateChatRing(); watchNotes(otherUid); updateChatBadge(); paintPin();
    showErr('');
    showNewErr('');
    resetDelBtn();
    ta.disabled = false; sendBtn.disabled = false;
    ta.value = store('uandi-draft-' + id) || '';
    applyChatTheme(id); applyBg(id); $('#themes').hidden = true;
    autosize();
    renderStatus();
    render();

    var chatRef = fs.collection('chats').doc(id);
    function subMsgs() {
    unsubMsgs = chatRef.collection('messages').orderBy('ts', 'desc').limit(state.lim).onSnapshot(function (snap) {
      var before = new Set(state.msgs.map(function (m) { return m.id; }));
      var firstLoad = !state.loaded;
      var paging = state.paging; state.paging = false;
      var list = [];
      snap.docs.forEach(function (d) {
        var v = d.data({ serverTimestamps: 'estimate' });
        if (v && typeof v.text === 'string' && typeof v.ts === 'number' && typeof v.uid === 'string' && !(typeof v.g === 'string' && typeof v.i === 'number')) {
          list.push({ id: d.id, uid: v.uid, text: v.text, ts: (v.sts && typeof v.sts.toMillis === 'function') ? v.sts.toMillis() : v.ts, likes: v.likes, reacts: v.reacts, edited: v.edited === true, delAt: typeof v.delAt === 'number' ? v.delAt : 0,
            audio: (typeof v.audio === 'string' && (v.audio.slice(0, 5) === 'data:' || v.audio.indexOf(CLD_BASE) === 0)) ? v.audio : null,
            dur: typeof v.dur === 'number' ? v.dur : 0,
            music: typeof v.music === 'string' ? v.music : '',
            img: (typeof v.img === 'string' && (v.img.slice(0, 11) === 'data:image/' || v.img.indexOf(CLD_BASE) === 0)) ? v.img : null,
            file: (v.file && typeof v.file.n === 'string' && ((typeof v.file.d === 'string' && v.file.d.slice(0, 5) === 'data:') || typeof v.file.g === 'string' || (typeof v.file.u === 'string' && v.file.u.indexOf(CLD_BASE) === 0))) ? { u: (typeof v.file.u === 'string' && v.file.u.indexOf(CLD_BASE) === 0) ? v.file.u : '', n: String(v.file.n || 'fichier').slice(0, 120), s: +v.file.s || 0, d: typeof v.file.d === 'string' ? v.file.d : '', g: String(v.file.g || ''), p: +v.file.p || 0, loc: v.file.loc === 'm' ? 'm' : 'f', mt: String(v.file.mt || '').slice(0, 80) } : null,
            reply: (v.reply && typeof v.reply.t === 'string') ? { id: String(v.reply.id || ''), uid: String(v.reply.uid || ''), t: v.reply.t } : null });
        }
      });
      list.sort(function (a, b) { return a.ts - b.ts || (a.id < b.id ? -1 : 1); });
      cleanOld(id, list);
      state.more = snap.size >= state.lim;
      var fresh = (firstLoad || paging) ? [] : list.filter(function (m) { return !before.has(m.id) && m.uid !== state.me; });
      var away = !nearBottom();
      state.msgs = list;
      state.loaded = true;
      if (firstLoad) state.stick = true;
      var h0 = logEl.scrollHeight, t0 = logEl.scrollTop;
      render();
      if (paging) { logEl.scrollTop = t0 + (logEl.scrollHeight - h0); return; }
      if (fresh.length && away) jumpBtn.hidden = false;
      if (fresh.length) notifyIncoming(fresh[fresh.length - 1]);
      if (firstLoad || fresh.length) markSeen();
    }, function (err) {
      state.dead = err && err.code === 'permission-denied'
        ? 'Accès refusé. Vérifie que les règles Firestore de LISEZMOI.md sont publiées.'
        : 'La connexion a été interrompue. Recharge la page pour reprendre.';
      state.loaded = true;
      ta.disabled = true; sendBtn.disabled = true;
      render();
    });
    }
    subMsgs();
    state.loadOlder = function () {
      if (!state.more || state.paging) return;
      state.paging = true; state.lim += 20;
      if (unsubMsgs) unsubMsgs(); unsubMsgs = null;
      subMsgs();
    };

    unsubPres = state.chat.group ? null : fs.collection('presence').doc(otherUid).onSnapshot(function (d) {
      state.otherPres = d.exists ? d.data() : null;
      var ph = state.otherPres && typeof state.otherPres.photo === 'string' ? state.otherPres.photo : null;
      if (photos[otherUid] !== ph) { photos[otherUid] = ph; paintPhoto($('#chatAvatar'), otherUid, otherName); }
      var pn = state.otherPres && typeof state.otherPres.name === 'string' && state.otherPres.name;
      if (pn && state.chat && state.chat.other === otherUid && !nickOf(chatOf(state.chat.id), otherUid) && pn !== state.chat.name) { state.chat.name = pn; $('#chatName').textContent = cap(pn); paintPhoto($('#chatAvatar'), otherUid, pn); }
      renderStatus();
    }, function () {});
    liveWatch(state.chat);
  }

  function leaveChat() {
    var vnw = document.getElementById('viewNews'); if (vnw) vnw.hidden = true;
    applyBg(null); delete document.documentElement.dataset.ct;
    cancelEdit(); state.picker = null;
    setTyping(false);
    stopRec(true);
    if (unsubMsgs) unsubMsgs(); unsubMsgs = null;
    if (unsubPres) unsubPres(); unsubPres = null;
    liveUnwatch();
    stopVoices(); state.chat = null; state.msgs = []; state.otherPres = null;
  }

