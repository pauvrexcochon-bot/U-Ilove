/* U&I — js/app/04-amis.js
   Amis, demandes, invitations par message
   (fait partie de l’appli : assemblée par js/boot/loader.js dans une seule fermeture) */
  /* ---------- amis, demandes, invitations par message ---------- */
  var FR = { list: [], unsub: null, pres: {}, presU: {}, tab: 'req', sug: { items: [], t: 0, busy: false } };
  var INV_MAX = 5, ONLINE_MS = 150000;
  var frDlg = $('#frDlg'), ucDlg = $('#userCard'), ucT = null;
  function frDoc(uid) { return fs.collection('friendships').doc(chatIdFor(state.me, uid)); }
  function frOther(f) { return (f.members || []).filter(function (x) { return x !== state.me; })[0]; }
  function frNameOf(f) { return (f.names && f.names[frOther(f)]) || 'Inconnu'; }
  /* amis = demandes acceptées + toutes les personnes avec qui une discussion existe déjà (hors invitations en attente) */
  function frAll() {
    var m = {};
    state.chats.forEach(function (c) {
      if (c.group || c.invite) return;
      var o = (c.members || []).filter(function (x) { return x !== state.me; })[0];
      if (!o) return;
      var nm = {}; nm[o] = (c.names && c.names[o]) || 'Inconnu';
      m[o] = { members: [state.me, o], names: nm, status: 'accepted', implicit: true };
    });
    FR.list.forEach(function (f) { if (f.status === 'accepted') m[frOther(f)] = f; });
    return Object.keys(m).map(function (k) { return m[k]; });
  }
  function frWith(uid) {
    var im = frAll().filter(function (f) { return frOther(f) === uid; })[0];
    return im || FR.list.filter(function (f) { return frOther(f) === uid; })[0] || null;
  }
  function inviteIn(c) { return !!(c && !c.group && c.invite && c.invite.from && c.invite.from !== state.me); }
  function invitePending(c) { return inviteIn(c) && c.invite.st !== 'declined'; }
  function frIncoming() { return FR.list.filter(function (f) { return f.status === 'pending' && f.from !== state.me; }); }
  function frCount() { return frIncoming().length + state.chats.filter(invitePending).length; }
  function frBadge() { var b = $('#frN'), n = frCount(); b.textContent = n; b.hidden = !n; var d = $('#menuDot'); if (d) d.hidden = !n; }
  function frWatchPres() {
    var want = {};
    frAll().forEach(function (f) { want[frOther(f)] = 1; });
    Object.keys(FR.presU).forEach(function (u) { if (!want[u]) { FR.presU[u](); delete FR.presU[u]; delete FR.pres[u]; } });
    Object.keys(want).forEach(function (u) {
      if (FR.presU[u]) return;
      FR.presU[u] = fs.collection('presence').doc(u).onSnapshot(function (d) {
        FR.pres[u] = { seen: d.exists ? (d.data().seen || 0) : 0, bday: d.exists && typeof d.data().bday === 'string' ? d.data().bday : null }; bdayPaint();
        if (frDlg.open) frRender();
        if (ucDlg.open) ucRender();
      }, function () {});
    });
  }
  var seenAt = {}, onSig = '';
  function isOnline(u) { var t = Math.max(seenAt[u] || 0, (FR.pres[u] && FR.pres[u].seen) || 0); return !!t && Date.now() - t < ONLINE_MS; }
  function onlineSig() {
    return state.chats.map(function (c) {
      if (c.group) return '';
      var o = (c.members || []).filter(function (x) { return x !== state.me; })[0];
      return o && isOnline(o) ? o : '';
    }).join(',');
  }
  setInterval(function () { if (!document.hidden && state.view === 'list' && onlineSig() !== onSig) renderList(); }, 15000);
  function frFail() { var e = $('#frErr'); e.textContent = 'Action impossible (connexion ou règles Firestore : « friendships »).'; e.hidden = false; }
  function frRow(uid, name, sub, subCls, online, btns, onOpen) {
    var r = el('div', 'frrow'), wrap = el('span', 'frav'), a = el('span', 'avatar sm');
    paintPhoto(a, uid, name); loadPhoto(uid); ensureBadge(uid); wrap.appendChild(a);
    if (online) wrap.appendChild(el('i', 'frdot'));
    wrap.addEventListener('click', function () { frDlg.close(); openUserCard(uid, name); });
    var mid = el('div', 'frmid');
    mid.appendChild(withBadge(el('b', '', cap(name)), uid));
    mid.appendChild(el('small', subCls || '', sub || ''));
    mid.addEventListener('click', onOpen);
    var bx = el('div', 'frbtns');
    (btns || []).forEach(function (o) { var b = el('button', 'ghost', o[0]); b.type = 'button'; b.addEventListener('click', o[1]); bx.appendChild(b); });
    r.appendChild(wrap); r.appendChild(mid); r.appendChild(bx);
    return r;
  }
  /* suggestions d'amis : comptes récemment actifs, sans les amis, les demandes en cours ni les profils certifiés */
  function frIsCertMe() {
    try {
      if (!state.me) return false;
      if (typeof verifs !== 'undefined' && state.me in verifs) return verifs[state.me] === true;
      return localStorage.getItem('uandi-cert-' + state.me) === '1';
    } catch (e) { return false; }
  }
  function frSuggest() {
    if (frIsCertMe()) return;
    if (FR.sug.busy || (FR.sug.t && Date.now() - FR.sug.t < 60000)) return;
    FR.sug.busy = true;
    fs.collection('presence').orderBy('seen', 'desc').limit(40).get().then(function (sn) {
      var out = [];
      sn.forEach(function (d) {
        var v = d.data(), u = d.id;
        if (u === state.me || v.verified === true || typeof v.name !== 'string' || !v.name || frWith(u)) return;
        if (typeof v.photo === 'string') { photos[u] = v.photo; photoReq[u] = 1; }
        out.push({ uid: u, name: v.name });
      });
      var mine = {}; frAll().forEach(function (f) { mine[frOther(f)] = 1; });
      /* suggestion seulement avec au moins 5 amis en commun */
      return Promise.all(out.map(function (x) {
        return fs.collection('friendships').where('members', 'array-contains', x.uid).limit(300).get().then(function (q) {
          var n = 0; q.forEach(function (d) { var v = d.data(); if (!v || v.status !== 'accepted') return; var o = (v.members || []).filter(function (m) { return m !== x.uid; })[0]; if (o && o !== state.me && mine[o]) n++; });
          x.mutual = n; return x;
        }).catch(function () { x.mutual = 0; return x; });
      })).then(function (all) {
        var ok = all.filter(function (x) { return x.mutual >= 5; });
        ok.sort(function (a, b) { return b.mutual - a.mutual; });
        FR.sug.items = ok.slice(0, 8); FR.sug.t = Date.now(); FR.sug.busy = false;
        if (frDlg.open) frRender();
      });
    }).catch(function () { FR.sug.busy = false; FR.sug.t = Date.now(); });
  }
  function frRender() {
    var box = $('#frBody'); box.replaceChildren();
    var inc = frIncoming(), out = FR.list.filter(function (f) { return f.status === 'pending' && f.from === state.me; });
    var inv = state.chats.filter(invitePending).sort(function (a, b) { return (b.lastTs || 0) - (a.lastTs || 0); });
    var friends = frAll();
    $('#frTabReq').textContent = 'Demandes' + (frCount() ? ' (' + frCount() + ')' : '');
    $('#frTabFr').textContent = 'Amis (' + friends.length + ')';
    $('#frTabReq').setAttribute('aria-pressed', FR.tab === 'req' ? 'true' : 'false');
    $('#frTabFr').setAttribute('aria-pressed', FR.tab === 'fr' ? 'true' : 'false');
    if (FR.tab === 'req') {
      box.appendChild(el('p', 'frh', 'Demandes d’amis'));
      if (!inc.length && !out.length) box.appendChild(el('p', 'frempty', 'Aucune demande d’ami.'));
      inc.forEach(function (f) {
        var u = frOther(f), nm = frNameOf(f);
        box.appendChild(frRow(u, nm, 'veut devenir ton ami', '', false, [
          ['Accepter', function () { frDoc(u).update({ status: 'accepted', ats: Date.now() }).catch(frFail); }],
          ['Refuser', function () { frDoc(u).delete().catch(frFail); }]
        ], function () { frDlg.close(); openUserCard(u, nm); }));
      });
      out.forEach(function (f) {
        var u = frOther(f), nm = frNameOf(f);
        box.appendChild(frRow(u, nm, 'Demande envoyée', '', false, [['Annuler', function () { frDoc(u).delete().catch(frFail); }]], function () { frDlg.close(); openUserCard(u, nm); }));
      });
      box.appendChild(el('p', 'frh', 'Invitations par message'));
      if (!inv.length) box.appendChild(el('p', 'frempty', 'Aucune invitation par message.'));
      inv.forEach(function (c) {
        var u = c.invite.from, nm = (c.names && c.names[u]) || 'Inconnu', n = c.invite.n || 1;
        var row = frRow(u, nm, 'Invitation par message · ' + n + ' message' + (n > 1 ? 's' : ''), 'inv', false, [
          ['Accepter', function () { fs.collection('chats').doc(c.id).update({ invite: firebase.firestore.FieldValue.delete() }).catch(frFail); }],
          ['Refuser', function () { fs.collection('chats').doc(c.id).update({ 'invite.st': 'declined' }).catch(frFail); }]
        ], function () { frDlg.close(); openChat(u, nm); });
        if (c.lastText) row.querySelector('.frmid').appendChild(el('small', '', '« ' + c.lastText + ' »'));
        box.appendChild(row);
      });
    } else {
      frSuggest();
      var on = friends.filter(function (f) { return isOnline(frOther(f)); }), off = friends.filter(function (f) { return !isOnline(frOther(f)); });
      if (!friends.length) box.appendChild(el('p', 'frempty', 'Aucun ami pour l’instant. Cherche un nom d’utilisateur pour en ajouter.'));
      function add(f, o) { var u = frOther(f), nm = frNameOf(f); box.appendChild(frRow(u, nm, (isClose(u) ? '⭐ Ami proche · ' : '') + (o ? 'En ligne' : 'Hors ligne'), '', o, [], function () { frDlg.close(); openChat(u, nm); })); }
      var bds = bdayList();
      var bt = bds.filter(function (x) { return x.days === 0; }), bn = bds.filter(function (x) { return x.days > 0 && x.days <= 30; });
      if (bt.length) { box.appendChild(el('p', 'frh', 'Anniversaires aujourd’hui')); bt.forEach(function (x) { box.appendChild(frRow(x.u, x.nm, '🎂 Aujourd’hui', '', false, [], function () { frDlg.close(); openChat(x.u, x.nm); })); }); }
      if (bn.length) { box.appendChild(el('p', 'frh', 'Prochains anniversaires')); bn.forEach(function (x) { box.appendChild(frRow(x.u, x.nm, bdayLabel(x.md) + ' · dans ' + x.days + ' j', '', false, [], function () { frDlg.close(); openChat(x.u, x.nm); })); }); }
      if (on.length) { box.appendChild(el('p', 'frh', 'Connectés (' + on.length + ')')); on.forEach(function (f) { add(f, true); }); }
      if (off.length) { box.appendChild(el('p', 'frh', on.length ? 'Hors ligne' : 'Tous les amis')); off.forEach(function (f) { add(f, false); }); }
      var sg = frIsCertMe() ? [] : FR.sug.items.filter(function (x) { return !frWith(x.uid); });
      if (sg.length) {
        box.appendChild(el('p', 'frh', 'Suggestions'));
        sg.forEach(function (x) {
          box.appendChild(frRow(x.uid, x.name, x.mutual + ' amis en commun', '', false, [['Ajouter', function () {
            var names = {}; names[state.me] = state.username; names[x.uid] = x.name;
            frDoc(x.uid).set({ members: [state.me, x.uid], names: names, from: state.me, status: 'pending', ts: Date.now() }).catch(frFail);
          }]], function () { frDlg.close(); openUserCard(x.uid, x.name); }));
        });
      }
    }
  }
  function frOpen(tab) { FR.tab = tab; $('#frErr').hidden = true; frRender(); frDlg.showModal(); }
  $('#openFriends').addEventListener('click', function () { frOpen('fr'); });
  $('#openReqs').addEventListener('click', function () { frOpen('req'); });
  $('#frTabReq').addEventListener('click', function () { FR.tab = 'req'; frRender(); });
  $('#frTabFr').addEventListener('click', function () { FR.tab = 'fr'; frRender(); });
  $('#frClose').addEventListener('click', function () { frDlg.close(); });
  setInterval(function () { if (!document.hidden && frDlg.open) frRender(); }, 20000);

  /* barre d'outils : menu ⋮, filtre « non lus », recherche d'une personne */
  var kmenu = $('#kmenu'), menuBtn = $('#menuBtn');
  function menuClose() { kmenu.hidden = true; menuBtn.setAttribute('aria-expanded', 'false'); }
  menuBtn.addEventListener('click', function (e) { e.stopPropagation(); var o = kmenu.hidden; kmenu.hidden = !o; menuBtn.setAttribute('aria-expanded', o ? 'true' : 'false'); });
  kmenu.addEventListener('click', menuClose);
  document.addEventListener('click', function (e) { if (!kmenu.hidden && !e.target.closest('#kmenu') && !e.target.closest('#menuBtn')) menuClose(); });
  $('#unreadBtn').addEventListener('click', function () { state.onlyUnread = !state.onlyUnread; renderList(); });
  $('#searchBtn').addEventListener('click', function () {
    var f = $('#newChat'); f.hidden = !f.hidden;
    if (!f.hidden) $('#who').focus(); else showNewErr('');
  });
  $('#openDSearch').addEventListener('click', function () { var i = $('#search'); i.hidden = false; setTimeout(function () { i.focus(); }, 0); });
  $('#search').addEventListener('blur', function () { if (!this.value.trim()) this.hidden = true; });

