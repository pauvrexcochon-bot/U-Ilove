/* U&I — js/app/10-actions-messages.js
   Supprimer et répondre à un message
   (fait partie de l’appli : assemblée par js/boot/loader.js dans une seule fermeture) */
  /* ---------- supprimer un message : pour tout le monde (laisse « Message effacé ») ou pour moi seulement ---------- */
  function hmKey() { return 'uandi-hm-' + state.me + '-' + (state.chat ? state.chat.id : ''); }
  function hiddenMsgs() { try { return JSON.parse(store(hmKey()) || '[]') || []; } catch (e) { return []; } }
  function visibleMsgs() {
    var h = hiddenMsgs();
    return h.length ? state.msgs.filter(function (m) { return h.indexOf(m.id) === -1; }) : state.msgs;
  }
  function hideMsgForMe(id) {
    var h = hiddenMsgs();
    if (h.indexOf(id) === -1) h.push(id);
    store(hmKey(), JSON.stringify(h.slice(-500)));
    state.open.delete(id); if (state.picker === id) state.picker = null;
    render();
  }
  /* nettoyage automatique (mes propres messages) : vocaux intégrés (data:) > 20 jours — ceux sur Cloudinary sont gardés —, messages effac\u00e9s > 5 jours */
  var CLEANED = {};
  function cleanPhotos(chatId, list, manual) {
    var cut = Date.now() - 7 * 86400000, n = 0, FV = firebase.firestore.FieldValue;
    list.forEach(function (m) {
      if (m.uid !== state.me || !m.img || String(m.img).slice(0, 11) !== 'data:image/' || m.ts >= cut || (CLEANED[m.id] && !manual)) return;
      CLEANED[m.id] = 1; n++;
      fs.collection('chats').doc(chatId).collection('messages').doc(m.id)
        .update({ img: FV.delete(), text: '\uD83D\uDCF7 Photo retir\u00e9e' }).catch(function () {});
    });
    return n;
  }
  function cleanOld(chatId, list) {
    var now = Date.now(), D = 86400000;
    list.forEach(function (m) {
      if (m.uid !== state.me || CLEANED[m.id]) return;
      var ref = fs.collection('chats').doc(chatId).collection('messages').doc(m.id);
      if (m.text === SYS + 'Message effac\u00e9' && now - (m.delAt || m.ts) > 5 * D) {
        CLEANED[m.id] = 1; ref.delete().catch(function () {});
      } else if (m.audio && String(m.audio).indexOf(CLD_BASE) !== 0 && now - m.ts > 20 * D) {
        CLEANED[m.id] = 1;
        var del = firebase.firestore.FieldValue.delete();
        ref.update({ audio: del, dur: del, music: del, text: SYS + 'Message effac\u00e9', delAt: now }).catch(function () {});
      }
    });
  }
  async function eraseForAll(id) {
    var chat = state.chat, m = state.msgs.find(function (x) { return x.id === id; });
    if (!chat || !m || m.uid !== state.me) return;
    var del = firebase.firestore.FieldValue.delete();
    var ref = fs.collection('chats').doc(chat.id), mref = ref.collection('messages').doc(id);
    var newest = state.msgs.reduce(function (a, x) { return Math.max(a, x.ts); }, 0);
    try {
      try { await mref.update({ text: SYS + 'Message effac\u00e9', delAt: Date.now(), edited: false, audio: del, img: del, file: del, reply: del, dur: del, music: del, likes: del, reacts: del }); }
      catch (e) { await mref.update({ text: SYS + 'Message effac\u00e9' }); }
      if (m.ts === newest) ref.update({ lastText: 'Message effac\u00e9' }).catch(function () {});
    } catch (e) { showErr('Le message n\u2019a pas pu \u00eatre effac\u00e9.'); }
  }
  function delChoose(id) {
    var m = state.msgs.find(function (x) { return x.id === id; });
    if (!m) return;
    var old = document.querySelector('.sheetbg'); if (old) old.remove();
    var bg = el('div', 'sheetbg'), sh = el('div', 'sheet');
    var close = function () { if (bg.classList.contains('out')) return; bg.classList.add('out'); setTimeout(function () { bg.remove(); }, 210); };
    sh.appendChild(el('h3', '', 'Supprimer ce message ?'));
    var mkb = function (label, fn) {
      var b = el('button', 'pick', label); b.type = 'button';
      b.addEventListener('click', function () { close(); fn(); }); sh.appendChild(b);
    };
    if (m.uid === state.me) mkb('Supprimer pour tout le monde', function () { eraseForAll(id); });
    mkb('Supprimer pour moi seulement', function () { hideMsgForMe(id); });
    sh.appendChild(el('p', '', m.uid === state.me ? 'Pour tout le monde : il reste \u00ab Message effac\u00e9 \u00bb dans la discussion.' : 'Le message dispara\u00eet seulement chez toi.'));
    var cn = el('button', 'ghost', 'Annuler'); cn.type = 'button'; cn.style.marginTop = '10px'; cn.addEventListener('click', close);
    sh.appendChild(cn); bg.appendChild(sh);
    bg.addEventListener('click', function (e) { if (e.target === bg) close(); });
    document.body.appendChild(bg);
  }
  async function removeMsg(id) {
    if (!state.chat) return;
    try { await fs.collection('chats').doc(state.chat.id).collection('messages').doc(id).delete(); }
    catch (e) { showErr('Le message n’a pas pu être supprimé.'); }
  }

  /* ---------- répondre à un message ---------- */
  function replyText(m) {
    if (m.img) return '📷 Photo';
    if (m.file) return '📎 ' + m.file.n;
    if (m.audio) return m.music ? '♪ ' + m.music : '🎤 Message vocal';
    return String(m.text || '').slice(0, 120);
  }
  function clearReply() { state.reply = null; $('#replybar').hidden = true; }
  function withReply(o) {
    var r = state.reply;
    if (r) { o.reply = { id: r.id, uid: r.uid, t: r.t }; clearReply(); }
    return o;
  }
  function setReply(id) {
    var m = state.msgs.find(function (x) { return x.id === id; });
    if (!m || isSys(m) || ta.disabled || state.editing) return;
    state.reply = { id: m.id, uid: m.uid, t: replyText(m) };
    $('#replyWho').textContent = m.uid === state.me ? 'Toi' : cap(state.chat ? state.chat.name : '');
    $('#replyTxt').textContent = state.reply.t;
    $('#replybar').hidden = false;
    ta.focus();
  }
  $('#replyCancel').addEventListener('click', clearReply);
  function quoteEl(r) {
    var q = el('div', 'quote');
    q.dataset.q = r.id;
    q.appendChild(el('b', '', r.uid === state.me ? 'Toi' : cap(state.chat ? state.chat.name : '')));
    q.appendChild(el('span', '', r.t));
    return q;
  }
  function jumpTo(id) {
    var rows = logEl.querySelectorAll('.row'), row = null;
    for (var i = 0; i < rows.length; i++) if (rows[i].dataset.id === id) { row = rows[i]; break; }
    if (!row) return;
    row.scrollIntoView({ block: 'center', behavior: 'smooth' });
    row.classList.add('flash');
    setTimeout(function () { row.classList.remove('flash'); }, 1400);
  }
  /* tirer un message vers la droite = répondre (comme WhatsApp) */
  var SW = { row: null, bw: null, ico: null, x: 0, y: 0, active: false, armed: false, done: false };
  function swReset(animate) {
    if (SW.bw) {
      if (animate) SW.bw.style.transition = 'transform .5s var(--spring-soft)';
      SW.bw.style.transform = '';
      var bw = SW.bw, ico = SW.ico;
      setTimeout(function () { bw.style.transition = ''; if (ico && ico.parentNode) ico.remove(); }, 520);
    }
    SW.row = SW.bw = SW.ico = null; SW.active = SW.armed = false;
  }
  logEl.addEventListener('pointerdown', function (ev) {
    SW.done = false; swReset(false);
    var t = ev.target, bw = t.closest && t.closest('.bwrap');
    if (!bw || t.closest('button, input') || ta.disabled || state.editing) return;
    SW.row = bw.closest('.row'); SW.bw = bw; SW.x = ev.clientX; SW.y = ev.clientY;
  });
  logEl.addEventListener('pointermove', function (ev) {
    if (!SW.row || HOLD.slide) return;
    var dx = ev.clientX - SW.x, dy = ev.clientY - SW.y;
    if (!SW.active) {
      if (Math.abs(dy) > 14 && Math.abs(dy) > Math.abs(dx)) { SW.row = SW.bw = null; return; }
      if (dx < 16 || dx < Math.abs(dy) * 1.5) return;
      SW.active = true; lpCancel();
      SW.ico = el('span', 'swipeico', '↩'); SW.bw.appendChild(SW.ico);
      try { logEl.setPointerCapture(ev.pointerId); } catch (e) {}
    }
    var x = Math.min(dx, 56 + Math.max(0, dx - 56) * 0.25, 90);
    SW.bw.style.transform = 'translateX(' + x + 'px)';
    SW.ico.style.opacity = Math.min(1, x / 56);
    var armed = dx >= 56;
    SW.ico.style.scale = armed ? '1.2' : String(0.5 + Math.min(1, x / 56) * 0.5);
    if (armed && !SW.armed) { try { if (navigator.vibrate) navigator.vibrate(12); } catch (e) {} }
    SW.armed = armed;
  });
  ['pointerup', 'pointercancel'].forEach(function (n) {
    logEl.addEventListener(n, function () {
      if (!SW.row && !SW.active) return;
      var go = SW.active && SW.armed && n === 'pointerup', id = SW.row && SW.row.dataset.id, was = SW.active;
      swReset(true);
      if (was) SW.done = true;
      if (go) setReply(id);
    });
  });
  /* appui long (maintenir) sur un message : réactions emoji + modifier */
  var LP = { t: null, x: 0, y: 0, fired: false, row: null };
  function rowById(id) { var rs = logEl.children; for (var i = 0; i < rs.length; i++) if (rs[i].dataset && rs[i].dataset.id === id) return rs[i]; return null; }
  function freshPicker(box, id) {
    var n = Date.now();
    if (HOLD.shown !== id) { HOLD.shown = id; HOLD.t0 = n; }
    var age = n - HOLD.t0;
    if (age < 450) {
      box.classList.add('fresh'); box.style.setProperty('--el', age + 'ms');
      for (var i = 0; i < box.children.length; i++) box.children[i].style.setProperty('--k', i);
    }
    return box;
  }
  function closePickerAnim(id, chosen, done) {
    var row = rowById(id), pk = row && row.querySelector('.picker');
    if (!pk || (window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches)) { done(); return; }
    pk.classList.remove('fresh');
    if (chosen) [].forEach.call(pk.querySelectorAll('.rxb'), function (b) { if (b.dataset.e === chosen) b.classList.add('chosen'); });
    pk.classList.add('out');
    setTimeout(function () {
      if (pk.parentNode) pk.parentNode.removeChild(pk);
      delete RC['r' + id];
      done();
    }, chosen ? 200 : 160);
  }
  function setHot(b) {
    if (HOLD.hot === b) return;
    if (HOLD.hot) HOLD.hot.classList.remove('hot');
    HOLD.hot = b;
    if (b) { b.classList.add('hot'); try { if (navigator.vibrate) navigator.vibrate(6); } catch (e) {} }
  }
  function hotAt(x, y) {
    var row = HOLD.id && rowById(HOLD.id), pk = row && row.querySelector('.picker');
    if (!pk) return null;
    var r = pk.getBoundingClientRect();
    if (x < r.left - 14 || x > r.right + 14 || y < r.top - 46 || y > r.bottom + 46) return null;
    var best = null, bd = 1e9, bs = pk.querySelectorAll('.rxb');
    for (var i = 0; i < bs.length; i++) {
      var q = bs[i].getBoundingClientRect(), d = Math.abs(x - (q.left + q.width / 2));
      if (d < bd && (y > q.top - 46 && y < q.bottom + 46)) { bd = d; best = bs[i]; }
    }
    return best;
  }
  document.addEventListener('pointerdown', function (ev) { HOLD.down = logEl.contains(ev.target); }, true);
  document.addEventListener('pointermove', function (ev) { if (HOLD.slide) setHot(hotAt(ev.clientX, ev.clientY)); }, { passive: true });
  function endSlide(cancel) {
    HOLD.down = false;
    if (!HOLD.slide) return;
    HOLD.slide = false;
    var b = HOLD.hot, id = HOLD.id; setHot(null);
    if (b && !cancel && id) setReaction(id, b.dataset.e);
  }
  document.addEventListener('pointerup', function () { endSlide(false); }, true);
  document.addEventListener('pointercancel', function () { endSlide(true); }, true);
  logEl.addEventListener('touchmove', function (ev) { if (HOLD.slide && ev.cancelable) ev.preventDefault(); }, { passive: false });
  function msgHold(id) {
    var m = state.msgs.find(function (x) { return x.id === id; });
    if (!m) return;
    state.confirm = null; state.open.add(id); state.picker = id;
    var row = rowById(id);
    if (row && !row.querySelector('.picker')) {
      var near = nearBottom(), mine = m.uid === state.me;
      var pk = freshPicker(pickerEl(reactionsOf(m)[state.me] || '', mine && !m.audio && !m.img && !m.file), id);
      row.classList.add('open');
      row.insertBefore(pk, row.querySelector('.meta'));
      if (near && logEl.scrollTo) logEl.scrollTo({ top: logEl.scrollHeight, behavior: 'smooth' });
    } else render();
    if (HOLD.down) { HOLD.slide = true; HOLD.id = id; SW.row = SW.bw = null; }
  }
  function lpCancel() { clearTimeout(LP.t); LP.t = null; if (LP.row) { LP.row.classList.remove('pressing'); LP.row = null; } }
  logEl.addEventListener('pointerdown', function (ev) {
    LP.fired = false; lpCancel();
    if (ev.pointerType === 'mouse' && ev.button !== 0) return;
    var t = ev.target, b = t.closest && t.closest('.bubble');
    if (!b || (t.closest('button, input') && !t.closest('.fcard'))) return;
    var row = b.closest('.row');
    if (!row) return;
    LP.x = ev.clientX; LP.y = ev.clientY; LP.row = row; row.classList.add('pressing');
    LP.t = setTimeout(function () {
      LP.t = null; LP.fired = true;
      if (LP.row) { LP.row.classList.remove('pressing'); LP.row = null; }
      try { if (navigator.vibrate) navigator.vibrate(18); } catch (e) {}
      msgHold(row.dataset.id);
    }, 380);
  });
  logEl.addEventListener('pointermove', function (ev) {
    if (LP.t && (Math.abs(ev.clientX - LP.x) > 10 || Math.abs(ev.clientY - LP.y) > 10)) lpCancel();
  });
  ['pointerup', 'pointercancel', 'pointerleave'].forEach(function (n) { logEl.addEventListener(n, lpCancel); });
  logEl.addEventListener('scroll', lpCancel, { passive: true });
  logEl.addEventListener('contextmenu', function (ev) {
    if (ev.target.closest && ev.target.closest('.bubble')) ev.preventDefault();
  });
  function closeMsgTools() {
    if (state.picker || state.open.size) {
      var pid = state.picker; state.picker = null; state.open.clear();
      if (pid) closePickerAnim(pid, '', render); else render();
    }
  }
  logEl.addEventListener('click', function (ev) {
    if (LP.fired) { LP.fired = false; return; }
    if (SW.done) { SW.done = false; return; }
    var t = ev.target;
    var qq = t.closest && t.closest('.quote');
    if (qq) { jumpTo(qq.dataset.q); return; }
    var row = t.closest && t.closest('.row');
    if (!row) { closeMsgTools(); return; }
    var id = row.dataset.id;
    if (t.closest('.vplay')) return;
    if (t.closest('.pimg')) { openPhoto(t.closest('.pimg').src); return; }
    var rb = t.closest('.rxb');
    if (rb) { setReaction(id, rb.dataset.e); return; }
    if (t.closest('.like')) { state.picker = state.picker === id ? null : id; render(); return; }
    if (t.closest('.edit')) { startEdit(id); return; }
    if (t.closest('.rpl')) { closeMsgTools(); setReply(id); return; }
    if (t.closest('.copy')) {
      var mm = state.msgs.find(function (x) { return x.id === id; });
      var btn = t.closest('.copy');
      if (mm && navigator.clipboard) {
        navigator.clipboard.writeText(mm.text).then(function () {
          btn.textContent = 'Copié ✓'; btn.classList.add('ok');
          setTimeout(function () { btn.textContent = 'Copier'; btn.classList.remove('ok'); }, 1500);
        }, function () {});
      }
      return;
    }
    if (t.closest('.del')) { delChoose(id); return; }
    closeMsgTools();
  });
