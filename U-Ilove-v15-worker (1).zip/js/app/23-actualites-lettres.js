/* U&I — js/app/23-actualites-lettres.js
   Actualités : lettres anonymes
   (fait partie de l’appli : assemblée par js/boot/loader.js dans une seule fermeture) */
  /* ---------- Actualités : lettres anonymes ---------- */
  var viewNews = $('#viewNews'), nwFeed = $('#nwFeed');
  var NWH = { shown: null, t0: 0, down: false, slide: false, key: '', hot: null }, NWSIG = {};
  var NW = { items: [], unsub: null, mineUnsub: null, mine: {}, id: null, uid: null, loaded: false, failed: false, last: 0, busy: false, open: {}, cm: {}, draft: {}, replyTo: {}, as: 'anon', cmLast: 0, pick: '', limit: 20 };
  var NW_ADJ = ['Discret', 'Curieux', 'Rêveur', 'Malin', 'Sauvage', 'Tranquille', 'Espiègle', 'Mystérieux', 'Rusé', 'Timide', 'Brave', 'Lunaire', 'Farouche', 'Sage', 'Fantasque', 'Nocturne', 'Pensif', 'Joyeux'];
  var NW_ANI = [['Renard', '🦊'], ['Hibou', '🦉'], ['Panda', '🐼'], ['Loup', '🐺'], ['Chat', '🐱'], ['Lynx', '🐆'], ['Dauphin', '🐬'], ['Koala', '🐨'], ['Faucon', '🦅'], ['Lapin', '🐰'], ['Cerf', '🦌'], ['Papillon', '🦋'], ['Tigre', '🐯'], ['Hérisson', '🦔'], ['Moineau', '🐦'], ['Lama', '🦙'], ['Castor', '🦫']];
  function nwRand(n) { var a = new Uint32Array(1); crypto.getRandomValues(a); return a[0] % n; }
  function nwMake() {
    var an = NW_ANI[nwRand(NW_ANI.length)];
    return { name: an[0] + ' ' + NW_ADJ[nwRand(NW_ADJ.length)] + ' ' + (10 + nwRand(90)), emoji: an[1], hue: nwRand(360) };
  }
  function nwAv(node, o) {
    node.textContent = o.emoji || '👤';
    node.style.background = 'hsl(' + (o.hue || 0) + ' 65% 55% / .28)';
  }
  function nwErr(t) { var e = $('#nwErr'); e.textContent = t || ''; e.hidden = !t; }
  function nwSaveId() {
    try { localStorage.setItem('uandi-anon:' + state.me, JSON.stringify(NW.id)); } catch (e) {}
    fs.collection('anonProfiles').doc(state.me).set(NW.id).catch(function () {});
  }
  function nwIdentity() {
    if (NW.id) return Promise.resolve(NW.id);
    var raw = null;
    try { raw = JSON.parse(localStorage.getItem('uandi-anon:' + state.me) || 'null'); } catch (e) {}
    if (raw && raw.name && raw.emoji) { NW.id = raw; return Promise.resolve(raw); }
    return fs.collection('anonProfiles').doc(state.me).get()
      .then(function (d) { return d.exists && d.data().name ? d.data() : null; }, function () { return null; })
      .then(function (x) { NW.id = x || nwMake(); nwSaveId(); return NW.id; });
  }
  function nwPaintId() {
    if (!NW.id) return;
    nwAv($('#nwIdAv'), NW.id);
    $('#nwIdName').textContent = NW.id.name;
  }
  function nwStop() {
    if (NW.unsub) NW.unsub();
    if (NW.mineUnsub) NW.mineUnsub();
    NW.unsub = null; NW.mineUnsub = null; NW.items = []; NW.mine = {}; NW.id = null; NW.uid = null;
    NW.loaded = false; NW.failed = false; NW.last = 0;
    Object.keys(NW.cm).forEach(function (k) { if (NW.cm[k].unsub) NW.cm[k].unsub(); }); NW.cm = {}; NW.open = {};
    atStop();
    if (window.__tdStop) window.__tdStop();
    if (nwFeed) nwFeed.textContent = '';
  }
  function nwAgo(ts) {
    var s = Math.max(0, (Date.now() - ts) / 1000);
    if (s < 60) return 'à l’instant';
    if (s < 3600) return Math.floor(s / 60) + ' min';
    if (s < 86400) return Math.floor(s / 3600) + ' h';
    return Math.floor(s / 86400) + ' j';
  }
  function nwCount(o) { var n = 0, k; o = o || {}; for (k in o) { if (o[k]) n++; } return n; }
  /* réactions (plusieurs emojis) sur les lettres et les commentaires */
  var NWRX = ['❤️', '😂', '😮', '😢', '👍', '🔥'];
  function nwRxOf(o) {
    var out = {}, l = o.likes, r = o.reacts;
    if (l && typeof l === 'object') Object.keys(l).forEach(function (k) { if (l[k] === true) out[k] = NWRX[0]; });
    if (r && typeof r === 'object') Object.keys(r).forEach(function (k) { if (typeof r[k] === 'string' && r[k]) out[k] = r[k]; });
    return out;
  }
  function nwRxBtn(o, key, ref) {
    var rx = nwRxOf(o), n = Object.keys(rx).length, mineR = rx[state.me] || '';
    var sg = n ? rxSummary(rx) : '';
    var b = el('button', 'vact rxbtn' + (NWSIG[key] !== undefined && NWSIG[key] !== sg ? ' pop' : ''), n ? sg : '♡ Réagir'); NWSIG[key] = sg; b.type = 'button';
    b.setAttribute('aria-pressed', mineR ? 'true' : 'false'); b.setAttribute('aria-label', 'Réagir (maintenir pour choisir)');
    b.style.cssText = '-webkit-user-select:none;user-select:none;-webkit-touch-callout:none;touch-action:manipulation';
    /* maintenir = choisir une réaction ; simple appui = ❤️ (ou retirer ma réaction) */
    var t = null, fired = false, x0 = 0, y0 = 0;
    function cancel() { clearTimeout(t); t = null; b.classList.remove('pressing'); }
    b.addEventListener('pointerdown', function (ev) {
      fired = false; cancel();
      if (ev.pointerType === 'mouse' && ev.button !== 0) return;
      x0 = ev.clientX; y0 = ev.clientY; b.classList.add('pressing');
      t = setTimeout(function () {
        t = null; fired = true;
        try { if (navigator.vibrate) navigator.vibrate(18); } catch (e) {}
        b.classList.remove('pressing'); NWH.slide = NWH.down; NWH.key = key;
        NW.pick = key; nwRender();
      }, 380);
    });
    b.addEventListener('pointermove', function (ev) { if (t && (Math.abs(ev.clientX - x0) > 10 || Math.abs(ev.clientY - y0) > 10)) cancel(); });
    ['pointerup', 'pointercancel', 'pointerleave'].forEach(function (nm) { b.addEventListener(nm, cancel); });
    b.addEventListener('contextmenu', function (ev) { ev.preventDefault(); });
    b.addEventListener('click', function () {
      if (fired) { fired = false; return; }
      if (NW.pick === key) { NW.pick = ''; nwRender(); return; }
      if (!ref) return;
      nwReact(ref, o, mineR ? mineR : NWRX[0]);
    });
    return b;
  }
  function nwReact(ref, o, e) {
    var cur = nwRxOf(o)[state.me] || '', p = {};
    p['reacts.' + state.me] = cur === e ? firebase.firestore.FieldValue.delete() : e;
    if (o.likes && o.likes[state.me]) p['likes.' + state.me] = false;
    ref.update(p).catch(function () { nwErr('Réaction impossible (connexion ou règles Firestore).'); });
  }
  function nwPickEl(o, ref) {
    var box = el('div', 'nwpick'), cur = nwRxOf(o)[state.me] || '';
    NWRX.forEach(function (e) {
      var b = el('button', 'vact', e); b.type = 'button'; b.setAttribute('aria-pressed', cur === e ? 'true' : 'false');
      b._pick = function () { NW.pick = ''; nwReact(ref, o, e); nwRender(); };
      b._go = function () {
        if (box.dataset.busy) return; box.dataset.busy = '1';
        b.classList.add('chosen'); box.classList.remove('fresh'); box.classList.add('out');
        try { if (navigator.vibrate) navigator.vibrate(8); } catch (x) {}
        setTimeout(b._pick, 190);
      };
      b.addEventListener('click', b._go);
      box.appendChild(b);
    });
    return box;
  }
  function nwFresh(box, key) {
    var n = Date.now();
    if (NWH.shown !== key) { NWH.shown = key; NWH.t0 = n; }
    var age = n - NWH.t0;
    if (age < 450) {
      box.classList.add('fresh'); box.style.setProperty('--el', age + 'ms');
      for (var i = 0; i < box.children.length; i++) box.children[i].style.setProperty('--k', i);
    }
    return box;
  }
  function nwSetHot(b) {
    if (NWH.hot === b) return;
    if (NWH.hot) NWH.hot.classList.remove('hot');
    NWH.hot = b;
    if (b) { b.classList.add('hot'); try { if (navigator.vibrate) navigator.vibrate(6); } catch (e) {} }
  }
  function nwHotAt(x, y) {
    var box = nwFeed.querySelector('.nwpick');
    if (!box) return null;
    var r = box.getBoundingClientRect();
    if (x < r.left - 14 || x > r.right + 14 || y < r.top - 46 || y > r.bottom + 46) return null;
    var best = null, bd = 1e9, bs = box.children;
    for (var i = 0; i < bs.length; i++) {
      var q = bs[i].getBoundingClientRect(), d = Math.abs(x - (q.left + q.width / 2));
      if (d < bd && y > q.top - 46 && y < q.bottom + 46) { bd = d; best = bs[i]; }
    }
    return best;
  }
  document.addEventListener('pointerdown', function (ev) { NWH.down = !!(ev.target.closest && ev.target.closest('#nwFeed')); }, true);
  document.addEventListener('pointermove', function (ev) { if (NWH.slide) nwSetHot(nwHotAt(ev.clientX, ev.clientY)); }, { passive: true });
  function nwEndSlide(cancel) {
    NWH.down = false;
    if (!NWH.slide) return;
    NWH.slide = false;
    var b = NWH.hot; nwSetHot(null);
    if (b && !cancel && b._go) b._go();
  }
  document.addEventListener('pointerup', function () { nwEndSlide(false); }, true);
  document.addEventListener('pointercancel', function () { nwEndSlide(true); }, true);
  nwFeed.addEventListener('touchmove', function (ev) { if (NWH.slide && ev.cancelable) ev.preventDefault(); }, { passive: false });
  var nwRaf = 0;
  function nwRender() {
    if (nwRaf) return;
    nwRaf = requestAnimationFrame(function () { nwRaf = 0; nwRenderNow(); });
  }
  function nwRenderNow() {
    if (!nwFeed) return;
    var fo = document.activeElement, foId = fo && fo.dataset && fo.dataset.lid;
    var keepTop = nwFeed.scrollTop; /* on garde la position : vider le fil la remettait tout en haut */
    if (!NW.pick) NWH.shown = null;
    nwFeed.textContent = '';
    if (!NW.loaded) { nwFeed.appendChild(el('p', 'hint', 'Chargement…')); return; }
    if (NW.failed) { nwFeed.appendChild(el('p', 'hint', 'Impossible de charger les lettres (règles Firestore : autorise la collection « letters »).')); return; }
    var creator = creatorOn();
    var list = NW.items.filter(function (it) { return creator || NW.mine[it.id] || nwCount(it.reports) < 3; });
    list = list.slice().sort(function (a, b) { return (b.pin === true) - (a.pin === true); });
    if (typeof crDlg !== 'undefined' && crDlg.open && CR.mode === 'mod') crRender();
    if (!list.length) { nwFeed.appendChild(el('p', 'hint', 'Aucune lettre pour l’instant. Écris la première !')); return; }
    var nwTotal = list.length, nwLim = NW.limit || 20;
    list = list.slice(0, nwLim);
    list.forEach(function (it) {
      var mine = !!NW.mine[it.id], nrep = nwCount(it.reports), likes = it.likes || {}, liked = !!likes[state.me], nl = nwCount(likes);
      var card = el('article', 'nwcard' + (nrep >= 3 ? ' nwflag' : '')); card.dataset.id = it.id;
      var head = el('div', 'nwhead'), av = el('span', 'nwav'), who = el('div', 'nwwho');
      nwAv(av, it);
      var lnm = el('b', null, it.alias || 'Anonyme');
      who.appendChild(lnm);
      who.appendChild(el('small', null, nwAgo(it.ts || 0)));
      if (it.pin === true) who.appendChild(el('small', 'nwpin', '📌 Épinglée'));
      head.appendChild(av); head.appendChild(who);
      card.appendChild(head);
      if (!(it.img && it.text === '📷 Photo')) card.appendChild(el('p', 'nwtext', it.text || ''));
      if (typeof it.img === 'string' && it.img.indexOf(CLD_BASE) === 0) {
        var pim = el('img', 'nwimg'); pim.src = it.img; pim.loading = 'lazy'; pim.alt = 'Photo anonyme'; pim.referrerPolicy = 'no-referrer';
        pim.addEventListener('click', function () {
          var lb = el('div', 'nw-lb'), li = el('img'), lx = el('button', null, '✖'); li.src = it.img; li.alt = 'Photo anonyme'; lx.type = 'button'; lx.setAttribute('aria-label', 'Fermer');
          lb.appendChild(li); lb.appendChild(lx); lb.addEventListener('click', function () { lb.remove(); }); document.body.appendChild(lb);
        });
        card.appendChild(pim);
      }
      if (nrep >= 3) card.appendChild(el('small', 'nwflagtxt', 'Masquée pour les autres : signalée ' + nrep + ' fois'));
      var acts = el('div', 'nwacts');
      acts.appendChild(nwRxBtn(it, 'l:' + it.id, fs.collection('letters').doc(it.id)));
      if (!mine) {
        var done = !!(it.reports && it.reports[state.me]);
        var rp = el('button', 'vact', done ? 'Signalée' : 'Signaler');
        rp.type = 'button'; rp.disabled = done;
        rp.addEventListener('click', function () { nwReport(it); });
        acts.appendChild(rp);
      }
      if (mine || creator) {
        var dl = el('button', 'vact vd', 'Supprimer');
        dl.type = 'button';
        dl.addEventListener('click', function () { nwDelete(it); });
        acts.appendChild(dl);
      }
      if (creator) {
        var pb = el('button', 'vact', it.pin === true ? 'Désépingler' : 'Épingler'); pb.type = 'button';
        pb.addEventListener('click', function () {
          fs.collection('letters').doc(it.id).update({ pin: it.pin === true ? firebase.firestore.FieldValue.delete() : true })
            .catch(function () { nwErr('Épinglage impossible (règles Firestore : le créateur doit pouvoir modifier « letters »).'); });
        });
        acts.appendChild(pb);
      }
      var cmb = el('button', 'vact', '💬 Commenter' + (nwNb(it) ? ' (' + nwNb(it) + ')' : ''));
      cmb.type = 'button'; cmb.setAttribute('aria-pressed', NW.open[it.id] ? 'true' : 'false');
      cmb.addEventListener('click', function () { nwCmToggle(it); });
      acts.appendChild(cmb);
      if (!mine) {
        var dc = el('button', 'vact', '🎭 Discuter');
        dc.type = 'button';
        dc.addEventListener('click', function () { atStart(it.id, { name: it.alias, emoji: it.emoji, hue: it.hue }); });
        acts.appendChild(dc);
      }
      if (NW.pick === 'l:' + it.id) acts.appendChild(nwFresh(nwPickEl(it, fs.collection('letters').doc(it.id)), 'l:' + it.id));
      card.appendChild(acts);
      if (NW.open[it.id] && NW.cm[it.id]) card.appendChild(nwCmBox(it));
      nwFeed.appendChild(card);
    });
    if (nwTotal > list.length) {
      var more = el('button', 'nwpost nwmore', 'Afficher plus (' + Math.min(20, nwTotal - list.length) + ' de plus)'); more.type = 'button';
      more.addEventListener('click', function () { NW.limit = (NW.limit || 20) + 20; nwRender(); });
      nwFeed.appendChild(more);
    }
    nwFeed.scrollTop = keepTop;
    if (foId) { var nf = nwFeed.querySelector('input[data-lid="' + foId + '"]'); if (nf) { nf.focus(); try { nf.setSelectionRange(nf.value.length, nf.value.length); } catch (e) {} } }
  }
  var _nwRenderNow0 = nwRenderNow;
  nwRenderNow = function () {
    var t = nwFeed ? nwFeed.scrollTop : 0;
    _nwRenderNow0();
    if (window.__tdPosts) window.__tdPosts();
    if (nwFeed) nwFeed.scrollTop = t;
  };
  function nwListen() {
    if (window.__tdStart) window.__tdStart();
    if (NW.unsub) return;
    NW.unsub = fs.collection('letters').orderBy('ts', 'desc').limit(100).onSnapshot(function (snap) {
      NW.items = snap.docs.map(function (d) { var v = d.data(); v.id = d.id; return v; });
      NW.loaded = true; NW.failed = false; nwRender();
    }, function () { NW.loaded = true; NW.failed = true; nwRender(); });
    NW.mineUnsub = fs.collection('letterOwners').where('uid', '==', state.me).onSnapshot(function (snap) {
      NW.mine = {}; snap.forEach(function (d) { NW.mine[d.id] = true; }); nwRender(); atWatch();
    }, function () {});
  }
  function nwLike(it) {
    var p = {}; p['likes.' + state.me] = !(it.likes && it.likes[state.me]);
    fs.collection('letters').doc(it.id).update(p).catch(function () { nwErr('Action impossible (connexion ou règles Firestore).'); });
  }
  function nwReport(it) {
    if (!confirm('Signaler cette lettre ? Elle sera masquée après plusieurs signalements.')) return;
    var p = {}; p['reports.' + state.me] = true;
    fs.collection('letters').doc(it.id).update(p).catch(function () { nwErr('Signalement impossible (connexion ou règles Firestore).'); });
  }
  function nwDelete(it) {
    if (!confirm('Supprimer cette lettre ?')) return;
    fs.collection('letters').doc(it.id).delete()
      .then(function () { fs.collection('letterOwners').doc(it.id).delete().catch(function () {}); })
      .catch(function () { nwErr('Suppression impossible (connexion ou règles Firestore).'); });
  }
  /* photo anonyme : redimensionnée et ré-encodée dans un canvas (supprime les métadonnées EXIF : position GPS, appareil…) */
  function nwPhotoClear() { NW.photo = null; var p = $('#nwPrev'); if (p) p.hidden = true; var f = $('#nwFile'); if (f) f.value = ''; }
  function nwPhotoPick(file) {
    nwErr('');
    if (!file) return;
    if (!/^image\//.test(file.type)) { nwErr('Choisis une image.'); return; }
    var url = URL.createObjectURL(file), im = new Image();
    im.onload = function () {
      try {
        var M = 1280, sc = Math.min(1, M / Math.max(im.width, im.height)), c = document.createElement('canvas');
        c.width = Math.max(1, Math.round(im.width * sc)); c.height = Math.max(1, Math.round(im.height * sc));
        c.getContext('2d').drawImage(im, 0, 0, c.width, c.height);
        NW.photo = c.toDataURL('image/jpeg', 0.82);
        $('#nwPrevImg').src = NW.photo; $('#nwPrev').hidden = false;
      } catch (e) { nwErr('Photo illisible.'); }
      URL.revokeObjectURL(url);
    };
    im.onerror = function () { URL.revokeObjectURL(url); nwErr('Photo illisible.'); };
    im.src = url;
  }
  async function nwPublish() {
    var ta = $('#nwText'), text = ta.value.trim(), btn = $('#nwPost');
    nwErr('');
    if (banGuard()) return;
    if (NW.busy) return;
    if (text.length < 3 && !NW.photo) { nwErr('Écris au moins quelques mots ou ajoute une photo.'); return; }
    if (Date.now() - NW.last < 30000) { nwErr('Patiente quelques secondes avant de publier une autre lettre.'); return; }
    NW.busy = true; btn.disabled = true;
    try {
      var id = await nwIdentity();
      var imgUrl = '';
      if (NW.photo) {
        var up = await cloudUp(NW.photo, 'image');
        if (!up) { nwErr('Envoi de la photo impossible' + (CLD_ERR ? ' (' + CLD_ERR + ')' : '') + '. Réessaie.'); NW.busy = false; btn.disabled = false; return; }
        imgUrl = up;
      }
      var ref = fs.collection('letters').doc(), b = fs.batch(), ts = Date.now();
      var ldata = { alias: id.name, emoji: id.emoji, hue: id.hue, text: (text || '📷 Photo').slice(0, 600), ts: ts, likes: {}, reports: {} };
      if (imgUrl) ldata.img = imgUrl;
      b.set(ref, ldata);
      b.set(fs.collection('letterOwners').doc(ref.id), { uid: state.me, ts: ts });
      await b.commit();
      ta.value = ''; $('#nwCount').textContent = '0 / 600'; NW.last = ts; nwPhotoClear(); pushNews(text || '📷 Photo');
    } catch (e) { nwErr('Publication impossible (règles Firestore : voir « letters » et « letterOwners »).'); }
    NW.busy = false; btn.disabled = false;
  }
