/* U&I — js/app/06-epingles-anniversaires-code.js
   Épingler, amis proches, anniversaires, verrouillage par code
   (fait partie de l’appli : assemblée par js/boot/loader.js dans une seule fermeture) */
  /* ---------- épingler, amis proches, anniversaires, notification d'ami, verrouillage ---------- */
  function lsGet(k, d) { try { return JSON.parse(localStorage.getItem(k) || 'null') || d; } catch (e) { return d; } }
  function lsSet(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} }
  function pinList() { return lsGet('uandi-pin-' + state.me, []); }
  function isPinned(id) { return pinList().indexOf(id) !== -1; }
  function paintPin() { var b = $('#pinChat'); if (b && state.chat) b.textContent = isPinned(state.chat.id) ? 'Désépingler' : 'Épingler'; }
  $('#pinChat').addEventListener('click', function () {
    if (!state.chat) return;
    var l = pinList(), i = l.indexOf(state.chat.id);
    if (i === -1) l.push(state.chat.id); else l.splice(i, 1);
    lsSet('uandi-pin-' + state.me, l); $('#chatMenu').hidden = true; paintPin();
  });
  function closeList() { return lsGet('uandi-close-' + state.me, []); }
  function isClose(u) { return closeList().indexOf(u) !== -1; }
  $('#ucStar').addEventListener('click', function () {
    if (!ucT) return;
    var l = closeList(), i = l.indexOf(ucT.uid);
    if (i === -1) l.push(ucT.uid); else l.splice(i, 1);
    lsSet('uandi-close-' + state.me, l); ucRender();
  });
  ['❤️', '😂', '😮', '😢', '👍', '🔥'].forEach(function (e) {
    var b = el('button', '', e); b.type = 'button'; b.setAttribute('aria-label', 'Réagir ' + e);
    b.addEventListener('click', function () { sendNoteReply(e); });
    $('#nvReacts').appendChild(b);
  });
  function notifyFriendReq(v) {
    var nm = (v.names && v.names[v.from]) || 'Quelqu’un';
    if (!npOn('friends')) return;
    var loud = fx();
    if (document.hidden) sysNotify(nm, 'veut devenir ton ami', 'friends', !loud); else { showToast(null, nm, 'veut devenir ton ami'); toastFr = true; }
  }
  /* anniversaires */
  var MOIS = ['janvier', 'février', 'mars', 'avril', 'mai', 'juin', 'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre'];
  function bdayDays(md) {
    var m = +md.slice(0, 2), d = +md.slice(3, 5), now = new Date(), t0 = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    var n = new Date(now.getFullYear(), m - 1, d); if (n < t0) n = new Date(now.getFullYear() + 1, m - 1, d);
    return Math.round((n - t0) / 864e5);
  }
  function bdayLabel(md) { return 'le ' + (+md.slice(3, 5)) + ' ' + MOIS[(+md.slice(0, 2)) - 1]; }
  function bdayList() {
    var out = [];
    frAll().forEach(function (f) {
      var u = frOther(f), md = FR.pres[u] && FR.pres[u].bday;
      if (md && /^\d\d-\d\d$/.test(md)) out.push({ u: u, nm: frNameOf(f), md: md, days: bdayDays(md) });
    });
    return out.sort(function (a, b) { return a.days - b.days; });
  }
  function bdayPaint() {
    var bar = $('#bdayBar'); if (!bar) return;
    var t = bdayList().filter(function (x) { return x.days === 0; });
    var done = ''; try { done = localStorage.getItem('uandi-bdx') || ''; } catch (e) {}
    bar.hidden = !t.length || done === new Date().toDateString();
    if (t.length) $('#bdayTxt').textContent = '🎂 Aujourd’hui, c’est l’anniversaire de ' + t.map(function (x) { return cap(x.nm); }).join(', ') + ' !';
  }
  $('#bdayX').addEventListener('click', function () { try { localStorage.setItem('uandi-bdx', new Date().toDateString()); } catch (e) {} bdayPaint(); });
  (function () {
    var d = $('#bdD'), m = $('#bdM'), i;
    d.appendChild(new Option('Jour', ''));
    for (i = 1; i <= 31; i++) d.appendChild(new Option(String(i), String(i)));
    m.appendChild(new Option('Mois', ''));
    MOIS.forEach(function (n, k) { m.appendChild(new Option(n, String(k + 1))); });
  })();
  function bdPaint() {
    var md = notePres[state.me] && notePres[state.me].bday;
    $('#bdD').value = md ? String(+md.slice(3, 5)) : ''; $('#bdM').value = md ? String(+md.slice(0, 2)) : '';
  }
  $('#bdSave').addEventListener('click', function () {
    var d = +$('#bdD').value, m = +$('#bdM').value; if (!d || !m) return;
    fs.collection('presence').doc(state.me).set({ bday: ('0' + m).slice(-2) + '-' + ('0' + d).slice(-2) }, { merge: true }).catch(function () {});
  });
  $('#bdDel').addEventListener('click', function () {
    $('#bdD').value = ''; $('#bdM').value = '';
    fs.collection('presence').doc(state.me).set({ bday: firebase.firestore.FieldValue.delete() }, { merge: true }).catch(function () {});
  });
  /* verrouillage : code à 4 chiffres + empreinte (WebAuthn) */
  var LK = { mode: '', buf: '', first: '', cb: null, hiddenAt: 0 }, lockDlg = $('#lockDlg');
  function lkData() { return lsGet('uandi-lock-' + state.me, null); }
  function lkOn() { return !!state.me && !!lkData(); }
  function lkBioId() { try { return localStorage.getItem('uandi-lockbio-' + state.me); } catch (e) { return null; } }
  function lkBioOk() { return !!(window.PublicKeyCredential && navigator.credentials && window.isSecureContext); }
  function lkErr(t) { var e = $('#lkErr'); e.textContent = t || ''; e.hidden = !t; }
  function lkDraw() { var d = $('#lkDots'); d.replaceChildren(); for (var i = 0; i < 4; i++) d.appendChild(el('i', i < LK.buf.length ? 'on' : '')); }
  function lkOpen(mode, cb) {
    LK.mode = mode; LK.buf = ''; LK.cb = cb || null; lkErr('');
    var T = { unlock: ['Verrouillé', 'Entre ton code'], new1: ['Nouveau code', 'Choisis un code à 4 chiffres'], new2: ['Confirme', 'Entre le même code'], verify: ['Code actuel', 'Entre ton code pour continuer'] }[mode];
    $('#lkTitle').textContent = T[0]; $('#lkSub').textContent = T[1];
    $('#lkCancel').hidden = mode === 'unlock'; $('#lkForgot').hidden = mode !== 'unlock';
    $('#lkBio').hidden = !(mode === 'unlock' && lkBioId() && lkBioOk());
    lkDraw();
    if (!lockDlg.open) lockDlg.showModal();
    if (mode === 'unlock' && lkBioId() && lkBioOk()) setTimeout(lkBio, 350);
  }
  function lkCheck() { if (lkOn() && LK.mode !== 'unlock') lkOpen('unlock'); }
  function lkClose() { LK.mode = ''; if (lockDlg.open) lockDlg.close(); lkPaint(); }
  async function lkDone() {
    var pin = LK.buf, md = LK.mode, dat = lkData();
    if (md === 'unlock' || md === 'verify') {
      var h = dat ? await sha256(dat.salt + ':' + pin) : '';
      if (dat && h === dat.hash) { var cb = LK.cb; LK.cb = null; if (md === 'verify' && cb) cb(); else lkClose(); }
      else { LK.buf = ''; lkDraw(); lkErr('Code incorrect.'); try { if (navigator.vibrate) navigator.vibrate(200); } catch (e) {} }
    } else if (md === 'new1') { LK.first = pin; lkOpen('new2'); }
    else if (md === 'new2') {
      if (pin !== LK.first) { lkOpen('new1'); lkErr('Les deux codes sont différents.'); return; }
      var salt = Math.random().toString(36).slice(2) + Date.now().toString(36);
      lsSet('uandi-lock-' + state.me, { salt: salt, hash: await sha256(salt + ':' + pin) });
      lkClose();
    }
  }
  function lkPress(k) {
    if (k === 'del') LK.buf = LK.buf.slice(0, -1);
    else if (LK.buf.length < 4) LK.buf += k;
    lkErr(''); lkDraw();
    if (LK.buf.length === 4) setTimeout(lkDone, 120);
  }
  ['1', '2', '3', '4', '5', '6', '7', '8', '9', '', '0', 'del'].forEach(function (k) {
    var b = el('button', '', k === 'del' ? '⌫' : k); b.type = 'button';
    if (k) b.addEventListener('click', function () { lkPress(k); });
    $('#lkPad').appendChild(b);
  });
  lockDlg.addEventListener('keydown', function (e) { if (/^\d$/.test(e.key)) lkPress(e.key); else if (e.key === 'Backspace') lkPress('del'); });
  lockDlg.addEventListener('cancel', function (e) { if (LK.mode === 'unlock') e.preventDefault(); else LK.mode = ''; });
  $('#lkCancel').addEventListener('click', lkClose);
  $('#lkForgot').addEventListener('click', function () {
    if (!confirm('Se déconnecter et retirer le verrou ? Tu devras te reconnecter avec ton mot de passe.')) return;
    try { localStorage.removeItem('uandi-lock-' + state.me); localStorage.removeItem('uandi-lockbio-' + state.me); } catch (e) {}
    lkClose(); auth.signOut();
  });
  async function lkBio() {
    var raw = lkBioId(); if (!raw || !lkBioOk()) return;
    try {
      await navigator.credentials.get({ publicKey: { challenge: crypto.getRandomValues(new Uint8Array(32)), allowCredentials: [{ type: 'public-key', id: unb64(raw) }], userVerification: 'preferred', timeout: 60000 } });
      if (LK.mode === 'unlock') lkClose();
    } catch (e) {}
  }
  $('#lkBio').addEventListener('click', lkBio);
  function lkPaint() {
    var on = lkOn(), bio = !!lkBioId();
    $('#lockState').textContent = on ? 'Code activé' + (bio ? ' · empreinte activée' : '') + '. L’appli se verrouille après 30 s en arrière-plan.' : 'Désactivé. Protège l’appli avec un code (et l’empreinte si ton téléphone le permet).';
    $('#lockSet').textContent = on ? 'Changer le code' : 'Définir un code';
    $('#lockOff').hidden = !on; $('#lockBio').hidden = !(on && !bio && lkBioOk());
  }
  $('#lockSet').addEventListener('click', function () { $('#lockErr').hidden = true; if (lkOn()) lkOpen('verify', function () { lkOpen('new1'); }); else lkOpen('new1'); });
  $('#lockOff').addEventListener('click', function () {
    lkOpen('verify', function () {
      try { localStorage.removeItem('uandi-lock-' + state.me); localStorage.removeItem('uandi-lockbio-' + state.me); } catch (e) {}
      lkClose();
    });
  });
  $('#lockBio').addEventListener('click', async function () {
    var err = $('#lockErr'); err.hidden = true;
    try {
      if (window.PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable && !(await PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable())) {
        err.textContent = 'Aucune empreinte ni verrouillage d’écran détecté sur ce téléphone. Active-en un dans les réglages du téléphone, puis réessaie.'; err.hidden = false; return;
      }
    } catch (x) {}
    try {
      var cred = await navigator.credentials.create({ publicKey: { challenge: crypto.getRandomValues(new Uint8Array(32)), rp: { name: 'U&I' }, user: { id: crypto.getRandomValues(new Uint8Array(16)), name: state.username, displayName: state.username }, pubKeyCredParams: [{ type: 'public-key', alg: -7 }, { type: 'public-key', alg: -257 }], authenticatorSelection: { authenticatorAttachment: 'platform', userVerification: 'preferred', residentKey: 'discouraged' }, attestation: 'none', timeout: 60000 } });
      localStorage.setItem('uandi-lockbio-' + state.me, b64(new Uint8Array(cred.rawId)));
      lkPaint();
    } catch (e) {
      var nm = (e && e.name) || '';
      err.textContent = nm === 'NotAllowedError' ? 'Empreinte refusée ou annulée. Vérifie que ton téléphone a une empreinte ou un verrouillage d’écran activé, puis réessaie.'
        : (nm === 'NotSupportedError' || nm === 'SecurityError') ? 'Non disponible ici : ouvre le site directement dans Chrome (https), pas dans une fenêtre intégrée ou une autre appli.'
        : 'Empreinte non activée (' + (nm || 'erreur') + ').';
      err.hidden = false;
    }
  });
  document.addEventListener('visibilitychange', function () {
    if (!state.me) return;
    if (document.hidden) LK.hiddenAt = Date.now();
    else if (lkOn() && LK.hiddenAt && Date.now() - LK.hiddenAt > 30000 && LK.mode !== 'unlock') lkOpen('unlock');
  });

  /* fiche d'une personne trouvée : ami, invitation par message, discussion */
  function ucChat(uid) { return state.chats.filter(function (x) { return !x.group && (x.members || []).indexOf(uid) !== -1; })[0] || null; }
  function openUserCard(uid, name) {
    ucT = { uid: uid, name: name };
    $('#ucErr').hidden = true; $('#ucMsgBox').hidden = true; $('#ucMsgIn').value = '';
    ucRender(); ucDlg.showModal();
  }
  function ucRender() {
    if (!ucT) return;
    var uid = ucT.uid, name = ucT.name, f = frWith(uid), c = ucChat(uid);
    paintPhoto($('#ucAv'), uid, name); loadPhoto(uid);
    $('#ucName').textContent = cap(name); ensureBadge(uid); withBadge($('#ucName'), uid);
    var fb = $('#ucFriend'), ob = $('#ucOpen'), mb = $('#ucMsg');
    fb.disabled = !!(f && f.implicit);
    if (!f) { fb.textContent = '➕ Ajouter en ami'; fb.dataset.a = 'add'; }
    else if (f.implicit) { fb.textContent = '✓ Amis'; fb.dataset.a = 'none'; }
    else if (f.status === 'accepted') { fb.textContent = '✓ Amis · Retirer'; fb.dataset.a = 'rm'; }
    else if (f.from === state.me) { fb.textContent = 'Demande envoyée · Annuler'; fb.dataset.a = 'rm'; }
    else { fb.textContent = '✓ Accepter sa demande d’ami'; fb.dataset.a = 'acc'; }
    $('#ucSub').textContent = f && f.status === 'accepted' ? (isOnline(uid) ? '● En ligne' : 'Ami · hors ligne') : '';
    var sb = $('#ucStar'); sb.hidden = !(f && f.status === 'accepted'); sb.textContent = isClose(uid) ? '⭐ Retirer des amis proches' : '⭐ Ajouter aux amis proches';
    var showOpen = (f && f.status === 'accepted') || !!c;
    ob.hidden = !showOpen; mb.hidden = showOpen; if (showOpen) $('#ucMsgBox').hidden = true;
    if (c && invitePending(c)) { ob.textContent = '✉️ Voir son invitation'; ob.dataset.a = 'inv'; }
    else { ob.textContent = c && c.invite ? '💬 Ouvrir (invitation en attente)' : '💬 Écrire'; ob.dataset.a = 'chat'; }
  }
  function ucFail() { var e = $('#ucErr'); e.textContent = 'Impossible : ajoute la règle Firestore « friendships » (connexion à vérifier aussi).'; e.hidden = false; }
  $('#ucFriend').addEventListener('click', function () {
    var t = ucT; if (!t) return;
    var a = this.dataset.a, f = frWith(t.uid);
    if (a === 'add') {
      var names = {}; names[state.me] = state.username; names[t.uid] = t.name;
      frDoc(t.uid).set({ members: [state.me, t.uid], names: names, from: state.me, status: 'pending', ts: Date.now() }).catch(ucFail);
    } else if (a === 'acc') frDoc(t.uid).update({ status: 'accepted', ats: Date.now() }).catch(ucFail);
    else if (a === 'rm') {
      if (f && f.status === 'accepted' && !confirm('Retirer ' + cap(t.name) + ' de tes amis ?')) return;
      frDoc(t.uid).delete().catch(ucFail);
    }
  });
  $('#ucOpen').addEventListener('click', function () {
    var t = ucT; if (!t) return;
    ucDlg.close();
    if (this.dataset.a === 'inv') frOpen('req'); else openChat(t.uid, t.name);
  });
  $('#ucMsg').addEventListener('click', function () { $('#ucMsgBox').hidden = false; $('#ucMsgIn').focus(); });
  async function ucInvite() {
    var t = ucT, inp = $('#ucMsgIn'), text = inp.value.trim(), err = $('#ucErr'), btn = $('#ucMsgSend');
    if (!t || !text) return;
    err.hidden = true; btn.disabled = true;
    try {
      var cid = chatIdFor(state.me, t.uid), ref = fs.collection('chats').doc(cid), ts = Date.now();
      if (!(await ref.get()).exists) {
        var names = {}; names[state.me] = myName(); names[t.uid] = t.name;
        var seen = {}; seen[state.me] = ts;
        var b = fs.batch();
        b.set(ref, { members: [state.me, t.uid], names: names, lastText: text.slice(0, 120), lastTs: ts, lastUid: state.me, seen: seen, invite: { from: state.me, n: 1, st: 'pending' } });
        b.set(ref.collection('messages').doc(), { uid: state.me, sts: SV(), text: text.slice(0, 2000), ts: ts });
        await b.commit();
        state.chatsById[cid] = true;
      }
      inp.value = ''; ucDlg.close(); openChat(t.uid, t.name);
    } catch (e) { err.textContent = 'Invitation non envoyée (connexion ou règles Firestore).'; err.hidden = false; }
    btn.disabled = false;
  }
  $('#ucMsgSend').addEventListener('click', ucInvite);
  $('#ucMsgIn').addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); ucInvite(); } });
  $('#ucClose').addEventListener('click', function () { ucDlg.close(); });
  [frDlg, ucDlg].forEach(function (d) { d.addEventListener('click', function (e) { if (e.target === d) d.close(); }); });

