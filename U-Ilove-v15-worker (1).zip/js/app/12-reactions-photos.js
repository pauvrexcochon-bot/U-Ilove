/* U&I — js/app/12-reactions-photos.js
   Réactions, modification de messages, photos
   (fait partie de l’appli : assemblée par js/boot/loader.js dans une seule fermeture) */
  /* ---------- réactions et modification de messages ---------- */
  var RX = ['❤️', '👍', '😂', '😮', '😢', '🙏'];
  function reactionsOf(m) {
    var out = {}, l = m.likes, r = m.reacts;
    if (l && typeof l === 'object') Object.keys(l).forEach(function (k) { if (l[k] === true) out[k] = RX[0]; });
    if (r && typeof r === 'object') Object.keys(r).forEach(function (k) { if (typeof r[k] === 'string' && r[k]) out[k] = r[k]; });
    return out;
  }
  function rxSummary(rx) {
    var counts = {}, order = [], n = Object.keys(rx).length;
    Object.keys(rx).forEach(function (k) {
      var e = rx[k];
      if (!counts[e]) { counts[e] = 0; order.push(e); }
      counts[e]++;
    });
    order.sort(function (a, b) { return counts[b] - counts[a]; });
    return order.slice(0, 3).join('') + (n > 1 ? ' ' + n : '');
  }
  function pickerEl(mine, canEdit) {
    var box = el('div', 'picker');
    box.setAttribute('role', 'group');
    box.setAttribute('aria-label', 'Choisir une réaction');
    RX.forEach(function (e) {
      var b = el('button', 'rxb', e);
      b.type = 'button'; b.dataset.e = e;
      b.setAttribute('aria-pressed', mine === e ? 'true' : 'false');
      box.appendChild(b);
    });
    if (canEdit) {
      var eb = el('button', 'edit pedit', '✏️ Modifier');
      eb.type = 'button';
      box.appendChild(eb);
    }
    return box;
  }
  async function setReaction(id, emoji) {
    if (!state.chat || busy.has(id)) return;
    var m = state.msgs.find(function (x) { return x.id === id; });
    if (!m) return;
    var del = firebase.firestore.FieldValue.delete();
    var next = (reactionsOf(m)[state.me] === emoji) ? '' : emoji;
    var hadHeart = !!(m.likes && m.likes[state.me] === true);
    var hadOther = !!(m.reacts && typeof m.reacts[state.me] === 'string');
    var patch = {};
    if (next === RX[0]) {
      patch['likes.' + state.me] = true;
      if (hadOther) patch['reacts.' + state.me] = del;
    } else if (next) {
      patch['reacts.' + state.me] = next;
      if (hadHeart) patch['likes.' + state.me] = false;
    } else {
      if (hadHeart) patch['likes.' + state.me] = false;
      if (hadOther) patch['reacts.' + state.me] = del;
    }
    state.picker = null;
    closePickerAnim(id, next, render);
    if (!Object.keys(patch).length) return;
    busy.add(id);
    try {
      await fs.collection('chats').doc(state.chat.id).collection('messages').doc(id).update(patch);
    } catch (e) {
      showErr('La réaction n’a pas pu être enregistrée (connexion ou règles Firestore).');
    } finally { busy.delete(id); }
  }
  function startEdit(id) {
    var m = state.msgs.find(function (x) { return x.id === id; });
    if (!m || m.uid !== state.me || m.audio || m.img || m.file || ta.disabled) return;
    clearReply();
    if (!state.editing) state.editDraft = ta.value;
    state.editing = id;
    state.picker = null;
    ta.value = m.text;
    autosize();
    $('#editbar').hidden = false;
    render();
    ta.focus();
  }
  function cancelEdit() {
    if (!state.editing) return;
    state.editing = null;
    ta.value = state.editDraft || '';
    state.editDraft = '';
    $('#editbar').hidden = true;
    autosize();
  }
  async function saveEdit(text) {
    var id = state.editing, chat = state.chat;
    var m = state.msgs.find(function (x) { return x.id === id; });
    if (!m || m.uid !== state.me || !chat) { cancelEdit(); return; }
    if (text === m.text) { cancelEdit(); return; }
    var newest = state.msgs.reduce(function (a, x) { return Math.max(a, x.ts); }, 0);
    showErr('');
    try {
      var chatRef = fs.collection('chats').doc(chat.id);
      await chatRef.collection('messages').doc(id).update({ text: text, edited: true });
      if (m.ts === newest) chatRef.update({ lastText: text.slice(0, 120) }).catch(function () {});
    } catch (e) {
      showErr('La modification n’a pas pu être enregistrée (connexion ou règles Firestore).');
      return;
    }
    cancelEdit();
  }
  $('#editCancel').addEventListener('click', cancelEdit);

  /* ---------- photos (compressées avant l'envoi) ---------- */
  var PIMG = {}, VEMB = {}, picBtn = $('#pic'), picFile = $('#picFile'), viewer = $('#viewer');
  function openPhoto(src) { $('#viewerImg').src = src; viewer.showModal(); }
  viewer.addEventListener('click', function () { viewer.close(); });
  function compressImage(file) {
    return new Promise(function (ok, ko) {
      var img = new Image(), url = URL.createObjectURL(file);
      img.onload = function () {
        URL.revokeObjectURL(url);
        var max = 960, q = 0.6, out = '';
        for (var n = 0; n < 6; n++) {
          var k = Math.min(1, max / Math.max(img.width, img.height));
          var c = document.createElement('canvas');
          c.width = Math.max(1, Math.round(img.width * k)); c.height = Math.max(1, Math.round(img.height * k));
          var g = c.getContext('2d');
          g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height);
          g.drawImage(img, 0, 0, c.width, c.height);
          out = c.toDataURL('image/jpeg', q);
          if (out.length <= 110000) break;
          max = Math.round(max * 0.8); q = Math.max(0.4, q - 0.05);
        }
        if (out.length <= 600000) ok(out); else ko();
      };
      img.onerror = function () { URL.revokeObjectURL(url); ko(); };
      img.src = url;
    });
  }
  async function sendPhoto(img) {
    var chat = state.chat;
    if (!state.me || !chat || ta.disabled) return;
    showErr('');
    state.stick = true;
    var label = '📷 Photo', orig = img;
    async function put(val) {
      var chatRef = fs.collection('chats').doc(chat.id);
      var msgRef = chatRef.collection('messages').doc();
      var ts = Date.now();
      var exists = !!state.chatsById[chat.id];
      if (!exists) { exists = (await chatRef.get()).exists; }
      var batch = fs.batch();
      batch.set(msgRef, withReply({ uid: state.me, sts: SV(), text: label, ts: ts, img: val }));
      var last = { lastText: label, lastTs: ts, lastUid: state.me };
      if (exists) {
        last['seen.' + state.me] = ts;
        batch.update(chatRef, last);
      } else {
        var names = {}; names[state.me] = myName(); names[chat.other] = chat.name;
        var seen = {}; seen[state.me] = ts;
        batch.set(chatRef, {
          members: [state.me, chat.other], names: names,
          lastText: label, lastTs: ts, lastUid: state.me, seen: seen
        });
      }
      await batch.commit();
      state.chatsById[chat.id] = true;
    }
    try {
      if (cntEl) { cntEl.hidden = false; cntEl.textContent = 'Envoi de la photo…'; }
      var upi = await mediaUp(img);
      if (upi) img = upi;
      else if (CLD_MEDIA && img.length > 140000) {
        showErr('Photo non envoyée : le téléversement a échoué (' + (CLD_ERR || 'connexion') + '). Réessaie quand la connexion est meilleure.');
        return;
      }
      try { await put(img); }
      catch (e1) {
        /* règles Firestore qui refusent le lien : on retente avec la photo intégrée (petite version compressée) */
        if (e1 && e1.code === 'permission-denied' && img !== orig && orig.length <= 600000) await put(orig);
        else throw e1;
      }
    } catch (e) {
      var code = e && e.code ? String(e.code) : '';
      showErr(code === 'permission-denied'
        ? 'Photo refusée par les règles Firestore (le lien Cloudinary et la photo intégrée sont refusés). À corriger dans Firebase > Firestore > Règles. [' + code + ']'
        : 'Photo non envoyée. Vérifie ta connexion et réessaie.' + (code ? ' [' + code + ']' : ''));
    } finally { if (cntEl) cntEl.hidden = true; }
  }
  picBtn.addEventListener('click', function () {
    if (state.chat && !ta.disabled && !picBtn.disabled) picFile.click();
  });
  picFile.addEventListener('change', function (e) {
    var f = e.target.files && e.target.files[0]; e.target.value = '';
    if (!f) return;
    var chatId = state.chat && state.chat.id;
    picBtn.disabled = true;
    compressImage(f).then(function (d) {
      if (state.chat && state.chat.id === chatId) return sendPhoto(d);
    }, function () { showErr('Image illisible ou trop lourde.'); })
      .then(function () { picBtn.disabled = false; });
  });

