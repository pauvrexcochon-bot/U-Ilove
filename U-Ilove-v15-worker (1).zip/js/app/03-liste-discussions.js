/* U&I — js/app/03-liste-discussions.js
   Liste des discussions
   (fait partie de l’appli : assemblée par js/boot/loader.js dans une seule fermeture) */
  /* ---------- liste des discussions ---------- */
  function unreadCount() {
    return state.chats.filter(isUnread).length;
  }
  function isUnread(c) {
    var seen = (c.seen && c.seen[state.me]) || 0;
    return c.lastUid && c.lastUid !== state.me && c.lastTs > seen;
  }
  function updateTitle() {
    var n = document.hidden ? unreadCount() : 0;
    document.title = n > 0 ? '(' + n + ') ' + BASE_TITLE : BASE_TITLE;
  }

  var rlRaf = 0;
  function renderList() {
    if (rlRaf) return;
    rlRaf = requestAnimationFrame(function () { rlRaf = 0; renderListNow(); });
  }
  function renderListNow() {
    $('#meName').textContent = (state.nick ? state.nick + ' · ' : '') + '@' + state.username;
    withBadge($('#meName'), state.me);
    updateMyNote();
    frBadge();
    onSig = onlineSig();
    var nUn = state.chats.filter(function (c) { return !inviteIn(c) && isUnread(c); }).length;
    $('#unreadN').textContent = nUn; $('#unreadN').hidden = !nUn;
    $('#unreadBtn').setAttribute('aria-pressed', state.onlyUnread ? 'true' : 'false');
    chatsEl.replaceChildren();
    var q = ($('#search').value || '').trim().toLowerCase();
    var sorted = state.chats.slice().sort(function (a, b) { return (b.lastTs || 0) - (a.lastTs || 0); });
    sorted = sorted.filter(function (c) { return isPinned(c.id); }).concat(sorted.filter(function (c) { return !isPinned(c.id); }));
    var hid = hiddenChats();
    sorted = sorted.filter(function (c) { return !(hid[c.id] && (c.lastTs || 0) <= hid[c.id]) && !inviteIn(c); });
    if (state.onlyUnread) sorted = sorted.filter(function (c) { return isUnread(c); });
    if (q) sorted = sorted.filter(function (c) {
      if (c.group) return String(c.title || '').toLowerCase().indexOf(q) !== -1;
      var o = (c.members || []).filter(function (x) { return x !== state.me; })[0];
      return String(nickOf(c, o) || (c.names && c.names[o]) || '').toLowerCase().indexOf(q) !== -1 || String((c.names && c.names[o]) || '').toLowerCase().indexOf(q) !== -1;
    });
    if (!state.chatsLoaded) { chatsEl.appendChild(el('li', 'loading', 'Chargement des discussions…')); return; }
    if (!sorted.length && state.onlyUnread) { chatsEl.appendChild(el('li', 'empty', 'Aucun message non lu.')); return; }
    if (!sorted.length) {
      var li = el('li', 'empty');
      li.appendChild(el('strong', '', 'Aucune discussion'));
      li.appendChild(document.createTextNode('Tape le nom d’utilisateur de quelqu’un dans le champ ci-dessus pour lui écrire.'));
      chatsEl.appendChild(li);
      return;
    }
    sorted.forEach(function (c) {
      if (c.group) {
        var gb = el('button', 'chatrow' + (isUnread(c) ? ' unread' : '') + (isPinned(c.id) ? ' pinned' : '')); gb.type = 'button'; gb.dataset.gid = c.id;
        var gav = el('span', 'avatar'); paintGroupAv(gav, c);
        var gi = el('span'); gi.appendChild(el('span', 'nm', c.title || 'Groupe'));
        var who = c.lastUid === state.me ? 'Toi : ' : ((nickOf(c, c.lastUid) || (c.names && c.names[c.lastUid])) ? cap(nickOf(c, c.lastUid) || c.names[c.lastUid]) + ' : ' : '');
        gi.appendChild(el('span', 'pv', who + (c.lastText || '')));
        var gs = el('span', 'side'); gs.appendChild(el('span', '', c.lastTs ? listTime(c.lastTs) : ''));
        if (isUnread(c)) gs.appendChild(el('span', 'pip'));
        gb.appendChild(gav); gb.appendChild(gi); gb.appendChild(gs);
        var gli = el('li'); gli.appendChild(gb); chatsEl.appendChild(gli);
        return;
      }
      var other = (c.members || []).filter(function (x) { return x !== state.me; })[0];
      var name = nickOf(c, other) || (c.names && c.names[other]) || 'Inconnu';
      var li = el('li');
      var b = el('button', 'chatrow' + (isUnread(c) ? ' unread' : '') + (isPinned(c.id) ? ' pinned' : ''));
      b.type = 'button';
      b.dataset.uid = other;
      b.dataset.name = name;
      var av = el('span', 'avatar' + ringClass(other)); paintPhoto(av, other, name); loadPhoto(other);
      var info = el('span');
      info.appendChild(withBadge(el('span', 'nm', cap(name)), other));
      info.appendChild(el('span', 'pv', (c.lastUid === state.me ? 'Toi : ' : '') + (c.lastText || '')));
      var side = el('span', 'side');
      side.appendChild(el('span', '', c.lastTs ? listTime(c.lastTs) : ''));
      if (isUnread(c)) side.appendChild(el('span', 'pip'));
      var avw = el('span', 'avw'); avw.appendChild(av); if (isOnline(other)) avw.appendChild(el('i', 'ondot'));
      b.appendChild(avw); b.appendChild(info); b.appendChild(side);
      li.appendChild(b);
      chatsEl.appendChild(li);
    });
  }

  $('#search').addEventListener('input', function () { if (state.view === 'list') renderList(); });

  chatsEl.addEventListener('click', function (ev) {
    var b = ev.target.closest && ev.target.closest('.chatrow');
    if (!b) return;
    if (b.dataset.gid) { var gcl = chatOf(b.dataset.gid); if (gcl) openChat('', gcl.title || 'Groupe', gcl); return; }
    if (ev.target.closest('.avatar')) { showNote(b.dataset.uid, b.dataset.name); return; }
    openChat(b.dataset.uid, b.dataset.name);
  });

  $('#newChat').addEventListener('submit', async function (ev) {
    ev.preventDefault();
    var name = $('#who').value.trim().toLowerCase().replace(/^@/, '').replace(/\s+/g, '');
    showNewErr('');
    if (!name) return;
    if (name === state.username) { showNewErr('C’est ton propre nom d’utilisateur.'); return; }
    if (!NAME_RE.test(name)) { showNewErr('Ce nom d’utilisateur n’est pas valide.'); return; }
    try {
      var snap = await fs.collection('usernames').doc(name).get();
      if (!snap.exists) { showNewErr('Aucun utilisateur ne s’appelle « ' + name + ' ».'); return; }
      var uid = snap.data().uid;
      if (uid === state.me) { showNewErr('C’est ton propre nom d’utilisateur.'); return; }
      $('#who').value = ''; $('#newChat').hidden = true;
      openUserCard(uid, name);
    } catch (e) {
      showNewErr('Recherche impossible. Vérifie ta connexion et les règles Firestore.');
    }
  });

