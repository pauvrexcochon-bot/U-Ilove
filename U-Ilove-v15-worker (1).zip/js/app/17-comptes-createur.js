/* U&I — js/app/17-comptes-createur.js
   Outil créateur : liste des comptes
   (fait partie de l’appli : assemblée par js/boot/loader.js dans une seule fermeture) */
  /* ---------- outil créateur : liste des comptes ---------- */
  var accDlg = $('#accDlg'), ACC = [];
  function accRender() {
    var q = ($('#accSearch').value || '').trim().toLowerCase(), box = $('#accRows');
    box.replaceChildren();
    ACC.filter(function (a) { return !q || a.name.indexOf(q) !== -1; }).forEach(function (a) {
      var row = el('div', 'accrow'); var acts = el('div', 'accacts');
      var b = el('button', 'gimem'); b.type = 'button';
      var av = el('span', 'avatar sm'); paintAvatar(av, a.name);
      b.appendChild(av); b.appendChild(withBadge(el('span', '', cap(a.name) + (a.uid === state.me ? ' \u00b7 toi' : '')), a.uid));
      if (a.uid !== state.me) b.addEventListener('click', function () {
        accDlg.close(); setDlg.close();
        if (state.view !== 'list') showList();
        openChat(a.uid, a.name);
      });
      row.appendChild(b);
      if (a.uid !== state.me) {
        var t = el('button', 'ghost', badges[a.uid] ? '\u2212 Cr\u00e9ateur' : '+ Cr\u00e9ateur'); t.type = 'button';
        t.addEventListener('click', function (e) { e.stopPropagation(); accBadge(a, t); });
        var ct = el('button', 'ghost', verifs[a.uid] ? '\u2212 Certifi\u00e9' : '+ Certifi\u00e9'); ct.type = 'button';
        ct.addEventListener('click', function (e) { e.stopPropagation(); accCert(a, ct); });
        acts.appendChild(ct);
        if (verifs[a.uid] && !badges[a.uid]) {
          var mu = el('button', 'ghost', musicOks[a.uid] ? '\u2212 Musique partag\u00e9e' : '+ Musique partag\u00e9e'); mu.type = 'button';
          mu.addEventListener('click', function (e) { e.stopPropagation(); accMusic(a, mu); });
          acts.appendChild(mu);
        }
        acts.appendChild(t);
        var bu = BANS[a.uid] || 0, on = bu > Date.now();
        var bn = el('button', 'ghost', on ? 'Lever la suspension' : 'Suspendre 7 j'); bn.type = 'button';
        bn.addEventListener('click', function (e) {
          e.stopPropagation();
          var ref = fs.collection('bans').doc(a.uid);
          (on ? ref.delete() : ref.set({ until: Date.now() + 7 * 864e5, ts: Date.now() }))
            .then(function () { if (on) delete BANS[a.uid]; else BANS[a.uid] = Date.now() + 7 * 864e5; accRender(); })
            .catch(function () { var er = $('#accListErr'); er.textContent = 'Suspension impossible : ajoute la règle Firestore « bans ».'; er.hidden = false; });
        });
        acts.appendChild(bn);
        var x = el('button', 'ghost del', 'Supprimer'); x.type = 'button';
        x.addEventListener('click', function (e) {
          e.stopPropagation();
          if (!confirm('Supprimer d\u00e9finitivement le compte \u00ab ' + cap(a.name) + ' \u00bb et ses conversations ?')) return;
          x.disabled = true;
          purgeAccount(a.uid, a.name).then(function (ok) {
            if (ok) { ACC = ACC.filter(function (z) { return z.uid !== a.uid; }); $('#accTitle').textContent = ACC.length + ' compte' + (ACC.length > 1 ? 's' : ''); accRender(); }
            else x.disabled = false;
          });
        });
        acts.appendChild(x);
        row.appendChild(acts);
      }
      box.appendChild(row);
    });
  }
  async function purgeAccount(uid, name) {
    var err = $('#accListErr'); err.hidden = true;
    if (!uid || uid === state.me) return false;
    if (name) { try { await fs.collection('recovery').doc(name).delete(); } catch (e) {} }
    var FV = firebase.firestore.FieldValue, bad = false, i, j;
    try {
      var un = await fs.collection('usernames').where('uid', '==', uid).get();
      for (i = 0; i < un.docs.length; i++) await un.docs[i].ref.delete();
      if (name) { try { await fs.collection('usernames').doc(name).delete(); } catch (e) {} }
    } catch (e) { bad = true; }
    try { await fs.collection('presence').doc(uid).delete(); } catch (e) { bad = true; }
    try {
      var lk = await fs.collection('profileLikes').where('to', '==', uid).get();
      for (i = 0; i < lk.docs.length; i++) await lk.docs[i].ref.delete();
    } catch (e) {}
    try {
      var cs = await fs.collection('chats').where('members', 'array-contains', uid).get();
      for (i = 0; i < cs.docs.length; i++) {
        var ref = cs.docs[i].ref, cd = cs.docs[i].data() || {};
        if (cd.group) {
          var upd = { members: FV.arrayRemove(uid) };
          upd['names.' + uid] = FV.delete(); upd['nicks.' + uid] = FV.delete();
          await ref.update(upd);
        } else {
          for (j = 0; j < 50; j++) {
            var ms = await ref.collection('messages').limit(400).get();
            if (ms.empty) break;
            var bt = fs.batch();
            ms.docs.forEach(function (d) { bt.delete(d.ref); });
            await bt.commit();
          }
          await ref.delete();
        }
      }
    } catch (e) { bad = true; }
    if (bad) {
      err.textContent = 'Suppression incompl\u00e8te : les r\u00e8gles Firestore doivent autoriser le cr\u00e9ateur \u00e0 lire/supprimer usernames, chats et messages.'; err.hidden = false;
      return false;
    }
    return true;
  }
  $('#accPurgeGo').addEventListener('click', function () {
    var uid = ($('#accPurgeUid').value || '').trim(), err = $('#accListErr');
    if (!uid) { err.textContent = 'Colle l\u2019identifiant (uid) du compte \u00e0 nettoyer.'; err.hidden = false; return; }
    if (uid === state.me) { err.textContent = 'Tu ne peux pas nettoyer ton propre compte ici.'; err.hidden = false; return; }
    if (!confirm('Nettoyer tout ce qui reste de cet identifiant (pseudo, profil, conversations) ?')) return;
    var b = this; b.disabled = true;
    purgeAccount(uid, '').then(function (ok) {
      b.disabled = false;
      if (ok) { $('#accPurgeUid').value = ''; err.textContent = 'Nettoy\u00e9.'; err.hidden = false; }
    });
  });
  function accMusic(a, btn) {
    var on = !musicOks[a.uid], err = $('#accListErr'); err.hidden = true; btn.disabled = true;
    fs.collection('presence').doc(a.uid).set({ musicOk: on ? true : firebase.firestore.FieldValue.delete() }, { merge: true })
      .then(function () { musicOks[a.uid] = on; accRender(); })
      .catch(function () { btn.disabled = false; err.textContent = 'Impossible : les r\u00e8gles Firestore doivent autoriser les cr\u00e9ateurs \u00e0 modifier \u00ab musicOk \u00bb.'; err.hidden = false; });
  }
  function accCert(a, btn) {
    var on = !verifs[a.uid], err = $('#accListErr'); err.hidden = true; btn.disabled = true;
    fs.collection('presence').doc(a.uid).set({ verified: on ? true : firebase.firestore.FieldValue.delete() }, { merge: true })
      .then(function () { verifs[a.uid] = on; accRender(); })
      .catch(function () {
        btn.disabled = false;
        err.textContent = 'Certification impossible : les r\u00e8gles Firestore doivent autoriser les cr\u00e9ateurs \u00e0 modifier \u00ab verified \u00bb.'; err.hidden = false;
      });
  }
  function accBadge(a, btn) {
    var on = !badges[a.uid], err = $('#accListErr'); err.hidden = true; btn.disabled = true;
    fs.collection('presence').doc(a.uid).set({ badge: on ? true : firebase.firestore.FieldValue.delete() }, { merge: true })
      .then(function () { badges[a.uid] = on; accRender(); })
      .catch(function () {
        btn.disabled = false;
        err.textContent = 'Badge impossible : les regles Firestore doivent autoriser les createurs a modifier le badge des autres.'; err.hidden = false;
      });
  }
  $('#accSearch').addEventListener('input', accRender);
  $('#accClose').addEventListener('click', function () { accDlg.close(); });
  accDlg.addEventListener('click', function (e) { if (e.target === accDlg) accDlg.close(); });
  $('#accList').addEventListener('click', function () {
    if (!creatorOn()) return;
    var err = $('#accListErr'); err.hidden = true; ACC = [];
    $('#accTitle').textContent = 'Comptes'; $('#accRows').replaceChildren(el('p', 'hint', 'Chargement\u2026'));
    $('#accSearch').value = ''; BANS = {};
    fs.collection('bans').get().then(function (sn) { sn.forEach(function (d) { BANS[d.id] = (d.data() || {}).until || 0; }); accRender(); }).catch(function () {});
    accDlg.showModal();
    fs.collection('usernames').get().then(function (sn) {
      sn.forEach(function (d) { var v = d.data(); if (v && typeof v.uid === 'string') ACC.push({ name: d.id, uid: v.uid }); });
      ACC.sort(function (a, b) { return a.name < b.name ? -1 : 1; });
      $('#accTitle').textContent = ACC.length + ' compte' + (ACC.length > 1 ? 's' : '');
      accRender();
      Promise.all(ACC.map(function (a) {
        return fs.collection('presence').doc(a.uid).get().then(function (d) { badges[a.uid] = !!(d.exists && d.data().badge === true); verifs[a.uid] = !!(d.exists && d.data().verified === true); musicOks[a.uid] = !!(d.exists && d.data().musicOk === true); }).catch(function () {});
      })).then(accRender);
    }).catch(function () {
      $('#accRows').replaceChildren();
      err.textContent = 'Lecture refus\u00e9e : autorise \u00ab list \u00bb sur usernames pour les cr\u00e9ateurs dans les r\u00e8gles Firestore.'; err.hidden = false;
    });
  });
  var NOTE_TTL = 24 * 60 * 60 * 1000;
  var notePres = {}, noteSubs = {}, noteTimer = null;
  var neDlg = $('#noteEdit'), nvDlg = $('#noteView'), nvTarget = null;
  function activeNote(uid) {
    var p = notePres[uid];
    if (!p || typeof p.note !== 'string' || !p.note.trim() || typeof p.noteTs !== 'number') return null;
    if (Date.now() - p.noteTs > NOTE_TTL) return null;
    if (uid !== state.me && Array.isArray(p.noteTo) && p.noteTo.indexOf(state.me) === -1) return null;
    return { text: p.note, ts: p.noteTs };
  }
  function seenNotes() {
    try { return JSON.parse(store('uandi-nseen-' + state.me) || '{}') || {}; } catch (e) { return {}; }
  }
  function ringClass(uid) {
    var a = activeNote(uid);
    if (!a) return '';
    if (uid === state.me) return ' ring';
    return (seenNotes()[uid] || 0) >= a.ts ? ' ring seen' : ' ring';
  }
  function updateMyNote() {
    var av = $('#myNoteAv'), a = activeNote(state.me);
    paintPhoto(av, state.me, state.username);
    loadPhoto(state.me);
    av.className = 'avatar' + (a ? ' ring' : '');
    var nb = $('#myNote');
    nb.classList.toggle('has', !!a);
    nb.title = a ? 'Ma note : ' + a.text : 'Ajouter une note';
  }
  function updateChatRing() {
    if (!state.chat) return;
    $('#chatAvatar').className = 'avatar sm' + ringClass(state.chat.other);
  }
  function watchNotes(extra) {
    var uids = [state.me];
    if (extra && extra !== state.me) uids.push(extra);
    state.chats.forEach(function (c) {
      (c.members || []).forEach(function (u) { if (uids.indexOf(u) === -1) uids.push(u); });
    });
    uids.forEach(function (uid) {
      if (noteSubs[uid]) return;
      noteSubs[uid] = fs.collection('presence').doc(uid).onSnapshot(function (d) {
        var v = d.exists ? d.data() : null;
        var wasOn = isOnline(uid); seenAt[uid] = (v && v.seen) || 0; var flip = wasOn !== isOnline(uid);
        var before = JSON.stringify(notePres[uid] || null);
        notePres[uid] = v ? { note: v.note, noteTs: v.noteTs, badge: v.badge === true, verified: v.verified === true, hideSeen: v.hideSeen === true, noteTo: Array.isArray(v.noteTo) ? v.noteTo : null, bday: typeof v.bday === 'string' ? v.bday : null } : null;
        badges[uid] = !!(v && v.badge === true); verifs[uid] = !!(v && v.verified === true);
        musicOks[uid] = !!(v && v.musicOk === true); if (uid === state.me) { try { localStorage.setItem('uandi-musicok-' + state.me, musicOks[uid] ? '1' : '0'); } catch (e) {} if (window.mShRefresh) mShRefresh(); }
        if (uid === state.me) { try { localStorage.setItem('uandi-cert-' + state.me, v && v.verified === true ? '1' : '0'); } catch (e) {} newsAccess(); apCheck(); try { localStorage.setItem('uandi-hide-' + state.me, v && v.hideOn === true ? '1' : '0'); localStorage.setItem('uandi-hs-' + state.me, v && v.hideSeen === true ? '1' : '0'); } catch (e) {} paintHide(); }
        var ph = v && typeof v.photo === 'string' ? v.photo : null;
        var photoChanged = (photos[uid] || null) !== ph;
        if (photoChanged) photos[uid] = ph;
        if (uid === state.me && photoChanged) updateMyNote();
        if (JSON.stringify(notePres[uid]) === before && !photoChanged && !flip) return;
        if (state.view === 'list') renderList();
        else if (state.view === 'chat') {
          updateChatRing(); updateChatBadge(); if (state.chat && state.chat.group) render();
          if (photoChanged && state.chat && state.chat.other === uid) paintPhoto($('#chatAvatar'), uid, state.chat.name);
        }
      }, function () {});
    });
  }
  function noteAgo(ts) {
    var m = Math.floor((Date.now() - ts) / 60000);
    if (m < 1) return 'à l’instant';
    if (m < 60) return 'il y a ' + m + ' min';
    return 'il y a ' + Math.floor(m / 60) + ' h';
  }
  function showNote(uid, name) {
    var a = activeNote(uid);
    if (a) {
      var seen = seenNotes(); seen[uid] = a.ts;
      store('uandi-nseen-' + state.me, JSON.stringify(seen));
    }
    nvTarget = { uid: uid, name: name };
    paintPhoto($('#nvAv'), uid, name);
    loadPhoto(uid);
    $('#nvName').textContent = cap(name);
    ensureBadge(uid); withBadge($('#nvName'), uid);
    $('#nvTime').textContent = a ? noteAgo(a.ts) : '';
    $('#nvText').textContent = a ? a.text : '';
    $('#nvText').hidden = !a;
    watchLikes(uid);
    $('#nvWrite').hidden = state.view === 'chat';
    $('#nvReplyBox').hidden = !(a && uid !== state.me);
    $('#nvReacts').hidden = !(a && uid !== state.me);
    $('#nvReplyIn').value = ''; $('#nvReplyErr').hidden = true;
    if (state.view === 'list') renderList(); else updateChatRing();
    nvDlg.showModal();
  }
  function noteCount() { $('#noteCount').textContent = $('#noteInput').value.length + ' / 60'; }
  function noteErr(t) { var e = $('#noteErr'); e.textContent = t || ''; e.hidden = !t; }
  $('#myNote').addEventListener('click', function () {
    var a = activeNote(state.me);
    $('#noteInput').value = a ? a.text : '';
    $('#noteDel').hidden = !a;
    $('#noteCloseOnly').checked = !!(notePres[state.me] && Array.isArray(notePres[state.me].noteTo));
    noteErr('');
    noteCount();
    neDlg.showModal();
    $('#noteInput').focus();
  });
  $('#noteInput').addEventListener('input', noteCount);
  $('#chatAvatar').addEventListener('click', function () {
    if (!state.chat) return;
    if (state.chat.group) openGroupInfo(); else showNote(state.chat.other, state.chat.name);
  });
  $('#noteCancel').addEventListener('click', function () { neDlg.close(); });
  $('#noteSave').addEventListener('click', function () {
    var text = $('#noteInput').value.trim();
    if (!text) { noteErr('Écris quelque chose avant de partager.'); return; }
    noteErr('');
    var only = $('#noteCloseOnly').checked;
    if (only && !closeList().length) { noteErr('Ajoute d’abord des amis proches (fiche d’un ami).'); return; }
    fs.collection('presence').doc(state.me).set({ name: myName(), note: text.slice(0, 60), noteTs: Date.now(), noteTo: only ? closeList() : firebase.firestore.FieldValue.delete() }, { merge: true })
      .then(function () { neDlg.close(); })
      .catch(function () { noteErr('La note n’a pas pu être publiée (connexion ou règles Firestore).'); });
  });
  $('#noteDel').addEventListener('click', function () {
    var del = firebase.firestore.FieldValue.delete();
    noteErr('');
    fs.collection('presence').doc(state.me).set({ note: del, noteTs: del }, { merge: true })
      .then(function () { neDlg.close(); })
      .catch(function () { noteErr('La note n’a pas pu être supprimée.'); });
  });
  $('#nvClose').addEventListener('click', function () { nvDlg.close(); });
  /* répondre directement à la note de quelqu'un : message dans leur discussion, avec la note citée */
  async function sendNoteReply(forced) {
    var t = nvTarget, inp = $('#nvReplyIn'), err = $('#nvReplyErr'), text = typeof forced === 'string' ? forced : inp.value.trim(), a = t && activeNote(t.uid);
    if (!t || !text || !a || t.uid === state.me) return;
    err.hidden = true;
    var btn = $('#nvReplySend'); btn.disabled = true;
    try {
      var cid = chatIdFor(state.me, t.uid), chatRef = fs.collection('chats').doc(cid), msgRef = chatRef.collection('messages').doc(), ts = Date.now();
      var exists = !!state.chatsById[cid];
      if (!exists) exists = (await chatRef.get()).exists;
      var batch = fs.batch();
      batch.set(msgRef, { uid: state.me, sts: SV(), text: text.slice(0, 2000), ts: ts, reply: { id: 'note:' + t.uid + ':' + a.ts, uid: t.uid, t: '📝 Note : ' + a.text.slice(0, 100) } });
      var last = { lastText: text.slice(0, 120), lastTs: ts, lastUid: state.me };
      if (exists) { last['seen.' + state.me] = ts; batch.update(chatRef, last); }
      else {
        var names = {}; names[state.me] = myName(); names[t.uid] = t.name;
        var seen = {}; seen[state.me] = ts;
        batch.set(chatRef, { members: [state.me, t.uid], names: names, lastText: last.lastText, lastTs: ts, lastUid: state.me, seen: seen });
      }
      await batch.commit();
      state.chatsById[cid] = true;
      inp.value = ''; nvDlg.close();
      if (!(state.view === 'chat' && state.chat && !state.chat.group && state.chat.other === t.uid)) openChat(t.uid, t.name);
    } catch (e) {
      err.textContent = 'Réponse non envoyée (connexion ou règles Firestore).'; err.hidden = false;
    }
    btn.disabled = false;
  }
  $('#nvReplySend').addEventListener('click', sendNoteReply);
  $('#nvReplyIn').addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); sendNoteReply(); } });
  $('#nvWrite').addEventListener('click', function () {
    var t = nvTarget; nvDlg.close();
    if (t) openChat(t.uid, t.name);
  });

