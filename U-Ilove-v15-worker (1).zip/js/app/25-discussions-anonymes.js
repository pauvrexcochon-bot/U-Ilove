/* U&I — js/app/25-discussions-anonymes.js
   Discussions entre profils anonymes
   (fait partie de l’appli : assemblée par js/boot/loader.js dans une seule fermeture) */
  /* ---------- discussions entre profils anonymes ---------- */
  var AT = { items: [], unsub: null, reqU: [], sig: '', cur: null, msgU: null, pane: 'feed', failed: false, selfU: null };
  /* les profils réels peuvent recevoir des messages d'anonymes (taquineries) ; on peut le refuser */
  function atOptKey() { return 'uandi-noanon-' + state.me; }
  function atOptIn() { try { return localStorage.getItem(atOptKey()) !== '1'; } catch (e) { return true; } }
  function atOptPaint() {
    var b = $('#atOptBtn'); if (!b) return;
    var on = atOptIn();
    b.setAttribute('aria-pressed', on ? 'true' : 'false');
    b.textContent = on ? '🎭 Les anonymes peuvent me taquiner ✓' : '🚫 Les anonymes ne peuvent pas m’écrire';
  }
  function atTErr(t) { var e = $('#atTErr'); if (!e) return; e.textContent = t || ''; e.hidden = !t; }
  function atInitial(name) { return String(name || '?').trim().charAt(0).toUpperCase() || '?'; }
  function atHue(name) { var h = 0, i; name = String(name || ''); for (i = 0; i < name.length; i++) h = (h * 31 + name.charCodeAt(i)) % 360; return h; }
  function atSeenKey(id) { return 'uandi-atseen:' + state.me + ':' + id; }
  function atSeen(id) { try { return +localStorage.getItem(atSeenKey(id)) || 0; } catch (e) { return 0; } }
  function atMark(id, ts) { try { localStorage.setItem(atSeenKey(id), String(ts || Date.now())); } catch (e) {} }
  function atUnread(t) { return !!t.lastUid && t.lastUid !== state.me && (t.lastTs || 0) > atSeen(t.id); }
  function atOther(t) { return (t.a === state.me ? t.bAlias : t.aAlias) || { name: 'Anonyme', emoji: '👤', hue: 0 }; }
  function atStop() {
    [AT.unsub, AT.msgU, AT.selfU].concat(AT.reqU).forEach(function (u) { if (u) { try { u(); } catch (e) {} } });
    AT.unsub = null; AT.msgU = null; AT.selfU = null; AT.reqU = []; AT.sig = ''; AT.items = []; AT.cur = null; AT.pane = 'feed';
  }
  /* demandes adressées à mon profil réel : 'u:' + mon uid */
  function atSelfWatch() {
    if (AT.selfU) return;
    AT.selfU = fs.collection('anonRequests').where('addr', '==', 'u:' + state.me).onSnapshot(function (sn) {
      sn.docs.forEach(function (d) {
        if (!atOptIn()) { d.ref.delete().catch(function () {}); return; }
        fs.collection('anonThreads').doc(d.id).update({ b: state.me, members: firebase.firestore.FieldValue.arrayUnion(state.me) })
          .then(function () { return d.ref.delete(); }).catch(function () {});
      });
    }, function () {});
  }
  function atListen() {
    if (newsBlocked()) return;
    atSelfWatch();
    if (AT.unsub) return;
    AT.unsub = fs.collection('anonThreads').where('members', 'array-contains', state.me).onSnapshot(function (sn) {
      AT.failed = false;
      AT.items = sn.docs.map(function (d) { var v = d.data(); v.id = d.id; return v; }).sort(function (a, b) { return (b.lastTs || 0) - (a.lastTs || 0); });
      atPaint();
    }, function () { AT.failed = true; atPaint(); });
  }
  /* le propriétaire d'une lettre/commentaire reçoit les demandes de discussion et les accepte */
  function atWatch() {
    if (newsBlocked()) return;
    var ret = atRetired(), ids = Object.keys(NW.mine).filter(function (k) { return ret.indexOf(k) === -1; }).sort(), sig = ids.join(',');
    if (sig === AT.sig) return;
    AT.sig = sig;
    AT.reqU.forEach(function (u) { try { u(); } catch (e) {} }); AT.reqU = [];
    for (var i = 0; i < ids.length; i += 10) (function (ch) {
      AT.reqU.push(fs.collection('anonRequests').where('addr', 'in', ch).onSnapshot(function (sn) {
        sn.docs.forEach(function (d) {
          fs.collection('anonThreads').doc(d.id).update({ b: state.me, members: firebase.firestore.FieldValue.arrayUnion(state.me) })
            .then(function () { return d.ref.delete(); }).catch(function () {});
        });
      }, function () {}));
    })(ids.slice(i, i + 10));
  }
  function atPaint() {
    var dot = $('#atDot'), any = AT.items.some(atUnread);
    if (dot) dot.hidden = !any || AT.pane === 'threads';
    var list = $('#atList');
    if (!list) return;
    list.textContent = '';
    if (AT.failed) { list.appendChild(el('p', 'hint', 'Discussions indisponibles (règles Firestore : « anonThreads » et « anonRequests »).')); return; }
    atOptPaint();
    if (!AT.items.length) { list.appendChild(el('p', 'hint', 'Aucune discussion. Touche « 🎭 Discuter » sur une lettre anonyme, ou « 🎭 Taquiner » sur le commentaire d’un profil (ou tape son identifiant ci-dessus).')); return; }
    AT.items.forEach(function (t) {
      var o = atOther(t), row = el('button', 'atrow' + (atUnread(t) ? ' unread' : '')), av = el('span', 'nwav'), box = el('div');
      row.type = 'button'; nwAv(av, o);
      box.appendChild(el('b', null, o.name)); box.appendChild(el('small', null, t.lastText || (t.b ? 'Dis bonjour !' : 'En attente de réponse…')));
      row.appendChild(av); row.appendChild(box);
      row.addEventListener('click', function () { atOpen(t.id); });
      list.appendChild(row);
    });
    if (AT.cur) atHead();
  }
  function atHead() {
    var t = AT.items.filter(function (x) { return x.id === AT.cur; })[0];
    if (!t) return;
    var o = atOther(t); nwAv($('#atAv'), o); $('#atName').textContent = o.name;
  }
  function nwPane(p) {
    AT.pane = p;
    ['Feed', 'Threads', 'Thread'].forEach(function (k) { $('#nwPane' + k).hidden = k.toLowerCase() !== p; });
    document.querySelectorAll('.nwtab').forEach(function (b) { b.setAttribute('aria-pressed', b.dataset.p === (p === 'thread' ? 'threads' : p) ? 'true' : 'false'); });
    if (p !== 'thread' && AT.msgU) { AT.msgU(); AT.msgU = null; AT.cur = null; }
    if (p !== 'feed') { atListen(); atPaint(); }
  }
  function atOpen(tid) {
    if (AT.msgU) { AT.msgU(); AT.msgU = null; }
    AT.cur = tid; $('#atErr').hidden = true; $('#atMsgs').textContent = '';
    nwPane('thread'); atHead();
    AT.msgU = fs.collection('anonThreads').doc(tid).collection('messages').orderBy('ts', 'asc').limit(200).onSnapshot(function (sn) {
      var box = $('#atMsgs'), last = 0;
      box.textContent = '';
      sn.docs.forEach(function (d) {
        var m = d.data(); last = Math.max(last, m.ts || 0);
        box.appendChild(el('div', 'atm' + (m.uid === state.me ? ' me' : ''), m.text || ''));
      });
      if (!sn.docs.length) {
        var tt = AT.items.filter(function (x) { return x.id === tid; })[0], tease = !!(tt && String(tt.addr || '').indexOf('u:') === 0);
        box.appendChild(el('p', 'hint', !tease ? 'Personne ne connaît ton identité. Écris le premier message !'
          : (tt.a === state.me ? 'Tu es anonyme : ' + atOther(tt).name + ' ne sait pas qui tu es. Taquine gentiment 😄' : 'Un anonyme veut te taquiner. Reste cool, tu peux ne pas répondre.')));
      }
      box.scrollTop = box.scrollHeight;
      atMark(tid, Math.max(last, Date.now()));
    }, function () { var e = $('#atErr'); e.textContent = 'Messages indisponibles (règles Firestore).'; e.hidden = false; });
  }
  async function atStart(addr, alias, realUid) {
    nwErr(''); atTErr('');
    var me0 = null;
    try { me0 = await nwIdentity(); } catch (e) {}
    /* une discussion = une adresse + une identité anonyme : si tu as changé de nom, on en ouvre une nouvelle */
    var ex = AT.items.filter(function (t) { return t.addr === addr && t.a === state.me && (!me0 || !t.aAlias || t.aAlias.name === me0.name); })[0];
    if (ex) { atOpen(ex.id); return; }
    if (realUid) {
      if (banGuard()) { atTErr($('#nwErr').textContent); return; }
      if (realUid === state.me) { atTErr('Tu ne peux pas te taquiner toi-même.'); return; }
      try {
        var pd = await fs.collection('presence').doc(realUid).get();
        if (pd.exists && pd.data().noAnon === true) { var m1 = 'Cette personne n’accepte pas les messages anonymes.'; atTErr(m1); nwErr(m1); return; }
      } catch (e) {}
    }
    try {
      var id = await nwIdentity(), ref = fs.collection('anonThreads').doc(), ts = Date.now(), b = fs.batch();
      b.set(ref, { addr: addr, a: state.me, b: null, members: [state.me], ts: ts, lastText: '', lastTs: ts, lastUid: '',
        aAlias: { name: id.name, emoji: id.emoji, hue: id.hue },
        bAlias: { name: alias.name || 'Anonyme', emoji: alias.emoji || '👤', hue: alias.hue || 0 } });
      b.set(fs.collection('anonRequests').doc(ref.id), { addr: addr, ts: ts });
      await b.commit();
      atListen(); atOpen(ref.id);
    } catch (e) { var m2 = 'Discussion impossible (règles Firestore : « anonThreads » et « anonRequests »).'; nwErr(m2); atTErr(m2); }
  }
  /* taquiner un profil réel depuis son identifiant */
  $('#atTeaseForm').addEventListener('submit', async function (ev) {
    ev.preventDefault();
    var inp = $('#atTeaseWho'), name = inp.value.trim().toLowerCase().replace(/^@/, '').replace(/\s+/g, '');
    atTErr('');
    if (!name) return;
    if (name === state.username) { atTErr('C’est ton propre identifiant.'); return; }
    if (!NAME_RE.test(name)) { atTErr('Cet identifiant n’est pas valide.'); return; }
    try {
      var snap = await fs.collection('usernames').doc(name).get();
      if (!snap.exists) { atTErr('Aucun utilisateur ne s’appelle « ' + name + ' ».'); return; }
      inp.value = '';
      var uid = snap.data().uid;
      await atStart('u:' + uid, { name: name, emoji: atInitial(name), hue: atHue(name) }, uid);
    } catch (e) { atTErr('Recherche impossible. Vérifie ta connexion et les règles Firestore.'); }
  });
  $('#atOptBtn').addEventListener('click', function () {
    var on = !atOptIn();
    try { if (on) localStorage.removeItem(atOptKey()); else localStorage.setItem(atOptKey(), '1'); } catch (e) {}
    fs.collection('presence').doc(state.me).set({ noAnon: on ? firebase.firestore.FieldValue.delete() : true }, { merge: true }).catch(function () {});
    atOptPaint();
  });
  async function atSend() {
    var inp = $('#atText'), text = inp.value.trim();
    if (!text || !AT.cur) return;
    inp.value = '';
    var ref = fs.collection('anonThreads').doc(AT.cur), ts = Date.now(), b = fs.batch();
    b.set(ref.collection('messages').doc(), { uid: state.me, text: text.slice(0, 600), ts: ts });
    b.update(ref, { lastText: text.slice(0, 60), lastTs: ts, lastUid: state.me });
    try { await b.commit(); }
    catch (e) { inp.value = text; var er = $('#atErr'); er.textContent = 'Envoi impossible (connexion ou règles Firestore).'; er.hidden = false; }
  }
  document.addEventListener('click', function (e) {
    var tb = e.target.closest && e.target.closest('.nwtab');
    if (tb) nwPane(tb.dataset.p);
  });
  $('#atSend').addEventListener('click', atSend);
  $('#atText').addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); atSend(); } });

  function openNews() {
    if (newsBlocked()) return;
    leaveChat(); stopGame();
    pushView({ news: true });
    state.view = 'news';
    if (NW.uid !== state.me) { nwStop(); NW.uid = state.me; }
    viewList.hidden = true; viewChat.hidden = true; viewGame.hidden = true; viewMusic.hidden = true; viewNews.hidden = false;
    if (document.activeElement && document.activeElement.blur) document.activeElement.blur();
    nwErr('');
    nwListen(); nwRender(); atListen(); nwPane('feed');
    nwIdentity().then(nwPaintId);
  }
  $('#openNews').addEventListener('click', openNews);
  $('#nwBack').addEventListener('click', function () {
    var forced = this.dataset.force; delete this.dataset.force;
    if (!forced && AT.pane === 'thread') { nwPane('threads'); return; }
    if (!forced && AT.pane === 'threads') { nwPane('feed'); return; }
    if (history.state && history.state.news) history.back(); else showList();
  });
  $('#nwPost').addEventListener('click', nwPublish);
  $('#nwPhoto').addEventListener('click', function () { $('#nwFile').click(); });
  $('#nwFile').addEventListener('change', function () { nwPhotoPick(this.files && this.files[0]); });
  $('#nwPrevX').addEventListener('click', nwPhotoClear);
  (function () {
    var box = document.querySelector('#nwPaneFeed .nwid'), tg = $('#nwIdToggle');
    if (!box || !tg) return;
    function set(min) {
      box.classList.toggle('min', min);
      tg.textContent = min ? '👁️' : '🙈';
      tg.setAttribute('aria-pressed', min ? 'true' : 'false');
      tg.setAttribute('aria-label', min ? 'Afficher le nom et le bouton Changer' : 'Masquer le nom et le bouton Changer');
    }
    var on = false; try { on = localStorage.getItem('uandi-nwid-min') === '1'; } catch (e) {}
    set(on);
    tg.addEventListener('click', function () {
      var min = !box.classList.contains('min'); set(min);
      try { localStorage.setItem('uandi-nwid-min', min ? '1' : '0'); } catch (e) {}
    });
  })();
  $('#nwText').addEventListener('input', function () { $('#nwCount').textContent = this.value.length + ' / 600'; });
  /* changement d'identité : on efface les discussions anonymes lancées avec l'ancien nom et tes messages dans les autres ; les lettres et commentaires restent */
  function atRetKey() { return 'uandi-anonret-' + state.me; }
  function atRetired() { try { return JSON.parse(localStorage.getItem(atRetKey()) || '[]'); } catch (e) { return []; } }
  /* les anciennes lettres/commentaires ne sont plus reliés à toi : on ne reçoit plus de discussions dessus */
  function atRetire() {
    var all = atRetired();
    Object.keys(NW.mine).forEach(function (k) { if (all.indexOf(k) === -1) all.push(k); });
    try { localStorage.setItem(atRetKey(), JSON.stringify(all)); } catch (e) {}
    AT.sig = '';
  }
  async function atWipe() {
    var sn = await fs.collection('anonThreads').where('members', 'array-contains', state.me).get(), ops = [];
    for (var i = 0; i < sn.docs.length; i++) {
      var d = sn.docs[i], ms = await d.ref.collection('messages').get();
      ms.forEach(function (m) { ops.push(m.ref); });
      ops.push(d.ref); ops.push(fs.collection('anonRequests').doc(d.id));
      try { localStorage.removeItem(atSeenKey(d.id)); } catch (e) {}
    }
    for (var j = 0; j < ops.length; j += 400) {
      var b = fs.batch();
      ops.slice(j, j + 400).forEach(function (r) { b.delete(r); });
      try { await b.commit(); } catch (e) { for (var k = j; k < Math.min(j + 400, ops.length); k++) { try { await ops[k].delete(); } catch (e2) {} } }
    }
  }
  $('#nwReroll').addEventListener('click', async function () {
    if (!confirm('Changer d’identité anonyme ? Tu repars comme une autre personne : toutes tes discussions anonymes sont effacées et tu ne recevras plus de discussions sur tes anciennes lettres. Elles restent publiées avec l’ancien nom.')) return;
    var btn = this; btn.disabled = true;
    try {
      if (AT.msgU) { AT.msgU(); AT.msgU = null; }
      if (AT.pane === 'thread') nwPane('threads');
      await atWipe();
    } catch (e) { nwErr('Certains messages n’ont pas pu être effacés (règles Firestore : autorise la suppression dans « anonThreads »).'); }
    atRetire(); NW.id = nwMake(); nwSaveId(); nwPaintId(); atWatch();
    btn.disabled = false;
  });

  function openMusic() {
    leaveChat(); stopGame();
    pushView({ music: true });
    state.view = 'music';
    viewList.hidden = true; viewChat.hidden = true; viewGame.hidden = true; viewMusic.hidden = false;
    if (document.activeElement && document.activeElement.blur) document.activeElement.blur();
    mLoad(); mRender(); try { mShStart(); } catch (e) {}
  }
  $('#openMusic').addEventListener('click', openMusic);
  $('#musicBack').addEventListener('click', function () {
    if (history.state && history.state.music) history.back(); else showList();
  });
  $('#mAdd').addEventListener('click', function () { $('#mFiles').click(); });
  $('#mFiles').addEventListener('change', function (e) {
    var fl = Array.prototype.slice.call(e.target.files || []);
    e.target.value = '';
    if (fl.length) mAdd(fl);
  });
  $('#mPlay').addEventListener('click', mToggle);
  $('#mNext').addEventListener('click', function () { mNext(false); });
  $('#mPrev').addEventListener('click', mPrev);
  $('#mShuffle').addEventListener('click', function () { M.shuffle = !M.shuffle; mRender(); });
  $('#mRepeat').addEventListener('click', function () {
    M.repeat = M.repeat === 'off' ? 'all' : M.repeat === 'all' ? 'one' : 'off';
    mRender();
  });
  $('#mSeek').addEventListener('input', function () {
    var d = mAu.duration;
    if (isFinite(d) && d > 0) { M.seekAt = Date.now(); mAu.currentTime = this.value / 1000 * d; }
  });
  function mSaveEdit() {
    var t = M.tracks[M.edit];
    M.edit = -1;
    if (t) {
      t.title = M.draft.trim().slice(0, 80);
      if (typeof t.id === 'number') {
        mTx('readwrite', function (st) {
          var r = st.get(t.id);
          r.onsuccess = function () { var v = r.result; if (v) { v.title = t.title; st.put(v); } };
          return r;
        }).catch(function () {});
      }
      mMeta();
    }
    mRender();
  }
  $('#mList').addEventListener('input', function (e) {
    if (e.target.classList.contains('mfield')) M.draft = e.target.value;
  });
  $('#mList').addEventListener('keydown', function (e) {
    if (!e.target.classList.contains('mfield')) return;
    if (e.key === 'Enter') { e.preventDefault(); mSaveEdit(); }
    else if (e.key === 'Escape') { M.edit = -1; mRender(); }
  });
  $('#mList').addEventListener('click', function (e) {
    if (e.target.closest('.mok')) { mSaveEdit(); return; }
    var rn = e.target.closest('.mren');
    if (rn) {
      var k = +rn.dataset.i;
      M.edit = k; M.draft = mLabel(M.tracks[k]); M.focusEdit = true;
      mRender();
      return;
    }
    var shb = e.target.closest('.mshare');
    if (shb) { mShareAsk(+shb.dataset.i); return; }
    var d = e.target.closest('.mdel');
    if (d) { mRemove(+d.dataset.i); return; }
    var b = e.target.closest('.mname');
    if (b) { var i = +b.dataset.i; if (i === M.cur) mToggle(); else mPlay(i); }
  });
  $('#mClear').addEventListener('click', function () {
    var b = this;
    if (!b.classList.contains('sure')) {
      b.classList.add('sure'); b.textContent = 'Confirmer ?';
      mClearT = setTimeout(resetMClear, 3000);
      return;
    }
    resetMClear();
    M.tracks.forEach(function (t) { try { URL.revokeObjectURL(t.url); } catch (e) {} });
    M.tracks = []; M.cur = -1; M.edit = -1;
    mAu.pause(); mAu.removeAttribute('src'); mAu.load();
    mTx('readwrite', function (st) { return st.clear(); }).catch(function () {});
    mMeta(); mRender(); mTime();
  });
  ['timeupdate', 'loadedmetadata', 'durationchange'].forEach(function (ev) { mAu.addEventListener(ev, mTime); });
  ['play', 'pause'].forEach(function (ev) { mAu.addEventListener(ev, mRender); });
  mAu.addEventListener('ended', function () { mNext(true); });
  mAu.addEventListener('error', function () {
    var t = M.tracks[M.cur];
    if (!t) return;
    if (t.remote && !t.fb) {
      t.fb = true; mMsg('Chargement de « ' + mLabel(t) + ' »…');
      mGetBlob(t.url).then(function (b) {
        if (!b) { mMsg('Impossible de lire « ' + mLabel(t) + ' » : le lien du cloud ne répond pas.'); return; }
        var f = (b.type && b.type.indexOf('audio/') === 0) ? b : b.slice(0, b.size, 'audio/mpeg');
        t.url = URL.createObjectURL(f);
        if (M.tracks[M.cur] === t) { mAu.src = t.url; var p = mAu.play(); if (p && p.catch) p.catch(function () {}); }
      });
      return;
    }
    mMsg('Impossible de lire « ' + mLabel(t) + ' ».');
  });
  try {
    if ('mediaSession' in navigator) {
      navigator.mediaSession.setActionHandler('play', mToggle);
      navigator.mediaSession.setActionHandler('pause', mToggle);
      navigator.mediaSession.setActionHandler('previoustrack', mPrev);
      navigator.mediaSession.setActionHandler('nexttrack', function () { mNext(false); });
    }
  } catch (e) {}

