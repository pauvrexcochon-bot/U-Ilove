/* U&I — js/app/20-ecoute-ensemble.js
   Écouter ensemble en direct (WebRTC)
   (fait partie de l’appli : assemblée par js/boot/loader.js dans une seule fermeture) */
  /* ---------- écouter ensemble en direct (WebRTC, signalisation via Firestore) ---------- */
  /* Serveurs relais (TURN) : nécessaires quand les deux téléphones sont en 4G/5G ou derrière un réseau strict.
     Les identifiants « openrelayproject » sont un service public gratuit (limité). Pour un direct fiable,
     crée un compte gratuit sur metered.ca (Open Relay) puis colle tes propres serveurs dans LIVE_TURN_EXTRA, par ex. :
     { urls: 'turn:global.relay.metered.ca:443?transport=tcp', username: 'TON_USER', credential: 'TON_MOT_DE_PASSE' } */
  var LIVE_TURN_EXTRA = [
    { urls: 'stun:stun.relay.metered.ca:80' },
    { urls: ['turn:global.relay.metered.ca:80', 'turn:global.relay.metered.ca:80?transport=tcp', 'turn:global.relay.metered.ca:443', 'turns:global.relay.metered.ca:443?transport=tcp'],
      username: '945203f5cdfa5f8655fe4730', credential: 'xvoDPMhJQP9TnTML' }
  ];
  var ICE = {
    iceServers: LIVE_TURN_EXTRA.concat([
      { urls: ['stun:stun.l.google.com:19302', 'stun:stun1.l.google.com:19302', 'stun:stun.cloudflare.com:3478'] },
      { urls: ['turn:openrelay.metered.ca:80', 'turn:openrelay.metered.ca:443', 'turn:openrelay.metered.ca:443?transport=tcp', 'turns:openrelay.metered.ca:443?transport=tcp'],
        username: 'openrelayproject', credential: 'openrelayproject' }
    ]),
    iceCandidatePoolSize: 2
  };
  var L = { role: null, chat: null, sid: '', jid: '', pc: null, rem: null, g: null, sigUnsub: null, beatT: null, gUnsub: null, gT: null, joinT: null,
            watch: null, watchT: null, sess: null, pend: [], title: '', state: 'wait', needTap: false, gAt: 0, peers: {}, n: 0, hname: '' };
  var LIVE_MAX = 8; /* auditeurs simultanés max par écoute de groupe (le téléphone de l’hôte envoie le son à chacun) */
  function liveRef(id) { return fs.collection('chats').doc(id).collection('live').doc('session'); }
  function liveCol(id) { return fs.collection('chats').doc(id).collection('liveSig'); }
  function liveId() { return Date.now().toString(36) + Math.random().toString(36).slice(2, 7); }
  function liveFresh(s) { return !!(s && s.host && Math.abs(Date.now() - (s.beat || 0)) < 120000); }
  function liveSdp(sdp) {
    var m = /a=rtpmap:(\d+) opus\/48000/i.exec(sdp);
    if (!m) return sdp;
    var re = new RegExp('a=fmtp:' + m[1] + ' ([^\\r\\n]*)');
    return sdp.replace(re, function (all, rest) {
      return /stereo=1/.test(rest) ? all : 'a=fmtp:' + m[1] + ' ' + rest + ';stereo=1;sprop-stereo=1;maxaveragebitrate=128000';
    });
  }
  function liveGraph() {
    if (L.g) return L.g;
    var AC = window.AudioContext || window.webkitAudioContext, ac = new AC();
    var src = ac.createMediaElementSource(mAu), dest = ac.createMediaStreamDestination();
    src.connect(ac.destination);
    L.g = { ac: ac, src: src, dest: dest };
    return L.g;
  }
  mAu.addEventListener('play', function () {
    if (L.g && L.g.ac.state === 'suspended') L.g.ac.resume().catch(function () {});
    if (L.role === 'host') liveBeat();
  });
  function liveName() { return L.chat ? cap(L.role === 'guest' && L.chat.group && L.hname ? L.hname : L.chat.name) : ''; }
  function liveHostName(chat, sess) {
    if (!chat || !chat.group) return cap(chat && chat.name);
    var gc = chatOf(chat.id), u = sess && sess.host;
    return cap(nickOf(gc, u) || (gc && gc.names && gc.names[u]) || 'Un membre');
  }
  function liveCount() { return Object.keys(L.peers).filter(function (k) { return L.peers[k].ok; }).length; }
  var liveClamp = null;
  function liveBar() {
    var b = $('#livebar');
    if (!L.role) { b.hidden = true; b.replaceChildren(); return; }
    var host = L.role === 'host', txt;
    if (host && L.chat && L.chat.group) {
      var gn = liveCount();
      txt = gn ? '🎧 ' + gn + (gn > 1 ? ' auditeurs' : ' auditeur') + (L.title ? ' · ' + L.title : '') : 'En attente d’auditeurs dans le groupe…';
    }
    else if (L.state === 'live') txt = 'Avec ' + liveName() + (L.title ? ' · ' + L.title : '');
    else if (L.state === 'lost') txt = 'Connexion instable…';
    else if (host && L.state === 'wait') txt = 'En attente de ' + liveName() + '…';
    else txt = 'Connexion…';
    b.replaceChildren();
    var grip = el('span', 'lbgrip', '🎧');
    grip.setAttribute('aria-label', txt + ' (touche pour afficher le titre, glisse pour déplacer)');
    b.appendChild(grip);
    if (L.exp) b.appendChild(el('span', 'lbtxt', txt));
    var mk = function (label, aria, fn) {
      var x = el('button', '', label); x.type = 'button'; x.setAttribute('aria-label', aria); x.addEventListener('click', fn); b.appendChild(x);
    };
    if (host) {
      mk('⏯', 'Lecture / pause', function () { mToggle(); });
      mk('⏭', 'Morceau suivant', function () { mNext(false); });
    } else if (L.needTap) mk('🔊', 'Activer le son', function () { if (L.rem) L.rem.play().then(function () { L.needTap = false; liveBar(); }).catch(function () {}); });
    mk('✕', host ? 'Arrêter' : 'Quitter', function () { liveStop(); });
    b.hidden = false;
    if (liveClamp) liveClamp();
  }
  /* la petite barre se déplace partout sur l'écran : on la tient par 🎧 (ou le titre) et on glisse ; un simple appui affiche/masque le titre */
  (function () {
    var bar = $('#livebar'), drag = null;
    function clamp() {
      if (bar.hidden || (!bar.style.left && !bar.style.top)) return;
      var r = bar.getBoundingClientRect();
      bar.style.left = Math.max(4, Math.min(window.innerWidth - r.width - 4, r.left)) + 'px';
      bar.style.top = Math.max(4, Math.min(window.innerHeight - r.height - 4, r.top)) + 'px';
    }
    liveClamp = clamp;
    window.addEventListener('resize', clamp);
    bar.addEventListener('pointerdown', function (ev) {
      if (ev.target.closest('button')) return;
      var r = bar.getBoundingClientRect();
      drag = { x: ev.clientX, y: ev.clientY, left: r.left, top: r.top, moved: false };
      try { bar.setPointerCapture(ev.pointerId); } catch (e) {}
    });
    bar.addEventListener('pointermove', function (ev) {
      if (!drag) return;
      var dx = ev.clientX - drag.x, dy = ev.clientY - drag.y;
      if (!drag.moved && Math.abs(dx) + Math.abs(dy) < 6) return;
      drag.moved = true;
      var w = bar.offsetWidth, h = bar.offsetHeight;
      bar.style.left = Math.max(4, Math.min(window.innerWidth - w - 4, drag.left + dx)) + 'px';
      bar.style.top = Math.max(4, Math.min(window.innerHeight - h - 4, drag.top + dy)) + 'px';
    });
    bar.addEventListener('pointerup', function () {
      var d = drag; drag = null;
      if (d && !d.moved) { L.exp = !L.exp; liveBar(); }
    });
    bar.addEventListener('pointercancel', function () { drag = null; });
  })();
  function liveBanner() {
    var b = $('#liveBanner'), s = L.sess, chat = state.chat;
    if (!b) return;
    var ok = !!(chat && s && s.host !== state.me && !L.role && liveFresh(s));
    b.hidden = !ok;
    if (!ok) { b.replaceChildren(); return; }
    b.replaceChildren();
    b.appendChild(el('span', '', '🎧 ' + liveHostName(chat, s) + ' écoute « ' + (s.title || 'une musique') + ' »' + (chat.group ? ' avec le groupe' : '')));
    var j = el('button', 'ghost', 'Rejoindre'); j.type = 'button';
    j.addEventListener('click', function () { liveJoin({ id: chat.id, other: chat.other, name: chat.name, group: !!chat.group }, s); });
    b.appendChild(j);
  }
  function liveWatch(chat) {
    liveUnwatch();
    if (!chat) return;
    L.watch = liveRef(chat.id).onSnapshot(function (d) { L.sess = d.exists ? d.data() : null; liveBanner(); }, function () {});
    L.watchT = setInterval(liveBanner, 10000);
  }
  function liveUnwatch() {
    if (L.watch) { try { L.watch(); } catch (e) {} }
    L.watch = null; clearInterval(L.watchT); L.sess = null;
    liveBanner();
  }
  function liveStatus(st) { L.state = st; liveBar(); }
  function liveBeat() {
    if (L.role !== 'host' || !L.chat) return;
    var t = M.tracks[M.cur];
    liveRef(L.chat.id).update({ beat: Date.now(), title: t ? mLabel(t) : '' }).catch(function () {});
  }
  function liveSig(kind, extra) {
    if (!L.chat) return;
    var d = { sid: L.sid, jid: L.jid, from: state.me, kind: kind, ts: Date.now() };
    for (var k in extra) d[k] = extra[k];
    if (L.role === 'host' && !d.jid) d.jid = '';
    liveCol(L.chat.id).add(d).catch(function () {});
  }
  function liveIce(c) {
    if (L.pc && L.pc.remoteDescription) L.pc.addIceCandidate(c).catch(function () {}); else L.pend.push(c);
  }
  function liveFlush() {
    var pc = L.pc;
    L.pend.splice(0).forEach(function (c) { if (pc) pc.addIceCandidate(c).catch(function () {}); });
  }
  function liveNewPc() {
    if (L.pc) { try { L.pc.close(); } catch (e) {} }
    var pc = new RTCPeerConnection(ICE);
    L.pc = pc;
    L.cand = { host: 0, srflx: 0, relay: 0 };
    pc.onicecandidate = function (e) {
      if (!e.candidate || L.pc !== pc) return;
      var m = / typ (host|srflx|relay)/.exec(e.candidate.candidate || '');
      if (m) L.cand[m[1]]++;
      liveSig('ice', { data: JSON.stringify(e.candidate) });
    };
    pc.onconnectionstatechange = function () {
      if (L.pc !== pc) return;
      var s = pc.connectionState;
      if (s === 'connected') { clearTimeout(L.joinT); liveStatus('live'); }
      else if (s === 'disconnected') liveStatus('lost');
      else if (s === 'failed') {
        var why = L.cand && !L.cand.relay ? 'Serveur relais injoignable : ajoute tes identifiants TURN (metered.ca).' : 'La connexion directe a échoué (réseau).';
        if (L.role === 'guest') {
          if ((L.retry || 0) < 1) {
            L.retry = (L.retry || 0) + 1;
            try { pc.close(); } catch (e) {}
            L.pc = null; L.jid = liveId(); L.pend = [];
            liveStatus('connecting');
            clearTimeout(L.joinT);
            L.joinT = setTimeout(function () { if (L.role === 'guest' && L.state !== 'live') liveStop(why); }, 25000);
            liveSig('join');
          } else liveStop(why);
        } else { try { pc.close(); } catch (e) {} L.pc = null; liveStatus('wait'); }
      }
    };
    return pc;
  }
  /* hôte : une connexion WebRTC par auditeur (clé = jid de l’auditeur) */
  function liveDropPeer(jid) {
    var pr = L.peers[jid];
    if (!pr) return;
    delete L.peers[jid];
    try { pr.pc.close(); } catch (e) {}
    if (L.role !== 'host') return;
    if (L.chat && L.chat.group) liveBar();
    else if (!Object.keys(L.peers).length) liveStatus('wait');
  }
  function liveHostPeer(jid, from) {
    var pc = new RTCPeerConnection(ICE), pr = { pc: pc, pend: [], from: from, ok: false, cand: { host: 0, srflx: 0, relay: 0 } };
    L.peers[jid] = pr;
    pc.onicecandidate = function (e) {
      if (!e.candidate || L.peers[jid] !== pr) return;
      var m = / typ (host|srflx|relay)/.exec(e.candidate.candidate || '');
      if (m) pr.cand[m[1]]++;
      liveSig('ice', { data: JSON.stringify(e.candidate), jid: jid });
    };
    pc.onconnectionstatechange = function () {
      if (L.peers[jid] !== pr) return;
      var st = pc.connectionState;
      if (st === 'connected') { pr.ok = true; clearTimeout(pr.t); if (L.chat && L.chat.group) liveBar(); else liveStatus('live'); }
      else if (st === 'disconnected') { pr.ok = false; if (L.chat && L.chat.group) liveBar(); else liveStatus('lost'); }
      else if (st === 'failed' || st === 'closed') liveDropPeer(jid);
    };
    /* un auditeur qui n’aboutit jamais ne doit pas rester dans la liste */
    pr.t = setTimeout(function () { if (L.peers[jid] === pr && !pr.ok) liveDropPeer(jid); }, 45000);
    return pr;
  }
  async function liveSignal(d) {
    try {
      if (L.role === 'host') {
        if (d.kind === 'join') {
          var old = Object.keys(L.peers).filter(function (k) { return L.peers[k].from === d.from; });
          old.forEach(liveDropPeer);
          var isGroup = !!(L.chat && L.chat.group);
          if (isGroup && Object.keys(L.peers).length >= LIVE_MAX) { liveSig('full', { jid: d.jid }); return; }
          var pr = liveHostPeer(d.jid, d.from), pc = pr.pc;
          if (!isGroup) liveStatus('connecting');
          var g = L.g;
          g.dest.stream.getAudioTracks().forEach(function (tr) { pc.addTrack(tr, g.dest.stream); });
          var off = await pc.createOffer();
          off.sdp = liveSdp(off.sdp);
          await pc.setLocalDescription(off);
          liveSig('offer', { data: JSON.stringify({ type: off.type, sdp: off.sdp }), jid: d.jid });
        } else if (d.kind === 'leave') {
          liveDropPeer(d.jid);
        } else if (L.peers[d.jid]) {
          var pe = L.peers[d.jid];
          if (d.kind === 'answer') {
            await pe.pc.setRemoteDescription(JSON.parse(d.data));
            pe.pend.splice(0).forEach(function (c) { pe.pc.addIceCandidate(c).catch(function () {}); });
          } else if (d.kind === 'ice') {
            var cd = JSON.parse(d.data);
            if (pe.pc.remoteDescription) pe.pc.addIceCandidate(cd).catch(function () {}); else pe.pend.push(cd);
          }
        }
      } else if (L.role === 'guest' && d.jid === L.jid) {
        if (d.kind === 'full') { liveStop('Le salon d’écoute est complet (' + LIVE_MAX + ' personnes max).'); return; }
        if (d.kind === 'offer') {
          clearTimeout(L.joinT);
          var pc2 = liveNewPc();
          pc2.ontrack = function (ev) {
            if (!L.rem) { L.rem = new Audio(); L.rem.autoplay = true; }
            L.rem.srcObject = ev.streams && ev.streams[0] ? ev.streams[0] : new MediaStream([ev.track]);
            L.rem.play().then(function () { L.needTap = false; liveBar(); }).catch(function () { L.needTap = true; liveBar(); });
          };
          await pc2.setRemoteDescription(JSON.parse(d.data));
          liveFlush();
          var ans = await pc2.createAnswer();
          ans.sdp = liveSdp(ans.sdp);
          await pc2.setLocalDescription(ans);
          liveSig('answer', { data: JSON.stringify({ type: ans.type, sdp: ans.sdp }) });
        } else if (d.kind === 'ice') liveIce(JSON.parse(d.data));
      }
    } catch (e) {}
  }
  function liveListenSig() {
    var seen = {};
    L.sigUnsub = liveCol(L.chat.id).where('sid', '==', L.sid).onSnapshot(function (snap) {
      snap.docChanges().forEach(function (ch) {
        if (ch.type !== 'added' || seen[ch.doc.id]) return;
        seen[ch.doc.id] = 1;
        var d = ch.doc.data();
        if (d && d.from !== state.me) liveSignal(d);
      });
    }, function () { liveStop('Le direct n’a pas pu démarrer (règles Firestore ?).'); });
  }
  async function liveNotice(chat, text) {
    try {
      var chatRef = fs.collection('chats').doc(chat.id), msgRef = chatRef.collection('messages').doc(), ts = Date.now();
      var exists = !!state.chatsById[chat.id] || !!chat.group;
      if (!exists) exists = (await chatRef.get()).exists;
      var batch = fs.batch();
      batch.set(msgRef, { uid: state.me, sts: SV(), text: text, ts: ts });
      var last = { lastText: text.slice(0, 120), lastTs: ts, lastUid: state.me };
      if (exists) { last['seen.' + state.me] = ts; batch.update(chatRef, last); }
      else {
        var names = {}; names[state.me] = myName(); names[chat.other] = chat.name;
        var seen = {}; seen[state.me] = ts;
        batch.set(chatRef, { members: [state.me, chat.other], names: names, lastText: last.lastText, lastTs: ts, lastUid: state.me, seen: seen });
      }
      await batch.commit();
      state.chatsById[chat.id] = true;
    } catch (e) {}
  }
  async function liveStart(chat, i) {
    var t = M.tracks[i];
    if (!t || L.role) return;
    if (!window.RTCPeerConnection || !(window.AudioContext || window.webkitAudioContext)) { showErr('Ton navigateur ne permet pas l’écoute en direct.'); return; }
    var g;
    try { g = liveGraph(); g.ac.resume().catch(function () {}); g.src.connect(g.dest); }
    catch (e) { showErr('Ton navigateur ne permet pas l’écoute en direct.'); return; }
    if (chat.group && L.sess && L.sess.host !== state.me && liveFresh(L.sess)) { showErr('Une écoute est déjà en cours dans ce groupe : rejoins-la.'); return; }
    L.role = 'host'; L.chat = chat; L.sid = liveId(); L.jid = ''; L.title = mLabel(t); L.pend = []; L.peers = {};
    liveStatus('wait');
    mPlay(i);
    await liveNotice(chat, chat.group ? '🎧 J’écoute « ' + mLabel(t) + ' » : rejoignez-moi avec le bandeau 🎧 (max ' + LIVE_MAX + ' personnes).' : '🎧 Écoutons « ' + mLabel(t) + ' » ensemble : appuie sur 🎧 pour me rejoindre.');
    try {
      await liveRef(chat.id).set({ host: state.me, sid: L.sid, title: mLabel(t), beat: Date.now(), ts: Date.now() });
    } catch (e) {
      liveStop();
      showErr('Direct impossible (connexion ou règles Firestore).');
      return;
    }
    L.beatT = setInterval(liveBeat, 15000);
    liveListenSig();
  }
  function liveJoin(chat, sess) {
    if (L.role) return;
    if (!window.RTCPeerConnection) { showErr('Ton navigateur ne permet pas l’écoute en direct.'); return; }
    L.retry = 0;
    L.role = 'guest'; L.chat = chat; L.hname = chat.group ? liveHostName(chat, sess) : ''; L.sid = sess.sid; L.jid = liveId(); L.title = sess.title || ''; L.pend = []; L.needTap = false;
    L.rem = new Audio(); L.rem.autoplay = true;
    liveStatus('connecting');
    liveListenSig();
    L.gAt = Date.now();
    L.gUnsub = liveRef(chat.id).onSnapshot(function (d) {
      var v = d.exists ? d.data() : null;
      if (!v || v.sid !== L.sid) { liveStop('L’écoute est terminée.'); return; }
      L.gAt = Date.now();
      if ((v.title || '') !== L.title) { L.title = v.title || ''; liveBar(); }
    }, function () {});
    L.gT = setInterval(function () { if (Date.now() - L.gAt > 60000) liveStop('L’écoute est terminée.'); }, 10000);
    L.joinT = setTimeout(function () { if (L.role === 'guest' && L.state !== 'live') liveStop(L.cand && !L.cand.relay ? 'Serveur relais injoignable : ajoute tes identifiants TURN (metered.ca).' : 'Impossible de te connecter (réseau ou la personne est partie).'); }, 25000);
    liveSig('join');
  }
  function liveStop(msg) {
    var chat = L.chat, role = L.role, sid = L.sid;
    if (role === 'guest') liveSig('leave');
    Object.keys(L.peers).forEach(function (k) { try { L.peers[k].pc.close(); } catch (e) {} clearTimeout(L.peers[k].t); });
    L.peers = {}; L.hname = '';
    clearInterval(L.beatT); clearInterval(L.gT); clearTimeout(L.joinT);
    if (L.sigUnsub) { try { L.sigUnsub(); } catch (e) {} }
    if (L.gUnsub) { try { L.gUnsub(); } catch (e) {} }
    if (L.pc) { try { L.pc.close(); } catch (e) {} }
    if (L.rem) { try { L.rem.pause(); L.rem.srcObject = null; } catch (e) {} }
    if (L.g) { try { L.g.src.disconnect(L.g.dest); } catch (e) {} }
    L.role = null; L.chat = null; L.sid = ''; L.jid = ''; L.pc = null; L.rem = null; L.sigUnsub = null; L.gUnsub = null;
    L.beatT = null; L.gT = null; L.joinT = null; L.pend = []; L.title = ''; L.needTap = false; L.state = 'wait';
    if (role === 'host' && chat) {
      liveRef(chat.id).delete().catch(function () {});
      liveCol(chat.id).where('sid', '==', sid).get().then(function (sn) {
        var b = fs.batch(); sn.forEach(function (d) { b.delete(d.ref); }); return b.commit();
      }).catch(function () {});
    }
    liveBar();
    if (msg) {
      var bar = $('#livebar');
      bar.replaceChildren(el('span', 'lbtxt', '🎧 ' + msg));
      bar.hidden = false;
      setTimeout(function () { if (!L.role) bar.hidden = true; }, 4500);
    }
  }
  function liveOpen() {
    var chat = state.chat;
    if (!chat) return;
    mShareClose();
    var bg = el('div', 'sheetbg'), sheet = el('div', 'sheet'), nm = cap(chat.name), s = L.sess, hn = liveHostName(chat, s);
    var stopB = function (label) {
      var b = el('button', 'ghost', label); b.type = 'button'; b.style.marginTop = '10px';
      b.addEventListener('click', function () { mShareClose(); liveStop(); });
      return b;
    };
    if (L.role && L.chat.id !== chat.id) {
      sheet.appendChild(el('h3', '', 'Écoute en cours avec ' + liveName()));
      sheet.appendChild(stopB(L.role === 'host' ? 'Arrêter' : 'Quitter'));
    } else if (L.role === 'guest') {
      sheet.appendChild(el('h3', '', 'Tu écoutes avec ' + (chat.group ? hn : nm)));
      if (L.title) sheet.appendChild(el('p', '', '« ' + L.title + ' »'));
      sheet.appendChild(stopB('Quitter'));
    } else if (!L.role && s && s.host !== state.me && liveFresh(s)) {
      sheet.appendChild(el('h3', '', hn + ' écoute « ' + (s.title || 'une musique') + ' »'));
      var jb = el('button', 'pick', '🎧 Rejoindre'); jb.type = 'button';
      jb.addEventListener('click', function () { mShareClose(); liveJoin({ id: chat.id, other: chat.other, name: chat.name, group: !!chat.group }, s); });
      sheet.appendChild(jb);
    } else {
      sheet.appendChild(el('h3', '', L.role === 'host' ? 'Changer de morceau' : 'Écouter ensemble avec ' + (chat.group ? 'le groupe' : nm)));
      sheet.appendChild(el('p', '', chat.group ? 'Choisis un morceau de ta bibliothèque : les membres du groupe pourront l’écouter en même temps que toi (' + LIVE_MAX + ' max).' : 'Choisis un morceau de ta bibliothèque : ' + nm + ' l’entendra en même temps que toi.'));
      var box = el('div');
      sheet.appendChild(box);
      Promise.resolve(mLoad()).then(function () {
        if (!M.tracks.length) { box.appendChild(el('p', '', 'Ajoute d’abord des musiques dans ♪ Musique.')); return; }
        M.tracks.forEach(function (t, i) {
          var b = el('button', 'pick', mLabel(t)); b.type = 'button';
          b.addEventListener('click', function () {
            mShareClose();
            if (L.role === 'host') mPlay(i); else liveStart({ id: chat.id, other: chat.other, name: chat.name, group: !!chat.group }, i);
          });
          box.appendChild(b);
        });
      });
      if (L.role === 'host') sheet.appendChild(stopB('Arrêter l’écoute'));
    }
    var cn = el('button', 'ghost', 'Fermer');
    cn.type = 'button'; cn.style.marginTop = '10px';
    cn.addEventListener('click', mShareClose);
    sheet.appendChild(cn);
    bg.appendChild(sheet);
    bg.addEventListener('click', function (e) { if (e.target === bg) mShareClose(); });
    document.body.appendChild(bg);
  }
  window.uandiMusic = { load: function () { return Promise.resolve(mLoad()); }, tracks: function () { return M.tracks; }, label: mLabel, add: mAdd,
    pause: function () { if (L.role !== 'host') { try { mAu.pause(); } catch (e) {} } } };
  $('#liveBtn').addEventListener('click', liveOpen);
  window.addEventListener('pagehide', function () { if (L.role === 'host' && L.chat) { try { liveRef(L.chat.id).delete(); } catch (e) {} } });

