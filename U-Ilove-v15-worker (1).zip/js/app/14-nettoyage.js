/* U&I — js/app/14-nettoyage.js
   Libérer de l’espace, supprimer une discussion
   (fait partie de l’appli : assemblée par js/boot/loader.js dans une seule fermeture) */
  /* ---------- libérer de l'espace : retire mes anciennes photos intégrées (data:) ---------- */
  var freeBtn = $('#freeSpace'), freeMsg = $('#freeMsg'), freeBusy = false;
  function freeSpace() {
    /* aucune lecture Firestore en plus : on ne travaille que sur les messages déjà chargés de la discussion ouverte */
    if (freeBusy || !state.me) return;
    if (!state.chat || !state.msgs.length) { freeMsg.textContent = 'Ouvre une discussion, puis reviens ici : seuls les messages déjà chargés sont nettoyés (aucune lecture en plus).'; return; }
    var n = cleanPhotos(state.chat.id, state.msgs, true);
    freeMsg.textContent = n ? n + ' ancienne(s) photo(s) retirée(s) de tes messages dans cette discussion.' : 'Rien à nettoyer ici : aucune photo intégrée de plus de 7 jours dans tes messages chargés.';
  }
  freeBtn.addEventListener('click', freeSpace);

  /* ---------- supprimer une discussion ---------- */
  var delBtn = $('#delChat'), delTimer = null;
  function hiddenChats() {
    try { return JSON.parse(store('uandi-hidden-' + state.me) || '{}'); } catch (e) { return {}; }
  }
  function hideChatLocally(id) {
    var h = hiddenChats(); h[id] = Date.now();
    store('uandi-hidden-' + state.me, JSON.stringify(h));
  }
  function resetDelBtn() {
    clearTimeout(delTimer);
    delBtn.classList.remove('sure');
    delBtn.textContent = (state.chat && state.chat.group && (chatOf(state.chat.id) || {}).owner !== state.me) ? 'Quitter' : 'Supprimer';
    delBtn.disabled = false;
  }
  async function deleteChat() {
    var chat = state.chat;
    if (!chat) return;
    delBtn.disabled = true;
    delBtn.textContent = 'Suppression…';
    var chatRef = fs.collection('chats').doc(chat.id);
    var leaving = !!(chat.group && (chatOf(chat.id) || {}).owner !== state.me);
    var ok = true;
    try {
      if (leaving) {
        var FV = firebase.firestore.FieldValue, upd = { members: FV.arrayRemove(state.me) };
        upd['names.' + state.me] = FV.delete(); upd['nicks.' + state.me] = FV.delete();
        await chatRef.update(upd);
      } else {
        for (var guard = 0; guard < 50; guard++) {
          var snap = await chatRef.collection('messages').limit(400).get();
          if (snap.empty) break;
          var batch = fs.batch();
          snap.docs.forEach(function (d) { batch.delete(d.ref); });
          await batch.commit();
        }
        await chatRef.delete();
      }
    } catch (e) { ok = false; }
    if (!ok && !leaving) hideChatLocally(chat.id);
    resetDelBtn();
    state.chatsById[chat.id] = false;
    if (history.state && history.state.chat) history.back(); else showList();
    if (!ok) showNewErr(leaving ? 'Impossible de quitter le groupe pour le moment : réessaie.' : 'Suppression complète refusée : la discussion est masquée sur cet appareil seulement.');
  }
  delBtn.addEventListener('click', function () {
    if (delBtn.classList.contains('sure')) { deleteChat(); return; }
    delBtn.classList.add('sure');
    delBtn.textContent = 'Confirmer ?';
    delTimer = setTimeout(resetDelBtn, 3500);
  });

  logEl.addEventListener('scroll', function () { if (nearBottom()) jumpBtn.hidden = true; }, { passive: true });
  jumpBtn.addEventListener('click', scrollBottom);
  form.addEventListener('submit', function (ev) { ev.preventDefault(); send(); });
  ta.addEventListener('input', function () {
    autosize();
    if (state.chat && !state.editing) store('uandi-draft-' + state.chat.id, ta.value || null);
    setTyping(ta.value.trim().length > 0);
  });
  ta.addEventListener('keydown', function (ev) {
    if (ev.key === 'Enter' && !ev.shiftKey && !ev.isComposing &&
        window.matchMedia && matchMedia('(pointer: fine)').matches) {
      ev.preventDefault();
      send();
    }
  });
  ta.addEventListener('blur', function () { setTyping(false); });

  $('#back').addEventListener('click', function () {
    if (history.state && history.state.chat) history.back(); else showList();
  });
  window.addEventListener('popstate', function () { if (state.view === 'chat' || state.view === 'game' || state.view === 'music' || state.view === 'news') showList(); });

  document.addEventListener('visibilitychange', function () {
    if (!state.me) return;
    if (document.hidden) { typingChat = null; writePresence({ typingIn: null, seen: 0 }); }
    else { beat(); markSeen(); }
    updateTitle();
  });

  $('#logout').addEventListener('click', function () {
    var done0 = function () { auth.signOut(); };
    var done = function () { pushUnreg().then(done0, done0); };
    if (state.me) {
      fs.collection('presence').doc(state.me).set({ seen: 0, typingIn: null }, { merge: true }).then(done, done);
    } else done();
  });

