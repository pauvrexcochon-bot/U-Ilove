/* U&I — js/app/13-fichiers-vocaux.js
   Fichiers et musiques partagés, lecteur et messages vocaux
   (fait partie de l’appli : assemblée par js/boot/loader.js dans une seule fermeture) */
  /* ---------- fichiers et musiques partagés (discussions et groupes) ---------- */
  var FILE_MAX = 640 * 1024, BIG_MAX = 8 * 1024 * 1024, CHUNK = 600000, LF = {}, fileBusy = false;
  var docBtn = $('#docBtn'), docFile = $('#docFile'), musBtn = $('#musBtn'), musFile = $('#musFile'), cntEl = $('#count');
  function fmtSize(n) { return n >= 1048576 ? (n / 1048576).toFixed(1).replace('.', ',') + ' Mo' : Math.max(1, Math.round(n / 1024)) + ' Ko'; }
  function isAudioFile(fl) { return /^audio\//.test(fl.mt || '') || /\.(mp3|m4a|aac|wav|ogg|opus|flac|weba)$/i.test(fl.n || ''); }
  var MIMES = { pdf: 'application/pdf', docx: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', pptx: 'application/vnd.openxmlformats-officedocument.presentationml.presentation', xlsx: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', doc: 'application/msword', ppt: 'application/vnd.ms-powerpoint', xls: 'application/vnd.ms-excel', odt: 'application/vnd.oasis.opendocument.text', zip: 'application/zip', txt: 'text/plain', csv: 'text/csv', md: 'text/markdown', json: 'application/json', html: 'text/html', png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', gif: 'image/gif', webp: 'image/webp', mp3: 'audio/mpeg', m4a: 'audio/mp4', wav: 'audio/wav', ogg: 'audio/ogg', mp4: 'video/mp4' };
  function extOf(n) { var m = /\.([A-Za-z0-9]{1,6})$/.exec(String(n || '')); return m ? m[1].toLowerCase() : ''; }
  function guessMime(name, mt) { return (mt && mt !== 'application/octet-stream') ? mt : (MIMES[extOf(name)] || mt || 'application/octet-stream'); }
  function safeName(n, mt) {
    n = String(n || 'fichier').replace(/[\\/:*?"<>|\u0000-\u001f]+/g, '_').trim() || 'fichier';
    if (!extOf(n)) { for (var k in MIMES) if (MIMES[k] === mt) { n += '.' + k; break; } }
    return n;
  }
  function saveBlob(bl, name) {
    var nm = safeName(name, bl.type), u = URL.createObjectURL(bl), a = document.createElement('a');
    a.href = u; a.download = nm; document.body.appendChild(a); a.click(); a.remove();
    setTimeout(function () { URL.revokeObjectURL(u); }, 60000);
  }
  /* vérifie que le contenu reçu est bien le fichier annoncé (et pas une page d'erreur enregistrée sous le même nom) */
  function sniff(bl, name) {
    return bl.slice(0, 16).arrayBuffer().then(function (b) {
      var u = new Uint8Array(b), s = String.fromCharCode.apply(null, Array.prototype.slice.call(u)), e = extOf(name);
      if (!u.length) return false;
      if (e === 'pdf') return s.indexOf('%PDF') === 0;
      if (/^(docx|pptx|xlsx|zip|odt|ods|odp|epub|apk)$/.test(e)) return s.slice(0, 2) === 'PK';
      if (e === 'png') return s.slice(1, 4) === 'PNG';
      if (/^jpe?g$/.test(e)) return u[0] === 0xFF && u[1] === 0xD8;
      if (e === 'gif') return s.slice(0, 3) === 'GIF';
      if (/^(html?|json|txt|md|csv|xml|svg)$/.test(e)) return true;
      return !/^\s*(<!doctype|<html|\{"error")/i.test(s);
    });
  }
  function fileErr(why, extra) { var e = new Error(why); e.why = why; if (extra) e.code = extra; return e; }
  function fileErrMsg(e) {
    var w = e && e.why;
    if (w === 'bloque') return 'Le stockage (Cloudinary) refuse de livrer ce fichier : les PDF et ZIP y sont bloqués par défaut. Active « PDF and ZIP files delivery » dans Cloudinary > Settings > Security (ou renvoie le fichier : les nouveaux envois n’utilisent plus ce chemin).';
    if (w === 'invalide' || w === 'incomplet') return 'Ce fichier est incomplet ou abîmé : demande à l’expéditeur de le renvoyer.';
    if (e && e.code === 'permission-denied') return 'Lecture refusée par les règles Firestore (collection fchunks). À corriger dans Firebase > Firestore > Règles.';
    return 'Impossible de récupérer le fichier : vérifie ta connexion et réessaie.';
  }
  function fileBlob(m, cid) {
    if (LF[m.id]) return Promise.resolve(LF[m.id]);
    var mt = guessMime(m.file.n, m.file.mt), p, exact = false;
    var typed = function (bl) { return new Blob([bl], { type: mt }); };
    if (m.file.u) {
      p = fetch(m.file.u, { cache: 'no-cache' }).then(function (r) {
        if (!r.ok) throw fileErr(r.status === 401 || r.status === 403 || r.status === 404 ? 'bloque' : 'reseau');
        return r.blob();
      }, function () { throw fileErr('reseau'); }).then(typed);
    } else if (m.file.d) {
      exact = true;
      p = fetch(m.file.d).then(function (r) { return r.blob(); }).then(typed);
    } else {
      exact = true;
      p = fs.collection('chats').doc(cid).collection(m.file.loc === 'm' ? 'messages' : 'fchunks').where('g', '==', m.file.g).get().then(function (snap) {
        var parts = [];
        snap.forEach(function (d) { var v = d.data(); if (typeof v.i === 'number' && typeof v.d === 'string') parts[v.i] = v.d; });
        for (var i = 0; i < m.file.p; i++) if (typeof parts[i] !== 'string') throw fileErr('incomplet');
        return fetch('data:' + mt + ';base64,' + parts.join('')).then(function (r) { return r.blob(); }).then(typed);
      });
    }
    return p.then(function (bl) {
      if (exact && m.file.s && bl.size !== m.file.s) throw fileErr('incomplet');
      return sniff(bl, m.file.n).then(function (ok) {
        if (!ok) throw fileErr(m.file.u ? 'bloque' : 'invalide');
        LF[m.id] = bl; return bl;
      });
    });
  }
  function fmtT(t) { if (!isFinite(t) || t < 0) t = 0; var mn = Math.floor(t / 60), r = Math.floor(t % 60); return mn + ':' + (r < 10 ? '0' : '') + r; }
  function audioPlayer(a, bl, m, sub) {
    var PLAY = '<svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path d="M8 5.5v13a1 1 0 0 0 1.5.86l10.5-6.5a1 1 0 0 0 0-1.72L9.5 4.64A1 1 0 0 0 8 5.5z" fill="currentColor"/></svg>';
    var PAUSE = '<svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><rect x="6" y="5" width="4.2" height="14" rx="1.4" fill="currentColor"/><rect x="13.8" y="5" width="4.2" height="14" rx="1.4" fill="currentColor"/></svg>';
    var w = el('div', 'fpl'), pb = el('button', 'fpp'), main = el('div', 'fpm'), bar = el('div', 'fwv'), bars = [];
    var meta = el('div', 'fpt'), tm = el('span', 'ftm', '0:00'), sp = el('button', 'fsp', '1×'), dl = el('button', 'fdl2');
    pb.type = sp.type = dl.type = 'button'; pb.setAttribute('aria-label', 'Lecture / pause'); sp.setAttribute('aria-label', 'Vitesse'); dl.setAttribute('aria-label', 'Enregistrer');
    pb.innerHTML = PLAY;
    dl.innerHTML = '<svg viewBox="0 0 24 24" width="17" height="17" aria-hidden="true"><path d="M12 4v11m0 0-4-4m4 4 4-4M5 19h14" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>';
    waveFor(m.id || m.file.n).forEach(function (h) { var i = document.createElement('i'); i.style.height = Math.round(h * 100) + '%'; bar.appendChild(i); bars.push(i); });
    meta.appendChild(tm); meta.appendChild(el('span', 'fsc')); meta.appendChild(sp); meta.appendChild(dl);
    main.appendChild(bar); main.appendChild(meta); w.appendChild(pb); w.appendChild(main);
    function paint() {
      var d = a.duration, c = a.currentTime || 0, pc = (isFinite(d) && d > 0) ? Math.min(100, c / d * 100) : 0;
      var on = Math.round(pc / 100 * bars.length);
      for (var k = 0; k < bars.length; k++) bars[k].classList.toggle('on', k < on);
      tm.textContent = fmtT(c) + (isFinite(d) && d > 0 ? ' / ' + fmtT(d) : '');
    }
    a.addEventListener('timeupdate', paint); a.addEventListener('loadedmetadata', paint); a.addEventListener('durationchange', paint);
    a.addEventListener('play', function () { pb.innerHTML = PAUSE; w.classList.add('on'); });
    a.addEventListener('pause', function () { pb.innerHTML = PLAY; w.classList.remove('on'); });
    a.addEventListener('ended', function () { pb.innerHTML = PLAY; w.classList.remove('on'); a.currentTime = 0; paint(); });
    pb.addEventListener('click', function (e) { e.stopPropagation(); if (a.paused) a.play().catch(function () {}); else a.pause(); });
    var rates = [1, 1.5, 2], ri = 0;
    sp.addEventListener('click', function (e) { e.stopPropagation(); ri = (ri + 1) % rates.length; a.playbackRate = rates[ri]; sp.textContent = (rates[ri] === 1.5 ? '1,5' : rates[ri]) + '×'; });
    dl.addEventListener('click', function (e) { e.stopPropagation(); saveBlob(bl, m.file.n); });
    var drag = false;
    function seek(e) {
      var r = bar.getBoundingClientRect(), d = a.duration;
      if (!isFinite(d) || d <= 0 || !r.width) return;
      a.currentTime = Math.max(0, Math.min(1, (e.clientX - r.left) / r.width)) * d; paint();
    }
    bar.addEventListener('pointerdown', function (e) { e.stopPropagation(); drag = true; try { bar.setPointerCapture(e.pointerId); } catch (x) {} seek(e); });
    bar.addEventListener('pointermove', function (e) { if (drag) seek(e); });
    bar.addEventListener('pointerup', function () { drag = false; });
    bar.addEventListener('pointercancel', function () { drag = false; });
    w.addEventListener('click', function (e) { e.stopPropagation(); });
    paint();
    return w;
  }
  function fileCard(m) {
    var cid = state.chat.id, aud = isAudioFile(m.file), box = el('div', 'fbox'), b = el('button', 'fcard'); b.type = 'button';
    var ico = el('span', 'fico');
    ico.innerHTML = aud
      ? '<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path d="M9 18V6l10-2v12" stroke="currentColor" stroke-width="1.9" fill="none" stroke-linecap="round" stroke-linejoin="round"/><circle cx="6.5" cy="18" r="2.5" stroke="currentColor" stroke-width="1.9" fill="none"/><circle cx="16.5" cy="16" r="2.5" stroke="currentColor" stroke-width="1.9" fill="none"/></svg>'
      : '<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8zM14 3v5h5M12 11v6M9.5 14.5 12 17l2.5-2.5" stroke="currentColor" stroke-width="1.9" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>';
    var sub = el('span', 'fsz', fmtSize(m.file.s) + (aud ? ' · Écouter' : ' · Télécharger')), tx = el('span', 'ftx');
    tx.appendChild(el('span', 'fnm', m.file.n)); tx.appendChild(sub);
    b.appendChild(ico); b.appendChild(tx); box.appendChild(b);
    b.addEventListener('click', function (ev) {
      ev.stopPropagation();
      if (LP.fired) { LP.fired = false; return; }
      var au = box.querySelector('audio');
      if (au) { if (au.paused) au.play().catch(function () {}); else au.pause(); return; }
      sub.textContent = 'Chargement…';
      fileBlob(m, cid).then(function (bl) {
        if (aud) {
          var a = document.createElement('audio'); a.className = 'faud'; a.preload = 'metadata'; a.src = URL.createObjectURL(bl);
          box.appendChild(a); box.appendChild(audioPlayer(a, bl, m, sub)); a.play().catch(function () {});
          sub.textContent = fmtSize(m.file.s) + ' · Lecture';
        } else { saveBlob(bl, m.file.n); sub.textContent = fmtSize(m.file.s) + ' · Télécharger'; }
      }).catch(function (e) { sub.textContent = 'Échec · réessayer'; showErr(fileErrMsg(e)); });
    });
    return box;
  }
  function readB64(f) {
    return new Promise(function (ok, ko) {
      var rd = new FileReader();
      rd.onload = function () { var r = String(rd.result), i = r.indexOf(','); ok(r.slice(i + 1)); };
      rd.onerror = function () { ko(rd.error); };
      rd.readAsDataURL(f);
    });
  }
  function readUrl(f) {
    return new Promise(function (ok, ko) {
      var rd = new FileReader(); rd.onload = function () { ok(String(rd.result)); }; rd.onerror = function () { ko(rd.error); }; rd.readAsDataURL(f);
    });
  }
  async function urlIntact(u, size, name) {
    try {
      var r = await fetch(u, { cache: 'no-store' });
      if (!r.ok) return false;
      var bl = await r.blob();
      if (size && bl.size !== size) return false;
      return await sniff(bl, name);
    } catch (e) { return false; }
  }
  async function sendFileMsg(f) {
    var chat = state.chat;
    if (!state.me || !chat || ta.disabled) return;
    showErr(''); state.stick = true;
    if (cntEl) { cntEl.hidden = false; cntEl.textContent = 'Envoi du fichier…'; }
    var name = String(f.name || 'fichier').slice(0, 120), mt = guessMime(name, f.type || '');
    var aud = isAudioFile({ n: name, mt: mt }), label = (aud ? '🎵 ' : '📎 ') + name;
    var chatRef = fs.collection('chats').doc(chat.id), file;
    try {
      var exists = !!state.chatsById[chat.id];
      if (!exists) { exists = (await chatRef.get()).exists; }
      var upf = null;
      if (aud || /^image\//.test(mt)) upf = await cloudUp(f);
      else {
        /* documents : on n'utilise Cloudinary que si le fichier en ressort intact (PDF/ZIP souvent bloqués) ; sinon Firestore */
        upf = await cloudUp(f, 'raw');
        if (upf && !(await urlIntact(upf, f.size, name))) upf = null;
      }
      if (upf) {
        file = { n: name, s: f.size || 0, u: upf, mt: mt };
      } else if (f.size <= FILE_MAX) {
        file = { n: name, s: f.size || 0, d: await readUrl(f), mt: mt };
      } else {
        if (!exists) { showErr('Envoie d’abord un message dans cette discussion, puis réessaie.'); return; }
        var b64 = await readB64(f), gid = state.me.slice(0, 6) + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
        var parts = Math.ceil(b64.length / CHUNK), loc = 'f', cts = Date.now();
        for (var i = 0; i < parts; i++) {
          if (cntEl) { cntEl.hidden = false; cntEl.textContent = 'Envoi du fichier… ' + (i + 1) + ' / ' + parts; }
          var data = { uid: state.me, g: gid, i: i, d: b64.slice(i * CHUNK, (i + 1) * CHUNK), text: '📎', ts: cts, sts: SV() }, id = gid + '-' + i;
          try { await chatRef.collection(loc === 'f' ? 'fchunks' : 'messages').doc(id).set(data); }
          catch (e) {
            if (i === 0 && loc === 'f') { loc = 'm'; await chatRef.collection('messages').doc(id).set(data); } else throw e;
          }
        }
        file = { n: name, s: f.size, g: gid, p: parts, loc: loc, mt: mt };
      }
      var msgRef = chatRef.collection('messages').doc(), ts = Date.now(), batch = fs.batch();
      batch.set(msgRef, withReply({ uid: state.me, sts: SV(), text: label, ts: ts, file: file }));
      var last = { lastText: label, lastTs: ts, lastUid: state.me };
      if (exists) {
        last['seen.' + state.me] = ts;
        batch.update(chatRef, last);
      } else {
        var names = {}; names[state.me] = myName(); names[chat.other] = chat.name;
        var seen = {}; seen[state.me] = ts;
        batch.set(chatRef, { members: [state.me, chat.other], names: names, lastText: label, lastTs: ts, lastUid: state.me, seen: seen });
      }
      await batch.commit();
      state.chatsById[chat.id] = true;
    } catch (e) {
      showErr('Fichier non envoyé. Vérifie ta connexion (ou les règles Firestore) et réessaie.');
    } finally { if (cntEl) cntEl.hidden = true; }
  }
  function onPick(e) {
    var f = e.target.files && e.target.files[0]; e.target.value = '';
    if (!f || fileBusy) return;
    if (f.size > BIG_MAX) { showErr('Fichier trop lourd : ' + fmtSize(BIG_MAX) + ' maximum.'); return; }
    fileBusy = true; docBtn.disabled = true; musBtn.disabled = true;
    sendFileMsg(f).then(function () { fileBusy = false; docBtn.disabled = false; musBtn.disabled = false; });
  }
  docBtn.addEventListener('click', function () { if (state.chat && !ta.disabled && !fileBusy) docFile.click(); });
  musBtn.addEventListener('click', function () { if (state.chat && !ta.disabled && !fileBusy) musFile.click(); });
  docFile.addEventListener('change', onPick);
  musFile.addEventListener('change', onPick);

  /* ---------- lecteur vocal ---------- */
  var VP = {}, VBARS = 30;
  var ICON_PLAY = '<svg class="i-play" viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M8 5.5v13a1 1 0 0 0 1.5.86l10.5-6.5a1 1 0 0 0 0-1.72L9.5 4.64A1 1 0 0 0 8 5.5z"/></svg>';
  var ICON_PAUSE = '<svg class="i-pause" viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M7 4.5h3.5v15H7zM13.5 4.5H17v15h-3.5z"/></svg>';
  function waveFor(id) {
    var s = 2166136261, i;
    for (i = 0; i < id.length; i++) { s ^= id.charCodeAt(i); s = Math.imul(s, 16777619); }
    var ph = (s >>> 0) % 628 / 100, out = [];
    for (i = 0; i < VBARS; i++) {
      s = (Math.imul(s, 1664525) + 1013904223) >>> 0;
      out.push(0.2 + 0.8 * (0.6 * Math.abs(Math.sin(i * 0.5 + ph)) + 0.4 * ((s >>> 8) / 16777216)));
    }
    return out;
  }
  function stopVoices() {
    PIMG = {}; VEMB = {};
    Object.keys(VP).forEach(function (k) { try { VP[k].au.pause(); } catch (e) {} });
    VP = {};
  }
  function paintVoice(p) {
    var u = p.ui, au = p.au, playing = !au.paused;
    var total = p.dur || (isFinite(au.duration) ? au.duration : 0);
    var cur = au.currentTime || 0;
    var on = total ? Math.round(Math.min(1, cur / total) * u.bars.length) : 0;
    for (var i = 0; i < u.bars.length; i++) u.bars[i].classList.toggle('on', i < on);
    u.root.classList.toggle('playing', playing);
    u.btn.setAttribute('aria-label', playing ? 'Mettre en pause' : 'Écouter le message vocal');
    u.time.textContent = fmtDur(playing || cur > 0.1 ? cur : total);
  }
  function voiceUI(m) {
    var p = VP[m.id];
    if (!p) {
      p = VP[m.id] = { au: new Audio(), ui: null, dur: 0 };
      p.au.preload = 'metadata';
      p.au.src = m.audio;
      var sync = function () { if (p.ui && p.ui.root.isConnected) paintVoice(p); };
      ['timeupdate', 'play', 'pause'].forEach(function (ev) { p.au.addEventListener(ev, sync); });
      p.au.addEventListener('play', function () {
        Object.keys(VP).forEach(function (k) { if (VP[k] !== p) VP[k].au.pause(); });
      });
      p.au.addEventListener('ended', function () { p.au.currentTime = 0; sync(); });
    }
    p.dur = m.dur || p.dur;
    var root = el('div', 'vox'), btn = el('button', 'vplay');
    btn.type = 'button';
    btn.innerHTML = ICON_PLAY + ICON_PAUSE;
    btn.addEventListener('click', function () {
      if (p.au.paused) p.au.play().catch(function () {}); else p.au.pause();
    });
    var wave = el('div', 'vwave'), bars = [];
    waveFor(m.id).forEach(function (h) {
      var b = document.createElement('i');
      b.style.height = Math.round(h * 100) + '%';
      wave.appendChild(b); bars.push(b);
    });
    var seeking = false;
    function vseek(e) {
      var r = wave.getBoundingClientRect(), d = isFinite(p.au.duration) && p.au.duration > 0 ? p.au.duration : p.dur;
      if (!d || !r.width) return;
      try { p.au.currentTime = Math.max(0, Math.min(1, (e.clientX - r.left) / r.width)) * d; } catch (x) {}
      paintVoice(p);
    }
    wave.style.touchAction = 'none'; wave.style.cursor = 'pointer';
    wave.addEventListener('pointerdown', function (e) { e.stopPropagation(); seeking = true; try { wave.setPointerCapture(e.pointerId); } catch (x) {} vseek(e); });
    wave.addEventListener('pointermove', function (e) { if (seeking) vseek(e); });
    wave.addEventListener('pointerup', function () { seeking = false; });
    wave.addEventListener('pointercancel', function () { seeking = false; });
    var time = el('span', 'vtime');
    root.appendChild(btn); root.appendChild(wave); root.appendChild(time);
    p.ui = { root: root, btn: btn, bars: bars, time: time };
    paintVoice(p);
    return root;
  }
  /* ---------- messages vocaux (stockés dans Firestore, 60 s max) ---------- */
  var micBtn = $('#mic'), recBar = $('#recbar'), recTimeEl = $('#rectime');
  var rec = null, MAX_REC = 60;
  function pickMime() {
    if (!window.MediaRecorder) return null;
    var c = ['audio/webm;codecs=opus', 'audio/mp4', 'audio/webm', 'audio/ogg;codecs=opus'];
    for (var i = 0; i < c.length; i++) {
      try { if (MediaRecorder.isTypeSupported(c[i])) return c[i]; } catch (e) {}
    }
    return '';
  }
  function fmtDur(s) { s = Math.floor(s); return Math.floor(s / 60) + ':' + ('0' + (s % 60)).slice(-2); }
  function recTick() {
    if (!rec) return;
    var s = (Date.now() - rec.t0) / 1000;
    recTimeEl.textContent = fmtDur(s);
    if (s >= MAX_REC) stopRec(false);
  }
  async function startRec() {
    if (rec || !state.chat || ta.disabled) return;
    var mime = pickMime();
    if (mime === null || !navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      showErr('Ton navigateur ne permet pas d’enregistrer un vocal.');
      return;
    }
    var stream;
    try { stream = await getMic({ audio: true }); }
    catch (e) { showErr('Micro refusé. Autorise le micro pour ce site dans le navigateur. ' + MIC_HELP); return; }
    if (!state.chat) { stream.getTracks().forEach(function (t) { t.stop(); }); return; }
    var opts = { audioBitsPerSecond: 24000 };
    if (mime) opts.mimeType = mime;
    var mr;
    try { mr = new MediaRecorder(stream, opts); }
    catch (e) {
      stream.getTracks().forEach(function (t) { t.stop(); });
      showErr('L’enregistrement n’a pas pu démarrer.');
      return;
    }
    var r = { mr: mr, chunks: [], stream: stream, t0: Date.now(), cancelled: false, chatId: state.chat.id, timer: null };
    mr.ondataavailable = function (e) { if (e.data && e.data.size) r.chunks.push(e.data); };
    mr.onstop = function () { finishRec(r); };
    showErr('');
    mr.start();
    rec = r;
    r.timer = setInterval(recTick, 250);
    recBar.hidden = false;
    micBtn.classList.add('on');
    micBtn.setAttribute('aria-label', 'Envoyer le vocal');
    startMeter(r);
    recTick();
  }
  function stopRec(cancel) {
    if (!rec) return;
    var r = rec;
    r.cancelled = !!cancel;
    clearInterval(r.timer);
    try { if (r.mr.state !== 'inactive') r.mr.stop(); else finishRec(r); } catch (e) { finishRec(r); }
  }
  function finishRec(r) {
    clearInterval(r.timer);
    try { r.stream.getTracks().forEach(function (t) { t.stop(); }); } catch (e) {}
    if (rec === r) rec = null;
    recBar.hidden = true;
    micBtn.classList.remove('on');
    micBtn.setAttribute('aria-label', 'Message vocal');
    stopMeter(r);
    if (r.cancelled) return;
    var dur = (Date.now() - r.t0) / 1000;
    if (dur < 0.7 || !r.chunks.length) return;
    var blob = new Blob(r.chunks, { type: (r.mr && r.mr.mimeType) || 'audio/webm' });
    if (blob.size > 650000) { showErr('Vocal trop long.'); return; }
    var fr = new FileReader();
    fr.onload = function () {
      if (!state.chat || state.chat.id !== r.chatId) return;
      sendVoice(String(fr.result), dur);
    };
    fr.readAsDataURL(blob);
  }
  async function sendVoice(audio, dur, noCloud) {
    var chat = state.chat;
    if (!state.me || !chat || ta.disabled) return;
    if (audio.length > 900000) { showErr('Vocal trop long.'); return; }
    showErr('');
    var orig = audio, up = noCloud ? null : await mediaUp(audio); if (up) audio = up;
    state.stick = true;
    var label = '🎤 Message vocal';
    try {
      var chatRef = fs.collection('chats').doc(chat.id);
      var msgRef = chatRef.collection('messages').doc();
      var ts = Date.now();
      var exists = !!state.chatsById[chat.id];
      if (!exists) { exists = (await chatRef.get()).exists; }
      var batch = fs.batch();
      batch.set(msgRef, withReply({ uid: state.me, sts: SV(), text: label, ts: ts, audio: audio, dur: Math.round(dur) }));
      var last = { lastText: label, lastTs: ts, lastUid: state.me };
      if (exists) {
        last['seen.' + state.me] = ts;
        batch.update(chatRef, last);
      } else {
        var names = {}; names[state.me] = myName(); names[chat.other] = chat.name;
        var seen = {}; seen[state.me] = ts;
        batch.set(chatRef, {
          members: [state.me, chat.other], names: names,
          lastText: label, lastTs: ts, lastUid: state.me, seen: seen
        });
      }
      await batch.commit();
      state.chatsById[chat.id] = true;
    } catch (e) {
      if (e && e.code === 'permission-denied' && audio !== orig) { return sendVoice(orig, dur, true); }
      showErr('Vocal non envoyé. Vérifie ta connexion (ou les règles Firestore) et réessaie.' + (e && e.code ? ' [' + e.code + ']' : ''));
    }
  }
  var recMeterEl = $('#recmeter'), meterBars = [];
  for (var mi = 0; mi < 30; mi++) { var mb = document.createElement('i'); recMeterEl.appendChild(mb); meterBars.push(mb); }
  function startMeter(r) {
    r.lv = meterBars.map(function () { return 0; });
    try {
      var AC = window.AudioContext || window.webkitAudioContext;
      r.ac = new AC();
      if (r.ac.resume) r.ac.resume();
      r.an = r.ac.createAnalyser(); r.an.fftSize = 256;
      r.ac.createMediaStreamSource(r.stream).connect(r.an);
      r.buf = new Uint8Array(r.an.fftSize);
    } catch (e) { r.an = null; return; }
    r.lastM = 0;
    (function loop(now) {
      if (rec !== r || !r.an) return;
      if (now - r.lastM > 70) {
        r.lastM = now;
        r.an.getByteTimeDomainData(r.buf);
        var sum = 0;
        for (var i = 0; i < r.buf.length; i++) { var v = (r.buf[i] - 128) / 128; sum += v * v; }
        r.lv.shift(); r.lv.push(Math.min(1, Math.sqrt(sum / r.buf.length) * 4));
        for (var k = 0; k < meterBars.length; k++) meterBars[k].style.height = (3 + r.lv[k] * 26) + 'px';
      }
      requestAnimationFrame(loop);
    })(0);
  }
  function stopMeter(r) {
    r.an = null;
    try { if (r.ac) r.ac.close(); } catch (e) {}
    meterBars.forEach(function (b) { b.style.height = ''; });
  }
  micBtn.addEventListener('click', function () { if (rec) stopRec(false); else startRec(); });
  $('#recCancel').addEventListener('click', function () { stopRec(true); });

