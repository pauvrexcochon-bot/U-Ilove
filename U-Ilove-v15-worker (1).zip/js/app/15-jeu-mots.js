/* U&I — js/app/15-jeu-mots.js
   Jeu : mots mélangés
   (fait partie de l’appli : assemblée par js/boot/loader.js dans une seule fermeture) */
  /* ---------- jeux : mots mélangés ---------- */
  var viewGame = $('#viewGame');
  var WORDS = [
    ['lune', 'rose', 'chat', 'pain', 'sable', 'nuit', 'jour', 'miel', 'amour', 'livre', 'table', 'fleur', 'plage', 'neige', 'image', 'sucre', 'tigre', 'zèbre', 'poule', 'herbe', 'monde', 'verre', 'porte', 'pomme', 'fruit', 'glace', 'ciel', 'vent', 'pluie', 'étang', 'lapin', 'nuage', 'radio', 'avion', 'forêt'],
    ['jardin', 'soleil', 'maison', 'voiture', 'cuisine', 'fenêtre', 'musique', 'amitié', 'bonheur', 'chemin', 'oiseau', 'poisson', 'orange', 'banane', 'citron', 'cerise', 'panier', 'mystère', 'étoile', 'bateau', 'cheval', 'souris', 'gâteau', 'lumière', 'baleine', 'dauphin'],
    ['chocolat', 'ordinateur', 'téléphone', 'papillon', 'champion', 'aventure', 'dinosaure', 'croissant', 'parapluie', 'tournesol', 'chaussure', 'hirondelle', 'escargot', 'montagne', 'souvenir', 'vacances', 'chandelle', 'éléphant', 'crocodile', 'amoureux']
  ];
  var ALLN = {};
  function wNorm(s) { return String(s).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase(); }
  WORDS.forEach(function (t) { t.forEach(function (w) { ALLN[wNorm(w)] = true; }); });

  var W = {
    target: '', tn: '', tiles: [], order: [], ans: [], hints: 0, lock: false, win: false, msg: '', timer: 0,
    score: 0, streak: 0, solved: 0, seen: {}, hintsLeft: 3,
    best: parseInt(store('uandi-mots-best') || '0', 10) || 0
  };
  function wShuffleArr(a) {
    for (var i = a.length - 1; i > 0; i--) {
      var j = Math.floor(Math.random() * (i + 1)), t = a[i]; a[i] = a[j]; a[j] = t;
    }
    return a;
  }
  function wPick() {
    var cur = W.solved < 4 ? 0 : W.solved < 10 ? 1 : 2;
    for (var tries = 0; tries < 3; tries++) {
      var ti = Math.random() < 0.65 ? cur : Math.floor(Math.random() * (cur + 1));
      var pool = WORDS[ti].filter(function (w) { return !W.seen[w]; });
      if (pool.length) { var w = pool[Math.floor(Math.random() * pool.length)]; W.seen[w] = 1; return w; }
    }
    W.seen = {};
    var all = WORDS[cur], w2 = all[Math.floor(Math.random() * all.length)];
    W.seen[w2] = 1;
    return w2;
  }
  function wNewRound() {
    clearTimeout(W.timer);
    var w = wPick();
    W.target = w; W.tn = wNorm(w);
    W.tiles = w.split('').map(function (ch, i) { return { id: i, ch: ch, n: wNorm(ch) }; });
    var ids = W.tiles.map(function (t) { return t.id; });
    for (var k = 0; k < 20; k++) {
      wShuffleArr(ids);
      if (ids.map(function (i) { return W.tiles[i].n; }).join('') !== W.tn) break;
    }
    W.order = ids; W.ans = []; W.hints = 0; W.lock = false; W.win = false; W.msg = '';
    wRender();
  }
  function wRender() {
    $('#wScore').textContent = W.score;
    $('#wStreak').textContent = W.streak;
    $('#wBest').textContent = W.best;
    $('#wHint').textContent = 'Indice (' + W.hintsLeft + ')';
    $('#wHint').disabled = W.hintsLeft <= 0;
    var slots = $('#wSlots'), tiles = $('#wTiles'), n = W.tiles.length;
    slots.replaceChildren(); tiles.replaceChildren();
    for (var i = 0; i < n; i++) {
      var filled = i < W.ans.length;
      var s = el('button', 'wslot' + (filled ? ' fill' : '') + (W.win ? ' ok' : '') + (filled && i === W.ans.length - 1 && W.ans.length > (W.prevLen || 0) ? ' pop' : ''), filled ? W.tiles[W.ans[i]].ch : '');
      s.type = 'button'; s.dataset.i = i; s.style.setProperty('--i', i);
      s.setAttribute('aria-label', filled ? 'Retirer la lettre ' + W.tiles[W.ans[i]].ch : 'Case vide');
      slots.appendChild(s);
    }
    W.order.forEach(function (id) {
      var b = el('button', 'wtile', W.tiles[id].ch);
      b.type = 'button'; b.dataset.id = id;
      b.disabled = W.ans.indexOf(id) !== -1;
      tiles.appendChild(b);
    });
    $('#wMsg').textContent = W.msg;
    W.prevLen = W.ans.length;
  }
  function fxWin(pts) {
    if (window.SFX) SFX.win();
    if (!window.FX) return;
    var r = $('#wSlots').getBoundingClientRect(), x = r.left + r.width / 2, y = r.top + r.height / 2;
    FX.confetti(x, y); FX.float('+' + pts + (W.streak >= 3 ? ' \uD83D\uDD25 x' + W.streak : ''), x, y - 24);
  }
  function wCheck() {
    var n = W.tiles.length;
    if (W.ans.length !== n) return;
    var g = W.ans.map(function (id) { return W.tiles[id].n; }).join('');
    if (g === W.tn || ALLN[g]) {
      var pts = Math.max(2, 5 + n * 2 + Math.min(W.streak, 5) - W.hints * 4);
      W.streak++; W.solved++; W.score += pts;
      if (W.score > W.best) { W.best = W.score; store('uandi-mots-best', String(W.best)); }
      W.lock = true; W.win = true; W.msg = 'Bravo ! +' + pts;
      wRender(); fxWin(pts);
      W.timer = setTimeout(wNewRound, 1100);
    } else {
      W.msg = 'Ce n’est pas ça, essaie encore.';
      wRender();
      var sl = $('#wSlots'); sl.classList.remove('shake'); void sl.offsetWidth; sl.classList.add('shake');
      if (window.SFX) SFX.error();
    }
  }
  function wHint() {
    if (W.lock || W.hintsLeft <= 0) return;
    var k = 0;
    while (k < W.ans.length && W.tiles[W.ans[k]].n === W.tn.charAt(k)) k++;
    W.ans = W.ans.slice(0, k);
    var want = W.tn.charAt(k), pick = -1;
    for (var i = 0; i < W.order.length; i++) {
      var id = W.order[i];
      if (W.ans.indexOf(id) === -1 && W.tiles[id].n === want) { pick = id; break; }
    }
    if (pick === -1) return;
    W.hintsLeft--; if (window.SFX) SFX.hint();
    W.ans.push(pick); W.hints++;
    W.msg = 'Indice utilisé (−4 points)' + (W.hintsLeft > 0 ? ' · il t’en reste ' + W.hintsLeft : ' · plus d’indice dans cette série');
    wRender(); wCheck();
  }
  function wSkip() {
    if (W.lock) return;
    if (window.SFX) SFX.lose();
    W.lock = true; W.streak = 0; W.hintsLeft = 3; W.ans = []; W.msg = 'C’était : ' + W.target.toUpperCase();
    wRender();
    W.timer = setTimeout(wNewRound, 1800);
  }
  function startGame() {
    W.score = 0; W.streak = 0; W.solved = 0; W.seen = {}; W.hintsLeft = 3;
    wNewRound();
  }
  function stopGame() {
    clearTimeout(W.timer);
  }
  function openGame() {
    leaveChat();
    pushView({ game: true });
    state.view = 'game';
    viewList.hidden = true;
    viewChat.hidden = true;
    viewMusic.hidden = true;
    viewGame.hidden = false;
    if (document.activeElement && document.activeElement.blur) document.activeElement.blur();
    startGame();
  }
  $('#openGame').addEventListener('click', openGame);
  $('#gameBack').addEventListener('click', function () {
    if (history.state && history.state.game) history.back(); else showList();
  });
  $('#wTiles').addEventListener('click', function (e) {
    var b = e.target.closest('.wtile');
    if (!b || W.lock) return;
    var id = +b.dataset.id;
    if (W.ans.indexOf(id) !== -1) return;
    W.ans.push(id); W.msg = ''; if (window.SFX) SFX.tap();
    wRender(); wCheck();
  });
  $('#wSlots').addEventListener('click', function (e) {
    var b = e.target.closest('.wslot');
    if (!b || W.lock) return;
    var i = +b.dataset.i;
    if (i < W.ans.length) { W.ans.splice(i, 1); W.msg = ''; if (window.SFX) SFX.back(); wRender(); }
  });
  $('#wShuffle').addEventListener('click', function () { if (!W.lock) { wShuffleArr(W.order); if (window.SFX) SFX.swap(); wRender(); } });
  $('#wClear').addEventListener('click', function () { if (!W.lock) { W.ans = []; W.msg = ''; if (window.SFX) SFX.back(); wRender(); } });
  $('#wHint').addEventListener('click', wHint);
  $('#wSkip').addEventListener('click', wSkip);
  document.addEventListener('keydown', function (e) {
    if (state.view !== 'game' || W.lock || e.ctrlKey || e.metaKey || e.altKey) return;
    if (e.key === 'Backspace') { e.preventDefault(); W.ans.pop(); W.msg = ''; if (window.SFX) SFX.back(); wRender(); return; }
    if (e.key.length !== 1) return;
    var n = wNorm(e.key);
    if (!/^[a-z]$/.test(n)) return;
    for (var i = 0; i < W.order.length; i++) {
      var id = W.order[i];
      if (W.ans.indexOf(id) === -1 && W.tiles[id].n === n) {
        e.preventDefault(); W.ans.push(id); W.msg = ''; if (window.SFX) SFX.tap();
        wRender(); wCheck();
        return;
      }
    }
  });

