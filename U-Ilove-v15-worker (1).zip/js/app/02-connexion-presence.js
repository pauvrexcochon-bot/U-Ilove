/* U&I — js/app/02-connexion-presence.js
   Connexion / inscription, présence
   (fait partie de l’appli : assemblée par js/boot/loader.js dans une seule fermeture) */
  /* ---------- connexion / inscription ---------- */
  function setMode(mode) {
    state.mode = mode;
    var signup = mode === 'signup';
    tabLogin.setAttribute('aria-selected', signup ? 'false' : 'true');
    tabSignup.setAttribute('aria-selected', signup ? 'true' : 'false');
    $('#p2').hidden = !signup;
    $('#p2Label').hidden = !signup;
    $('#uHint').hidden = !signup;
    $('#p').setAttribute('autocomplete', signup ? 'new-password' : 'current-password');
    authBtn.textContent = signup ? 'Créer mon compte' : 'Entrer';
    setAuthErr('');
  }
  tabLogin.addEventListener('click', function () { setMode('login'); });
  tabSignup.addEventListener('click', function () { setMode('signup'); });

  authForm.addEventListener('submit', function (ev) {
    ev.preventDefault();
    var name = $('#u').value.trim().toLowerCase().replace(/\s+/g, '');
    var pass = $('#p').value;
    var signup = state.mode === 'signup';
    setAuthErr('');
    if (signup) {
      if (!NAME_RE.test(name)) { setAuthErr('Nom d’utilisateur : 3 à 20 caractères, avec lettres, chiffres, point, tiret ou souligné.'); return; }
      if (pass.length < 6) { setAuthErr('Le mot de passe doit faire au moins 6 caractères.'); return; }
      if (pass !== $('#p2').value) { setAuthErr('Les deux mots de passe ne sont pas identiques.'); return; }
    } else if (!name || !pass) return;

    authBtn.disabled = true;
    var email = name + '@' + CFG.emailDomain;
    apNew = signup;
    var p = signup ? auth.createUserWithEmailAndPassword(email, pass) : auth.signInWithEmailAndPassword(email, pass);
    p.catch(function (e) {
      var c = e && e.code;
      setAuthErr(
        c === 'auth/email-already-in-use' ? 'Ce nom d’utilisateur est déjà pris.' :
        c === 'auth/weak-password' ? 'Le mot de passe doit faire au moins 6 caractères.' :
        c === 'auth/too-many-requests' ? 'Trop d’essais. Réessaie dans quelques minutes.' :
        c === 'auth/network-request-failed' ? 'Pas de connexion internet.' :
        c === 'auth/operation-not-allowed' ? 'La connexion par e-mail et mot de passe n’est pas activée dans Firebase.' :
        signup ? 'Le compte n’a pas pu être créé.' : 'Nom d’utilisateur ou mot de passe incorrect.');
    }).then(function () { authBtn.disabled = false; });
  });

  /* ---------- présence ---------- */
  var typingChat = null, typingTimer = null, lastTypingWrite = 0;
  function writePresence(extra) {
    if (!state.me || state.deleting) return;
    var data = { name: myName(), seen: hideOn() ? 0 : Date.now() };
    for (var k in extra) data[k] = extra[k];
    fs.collection('presence').doc(state.me).set(data, { merge: true }).catch(function () {});
  }
  function beat() { if (!document.hidden) writePresence({ typingIn: typingChat, typingAt: Date.now() }); }
  function setTyping(v) {
    if (!state.me || !state.chat) return;
    var now = Date.now(), id = state.chat.id;
    if (v) {
      clearTimeout(typingTimer);
      typingTimer = setTimeout(function () { setTyping(false); }, 3000);
      if (typingChat === id && now - lastTypingWrite < 4000) return;
      typingChat = id;
    } else {
      if (!typingChat) return;
      typingChat = null;
    }
    lastTypingWrite = now;
    writePresence({ typingIn: typingChat, typingAt: now });
  }
  function renderStatus() {
    if (!state.chat) return;
    if (state.chat.group) {
      var gcd = chatOf(state.chat.id);
      statusEl.classList.remove('on');
      statusText.textContent = ((gcd && gcd.members) ? gcd.members.length : '') + ' membres';
      document.getElementById('typingLine').hidden = true;
      return;
    }
    var p = state.otherPres, now = Date.now();
    var online = p && now - (p.seen || 0) < 150000;
    statusEl.classList.toggle('on', !!online);
    if (!online) { statusText.textContent = 'Hors ligne'; document.getElementById('typingLine').hidden = true; return; }
    var isTyping = p.typingIn === state.chat.id && now - (p.typingAt || 0) < 8000;
    statusText.textContent = isTyping ? 'écrit…' : 'En ligne';
    var tl = document.getElementById('typingLine');
    if (isTyping) {
      if (!tl.dataset.on) {
        tl.innerHTML = '<span class="tbub" aria-hidden="true"><i></i><i></i><i></i></span><span class="tnm"></span>';
        tl.dataset.on = '1';
      }
      tl.querySelector('.tnm').textContent = cap(state.chat.name) + ' écrit…';
      tl.hidden = false;
    } else { tl.hidden = true; delete tl.dataset.on; }
  }

