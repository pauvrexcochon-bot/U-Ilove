/* U&I — js/app/05-outils-createur.js
   Statut masqué, annonce, suspension, outils du créateur
   (fait partie de l’appli : assemblée par js/boot/loader.js dans une seule fermeture) */
  /* ---------- statut en ligne masqué, annonce, suspension, outils créateur ---------- */
  var BANS = {};
  function hideOn() { try { return !!state.me && localStorage.getItem('uandi-hide-' + state.me) === '1'; } catch (e) { return false; } }
  function paintHide() {
    var b = $('#hideOnBtn'); if (!b) return;
    b.setAttribute('aria-pressed', hideOn() ? 'true' : 'false'); b.textContent = hideOn() ? 'Statut en ligne masqué ✓' : 'Masquer mon statut en ligne';
    var h = $('#hideSeenBtn'); h.setAttribute('aria-pressed', hideSeenOn() ? 'true' : 'false'); h.textContent = hideSeenOn() ? 'Mes « Vu » sont masqués ✓' : 'Masquer mes « Vu »';
  }
  function hideSeenOn() { try { return !!state.me && localStorage.getItem('uandi-hs-' + state.me) === '1'; } catch (e) { return false; } }
  $('#hideSeenBtn').addEventListener('click', function () {
    var on = !hideSeenOn();
    try { localStorage.setItem('uandi-hs-' + state.me, on ? '1' : '0'); } catch (e) {}
    paintHide();
    fs.collection('presence').doc(state.me).set({ hideSeen: on ? true : firebase.firestore.FieldValue.delete() }, { merge: true }).catch(function () {});
  });
  $('#hideOnBtn').addEventListener('click', function () {
    var on = !hideOn();
    try { localStorage.setItem('uandi-hide-' + state.me, on ? '1' : '0'); } catch (e) {}
    paintHide();
    var FV = firebase.firestore.FieldValue;
    fs.collection('presence').doc(state.me).set(on ? { seen: 0, hideOn: true } : { seen: Date.now(), hideOn: FV.delete() }, { merge: true }).catch(function () {});
  });
  $('#openSet').addEventListener('click', function () { paintHide(); lkPaint(); bdPaint(); });
  function banGuard() {
    if (state.banUntil && Date.now() < state.banUntil) { nwErr('Tu es suspendu(e) des publications jusqu’au ' + new Date(state.banUntil).toLocaleString('fr-FR') + '.'); return true; }
    return false;
  }
  /* annonce du créateur : bandeau pour tout le monde */
  var ANN = { unsub: null, ban: null, data: null };
  function annPaint() {
    var d = ANN.data, bar = $('#annBar'), x = null;
    try { x = localStorage.getItem('uandi-annx'); } catch (e) {}
    var show = !!(d && d.text && String(d.ts) !== x);
    bar.hidden = !show; if (show) $('#annTxt').textContent = d.text;
  }
  $('#annX').addEventListener('click', function () { try { localStorage.setItem('uandi-annx', String(ANN.data && ANN.data.ts)); } catch (e) {} annPaint(); });
  function annStart() {
    ANN.unsub = fs.collection('announce').doc('main').onSnapshot(function (d) { ANN.data = d.exists ? d.data() : null; annPaint(); }, function () {});
    ANN.ban = fs.collection('bans').doc(state.me).onSnapshot(function (d) { state.banUntil = d.exists ? ((d.data() || {}).until || 0) : 0; }, function () {});
  }
  function annStop() { if (ANN.unsub) ANN.unsub(); if (ANN.ban) ANN.ban(); ANN.unsub = ANN.ban = null; ANN.data = null; state.banUntil = 0; annPaint(); }
  /* fenêtre des outils créateur */
  var crDlg = $('#crDlg'), CR = { mode: '' };
  function crErr(t) { var e = $('#crErr'); e.textContent = t || ''; e.hidden = !t; }
  function crRender() {
    var box = $('#crBody'); box.replaceChildren();
    if (CR.mode === 'ap') { apRender(); return; }
    if (CR.mode === 'mod') {
      var fl = NW.items.filter(function (it) { return nwCount(it.reports) > 0; }).sort(function (a, b) { return nwCount(b.reports) - nwCount(a.reports); });
      if (!NW.loaded) { box.appendChild(el('p', 'hint', 'Chargement…')); return; }
      if (!fl.length) { box.appendChild(el('p', 'hint', 'Aucune lettre signalée.')); return; }
      fl.forEach(function (it) {
        var n = nwCount(it.reports), r = el('div', 'frrow'), mid = el('div', 'frmid'), bx = el('div', 'frbtns');
        mid.appendChild(el('b', '', (it.alias || 'Anonyme') + ' · ' + n + ' signalement' + (n > 1 ? 's' : '') + (n >= 3 ? ' · masquée' : '')));
        mid.appendChild(el('small', '', String(it.text || '').slice(0, 140)));
        var ok = el('button', 'ghost', 'Rétablir'); ok.type = 'button';
        ok.addEventListener('click', function () { fs.collection('letters').doc(it.id).update({ reports: {} }).catch(function () { crErr('Action impossible (règles Firestore).'); }); });
        var dl = el('button', 'ghost', 'Supprimer'); dl.type = 'button';
        dl.addEventListener('click', function () { nwDelete(it); });
        bx.appendChild(ok); bx.appendChild(dl); r.appendChild(mid); r.appendChild(bx); box.appendChild(r);
      });
    }
  }
  function crOpen(mode, title) { CR.mode = mode; $('#crTitle').textContent = title; crErr(''); $('#crBody').replaceChildren(); crDlg.showModal(); }
  $('#crClose').addEventListener('click', function () { crDlg.close(); });
  crDlg.addEventListener('click', function (e) { if (e.target === crDlg) crDlg.close(); });
  $('#apBtn').addEventListener('click', function () { if (!creatorOn()) return; crOpen('ap', 'Comptes à approuver'); apRender(); });
  $('#modBtn').addEventListener('click', function () { if (!creatorOn()) return; crOpen('mod', 'Lettres signalées'); nwListen(); crRender(); });
  $('#annBtn').addEventListener('click', function () {
    if (!creatorOn()) return;
    crOpen('ann', 'Annonce à tous');
    var box = $('#crBody'), ta = el('textarea', 'crtxt'); ta.maxLength = 300; ta.placeholder = 'Ton message, affiché en haut de la liste de tout le monde…';
    ta.value = (ANN.data && ANN.data.text) || '';
    var row = el('div', 'pfrow'), go = el('button', 'ghost', 'Publier'), off = el('button', 'ghost', 'Retirer l’annonce');
    go.type = off.type = 'button';
    go.addEventListener('click', function () {
      var t = ta.value.trim(); if (!t) { crErr('Écris un message.'); return; }
      fs.collection('announce').doc('main').set({ text: t.slice(0, 300), ts: Date.now() }).then(function () { crDlg.close(); }).catch(function () { crErr('Impossible : ajoute la règle Firestore « announce ».'); });
    });
    off.addEventListener('click', function () { fs.collection('announce').doc('main').delete().then(function () { crDlg.close(); }).catch(function () { crErr('Impossible (règles Firestore).'); }); });
    row.appendChild(go); row.appendChild(off); box.appendChild(ta); box.appendChild(row);
  });
  $('#statsBtn').addEventListener('click', function () {
    if (!creatorOn()) return;
    crOpen('stats', 'Statistiques'); nwListen();
    var box = $('#crBody'); box.appendChild(el('p', 'hint', 'Chargement…'));
    fs.collection('usernames').get().then(function (sn) {
      var uids = []; sn.forEach(function (d) { var v = d.data(); if (v && typeof v.uid === 'string') uids.push(v.uid); });
      return Promise.all(uids.map(function (u) { return fs.collection('presence').doc(u).get().then(function (d) { return d.exists ? d.data() : {}; }).catch(function () { return {}; }); })).then(function (ps) {
        var on = ps.filter(function (v) { return v.seen && Date.now() - v.seen < 150000; }).length;
        var cert = ps.filter(function (v) { return v.verified === true; }).length;
        var hid = ps.filter(function (v) { return v.hideOn === true; }).length;
        var items = NW.items || [], cm = items.reduce(function (n, it) { return n + (it.cc || 0); }, 0);
        var rows = [['Comptes', uids.length], ['En ligne maintenant', on], ['Comptes certifiés', cert], ['Statut masqué', hid], ['Lettres (100 dernières)', items.length], ['Commentaires dessus', cm], ['Lettres signalées', items.filter(function (it) { return nwCount(it.reports) > 0; }).length]];
        box.replaceChildren();
        rows.forEach(function (r) { var d = el('div', 'crstat'); d.appendChild(el('span', '', r[0])); d.appendChild(el('b', '', String(r[1]))); box.appendChild(d); });
      });
    }).catch(function () { box.replaceChildren(); crErr('Lecture refusée : les règles Firestore doivent autoriser le créateur à lire « usernames » et « presence ».'); });
  });

