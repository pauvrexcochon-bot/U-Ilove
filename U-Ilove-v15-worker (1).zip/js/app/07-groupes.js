/* U&I — js/app/07-groupes.js
   Groupes (30 max) et infos du groupe
   (fait partie de l’appli : assemblée par js/boot/loader.js dans une seule fermeture) */
  /* ---------- groupes (30 personnes max) ---------- */
  var gnDlg = $('#groupNew');
  function gnErr(t) { var e = $('#gnErr'); e.textContent = t || ''; e.hidden = !t; }
  $('#newGroup').addEventListener('click', function () { $('#gnTitle').value = ''; $('#gnNames').value = ''; gnErr(''); gnDlg.showModal(); });
  $('#gnCancel').addEventListener('click', function () { gnDlg.close(); });
  $('#gnGo').addEventListener('click', async function () {
    var btn = this, title = $('#gnTitle').value.trim().slice(0, 40), names = [];
    $('#gnNames').value.toLowerCase().split(/[\s,;]+/).forEach(function (n) {
      n = n.replace(/^@/, ''); if (n && n !== state.username && names.indexOf(n) === -1) names.push(n);
    });
    if (!title) { gnErr('Donne un nom au groupe.'); return; }
    if (!names.length) { gnErr('Ajoute au moins une personne.'); return; }
    if (names.length > 29) { gnErr('30 personnes maximum, toi compris.'); return; }
    var bad = names.filter(function (n) { return !NAME_RE.test(n); });
    if (bad.length) { gnErr('Nom d’utilisateur invalide : ' + bad[0]); return; }
    btn.disabled = true; gnErr('');
    try {
      var snaps = await Promise.all(names.map(function (n) { return fs.collection('usernames').doc(n).get(); }));
      var members = [state.me], nm = {}; nm[state.me] = myName();
      for (var i = 0; i < snaps.length; i++) {
        if (!snaps[i].exists) { gnErr('Aucun utilisateur ne s’appelle « ' + names[i] + ' ».'); btn.disabled = false; return; }
        var u = snaps[i].data().uid;
        if (members.indexOf(u) === -1) { members.push(u); nm[u] = names[i]; }
      }
      var id = 'g_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 7), now = Date.now(), seen = {}; seen[state.me] = now;
      var doc = { members: members, group: true, owner: state.me, title: title, names: nm, lastText: 'Groupe créé', lastTs: now, lastUid: state.me, seen: seen };
      await fs.collection('chats').doc(id).set(doc);
      state.chatsById[id] = true;
      gnDlg.close();
      openChat('', title, Object.assign({ id: id }, doc));
    } catch (e) { gnErr('Création impossible (connexion ou règles Firestore).'); }
    btn.disabled = false;
  });

  /* ---------- infos du groupe : nom, photo, membres ---------- */
  var giDlg = $('#groupInfo');
  function curGroup() { return state.chat && state.chat.group ? chatOf(state.chat.id) : null; }
  function giErr(t) { var e = $('#giErr'); e.textContent = t || ''; e.hidden = !t; }
  function editNick(g, u, real, row) {
    var nx = row.nextSibling;
    if (nx && nx.classList && nx.classList.contains('gimform')) { nx.remove(); return; }
    var f = el('form', 'gimform'), inp = el('input', 'field'), ok = el('button', 'ghost', 'OK');
    inp.maxLength = 24; inp.placeholder = 'Pseudo dans ce groupe'; inp.value = nickOf(g, u); ok.type = 'submit';
    f.appendChild(inp); f.appendChild(ok); row.after(f); inp.focus();
    f.addEventListener('submit', function (e) {
      e.preventDefault();
      var raw = inp.value.replace(/\s+/g, ' ').trim(), old = nickOf(g, u);
      if (raw === old) { f.remove(); return; }
      var note = raw ? cap(myName()) + ' a défini le pseudo de ' + cap(real) + ' : ' + raw : cap(myName()) + ' a retiré le pseudo de ' + cap(old || real);
      var ts = Date.now(), ref = fs.collection('chats').doc(g.id), upd = {};
      upd['nicks.' + u] = raw ? raw : firebase.firestore.FieldValue.delete();
      upd.lastText = note; upd.lastTs = ts; upd.lastUid = state.me; upd['seen.' + state.me] = ts;
      giErr('');
      var batch = fs.batch(); batch.update(ref, upd);
      batch.set(ref.collection('messages').doc(), { uid: state.me, sts: SV(), text: SYS + note, ts: ts });
      batch.commit().then(function () { f.remove(); }).catch(function () { giErr('Pseudo impossible (connexion ou règles Firestore).'); });
    });
  }
  function renderGroupInfo() {
    var g = curGroup(); if (!g) return;
    if (document.querySelector('.gimform input:focus')) return;
    var owner = g.owner === state.me;
    paintGroupAv($('#giAv'), g);
    if (document.activeElement !== $('#giTitle')) $('#giTitle').value = g.title || '';
    $('#giTitle').disabled = !owner; $('#giSave').hidden = !owner; $('#giPick').hidden = !owner;
    $('#giDel').hidden = !owner || !g.photo; $('#giAddSec').hidden = !owner; $('#giHint').hidden = owner;
    var ms = (g.members || []).slice().sort(function (a, b) { return (b === g.owner) - (a === g.owner); });
    $('#giCount').textContent = 'Membres (' + ms.length + ' / 30)';
    var box = $('#giMembers'); box.replaceChildren();
    ms.forEach(function (u) {
      var real = u === state.me ? myName() : ((g.names && g.names[u]) || 'Membre'), nick = nickOf(g, u), nm = nick || real;
      var row = el('div', 'gimrow');
      var b = el('button', 'gimem'); b.type = 'button';
      var av = el('span', 'avatar sm'); paintPhoto(av, u, nm); loadPhoto(u);
      b.appendChild(av); b.appendChild(el('span', '', cap(nm) + (nick ? ' (' + cap(real) + ')' : '') + (u === state.me ? ' · toi' : '')));
      if (u === g.owner) b.appendChild(el('small', '', 'créateur'));
      if (u !== state.me) b.addEventListener('click', function () { showNote(u, nm); });
      var ed = el('button', 'gimedit', '✏️'); ed.type = 'button'; ed.title = 'Pseudo'; ed.setAttribute('aria-label', 'Pseudo de ' + real);
      ed.addEventListener('click', function () { editNick(g, u, real, row); });
      row.appendChild(b); row.appendChild(ed);
      box.appendChild(row);
    });
  }
  function openGroupInfo() { if (!curGroup()) return; giErr(''); renderGroupInfo(); giDlg.showModal(); }
  function giUpdate(obj) {
    var g = curGroup(); if (!g) return Promise.resolve();
    giErr('');
    return fs.collection('chats').doc(g.id).update(obj).catch(function () { giErr('Modification impossible (connexion ou règles Firestore).'); });
  }
  $('#giBtn').addEventListener('click', function () { $('#chatMenu').hidden = true; openGroupInfo(); });
  $('#chatName').addEventListener('click', function () { if (state.chat && state.chat.group) openGroupInfo(); });
  $('#giClose').addEventListener('click', function () { giDlg.close(); });
  giDlg.addEventListener('click', function (e) { if (e.target === giDlg) giDlg.close(); });
  $('#giSave').addEventListener('click', function () {
    var t = $('#giTitle').value.trim().slice(0, 40);
    if (!t) { giErr('Le nom ne peut pas être vide.'); return; }
    giUpdate({ title: t });
  });
  $('#giPick').addEventListener('click', function () { $('#giFile').click(); });
  $('#giDel').addEventListener('click', function () { giUpdate({ photo: firebase.firestore.FieldValue.delete() }); });
  $('#giFile').addEventListener('change', function (e) {
    var f = e.target.files && e.target.files[0]; e.target.value = '';
    if (!f) return;
    fileToPhoto(f).then(function (d) { giUpdate({ photo: d }); }, function () { giErr('Image illisible.'); });
  });
  $('#gaGo').addEventListener('click', async function () {
    var g = curGroup(); if (!g) return;
    var btn = this, names = [];
    $('#gaNames').value.toLowerCase().split(/[\s,;]+/).forEach(function (n) {
      n = n.replace(/^@/, ''); if (n && n !== state.username && names.indexOf(n) === -1) names.push(n);
    });
    if (!names.length) { giErr('Écris au moins un nom d’utilisateur.'); return; }
    var bad = names.filter(function (n) { return !NAME_RE.test(n); });
    if (bad.length) { giErr('Nom d’utilisateur invalide : ' + bad[0]); return; }
    btn.disabled = true; giErr('');
    try {
      var snaps = await Promise.all(names.map(function (n) { return fs.collection('usernames').doc(n).get(); }));
      var upd = {}, add = [], cur = g.members || [];
      for (var i = 0; i < snaps.length; i++) {
        if (!snaps[i].exists) { giErr('Aucun utilisateur ne s’appelle « ' + names[i] + ' ».'); btn.disabled = false; return; }
        var u = snaps[i].data().uid;
        if (cur.indexOf(u) === -1 && add.indexOf(u) === -1) { add.push(u); upd['names.' + u] = names[i]; }
      }
      if (!add.length) { giErr('Ces personnes sont déjà dans le groupe.'); btn.disabled = false; return; }
      if (cur.length + add.length > 30) { giErr('30 personnes maximum : il reste ' + (30 - cur.length) + ' place(s).'); btn.disabled = false; return; }
      upd.members = firebase.firestore.FieldValue.arrayUnion.apply(null, add);
      await fs.collection('chats').doc(g.id).update(upd);
      $('#gaNames').value = '';
    } catch (e) { giErr('Ajout impossible (connexion ou règles Firestore).'); }
    btn.disabled = false;
  });

