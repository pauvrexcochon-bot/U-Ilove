/* U&I — js/app/01-base.js
   Config, constantes, utilitaires, envoi de fichiers (Cloudinary)
   (fait partie de l’appli : assemblée par js/boot/loader.js dans une seule fermeture) */
  var CFG = window.APP_CONFIG;
  var HEART = '<svg viewBox="0 0 24 24" width="14" height="14" aria-hidden="true"><path fill="currentColor" d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg>';
  var NAME_RE = /^[a-z0-9._-]{3,20}$/;

  var $ = function (s) { return document.querySelector(s); };
  var loginEl = $('#login'), appEl = $('#app'), viewList = $('#viewList'), viewChat = $('#viewChat');
  var authForm = $('#authForm'), authBtn = $('#authBtn'), authErr = $('#authErr');
  var tabLogin = $('#tabLogin'), tabSignup = $('#tabSignup');
  var logEl = $('#log'), ta = $('#msg'), sendBtn = $('#send'), form = $('#composer');
  var jumpBtn = $('#jump'), errEl = $('#err');
  var chatsEl = $('#chats'), newErr = $('#newErr');
  var HOLD = { shown: null, t0: 0, down: false, slide: false, hot: null, id: null }, RXSIG = {};
  var statusEl = $('#status'), statusText = $('#statusText');
  var BASE_TITLE = document.title;

  function setAuthErr(t) { authErr.textContent = t; authErr.hidden = !t; }

  var configured = CFG && CFG.firebase && CFG.firebase.apiKey && CFG.firebase.apiKey.indexOf('COLLE') !== 0;
  if (!configured) {
    loginEl.hidden = false;
    authBtn.disabled = true;
    setAuthErr('Configuration manquante : ouvre index.html et remplace les valeurs « COLLE_ICI » par celles de ton projet Firebase (voir LISEZMOI.md).');
    return;
  }

  firebase.initializeApp(CFG.firebase);
  var auth = firebase.auth();
  var fs = firebase.firestore();
  var IS_IOS = /iP(hone|ad|od)/.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
  if (!IS_IOS) { try { fs.enablePersistence({ synchronizeTabs: true }).catch(function () {}); } catch (e) {} }

  var state = {
    me: null, username: '', nick: '', mode: 'login', view: 'list',
    chats: [], chatsById: {}, chatsLoaded: false,
    chat: null, msgs: [], loaded: false, dead: null,
    open: new Set(), confirm: null, picker: null, editing: null, editDraft: '', otherPres: null, stick: true, unread: 0
  };
  var unsubChats = null, unsubMsgs = null, unsubPres = null, hbTimer = null, stTimer = null;
  var busy = new Set();

  /* ---------- utilitaires ---------- */
  function store(key, val) {
    try {
      if (val === undefined) return localStorage.getItem(key);
      if (val === null) localStorage.removeItem(key); else localStorage.setItem(key, val);
    } catch (e) {}
    return null;
  }
  function el(tag, cls, text) {
    var n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text != null) n.textContent = text;
    return n;
  }
  function chatOf(id) { return state.chats.filter(function (x) { return x.id === id; })[0] || null; }
  function nickOf(c, uid) { return (c && c.nicks && typeof c.nicks[uid] === 'string' && c.nicks[uid]) || ''; }
  function myName() { return state.nick || state.username; }
  /* ---------- Cloudinary : vocaux, musiques et photos sont envoy\u00e9s l\u00e0-bas, Firestore ne garde que le lien ---------- */
  var CLD_NAME = 'hjnf54dr', CLD_PRESET = 'uandi_upload', CLD_BASE = 'https://res.cloudinary.com/' + CLD_NAME + '/';
  /* Photos et vocaux sont hébergés sur Cloudinary (nécessite la version de validMedia qui accepte https://res.cloudinary.com/hjnf54dr/).
     Si les règles refusent le lien, l'app renvoie automatiquement la version intégrée (data:). */
  var CLD_MEDIA = true;
  function mediaUp(x) { return CLD_MEDIA ? cloudUp(x) : Promise.resolve(null); }
  var CLD_ERR = '';
  async function cloudUp(dataUrl, kind) {
    var size = dataUrl && (dataUrl.size || dataUrl.length) || 0;
    var ms = Math.max(30000, Math.round(size / 25000) * 1000);
    CLD_ERR = '';
    for (var att = 0; att < 3; att++) {
      var ctl = window.AbortController ? new AbortController() : null, tm = ctl ? setTimeout(function () { ctl.abort(); }, ms) : 0;
      try {
        var fd = new FormData();
        fd.append('file', dataUrl);
        fd.append('upload_preset', CLD_PRESET);
        var r = await fetch('https://api.cloudinary.com/v1_1/' + CLD_NAME + '/' + (kind || 'auto') + '/upload', { method: 'POST', body: fd, signal: ctl ? ctl.signal : undefined });
        var j = await r.json();
        clearTimeout(tm);
        if (j && typeof j.secure_url === 'string' && j.secure_url.indexOf(CLD_BASE) === 0) return j.secure_url;
        CLD_ERR = (j && j.error && j.error.message) || ('HTTP ' + r.status);
        if (r.status >= 400 && r.status < 500) break;   /* refus définitif : inutile de réessayer */
      } catch (e) {
        clearTimeout(tm);
        CLD_ERR = (e && e.name === 'AbortError') ? 'délai dépassé' : 'réseau';
      }
      if (att < 2) await new Promise(function (ok) { setTimeout(ok, 1200 * (att + 1)); });
    }
    return null;
  }
  var SYS = '\u2063';
  function isSys(m) { return !!m && typeof m.text === 'string' && m.text.charAt(0) === SYS; }
  function cap(n) { n = String(n || ''); return n ? n.charAt(0).toUpperCase() + n.slice(1) : '?'; }
  function paintAvatar(node, name) {
    var h = 0, s = String(name || '');
    for (var i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) % 360;
    node.style.background = 'hsl(' + h + ' 38% 42%)';
    node.textContent = cap(s).charAt(0);
  }
  var timeFmt = new Intl.DateTimeFormat('fr-FR', { hour: '2-digit', minute: '2-digit' });
  var dayFmt = new Intl.DateTimeFormat('fr-FR', { weekday: 'long', day: 'numeric', month: 'long' });
  var shortFmt = new Intl.DateTimeFormat('fr-FR', { day: '2-digit', month: '2-digit' });
  function dayLabel(ts) {
    var d = new Date(ts), now = new Date();
    var y = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 1);
    if (d.toDateString() === now.toDateString()) return 'Aujourd’hui';
    if (d.toDateString() === y.toDateString()) return 'Hier';
    return dayFmt.format(d);
  }
  function listTime(ts) {
    var d = new Date(ts), now = new Date();
    var y = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 1);
    if (d.toDateString() === now.toDateString()) return timeFmt.format(d);
    if (d.toDateString() === y.toDateString()) return 'Hier';
    return shortFmt.format(d);
  }
  function nearBottom() { return logEl.scrollHeight - logEl.scrollTop - logEl.clientHeight < 90; }
  var SCROLL_WARM = false;
  function scrollBottom() {
    var d = logEl.scrollHeight - logEl.clientHeight - logEl.scrollTop;
    var rm = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (SCROLL_WARM && !rm && d > 2 && d < 700 && logEl.scrollTo) logEl.scrollTo({ top: logEl.scrollHeight, behavior: 'smooth' });
    else logEl.scrollTop = logEl.scrollHeight;
    jumpBtn.hidden = true;
  }
  function showErr(t) { errEl.textContent = t; errEl.hidden = !t; }
  var MIC_HELP = 'Micro bloqué. Si Android affiche « Ce site ne peut pas demander votre autorisation », ferme les bulles et fenêtres flottantes (Messenger, enregistreur d’écran, filtre de lumière bleue, fenêtre flottante du navigateur), puis réessaie.';
  function getMic(constraints) {
    return navigator.mediaDevices.getUserMedia(constraints).catch(function (e) {
      if (e && (e.name === 'NotAllowedError' || e.name === 'SecurityError' || e.name === 'AbortError')) {
        return new Promise(function (r) { setTimeout(r, 700); }).then(function () { return navigator.mediaDevices.getUserMedia(constraints); });
      }
      throw e;
    });
  }
  function showNewErr(t) { newErr.textContent = t; newErr.hidden = !t; }
  function likedBy(m) {
    var l = m.likes;
    if (!l || typeof l !== 'object') return [];
    return Object.keys(l).filter(function (k) { return l[k] === true; });
  }
  function SV() { return firebase.firestore.FieldValue.serverTimestamp(); }
  function chatIdFor(a, b) { return [a, b].sort().join('_'); }

