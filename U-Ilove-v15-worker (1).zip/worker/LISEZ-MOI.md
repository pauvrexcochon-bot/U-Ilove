# Activer l'e-mail de récupération (Worker « ui-recovery »)

Le site ne peut pas envoyer d'e-mail tout seul : un petit serveur (Worker Cloudflare, comme `ui-push`) envoie les codes et change le mot de passe. Il faut le créer une seule fois (environ 15 minutes, gratuit).

Tant que ce n'est pas fait, le site fonctionne comme avant : la fonction reste simplement cachée.

## 1. Brevo (envoi des e-mails, gratuit : 300 e-mails par jour)

1. Crée un compte sur brevo.com.
2. **Senders, domains & dedicated IPs → Senders → Add a sender** : mets ton adresse e-mail et clique sur le lien de validation reçu. Cette adresse sera l'expéditeur (`MAIL_FROM`).
3. **SMTP & API → API keys → Generate a new API key** : copie la clé (`BREVO_API_KEY`).

Les messages envoyés depuis une adresse Gmail peuvent arriver dans les courriers indésirables. Avec une adresse sur ton propre domaine, c'est mieux.

## 2. Clé Firebase (pour pouvoir changer un mot de passe)

1. Console Firebase → ⚙ **Paramètres du projet** → **Comptes de service**.
2. **Générer une nouvelle clé privée** : un fichier `.json` se télécharge.
3. Ce fichier est un secret : ne le mets jamais sur GitHub ni dans un message. Supprime-le de ton ordinateur après l'étape 3.

## 3. Cloudflare

1. **Workers & Pages → Create → Create Worker**, nom : `ui-recovery`, puis **Deploy**.
2. **Edit code** : efface tout, colle le contenu de `worker/ui-recovery.js`, puis **Deploy**.
3. **Storage & databases → KV → Create** un espace nommé `ui-recovery`.
4. Dans le Worker : **Settings → Bindings → Add → KV namespace**, nom de variable **`RECOVERY`**, choisis l'espace créé.
5. **Settings → Variables and Secrets → Add** :

| Nom | Type | Valeur |
|---|---|---|
| `FIREBASE_PROJECT_ID` | Texte | `u-i-love` |
| `EMAIL_DOMAIN` | Texte | `u-and-i.app` |
| `MAIL_FROM` | Texte | l'adresse validée dans Brevo |
| `BREVO_API_KEY` | Secret | la clé Brevo |
| `PEPPER` | Secret | une longue phrase au hasard (20 caractères ou plus) |
| `GOOGLE_SERVICE_ACCOUNT` | Secret | tout le contenu du fichier `.json`, collé tel quel |

6. Copie l'adresse du Worker (du type `https://ui-recovery.xxxx.workers.dev`).

## 4. Dans le site

Ouvre `js/config.js` et remplace `COLLE-ICI-L-ADRESSE-DU-WORKER-ui-recovery` par l'adresse du Worker. Teste d'abord sur `http://localhost:8000`, puis envoie les fichiers sur GitHub (la version est déjà passée à 15).

## Comment ça marche pour les utilisateurs

- Après connexion, si le compte n'a pas d'e-mail de récupération, une fenêtre le propose : on saisit l'e-mail, on reçoit un code à 6 chiffres, on le confirme. « Plus tard » repousse la demande de 3 jours.
- Même chose dans **Réglages → E-mail de récupération** (ajouter, changer, retirer).
- **Mot de passe oublié ?** : nom d'utilisateur, code reçu par e-mail, nouveau mot de passe. La personne est ensuite connectée directement.
- L'ancien code de récupération reste disponible via « J'ai un code de récupération ».

## Sécurité

- Un code vaut 10 minutes, ne marche qu'une fois et accepte 5 essais.
- Un nouveau code ne peut être demandé qu'une fois par minute.
- Les codes sont stockés hachés, jamais en clair ; les e-mails ne sont pas dans Firestore.
- La réponse est la même que le nom d'utilisateur existe ou non.
- Après une réinitialisation, les autres appareils connectés sont déconnectés.
