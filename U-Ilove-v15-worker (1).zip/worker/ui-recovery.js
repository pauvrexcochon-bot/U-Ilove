/* U&I — worker/ui-recovery.js
   Worker Cloudflare « ui-recovery » : e-mail de récupération + mot de passe oublié par code.
   Ce fichier ne s'exécute PAS sur le site : on le colle dans Cloudflare (voir worker/LISEZ-MOI.md).

   Variables / secrets à créer dans Cloudflare :
     RECOVERY               (liaison KV)     stocke e-mails et codes
     FIREBASE_PROJECT_ID    (variable)       u-i-love
     EMAIL_DOMAIN           (variable)       u-and-i.app
     MAIL_FROM              (variable)       l'adresse expéditrice validée dans Brevo
     BREVO_API_KEY          (secret)         clé API Brevo
     PEPPER                 (secret)         une longue phrase au hasard
     GOOGLE_SERVICE_ACCOUNT (secret)         le JSON de compte de service Firebase (collé tel quel) */

const CODE_TTL = 10 * 60;      /* un code vit 10 minutes */
const MAX_TRIES = 5;           /* 5 essais par code */
const COOLDOWN = 60;           /* 1 code par minute au maximum */
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const NAME_RE = /^[a-z0-9._-]{3,20}$/;

const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'Authorization, Content-Type',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  'Access-Control-Max-Age': '86400'
};
function json(obj, status) {
  return new Response(JSON.stringify(obj), { status: status || 200, headers: Object.assign({ 'Content-Type': 'application/json' }, CORS) });
}

/* ---------- outils ---------- */
const enc = new TextEncoder();
function b64urlToBytes(s) {
  s = s.replace(/-/g, '+').replace(/_/g, '/'); while (s.length % 4) s += '=';
  return Uint8Array.from(atob(s), c => c.charCodeAt(0));
}
function bytesToB64url(buf) {
  let s = ''; const u = new Uint8Array(buf);
  for (let i = 0; i < u.length; i++) s += String.fromCharCode(u[i]);
  return btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}
async function sha256hex(text) {
  const d = await crypto.subtle.digest('SHA-256', enc.encode(text));
  return Array.from(new Uint8Array(d)).map(b => b.toString(16).padStart(2, '0')).join('');
}
function newCode() {
  const r = crypto.getRandomValues(new Uint32Array(1))[0] % 1000000;
  return String(r).padStart(6, '0');
}
function mask(email) {
  const [u, d] = email.split('@');
  return (u.length <= 2 ? u[0] : u.slice(0, 2)) + '***@' + d;
}
function sameHash(a, b) {
  if (a.length !== b.length) return false;
  let x = 0; for (let i = 0; i < a.length; i++) x |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return x === 0;
}

/* ---------- vérification du jeton Firebase de la personne connectée ---------- */
let jwkCache = { keys: null, t: 0 };
async function getJwks() {
  if (jwkCache.keys && Date.now() - jwkCache.t < 3600e3) return jwkCache.keys;
  const r = await fetch('https://www.googleapis.com/service_accounts/v1/jwk/securetoken@system.gserviceaccount.com');
  if (!r.ok) throw new Error('jwks');
  jwkCache = { keys: (await r.json()).keys, t: Date.now() };
  return jwkCache.keys;
}
async function verifyUser(request, env) {
  const h = request.headers.get('Authorization') || '';
  const tok = h.startsWith('Bearer ') ? h.slice(7) : '';
  const parts = tok.split('.');
  if (parts.length !== 3) return null;
  try {
    const head = JSON.parse(new TextDecoder().decode(b64urlToBytes(parts[0])));
    const pay = JSON.parse(new TextDecoder().decode(b64urlToBytes(parts[1])));
    if (head.alg !== 'RS256') return null;
    const jwk = (await getJwks()).find(k => k.kid === head.kid);
    if (!jwk) return null;
    const key = await crypto.subtle.importKey('jwk', jwk, { name: 'RSASSA-PKCS1-v1_5', hash: 'SHA-256' }, false, ['verify']);
    const ok = await crypto.subtle.verify('RSASSA-PKCS1-v1_5', key, b64urlToBytes(parts[2]), enc.encode(parts[0] + '.' + parts[1]));
    if (!ok) return null;
    const now = Math.floor(Date.now() / 1000);
    if (pay.aud !== env.FIREBASE_PROJECT_ID || pay.iss !== 'https://securetoken.google.com/' + env.FIREBASE_PROJECT_ID) return null;
    if (!pay.sub || pay.exp < now || pay.iat > now + 300) return null;
    const mail = String(pay.email || '');
    const suffix = '@' + env.EMAIL_DOMAIN;
    if (!mail.endsWith(suffix)) return null;
    const username = mail.slice(0, -suffix.length);
    if (!NAME_RE.test(username)) return null;
    return { uid: pay.sub, username: username };
  } catch (e) { return null; }
}

/* ---------- accès administrateur Firebase (pour changer un mot de passe) ---------- */
let adminTok = { v: null, exp: 0 };
async function adminToken(env) {
  if (adminTok.v && Date.now() < adminTok.exp - 60e3) return adminTok.v;
  const sa = JSON.parse(env.GOOGLE_SERVICE_ACCOUNT);
  const now = Math.floor(Date.now() / 1000);
  const head = bytesToB64url(enc.encode(JSON.stringify({ alg: 'RS256', typ: 'JWT' })));
  const claim = bytesToB64url(enc.encode(JSON.stringify({
    iss: sa.client_email, scope: 'https://www.googleapis.com/auth/cloud-platform',
    aud: 'https://oauth2.googleapis.com/token', iat: now, exp: now + 3600
  })));
  const pem = sa.private_key.replace(/-----[^-]+-----/g, '').replace(/\s+/g, '');
  const der = Uint8Array.from(atob(pem), c => c.charCodeAt(0));
  const key = await crypto.subtle.importKey('pkcs8', der, { name: 'RSASSA-PKCS1-v1_5', hash: 'SHA-256' }, false, ['sign']);
  const sig = await crypto.subtle.sign('RSASSA-PKCS1-v1_5', key, enc.encode(head + '.' + claim));
  const r = await fetch('https://oauth2.googleapis.com/token', {
    method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: 'grant_type=' + encodeURIComponent('urn:ietf:params:oauth:grant-type:jwt-bearer') + '&assertion=' + head + '.' + claim + '.' + bytesToB64url(sig)
  });
  if (!r.ok) throw new Error('admin token ' + r.status);
  const j = await r.json();
  adminTok = { v: j.access_token, exp: Date.now() + (j.expires_in || 3600) * 1000 };
  return adminTok.v;
}
async function setPassword(env, uid, password) {
  const tok = await adminToken(env);
  const r = await fetch('https://identitytoolkit.googleapis.com/v1/projects/' + env.FIREBASE_PROJECT_ID + '/accounts:update', {
    method: 'POST',
    headers: { Authorization: 'Bearer ' + tok, 'Content-Type': 'application/json' },
    /* validSince : les anciennes sessions (autres appareils) sont déconnectées */
    body: JSON.stringify({ localId: uid, password: password, validSince: String(Math.floor(Date.now() / 1000)) })
  });
  return r.ok;
}

/* ---------- envoi d'e-mail (Brevo) ---------- */
async function sendMail(env, to, subject, intro, code) {
  const html = '<div style="font-family:system-ui,Arial,sans-serif;max-width:420px;margin:auto;padding:24px;color:#3a1020">' +
    '<h2 style="margin:0 0 4px;color:#E0457B">U&amp;I</h2><p>' + intro + '</p>' +
    '<p style="font-size:32px;font-weight:700;letter-spacing:6px;margin:18px 0">' + code + '</p>' +
    '<p style="color:#777;font-size:13px">Ce code est valable 10 minutes. Si tu n’es pas à l’origine de cette demande, ignore ce message : rien ne sera modifié.</p></div>';
  const r = await fetch('https://api.brevo.com/v3/smtp/email', {
    method: 'POST',
    headers: { 'api-key': env.BREVO_API_KEY, 'Content-Type': 'application/json', Accept: 'application/json' },
    body: JSON.stringify({
      sender: { name: 'U&I', email: env.MAIL_FROM }, to: [{ email: to }], subject: subject,
      htmlContent: html, textContent: intro + '\n\nCode : ' + code + '\n\nValable 10 minutes.'
    })
  });
  return r.ok;
}

/* ---------- codes à usage unique (stockés hachés dans KV) ---------- */
async function cooldownHit(env, key) {
  if (await env.RECOVERY.get('cd:' + key)) return true;
  await env.RECOVERY.put('cd:' + key, '1', { expirationTtl: COOLDOWN });
  return false;
}
async function issue(env, kvKey, scope, extra) {
  const code = newCode();
  const rec = Object.assign({ h: await sha256hex(code + ':' + scope + ':' + env.PEPPER), tries: 0 }, extra || {});
  await env.RECOVERY.put(kvKey, JSON.stringify(rec), { expirationTtl: CODE_TTL });
  return code;
}
/* renvoie l'enregistrement si le code est bon ; sinon null (et compte l'essai) */
async function check(env, kvKey, scope, code) {
  const raw = await env.RECOVERY.get(kvKey);
  if (!raw) return null;
  const rec = JSON.parse(raw);
  if (rec.tries >= MAX_TRIES) { await env.RECOVERY.delete(kvKey); return null; }
  const h = await sha256hex(String(code || '').replace(/\D/g, '') + ':' + scope + ':' + env.PEPPER);
  if (sameHash(h, rec.h)) return rec;
  rec.tries++;
  await env.RECOVERY.put(kvKey, JSON.stringify(rec), { expirationTtl: CODE_TTL });
  return null;
}

/* ---------- routes ---------- */
export default {
  async fetch(request, env) {
    if (request.method === 'OPTIONS') return new Response(null, { status: 204, headers: CORS });
    const path = new URL(request.url).pathname.replace(/\/+$/, '');
    let body = {};
    if (request.method === 'POST') { try { body = await request.json(); } catch (e) { return json({ error: 'bad-json' }, 400); } }

    try {
      /* --- e-mail de récupération (connecté) --- */
      if (path === '/email/status' && request.method === 'GET') {
        const u = await verifyUser(request, env); if (!u) return json({ error: 'auth' }, 401);
        const raw = await env.RECOVERY.get('uid:' + u.uid);
        return json({ has: !!raw, masked: raw ? mask(JSON.parse(raw).email) : '' });
      }
      if (path === '/email/start') {
        const u = await verifyUser(request, env); if (!u) return json({ error: 'auth' }, 401);
        const email = String(body.email || '').trim().toLowerCase();
        if (!EMAIL_RE.test(email) || email.length > 120) return json({ error: 'bad-email' }, 400);
        if (await cooldownHit(env, 'es:' + u.uid)) return json({ error: 'wait' }, 429);
        const code = await issue(env, 'pend:' + u.uid, 'pend:' + u.uid, { email: email });
        const sent = await sendMail(env, email, 'Ton code U&I : ' + code, 'Voici le code pour confirmer ton e-mail de récupération sur U&amp;I.', code);
        return sent ? json({ ok: true }) : json({ error: 'mail' }, 502);
      }
      if (path === '/email/confirm') {
        const u = await verifyUser(request, env); if (!u) return json({ error: 'auth' }, 401);
        const rec = await check(env, 'pend:' + u.uid, 'pend:' + u.uid, body.code);
        if (!rec) return json({ error: 'bad-code' }, 400);
        const old = await env.RECOVERY.get('uid:' + u.uid);
        await env.RECOVERY.put('mail:' + u.username, JSON.stringify({ uid: u.uid, email: rec.email }));
        await env.RECOVERY.put('uid:' + u.uid, JSON.stringify({ username: u.username, email: rec.email }));
        await env.RECOVERY.delete('pend:' + u.uid);
        return json({ ok: true, masked: mask(rec.email), replaced: !!old });
      }
      if (path === '/email/remove') {
        const u = await verifyUser(request, env); if (!u) return json({ error: 'auth' }, 401);
        await env.RECOVERY.delete('mail:' + u.username);
        await env.RECOVERY.delete('uid:' + u.uid);
        return json({ ok: true });
      }

      /* --- mot de passe oublié (personne non connectée) --- */
      if (path === '/forgot/start') {
        const name = String(body.username || '').trim().toLowerCase().replace(/\s+/g, '');
        if (!NAME_RE.test(name)) return json({ ok: true });                 /* réponse identique : on ne révèle rien */
        const raw = await env.RECOVERY.get('mail:' + name);
        if (raw && !(await cooldownHit(env, 'fs:' + name))) {
          const rec = JSON.parse(raw);
          const code = await issue(env, 'rst:' + name, 'rst:' + name, { uid: rec.uid });
          await sendMail(env, rec.email, 'Ton code U&I : ' + code, 'Voici ton code pour choisir un nouveau mot de passe sur U&amp;I.', code);
        }
        return json({ ok: true });
      }
      if (path === '/forgot/reset') {
        const name = String(body.username || '').trim().toLowerCase().replace(/\s+/g, '');
        const pass = String(body.password || '');
        if (!NAME_RE.test(name)) return json({ error: 'bad-code' }, 400);
        if (pass.length < 6 || pass.length > 128) return json({ error: 'weak' }, 400);
        const rec = await check(env, 'rst:' + name, 'rst:' + name, body.code);
        if (!rec) return json({ error: 'bad-code' }, 400);
        if (!(await setPassword(env, rec.uid, pass))) return json({ error: 'admin' }, 502);
        await env.RECOVERY.delete('rst:' + name);
        return json({ ok: true });
      }
      return json({ error: 'not-found' }, 404);
    } catch (e) {
      return json({ error: 'server' }, 500);
    }
  }
};
